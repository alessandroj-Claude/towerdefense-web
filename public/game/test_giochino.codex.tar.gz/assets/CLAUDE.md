# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Session setup

Activate `/caveman ultra` mode at the start of every session in this project.

### Stato operativo corrente (2026-05-05)

- Milestone attiva: **v7.4 web deployment** (in corso).
- Frontend pubblico su Vercel: `https://towerdefense-cj.online` (repo `towerdefense-web`).
- Backend pubblico su Render: `https://tower-defense-cj.onrender.com`.
- Priorità tecnica corrente: chiudere il loop web auth/save/load su backend cloud (niente fallback locale involontario).

Quando si eseguono comandi Bash con python: impostare **sempre** il parametro `timeout`. Non usare `run_in_background=True` su comandi bloccanti (mainloop, import pesanti) senza kill esplicito — i processi orfani consumano RAM illimitata.

**Token efficiency:** non rileggere file già letti nella stessa sessione. Usa `offset`/`limit` per file grandi. Dopo un'edit, rileggi solo le righe modificate.

Quando si entra in **plan mode**, invocare sempre `/superpowers` (es. `superpowers:systematic-debugging`, `superpowers:brainstorming`, ecc.) prima di qualsiasi altra azione.

---

## Repository

Architettura dettagliata + file tree: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)

---

## Progetto

[ask at the start of the session]

---

## Piano di implementazione

Metodologia: **Subagent-Driven Development** con **TDD** ma cercando di limitare il consumo di token, potenzialmente usando agenti con Haiku (4.5) se il task è semplice.
- Ogni task: subagente dedicato → scrivi test → FAIL → implementa → PASS → commit
- Dopo ogni task: spec + quality review **inline** (no subagent reviewer — troppo costoso)
- **Dopo ogni task completato:** aggiorna `[ ]` → `[x]` nel piano + commit + `git push origin main`
- **Fine di ogni piano:** aggiorna `docs/ARCHITECTURE.md` (file tree + moduli) + sezione "Versione corrente" qui sotto
- **Fine di ogni piano:** aggiorna la RUNTIME_VERSION in src/game.py
- **Build web hard rule:** non eseguire mai `python3 -m pygbag --build main.py` direttamente dalla root repo. Usa sempre `bash scripts/build_web_clean.sh`, che nasconde `towerdefense-web`, `.worktrees`, `.superpowers` e `screenshots` prima del packaging. Motivo: un build diretto dalla root puo` includere repo annidate/cache (`towerdefense-web/.next`, `node_modules`, artifact precedenti) e produrre artifact multi-GB o gonfiare la history Git della repo web.
- **Web artifact sanity check:** dopo ogni build web e prima di commit/push in `towerdefense-web`, verifica dimensioni con `du -sh build/web towerdefense-web/public/game towerdefense-web/.git` e `ls -lh towerdefense-web/public/game/test_giochino.codex.apk towerdefense-web/public/game/test_giochino.codex.tar.gz`. Se APK/TAR superano poche decine di MB, fermati e indaga prima di committare.

### Piano del piano
- **Inizio:** crea `docs/superpowers/plans/YYYY-MM-DD-vX.Y.md` + spec, committa, aggiorna "Versione corrente" qui sotto
- **Dopo ogni task:** marca `[x]` solo dopo spec ✅ + quality ✅ — commit+push — poi **chiedi permesso prima del task successivo**


### Versione corrente: v8.0

### Note tecniche — Web canvas rendering quality (HiDPI/Retina)

- **Problema noto:** su display Retina/HiDPI (DPR=2), il canvas pygame-wasm subisce upscaling CSS bilinear → testo sfocato.
- **Fix attuale (v7.6):** `image-rendering: pixelated; crisp-edges` in `towerdefense-web/public/game/index.html` su `canvas.emscripten`. Nearest-neighbor upscaling, leggibile ma "pixel art look".
- **Cosa NON funziona:** aumentare TILE (es. 64→96) aumenta risoluzione interna ma il canvas CSS shrinka proporzionalmente → tutto appare più piccolo. Non migliora la qualità percepita.
- **Fix vero futuro:** render nativo a DPR fisico — JS lato HTML imposta `canvas.width/height = fb * devicePixelRatio`, poi scala CSS a `1/DPR`. Lavoro non triviale su pygbag template. Da pianificare come task dedicato se la qualità UI diventa priorità.



### v7.3 — Consolidamento debug web locale (2026-05-01)

- Web runtime:
  - `main.py` separa avvio desktop/web (`asyncio.run(_run_web())` su emscripten).
  - Import esplicito `pygame` nel branch web per aiutare la risoluzione dipendenze pygbag.
- Compatibilità pygame/wasm:
  - fallback bootstrap pygame nei moduli core/renderer.
  - `src/game.py` usa init sicuro (`_safe_pygame_init`) invece di `pygame.init()` hard.
  - `from __future__ import annotations` aggiunto ai moduli con type hints pygame.
- API client web:
  - `src/config.py`: backend URL default web aggiornato a `http://127.0.0.1:9000`.
  - `src/api_client.py`: gestione risposta `platform.request` più robusta (`data`/`text`), parsing safer.
  - fallback emscripten senza `asyncio.to_thread`.
- Profili/login:
  - fallback locale (SQLite) se backend non raggiungibile in flow web (`exists/register/login`), per evitare blocco utente.
  - messaggi UI aggiornati per distinguere backend offline vs errori credenziali.
- Script debug:
  - `scripts/build_web_clean.sh` per build web pulita con esclusione cartelle “pesanti”.
  - `scripts/web_debug_loop.sh` unifica build + start web server + tentativo backend + check health.
  - reset cache build web a ogni run (`build/web-cache`) per ridurre falsi positivi da cache.
  - warning esplicito: evitare `?-i` in questo setup (può forzare `/cdn` locale non presente).
  - se backend manca (`backend/main.py` assente), loop continua in modalità fallback locale.

### TODO tecnico (post-v7.3)

- Ripristinare backend reale in questa worktree (cartella `backend/` attualmente assente), poi:
  - riallineare `scripts/web_debug_loop.sh` a backend obbligatorio (non solo fallback),
  - riverificare login/register/save/load via API end-to-end in web,
  - rimuovere o ridurre fallback locale nel path web una volta stabilizzata la connettività API.

---
