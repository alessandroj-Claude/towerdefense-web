#!/usr/bin/env bash
set -e
PYTHON_BIN="${KEYGEN_PYTHON:-python3}"

echo "Checking Python/Tk runtime..."
"$PYTHON_BIN" - <<'PY'
import sys
import tkinter
major = int(tkinter.TkVersion)
minor = int(round((tkinter.TkVersion - major) * 10))
print(f"Python: {sys.executable}")
print(f"Tk: {tkinter.TkVersion} / Tcl: {tkinter.TclVersion}")
if (major, minor) < (8, 6):
    raise SystemExit(
        "ERROR: Tk < 8.6 rilevato. Questo runtime produce spesso finestra bianca su macOS.\n"
        "Usa un Python con Tk 8.6+ e rilancia, ad esempio:\n"
        "  KEYGEN_PYTHON=/path/to/python3 bash build_keygen.sh"
    )
PY

echo "Installing dependencies..."
"$PYTHON_BIN" -m pip install -r requirements-build.txt --quiet
echo "Building DLCKeygen.app..."
"$PYTHON_BIN" -m PyInstaller -y --windowed \
  --name "DLCKeygen" \
  --hidden-import _tkinter \
  keygen_main.py
echo "Build complete: dist/DLCKeygen.app"
