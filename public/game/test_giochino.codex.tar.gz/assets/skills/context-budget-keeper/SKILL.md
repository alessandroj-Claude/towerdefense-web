---
name: context-budget-keeper
description: Riduce consumo token definendo budget per fase, selezionando solo file necessari e imponendo letture incrementali orientate al task.
---

# Scopo
Usa questa skill quando il task rischia di gonfiare il contesto (multi-file, multi-step, review ampie, piani lunghi).

# Obiettivo
1. leggere meno file possibile
2. evitare riletture inutili
3. mantenere continuita tra step con summary brevi

# Procedura

## 1. Definisci budget iniziale
- mappa task in fasi: discovery, modifica, verifica
- assegna budget token per fase
- segnala subito se il budget non basta

## 2. Seleziona contesto minimo
- leggi prima indici (`rg --files`, `rg -n`) poi file completi solo se indispensabili
- usa `sed -n start,endp` su porzioni mirate
- evita rilettura di file gia letti: riapri solo blocchi modificati

## 3. Applica regola delta-only
- ad ogni passaggio riporta solo cosa e cambiato
- evita riassunti completi ripetuti
- mantieni un mini ledger: file toccati, decisioni, test

## 4. Compressione finale
- output finale: risultato, file cambiati, test eseguiti, rischi residui
- niente narrativa lunga se non richiesta

# Trigger tipici
- "ottimizza token"
- "fai review struttura"
- task con molti documenti o piani in parallelo
