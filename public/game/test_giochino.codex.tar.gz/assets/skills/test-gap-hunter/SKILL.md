---
name: test-gap-hunter
description: Individua gap di test ad alto rischio e propone la minima suite aggiuntiva per proteggere regressioni reali.
---

# Scopo
Usa questa skill per trovare rapidamente aree vulnerabili non ben coperte dai test, con priorità sul rischio funzionale.

# Quando usarla
Usala se:
- hai fatto modifiche in aree sensibili
- vuoi hardening prima di merge/release
- sospetti regressioni non coperte

# Obiettivo
1. trovare gap ad alto impatto
2. proporre pochi test ad alto valore
3. ridurre rischio regressione con costo minimo

# Procedura

## 1. Mappa superfici toccate
- file modificati
- flussi critici collegati
- dipendenze indirette rilevanti

## 2. Confronta con test esistenti
- test presenti vicini al codice
- branch/edge non coperti
- contratti impliciti non verificati

## 3. Prioritizza gap
- impatto utente
- probabilità regressione
- costo di test

## 4. Proponi suite minima
- 1-5 test con obiettivo esplicito
- nomi test chiari
- comando pytest mirato

## 5. Valida
- esegui i test nuovi o candidati più utili
- segnala eventuali falsi positivi/fragilità

# Formato di output

## Gap prioritari
## Test proposti
## Comando minimo
## Esito validazione
## Rischi residui
## Confidenza

# Regole
- Non inseguire coverage % fine a sé stessa
- Preferisci test di comportamento, non implementazione
- Mantieni i test piccoli e stabili
