---
name: prompt-delta-logger
description: Riduce token nei report intermedi tracciando solo delta tecnici tra step consecutivi (file, test, decisioni, rischi).
---

# Scopo
Usa questa skill in task multi-step per evitare recap completi ad ogni aggiornamento.

# Regola base
Scrivi solo il delta rispetto allo step precedente.

# Formato delta consigliato

## Changed
- file nuovi/modificati
- edit significative

## Verified
- test/comandi eseguiti
- esito sintetico

## Decided
- decisioni tecniche prese ora

## Risk
- rischi residui aperti

# Linee guida
- niente riepilogo storico completo salvo richiesta esplicita
- max 3-6 righe per update intermedio
- nel messaggio finale puoi espandere solo se serve
