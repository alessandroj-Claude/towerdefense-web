---
name: parallel-plan-execution
description: Esegue task di piano in parallelo con subagenti, ownership disgiunta, verifica TDD e integrazione finale orientata al completamento.
---

# Scopo
Usa questa skill quando hai già un piano scritto e vuoi implementare task indipendenti in parallelo senza perdere controllo su qualità, integrazione e avanzamento piano.

# Quando usarla
Usala se:
- il piano è già formulato (`docs/superpowers/plans/...`)
- esistono task indipendenti o quasi-indipendenti
- puoi assegnare ownership file/moduli senza overlap
- l'esecuzione parallela riduce il tempo totale

Non usarla se:
- il task corrente è piccolo
- i task sono strettamente sequenziali
- c'è forte sovrapposizione sugli stessi file

# Obiettivo
Arrivare a:
1. decomposizione dei task parallelizzabili
2. assegnazione chiara ai subagenti
3. implementazione con TDD per task
4. validazione locale mirata
5. integrazione e aggiornamento piano secondo regole repo

# Procedura

## 1. Carica contesto piano
- apri piano e spec correnti
- identifica dipendenze: `A -> B`
- identifica task parallelizzabili: `A || B`

## 2. Definisci work package
Per ogni subagente definisci in modo esplicito:
- task id del piano
- obiettivo unico
- file/moduli consentiti (ownership)
- file/moduli da non toccare
- test minimi da scrivere/eseguire
- criterio di done

## 3. Esecuzione task (TDD)
Per ogni work package:
- scrivi/aggiorna test vicino al comportamento
- verifica FAIL
- implementa fix/feature minimo
- verifica PASS
- evita refactor fuori scope

## 4. Output standard subagente
Ogni subagente restituisce:

### Task coperto
- id task piano

### File modificati
- elenco sintetico

### Test
- test aggiunti/aggiornati
- comandi eseguiti
- esito

### Rischi
- regressioni o incertezze residue

### Prossima azione consigliata
- una sola azione

## 5. Integrazione agente principale
- deduplica modifiche
- risolvi conflitti tra approcci
- esegui validazione finale mirata (non necessariamente full suite)
- prepara decisione unica per il task

## 6. Aggiornamento piano (regole repo)
Dopo ogni task completato:
- aggiorna checkbox `[ ] -> [x]` nel piano worktree solo dopo test/spec/quality OK
- copia aggiornamento su `main`
- commit su entrambi
- `git push origin main`
- chiedi permesso prima del task successivo

A fine piano:
- esegui i passaggi di build/rilascio previsti in `AGENTS.md`
- aggiorna documentazione richiesta (`VERSION_HISTORY`, `ARCHITECTURE`, sezione versione corrente)

# Formato output finale
Rispondi con:

## Stato task piano
## Sintesi subagenti
## Integrazione finale
## Validazione
## Rischi / punti aperti
## Confidenza
## Prossimo passo consigliato

# Regole
- Non duplicare lavoro tra subagenti
- Non assegnare ownership sovrapposte
- Mantieni fix/feature minimi per task
- Nessuna dichiarazione di completamento senza evidenza test
- Se emergono conflitti tra risultati, dichiarali esplicitamente e riallinea prima di proseguire
