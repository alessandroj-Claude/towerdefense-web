---
name: targeted-test-runner
description: Seleziona subset pytest minimo ad alto valore in base ai file toccati, con fallback progressivo fino alla suite completa.
---

# Scopo
Usa questa skill per validare rapidamente modifiche locali senza lanciare sempre tutta la suite.

# Obiettivo
1. feedback rapido
2. copertura rischio adeguata al change set
3. escalation controllata verso full regression

# Procedura

## 1. Mappa file toccati -> test candidati
- `src/map.py` -> `tests/test_map.py`
- `src/enemy.py` -> `tests/test_enemy.py`, `tests/test_game.py`
- `src/tower.py` -> `tests/test_tower.py`, `tests/test_game.py`
- `src/wave.py` -> `tests/test_wave.py`, `tests/test_game.py`
- `src/game.py` -> `tests/test_game.py` + moduli correlati
- `src/ui.py` / `src/renderer.py` -> `tests/test_renderer.py`, `tests/test_game.py`
- `src/save.py` / `src/db.py` / `src/data_paths.py` -> `tests/test_save.py`
- `src/license.py` / `keygen_main.py` -> `tests/test_license.py`, `tests/test_keygen_main.py`

## 2. Esegui livelli di verifica
- L1: test file-specifici
- L2: integration vicine (`test_game.py`, `test_renderer.py`) se toccato wiring/runtime
- L3: `python3 -m pytest -v` prima di chiudere piano o release

## 3. Regole
- usa sempre `python3 -m pytest`, mai `pytest` bare
- se un test fallisce, non scalare di livello finche non e risolto
- documenta sempre il comando lanciato

# Output
- comando/i eseguiti
- motivazione scelta subset
- eventuale suggerimento di escalation L2/L3
