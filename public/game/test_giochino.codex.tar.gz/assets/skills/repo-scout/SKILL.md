---
name: repo-scout
description: Mappa rapidamente la codebase, trova entrypoint, test, configurazioni e punti di modifica rilevanti prima di proporre cambiamenti.
---

# Scopo
Usa questa skill quando devi capire una codebase in fretta prima di fare modifiche, review o debug.

# Quando usarla
Usala se:
- il repository è nuovo o poco familiare
- bisogna trovare dove vive una feature
- serve identificare entrypoint, moduli, config, test e dipendenze
- prima di proporre una modifica strutturale

# Obiettivo
Restituire una mappa operativa della repo, non una descrizione generica.

# Procedura

## 1. Identifica la struttura del progetto
- Individua package manager, workspace e monorepo config
- Cerca file come:
  - package.json
  - pnpm-workspace.yaml
  - turbo.json
  - nx.json
  - pyproject.toml
  - requirements.txt
  - Cargo.toml
  - go.mod
  - pom.xml
  - build.gradle
- Individua cartelle chiave:
  - src
  - app
  - packages
  - services
  - api
  - tests
  - docs
  - scripts

## 2. Trova gli entrypoint
- Identifica:
  - avvio app
  - router principali
  - handler API
  - job schedulati
  - command line entrypoint
- Segnala i file di bootstrap o wiring iniziale

## 3. Trova la configurazione
- Elenca:
  - file env di esempio
  - config runtime
  - feature flags
  - file CI
  - lint/format/test config
- Specifica quali config sembrano necessarie per sviluppare o testare localmente

## 4. Trova i test
- Individua framework di test
- Segnala:
  - dove sono i test unitari
  - dove sono i test integrazione/e2e
  - come lanciare solo i test pertinenti
- Se possibile, indica il comando minimo per validare una modifica locale

## 5. Mappa il punto richiesto
Se il task riguarda una feature o area specifica:
- individua i file direttamente coinvolti
- individua i file indirettamente coinvolti
- spiega il flusso: input -> elaborazione -> output

## 6. Evidenzia i rischi
Segnala:
- accoppiamenti forti
- cartelle legacy
- duplicazioni sospette
- moduli con naming ambiguo
- parti senza test

# Formato di output
Rispondi sempre con queste sezioni:

## Mappa rapida
- stack principale
- package manager / build system
- punti di ingresso
- cartelle chiave

## File più rilevanti
- file
- perché è importante

## Comandi utili
- install
- run/dev
- test
- lint/build

## Rischi / incertezze
- elenco sintetico

## Prossima azione consigliata
- la singola azione più utile per sbloccare il task

# Regole
- Non proporre refactor grandi in questa fase
- Non descrivere tutta la repo se non serve
- Preferisci evidenza concreta: file, comando, percorso
- Se mancano dettagli, dichiaralo chiaramente
