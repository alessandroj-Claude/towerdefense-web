---
name: balance-tuning
description: Bilancia parametri di gameplay (torri, nemici, economia, wave) con modifiche minime, evidenze misurabili e rischio regressioni controllato.
---

# Scopo
Usa questa skill per tuning numerico del gameplay senza alterare architettura o introdurre cambi strutturali non richiesti.

# Quando usarla
Usala se:
- il gioco risulta troppo facile/difficile
- una torre o nemico è palesemente sbilanciato
- reward/economia non sostengono la progressione
- wave curve ha picchi o buchi ingiustificati

# Obiettivo
1. definire problema di bilanciamento
2. proporre set minimo di parametri da ritoccare
3. validare con test/simulazioni rapide
4. evitare regressioni non volute

# Procedura

## 1. Definisci metrica target
- tempo medio sopravvivenza
- gold per wave
- tasso kill per tipo nemico
- costo/efficacia torri

## 2. Isola parametri candidati
- hp/speed/reward nemici
- danno/range/fire-rate/costo torri
- curva wave e scaling difficoltà
- costi upgrade/repair/sell

## 3. Applica tuning minimo
- cambia pochi parametri per iterazione
- mantieni traccia prima/dopo
- evita tuning contemporanei non correlati

## 4. Valida
- test unit esistenti rilevanti
- scenario breve riproducibile (early/mid/late)
- verifica che il problema iniziale migliori

## 5. Riassumi
- numeri modificati
- impatto osservato
- rischi aperti

# Formato di output

## Problema di bilanciamento
## Parametri modificati
## Evidenze prima/dopo
## Validazione minima
## Rischi
## Confidenza

# Regole
- Non fare refactor per tuning numerico
- Non cambiare più aree del necessario
- Se le evidenze sono deboli, dichiaralo chiaramente
