---
name: architecture-drift-check
description: Confronta codice reale e ARCHITECTURE.md, rileva drift documentale e propone aggiornamenti minimi allineati allo stato corrente.
---

# Scopo
Usa questa skill per mantenere allineata la documentazione architetturale con la codebase reale dopo feature, bugfix o refactor locali.

# Quando usarla
Usala se:
- hai finito task di piano
- hai introdotto nuovi moduli/flow/stati
- `docs/ARCHITECTURE.md` può essere diventato obsoleto

# Obiettivo
1. individuare divergenze doc vs codice
2. classificare drift critico/minore
3. proporre patch doc minima e precisa

# Procedura

## 1. Raccogli sorgenti verità
- moduli toccati e nuovi entrypoint
- stato corrente in `src/` e flussi runtime
- contenuto attuale di `docs/ARCHITECTURE.md`

## 2. Confronta e classifica drift
- file tree non aggiornato
- API/moduli descritti in modo incompleto
- comportamento runtime cambiato
- convenzioni obsolete

## 3. Proponi update minimo
- correggi solo sezioni divergenti
- mantieni struttura doc esistente
- evita prose generiche

## 4. Valida coerenza
- verifica riferimenti file/path
- allinea esempi comandi ai comandi reali repo

# Formato di output

## Drift rilevato
## Impatto
## Patch doc proposta
## Verifiche
## Rischi residui
## Confidenza

# Regole
- Non riscrivere l'intero documento senza necessità
- Preferisci cambi piccoli e verificabili
- Se una parte del codice resta incerta, dichiaralo
