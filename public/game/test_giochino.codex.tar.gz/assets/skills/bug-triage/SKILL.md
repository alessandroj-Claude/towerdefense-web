---
name: bug-triage
description: Riproduci un bug, individua la root cause, proponi il fix minimo e valida il rischio di regressioni.
---

# Scopo
Usa questa skill per gestire bug in modo rigoroso e ripetibile.

# Quando usarla
Usala se:
- c'è un errore riproducibile
- c'è un test che fallisce
- un comportamento è regressivo o incoerente
- bisogna capire la causa prima di modificare il codice

# Obiettivo
Arrivare a:
1. riproduzione
2. root cause probabile
3. fix minimo
4. validazione locale mirata
5. nota sui rischi

# Procedura

## 1. Definisci il bug
Raccogli:
- comportamento atteso
- comportamento osservato
- ambiente coinvolto
- input minimo che scatena il problema
- eventuale stack trace o messaggio di errore

Se mancano dettagli, inferisci dal codice e dai test esistenti senza inventare fatti.

## 2. Riproduci
- individua il comando o flusso minimo per riprodurre
- se esiste un test vicino al problema, usalo
- se non esiste, valuta un test mirato solo se utile a stabilizzare la diagnosi

## 3. Localizza la root cause
Cerca:
- mismatch tra contratto e implementazione
- validazioni mancanti
- errori di parsing / serializzazione
- problemi di async / race / stato condiviso
- branch logici non coperti
- assunzioni errate su null, tipo, ordine o formato

## 4. Proponi il fix minimo
Il fix deve:
- risolvere il bug specifico
- minimizzare superficie di impatto
- evitare refactor non necessari
- preservare comportamento compatibile dove possibile

## 5. Valida
Esegui o suggerisci:
- test più vicini al bug
- eventuale lint/typecheck minimo rilevante
- controllo dei casi limite adiacenti

## 6. Riassumi
Spiega:
- perché il bug avveniva
- cosa cambia il fix
- quali rischi residui rimangono

# Uso con subagenti
Se il task è abbastanza grande, suddividi così:

## subagente reproducer
Responsabilità:
- trovare la riproduzione minima
- raccogliere stack trace / test / log rilevanti

Output:
- comando o scenario minimo
- evidenza
- incertezze

## subagente root-cause
Responsabilità:
- analizzare i file coinvolti
- proporre 1-3 cause plausibili ordinate per probabilità

Output:
- file rilevanti
- ipotesi principale
- punti da verificare

## subagente validator
Responsabilità:
- controllare test esistenti
- stimare regressioni
- proporre validazione minima

Output:
- test da eseguire
- aree a rischio
- livello di fiducia

# Formato di output
Rispondi sempre con:

## Bug definito
## Riproduzione minima
## Root cause
## Fix minimo proposto
## Validazione
## Rischi / regressioni
## Confidenza

# Regole
- Non fare refactor ampi durante il triage
- Non dichiarare la root cause come certa se è solo probabile
- Se non puoi validare, dillo esplicitamente
- Preferisci fix piccoli, leggibili e verificabili
