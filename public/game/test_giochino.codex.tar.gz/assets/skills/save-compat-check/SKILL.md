---
name: save-compat-check
description: Verifica e protegge la compatibilità save/load tra versioni, con fallback espliciti, test mirati e piano di migrazione minimo.
---

# Scopo
Usa questa skill quando una modifica può impattare il formato di salvataggio o il comportamento di caricamento.

# Quando usarla
Usala se:
- tocchi `src/save.py` o strutture serializzate
- aggiungi/rimuovi campi nello stato gioco
- modifichi flussi profile/licenze/DLC persistiti
- devi garantire compatibilità tra versioni (es. `v3.0 -> v3.1`)

Non usarla se:
- il task non coinvolge persistenza
- cambi solo rendering/UI senza impatto su stato serializzato

# Obiettivo
Arrivare a:
1. mappa del formato attuale
2. analisi backward/forward compatibility
3. strategia di migrazione o fallback minima
4. test di compatibilità mirati
5. nota rischi residui

# Procedura

## 1. Mappa formato save
- individua path/file di save attivo
- elenca chiavi principali serializzate
- segnala invarianti obbligatori (tipi, range, presenza)

## 2. Confronta versioni
- identifica differenze schema tra baseline e modifica
- classifica impatto: compatibile, compatibile con default, breaking
- specifica casi legacy da supportare

## 3. Definisci strategia minima
- preferisci fallback semplici: default sicuri, coercion leggere, key optional
- evita migrazioni invasive se non necessarie
- documenta comportamento per save corrotti o incompleti

## 4. Valida con test mirati
- test load di save "vecchio" nel codice nuovo
- test round-trip save->load del formato corrente
- test di campi mancanti/malformati vicino ai casi reali

## 5. Riassumi decisione
- cosa resta compatibile
- cosa richiede fallback
- cosa (eventualmente) non è supportato e perché

# Formato di output

## Matrice compatibilità
## Differenze schema
## Strategia fallback/migrazione
## Test minimi
## Rischi aperti
## Confidenza

# Regole
- Non introdurre breaking change silenziosi
- Non cambiare formato senza test di compatibilità
- Se non puoi verificare un caso legacy, dichiaralo esplicitamente
- Preferisci fix piccoli e reversibili
