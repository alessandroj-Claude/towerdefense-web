---
name: wave-scenario-builder
description: Crea scenari di test riproducibili per ondate specifiche (boss/heavy/special), con fixture deterministiche e comandi pytest mirati.
---

# Scopo
Usa questa skill per costruire riproduzioni affidabili di comportamenti legati alle wave, evitando debug manuale rumoroso.

# Quando usarla
Usala se:
- devi verificare un comportamento a wave N specifica
- un bug compare solo con boss/heavy o combinazioni particolari
- servono test deterministici per spawn e progressione wave

# Obiettivo
1. definire scenario minimo riproducibile
2. fissare condizioni iniziali deterministiche
3. validare comportamento target con test mirato

# Procedura

## 1. Definisci scenario
- wave target e difficoltà
- composizione nemici attesa
- condizioni iniziali (gold, torri, vita, timer)

## 2. Rendi deterministico
- controlla random seed o stub dove necessario
- limita dipendenze da clock reale
- riduci superfici non necessarie al test

## 3. Implementa fixture/helper
- helper piccolo riusabile in `tests/`
- setup leggibile e isolato
- niente logica di produzione duplicata nel test

## 4. Scrivi test mirato
- una singola aspettativa chiara per test
- preferisci test brevi e locali
- includi edge case adiacente solo se utile

## 5. Valida
- esegui file o test case specifico
- conferma riproducibilità su run ripetute

# Formato di output

## Scenario
## Setup deterministico
## Test creati/aggiornati
## Comandi eseguiti
## Esito
## Rischi / limiti

# Regole
- Evita test fragili basati su timing non controllato
- Evita fixture monolitiche; privilegia composizione piccola
- Se la determinizzazione non è completa, dichiaralo
