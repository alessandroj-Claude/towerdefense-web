---
name: pygame-perf-pass
description: Individua hot path nel loop Pygame e propone micro-ottimizzazioni a basso rischio, validate con misure locali rapide.
---

# Scopo
Usa questa skill per migliorare frame-time e stabilità FPS senza refactor ampi.

# Quando usarla
Usala se:
- noti cali FPS o stutter
- il rendering cresce con numero entità
- update loop ha costo eccessivo

# Obiettivo
1. misurare il collo di bottiglia principale
2. applicare fix piccoli e locali
3. validare miglioramento con evidenza

# Procedura

## 1. Definisci sintomo e metrica
- scenario riproducibile (es. wave alta)
- metrica: ms/frame, FPS, funzione più costosa

## 2. Profilazione leggera
- identifica hot path in update/draw
- separa costo CPU logica vs rendering
- evita ottimizzazioni premature non misurate

## 3. Micro-fix mirati
- cache/calcolo ridondante
- riduzione allocazioni per frame
- early-return su oggetti non visibili/non attivi
- minimizzazione draw superflui

## 4. Validazione
- confronto prima/dopo sulla stessa scena
- controllo regressioni funzionali minime

# Formato di output

## Scenario misurato
## Hot path rilevati
## Micro-fix applicati
## Misure prima/dopo
## Rischi
## Confidenza

# Regole
- No refactor architetturali in questa fase
- No claim performance senza misura
- Mantieni leggibilità del codice
