---
name: plan-doc-sync
description: Sincronizza documentazione operativa di piano/versione tra AGENTS, CURRENT_VERSION, STATUS, ARCHITECTURE e VERSION_HISTORY con check deterministici.
---

# Scopo
Usa questa skill quando apri/chiudi piani o completi task che cambiano stato progetto.

# Obiettivo
1. evitare drift tra documenti core
2. mantenere un solo punto di verita per lo stato corrente
3. validare coerenza con controlli ripetibili

# Procedura

## 1. Aggiorna fonte primaria stato
- aggiorna `docs/superpowers/current/STATUS.md`
- aggiorna `docs/superpowers/current/CURRENT_VERSION`

## 2. Mantieni AGENTS snello
- in `AGENTS.md` lascia policy e riferimenti
- evita liste lunghe di stato volatile

## 3. Allinea documentazione tecnica
- aggiorna `docs/ARCHITECTURE.md` se cambia file tree/moduli/wiring
- aggiorna `docs/VERSION_HISTORY.md` a fine piano

## 4. Esegui check automatico
- lancia `bash scripts/check_doc_sync.sh`
- se fallisce, correggi subito prima di dichiarare task chiuso

# Output atteso
- elenco file aggiornati
- esito check sync
- eventuali mismatch rimasti e blocchi
