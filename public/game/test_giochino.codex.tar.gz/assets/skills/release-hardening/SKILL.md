---
name: release-hardening
description: Esegue una checklist di rilascio pre-build con verifiche tecniche, smoke test e criterio go/no-go basato su evidenze.
---

# Scopo
Usa questa skill alla chiusura di una milestone o bugfix prima di dichiarare il rilascio pronto.

# Quando usarla
Usala se:
- stai per eseguire build di release
- hai completato task di piano
- devi decidere go/no-go

# Obiettivo
1. verificare prerequisiti tecnici
2. eseguire controlli minimi obbligatori
3. produrre decisione go/no-go motivata

# Procedura

## 1. Verifica stato repo
- working tree e branch coerenti
- file di piano/spec/docs aggiornati se richiesto

## 2. Verifica qualità minima
- test mirati o suite richiesta da piano
- eventuali script build preliminari

## 3. Esegui build e smoke
- build app prevista
- smoke run essenziale (avvio, flusso base, feature critiche)

## 4. Verifica artefatti
- nome/path output attesi
- eventuale rinomina/versioning artefatto

## 5. Decisione
- GO se criteri soddisfatti
- NO-GO con blocchi espliciti

# Formato di output

## Checklist
## Evidenze
## Blocchi
## Decisione GO/NO-GO
## Prossima azione

# Regole
- Nessun "sembra ok" senza comando o evidenza
- Se non puoi eseguire una verifica, dichiaralo
- Non saltare smoke test su feature critiche
