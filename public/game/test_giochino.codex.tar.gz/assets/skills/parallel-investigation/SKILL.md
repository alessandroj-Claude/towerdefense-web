---
name: parallel-investigation
description: Orchestrazione di subagenti per esplorazione parallela, confronto ipotesi e sintesi finale orientata alla decisione.
---

# Scopo
Usa questa skill quando il problema può essere scomposto in filoni indipendenti e vale la pena delegare lavoro a più subagenti.

# Quando usarla
Usala se:
- devi esplorare aree diverse della codebase
- vuoi confrontare più ipotesi di root cause
- devi fare review multi-angolo (design, test, sicurezza, performance)
- il task è rumoroso e rischia di distrarre l'agente principale

Non usarla se:
- il task è piccolo
- il lavoro è fortemente sequenziale
- tutti avrebbero comunque bisogno degli stessi file e della stessa analisi

# Obiettivo
Fare emergere risultati complementari da più subagenti e sintetizzarli in una decisione unica.

# Ruoli suggeriti

## explorer
Cerca:
- entrypoint
- file coinvolti
- flusso applicativo
- configurazioni e test vicini

## hypothesis-checker
Cerca:
- possibili cause del problema
- assunzioni deboli
- branch o contratti sospetti

## validator
Cerca:
- test esistenti
- modi rapidi per verificare
- rischi di regressione
- effetti collaterali del fix

## reviewer
Cerca:
- leggibilità
- coerenza architetturale
- debito tecnico introdotto
- compatibilità con convenzioni del repo

# Istruzioni per l'agente principale

## 1. Decidi se delegare
Chiediti:
- il problema si divide in blocchi indipendenti?
- i subagenti possono lavorare con poca sovrapposizione?
- i risultati combinati aiuteranno una decisione migliore?

Se no, non usare subagenti.

## 2. Assegna compiti stretti
Ogni subagente deve avere:
- obiettivo unico
- area/file chiari
- formato di output obbligatorio

Evita richieste vaghe come:
- "analizza tutto"
- "capisci il problema"

Preferisci:
- "trova entrypoint e file coinvolti"
- "verifica le 3 cause più probabili"
- "identifica i test minimi da eseguire"

## 3. Richiedi output standard
Ogni subagente deve restituire:

### File rilevanti
- elenco sintetico

### Evidenze
- fatti osservati, non opinioni

### Conclusione
- ipotesi o risultato principale

### Incertezze
- cosa non è confermato

### Prossima azione consigliata
- una sola azione

## 4. Sintetizza
L'agente principale deve:
- eliminare duplicazioni
- evidenziare convergenze e conflitti
- decidere il piano finale
- dichiarare il livello di confidenza

# Formato di output finale
Rispondi con:

## Sintesi dei subagenti
- explorer
- hypothesis-checker
- validator
- reviewer

## Conclusione integrata
- la lettura più probabile del problema

## Piano consigliato
- passo 1
- passo 2
- passo 3

## Rischi / punti aperti
- elenco sintetico

## Confidenza
- bassa / media / alta

# Regole
- Non duplicare lavoro tra subagenti
- Non usare più subagenti del necessario
- Mantieni l'agente principale focalizzato sulla decisione
- Se i risultati sono in conflitto, dichiaralo apertamente
