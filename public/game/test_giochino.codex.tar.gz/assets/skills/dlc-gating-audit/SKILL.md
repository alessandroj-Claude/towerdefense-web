---
name: dlc-gating-audit
description: Audita i controlli DLC end-to-end per trovare bypass, inconsistenze tra UI e logica, e regressioni di sicurezza funzionale.
---

# Scopo
Usa questa skill per verificare che il gating DLC sia coerente in tutto il flusso: menu, validazione chiavi, attivazione, save/load e runtime.

# Quando usarla
Usala se:
- modifichi `src/license.py`, `src/game.py`, `src/ui.py`, `src/save.py`
- aggiungi nuovi DLC o contenuti gated
- noti mismatch tra stato unlock e feature disponibili

Non usarla se:
- il task non riguarda feature DLC/licenze

# Obiettivo
Arrivare a:
1. mappa completa feature -> controllo gating
2. verifica dei punti di enforcement
3. identificazione bypass plausibili
4. fix minimo di hardening
5. validazione regressioni principali

# Procedura

## 1. Mappa superfici DLC
- elenco DLC supportati
- elenco feature/blocchi gated per ciascun DLC
- punti di input chiave (UI, key entry, load stato)

## 2. Verifica enforcement
- controlla che ogni feature gated abbia check runtime reale
- verifica coerenza tra stato UI e stato logico
- confronta comportamento prima/dopo save/load

## 3. Cerca bypass
- path senza check
- flag impostabili indirettamente
- dipendenze deboli tra profilo e unlock
- condizioni race/order-sensitive

## 4. Definisci fix minimo
- rinforza i check nel punto più vicino all'uso della feature
- evita duplicazioni inutili di logica
- mantieni comportamento compatibile lato utente

## 5. Valida
- test positivi: DLC valido sblocca feature
- test negativi: DLC non valido non sblocca
- test persistenza: stato unlock coerente dopo restart/load

# Formato di output

## Mappa gating
## Evidenze enforcement
## Bypass plausibili
## Fix minimo proposto
## Validazione
## Rischi residui
## Confidenza

# Regole
- Non trattare la UI come controllo sufficiente: enforcement in logica dominio
- Non accettare stati "parzialmente sbloccati" senza definizione esplicita
- Se un bypass è solo ipotetico, etichettalo come tale
