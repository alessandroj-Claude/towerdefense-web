# Tower Defense — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a playable tower defense game for macOS using Python + Pygame, bundled as a `.app` with PyInstaller.

**Architecture:** Game logic (map, enemies, towers, waves, economy) is pure Python with no Pygame dependency, enabling full pytest coverage. Pygame is used only for rendering and input. `game.py` wires logic + renderer together in the game loop.

**Tech Stack:** Python 3.11+, Pygame 2.5, pytest, PyInstaller 6.x

---

## File Structure

```
Test_Giochino CODEX/
├── src/
│   ├── economy.py       # Gold, lives, score — pure Python
│   ├── map.py           # Procedural path generation — pure Python
│   ├── enemy.py         # Enemy classes + movement — pure Python
│   ├── tower.py         # Tower classes + targeting + projectiles — pure Python
│   ├── wave.py          # Wave manager + spawn schedule — pure Python
│   ├── renderer.py      # All pygame.draw calls (no logic)
│   ├── ui.py            # HUD + shop panel drawing + click detection
│   └── game.py          # Game loop, states, wires everything
├── tests/
│   ├── conftest.py      # Headless pygame init
│   ├── test_economy.py
│   ├── test_map.py
│   ├── test_enemy.py
│   ├── test_tower.py
│   └── test_wave.py
├── main.py              # Entry point: calls game.run()
├── requirements.txt
├── pytest.ini
└── build.sh
```

---

## Task 1: Project Setup

**Files:**
- Create: `requirements.txt`
- Create: `pytest.ini`
- Create: `tests/conftest.py`

- [ ] **Step 1: Create `requirements.txt`**

```
pygame==2.5.2
pyinstaller==6.6.0
pytest==8.2.0
```

- [ ] **Step 2: Install dependencies**

```bash
pip install -r requirements.txt
```

Expected: no errors. `python -c "import pygame; print(pygame.__version__)"` prints `2.5.2`.

- [ ] **Step 3: Create `pytest.ini`**

```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
```

- [ ] **Step 4: Create `tests/conftest.py`**

```python
import os
import pytest

@pytest.fixture(autouse=True, scope="session")
def headless_pygame():
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    os.environ["SDL_AUDIODRIVER"] = "dummy"
    import pygame
    pygame.init()
    pygame.display.set_mode((1, 1))
    yield
    pygame.quit()
```

- [ ] **Step 5: Verify pytest runs**

```bash
pytest --collect-only
```

Expected: `no tests ran` (no errors).

- [ ] **Step 6: Commit**

```bash
git init
git add requirements.txt pytest.ini tests/conftest.py
git commit -m "chore: project setup with pytest and headless pygame fixture"
```

---

## Task 2: Economy

**Files:**
- Create: `src/economy.py`
- Create: `tests/test_economy.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/test_economy.py
import pytest
from src.economy import Economy

def test_initial_state():
    e = Economy()
    assert e.gold == 150
    assert e.lives == 20
    assert e.score == 0

def test_can_afford_true():
    e = Economy()
    assert e.can_afford(150) is True

def test_can_afford_false():
    e = Economy()
    assert e.can_afford(151) is False

def test_spend_deducts_gold():
    e = Economy()
    e.spend(50)
    assert e.gold == 100

def test_spend_insufficient_raises():
    e = Economy()
    with pytest.raises(ValueError, match="Not enough gold"):
        e.spend(200)

def test_earn_adds_gold_and_score():
    e = Economy()
    e.earn(30)
    assert e.gold == 180
    assert e.score == 30

def test_lose_life_decrements():
    e = Economy()
    e.lose_life(3)
    assert e.lives == 17

def test_lose_life_clamps_to_zero():
    e = Economy()
    e.lose_life(100)
    assert e.lives == 0

def test_game_over_false_when_lives_remain():
    e = Economy()
    assert e.game_over is False

def test_game_over_true_when_no_lives():
    e = Economy()
    e.lose_life(20)
    assert e.game_over is True
```

- [ ] **Step 2: Run — verify FAIL**

```bash
pytest tests/test_economy.py -v
```

Expected: `ModuleNotFoundError: No module named 'src.economy'`

- [ ] **Step 3: Implement `src/economy.py`**

```python
class Economy:
    def __init__(self, gold: int = 150, lives: int = 20):
        self.gold = gold
        self.lives = lives
        self.score = 0

    def can_afford(self, cost: int) -> bool:
        return self.gold >= cost

    def spend(self, cost: int) -> None:
        if not self.can_afford(cost):
            raise ValueError("Not enough gold")
        self.gold -= cost

    def earn(self, amount: int) -> None:
        self.gold += amount
        self.score += amount

    def lose_life(self, amount: int = 1) -> None:
        self.lives = max(0, self.lives - amount)

    @property
    def game_over(self) -> bool:
        return self.lives <= 0
```

Also create `src/__init__.py` (empty).

- [ ] **Step 4: Run — verify PASS**

```bash
pytest tests/test_economy.py -v
```

Expected: all 10 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/__init__.py src/economy.py tests/test_economy.py
git commit -m "feat: add Economy with gold, lives, score"
```

---

## Task 3: Procedural Map

**Files:**
- Create: `src/map.py`
- Create: `tests/test_map.py`

Map is a `COLS × ROWS` grid. `path` is an ordered list of `(col, row)` tuples from col 0 to col COLS-1. `buildable` is the set of non-path cells.

- [ ] **Step 1: Write failing tests**

```python
# tests/test_map.py
import pytest
from src.map import GameMap

COLS, ROWS = 20, 12

@pytest.fixture
def game_map():
    return GameMap(cols=COLS, rows=ROWS, tile_size=48)

def test_path_starts_at_left(game_map):
    assert game_map.path[0][0] == 0

def test_path_ends_at_right(game_map):
    assert game_map.path[-1][0] == COLS - 1

def test_path_is_connected(game_map):
    for i in range(len(game_map.path) - 1):
        c1, r1 = game_map.path[i]
        c2, r2 = game_map.path[i + 1]
        assert abs(c2 - c1) + abs(r2 - r1) == 1, f"Gap between {(c1,r1)} and {(c2,r2)}"

def test_path_stays_in_bounds(game_map):
    for col, row in game_map.path:
        assert 0 <= col < COLS
        assert 0 <= row < ROWS

def test_no_duplicate_cells(game_map):
    assert len(game_map.path) == len(set(game_map.path))

def test_buildable_excludes_path(game_map):
    path_set = set(game_map.path)
    assert path_set.isdisjoint(game_map.buildable)

def test_buildable_covers_non_path_cells(game_map):
    path_set = set(game_map.path)
    all_cells = {(c, r) for c in range(COLS) for r in range(ROWS)}
    expected_buildable = all_cells - path_set
    assert game_map.buildable == expected_buildable

def test_is_path(game_map):
    c, r = game_map.path[0]
    assert game_map.is_path(c, r) is True

def test_is_buildable(game_map):
    path_set = set(game_map.path)
    non_path = next(
        (c, r) for c in range(COLS) for r in range(ROWS) if (c, r) not in path_set
    )
    assert game_map.is_buildable(*non_path) is True

def test_different_maps_on_each_call():
    maps = [GameMap(cols=COLS, rows=ROWS, tile_size=48).path for _ in range(10)]
    assert len(set(tuple(m) for m in maps)) > 1, "All maps identical — RNG broken"
```

- [ ] **Step 2: Run — verify FAIL**

```bash
pytest tests/test_map.py -v
```

Expected: `ModuleNotFoundError: No module named 'src.map'`

- [ ] **Step 3: Implement `src/map.py`**

```python
import random
from typing import List, Set, Tuple

Cell = Tuple[int, int]

class GameMap:
    def __init__(self, cols: int = 20, rows: int = 12, tile_size: int = 48):
        self.cols = cols
        self.rows = rows
        self.tile_size = tile_size
        self.path: List[Cell] = []
        self.buildable: Set[Cell] = set()
        self._generate()

    def _generate(self) -> None:
        while True:
            path = self._random_walk()
            if path:
                self.path = path
                all_cells = {(c, r) for c in range(self.cols) for r in range(self.rows)}
                self.buildable = all_cells - set(self.path)
                return

    def _random_walk(self) -> List[Cell]:
        row = random.randint(1, self.rows - 2)
        path: List[Cell] = [(0, row)]
        visited: Set[Cell] = {(0, row)}

        while path[-1][0] < self.cols - 1:
            col, row = path[-1]
            # Prefer moving right; allow up/down with 30% chance each
            choices = [(col + 1, row)]  # always can try right
            if row > 0:
                choices.append((col, row - 1))
            if row < self.rows - 1:
                choices.append((col, row + 1))

            random.shuffle(choices)
            # Weight: right gets 3 slots, up/down get 1 each
            weighted = [(col + 1, row)] * 3
            if row > 0:
                weighted.append((col, row - 1))
            if row < self.rows - 1:
                weighted.append((col, row + 1))

            moved = False
            random.shuffle(weighted)
            for nc, nr in weighted:
                if (nc, nr) not in visited and 0 <= nr < self.rows:
                    path.append((nc, nr))
                    visited.add((nc, nr))
                    moved = True
                    break

            if not moved:
                return []  # dead end — retry

        return path

    def is_path(self, col: int, row: int) -> bool:
        return (col, row) in set(self.path)

    def is_buildable(self, col: int, row: int) -> bool:
        return (col, row) in self.buildable

    def pixel_center(self, col: int, row: int) -> Tuple[int, int]:
        return (col * self.tile_size + self.tile_size // 2,
                row * self.tile_size + self.tile_size // 2)
```

- [ ] **Step 4: Run — verify PASS**

```bash
pytest tests/test_map.py -v
```

Expected: all 10 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/map.py tests/test_map.py
git commit -m "feat: procedural map generation with random walk"
```

---

## Task 4: Enemies

**Files:**
- Create: `src/enemy.py`
- Create: `tests/test_enemy.py`

Enemy tracks position via `progress` (float index into path list). `update(dt)` advances progress. At path end, `reached_end = True`.

- [ ] **Step 1: Write failing tests**

```python
# tests/test_enemy.py
import pytest
from src.enemy import Enemy, BasicEnemy, FastEnemy, TankEnemy, SwarmEnemy

PATH = [(i, 0) for i in range(10)]  # straight horizontal path, tile_size=48
TILE = 48

@pytest.fixture
def basic():
    return BasicEnemy(path=PATH, tile_size=TILE)

def test_initial_progress_is_zero(basic):
    assert basic.progress == 0.0

def test_initial_alive(basic):
    assert basic.alive is True

def test_initial_not_reached_end(basic):
    assert basic.reached_end is False

def test_take_damage_reduces_hp(basic):
    basic.take_damage(30)
    assert basic.hp == 70

def test_take_damage_kills_at_zero(basic):
    basic.take_damage(100)
    assert basic.alive is False

def test_take_damage_no_overkill(basic):
    basic.take_damage(200)
    assert basic.hp == 0

def test_update_advances_progress(basic):
    basic.update(dt=1.0)
    assert basic.progress > 0

def test_update_reaches_end():
    short_path = [(i, 0) for i in range(3)]
    e = BasicEnemy(path=short_path, tile_size=TILE)
    e.update(dt=100.0)
    assert e.reached_end is True

def test_pos_returns_pixel_coords(basic):
    px, py = basic.pos
    assert isinstance(px, (int, float))
    assert isinstance(py, (int, float))

def test_apply_slow_reduces_speed(basic):
    original = basic.speed
    basic.apply_slow(factor=0.5, duration=2.0)
    assert basic.speed == pytest.approx(original * 0.5)

def test_slow_expires_after_duration(basic):
    original = basic.speed
    basic.apply_slow(factor=0.5, duration=0.1)
    basic.update(dt=0.5)
    assert basic.speed == pytest.approx(original)

def test_tank_resists_slow():
    tank = TankEnemy(path=PATH, tile_size=TILE)
    original = tank.speed
    tank.apply_slow(factor=0.5, duration=2.0)
    # Tank: slow factor capped at 0.7 (30% resistance)
    assert tank.speed >= original * 0.7 - 0.001

def test_fast_enemy_faster_than_basic():
    fast = FastEnemy(path=PATH, tile_size=TILE)
    basic = BasicEnemy(path=PATH, tile_size=TILE)
    assert fast.speed > basic.speed

def test_enemy_types_have_correct_rewards():
    assert BasicEnemy(path=PATH, tile_size=TILE).reward == 10
    assert FastEnemy(path=PATH, tile_size=TILE).reward == 15
    assert TankEnemy(path=PATH, tile_size=TILE).reward == 40
    assert SwarmEnemy(path=PATH, tile_size=TILE).reward == 5
```

- [ ] **Step 2: Run — verify FAIL**

```bash
pytest tests/test_enemy.py -v
```

Expected: `ModuleNotFoundError: No module named 'src.enemy'`

- [ ] **Step 3: Implement `src/enemy.py`**

```python
from typing import List, Tuple
import math

Cell = Tuple[int, int]

class Enemy:
    BASE_SLOW_RESISTANCE = 0.0  # 0 = no resistance, 1 = full immunity

    def __init__(self, path: List[Cell], tile_size: int,
                 hp: int, speed: float, reward: int, lives_damage: int = 1):
        self.path = path
        self.tile_size = tile_size
        self.hp = hp
        self.max_hp = hp
        self._base_speed = speed
        self.speed = speed
        self.reward = reward
        self.lives_damage = lives_damage
        self.progress = 0.0
        self.alive = True
        self.reached_end = False
        self._slow_timer = 0.0
        self._slow_factor = 1.0

    def take_damage(self, amount: float) -> None:
        self.hp = max(0, self.hp - amount)
        if self.hp == 0:
            self.alive = False

    def apply_slow(self, factor: float, duration: float) -> None:
        effective = max(factor, self.BASE_SLOW_RESISTANCE)
        self._slow_factor = effective
        self._slow_timer = duration
        self.speed = self._base_speed * effective

    def update(self, dt: float) -> None:
        if not self.alive or self.reached_end:
            return

        if self._slow_timer > 0:
            self._slow_timer -= dt
            if self._slow_timer <= 0:
                self._slow_timer = 0
                self._slow_factor = 1.0
                self.speed = self._base_speed

        self.progress += self.speed * dt
        if self.progress >= len(self.path) - 1:
            self.progress = len(self.path) - 1
            self.reached_end = True

    @property
    def pos(self) -> Tuple[float, float]:
        idx = min(int(self.progress), len(self.path) - 2)
        frac = self.progress - idx
        c1, r1 = self.path[idx]
        c2, r2 = self.path[idx + 1] if idx + 1 < len(self.path) else self.path[idx]
        px = (c1 + (c2 - c1) * frac) * self.tile_size + self.tile_size // 2
        py = (r1 + (r2 - r1) * frac) * self.tile_size + self.tile_size // 2
        return px, py


class BasicEnemy(Enemy):
    def __init__(self, path, tile_size): super().__init__(path, tile_size, hp=100, speed=1.0, reward=10, lives_damage=1)

class FastEnemy(Enemy):
    def __init__(self, path, tile_size): super().__init__(path, tile_size, hp=60, speed=2.0, reward=15, lives_damage=1)

class TankEnemy(Enemy):
    BASE_SLOW_RESISTANCE = 0.7
    def __init__(self, path, tile_size): super().__init__(path, tile_size, hp=400, speed=0.5, reward=40, lives_damage=3)

class SwarmEnemy(Enemy):
    def __init__(self, path, tile_size): super().__init__(path, tile_size, hp=30, speed=1.5, reward=5, lives_damage=1)
```

- [ ] **Step 4: Run — verify PASS**

```bash
pytest tests/test_enemy.py -v
```

Expected: all 15 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/enemy.py tests/test_enemy.py
git commit -m "feat: add enemy classes with movement, slow, and damage"
```

---

## Task 5: Towers + Projectiles

**Files:**
- Create: `src/tower.py`
- Create: `tests/test_tower.py`

Projectile is a data object (no pygame). Tower targeting picks enemy with highest `progress` in range.

- [ ] **Step 1: Write failing tests**

```python
# tests/test_tower.py
import pytest
from src.tower import BasicTower, IceTower, BombTower, SniperTower, Projectile
from src.enemy import BasicEnemy, TankEnemy

PATH = [(i, 0) for i in range(20)]
TILE = 48

def make_enemy_at_progress(p):
    e = BasicEnemy(path=PATH, tile_size=TILE)
    e.progress = p
    return e

@pytest.fixture
def basic_tower():
    return BasicTower(col=5, row=2, tile_size=TILE)

def test_tower_center_px(basic_tower):
    cx, cy = basic_tower.center_px
    assert cx == 5 * TILE + TILE // 2
    assert cy == 2 * TILE + TILE // 2

def test_get_target_returns_most_advanced_in_range(basic_tower):
    near = make_enemy_at_progress(5.1)   # col ~5 row 0, near tower col=5 row=2
    far = make_enemy_at_progress(5.2)
    target = basic_tower.get_target([near, far])
    assert target is far

def test_get_target_ignores_dead(basic_tower):
    e = make_enemy_at_progress(5.1)
    e.alive = False
    assert basic_tower.get_target([e]) is None

def test_get_target_out_of_range(basic_tower):
    e = make_enemy_at_progress(0.0)  # col 0, far from col 5 row 2
    # distance > BasicTower range (120px). col0 row0 → col5 row2: sqrt((240)²+(96)²)≈258 > 120
    assert basic_tower.get_target([e]) is None

def test_shoot_creates_projectile(basic_tower):
    projectiles = []
    target = make_enemy_at_progress(5.1)
    basic_tower._shoot(target, projectiles)
    assert len(projectiles) == 1

def test_update_fires_when_cooled_down(basic_tower):
    projectiles = []
    target = make_enemy_at_progress(5.1)
    basic_tower.cooldown = 0.0
    basic_tower.update(dt=0.01, enemies=[target], projectiles=projectiles)
    assert len(projectiles) == 1

def test_cooldown_prevents_rapid_fire(basic_tower):
    projectiles = []
    target = make_enemy_at_progress(5.1)
    basic_tower.cooldown = 0.5
    basic_tower.update(dt=0.1, enemies=[target], projectiles=projectiles)
    assert len(projectiles) == 0

def test_upgrade_increases_damage(basic_tower):
    dmg1 = basic_tower.damage
    basic_tower.upgrade()
    assert basic_tower.damage > dmg1

def test_upgrade_increases_range(basic_tower):
    r1 = basic_tower.range_px
    basic_tower.upgrade()
    assert basic_tower.range_px > r1

def test_upgrade_max_level(basic_tower):
    basic_tower.upgrade()
    basic_tower.upgrade()
    basic_tower.upgrade()
    assert basic_tower.level == 3

def test_ice_tower_applies_slow():
    tower = IceTower(col=5, row=2, tile_size=TILE)
    projectiles = []
    target = make_enemy_at_progress(5.1)
    tower._shoot(target, projectiles)
    proj = projectiles[0]
    assert proj.slow_factor == 0.6
    assert proj.slow_duration > 0

def test_bomb_tower_has_splash():
    tower = BombTower(col=5, row=2, tile_size=TILE)
    assert tower.splash_radius > 0

def test_projectile_hits_enemy():
    proj = Projectile(x=100, y=100, target_enemy=make_enemy_at_progress(5.1),
                      damage=20, speed=300, slow_factor=1.0, slow_duration=0.0,
                      splash_radius=0)
    enemies = [proj.target]
    hits = proj.update(dt=1.0, enemies=enemies)
    assert proj.target in hits

def test_upgrade_cost():
    tower = BasicTower(col=0, row=0, tile_size=TILE)
    assert tower.upgrade_cost == tower.base_cost * 1  # level 1 → upgrade to 2 costs base*1
    tower.upgrade()
    assert tower.upgrade_cost == tower.base_cost * 2  # level 2 → upgrade to 3 costs base*2
```

- [ ] **Step 2: Run — verify FAIL**

```bash
pytest tests/test_tower.py -v
```

Expected: `ModuleNotFoundError: No module named 'src.tower'`

- [ ] **Step 3: Implement `src/tower.py`**

```python
import math
from typing import List, Optional, Tuple

class Projectile:
    def __init__(self, x: float, y: float, target_enemy, damage: float,
                 speed: float, slow_factor: float, slow_duration: float,
                 splash_radius: float):
        self.x = x
        self.y = y
        self.target = target_enemy
        self.damage = damage
        self.speed = speed
        self.slow_factor = slow_factor
        self.slow_duration = slow_duration
        self.splash_radius = splash_radius
        self.active = True

    def update(self, dt: float, enemies: list) -> list:
        if not self.active or not self.target.alive:
            self.active = False
            return []

        tx, ty = self.target.pos
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)

        if dist < self.speed * dt:
            self.active = False
            return self._on_hit(enemies)

        self.x += (dx / dist) * self.speed * dt
        self.y += (dy / dist) * self.speed * dt
        return []

    def _on_hit(self, enemies: list) -> list:
        hit = []
        if self.splash_radius > 0:
            tx, ty = self.target.pos
            for e in enemies:
                if e.alive:
                    ex, ey = e.pos
                    if math.hypot(ex - tx, ey - ty) <= self.splash_radius:
                        e.take_damage(self.damage)
                        if self.slow_factor < 1.0:
                            e.apply_slow(self.slow_factor, self.slow_duration)
                        hit.append(e)
        else:
            self.target.take_damage(self.damage)
            if self.slow_factor < 1.0:
                self.target.apply_slow(self.slow_factor, self.slow_duration)
            hit.append(self.target)
        return hit


class Tower:
    base_cost: int = 0
    base_damage: float = 0
    base_range: float = 0
    base_fire_rate: float = 1.0
    proj_speed: float = 300.0
    slow_factor: float = 1.0
    slow_duration: float = 0.0
    splash_radius: float = 0.0

    def __init__(self, col: int, row: int, tile_size: int):
        self.col = col
        self.row = row
        self.tile_size = tile_size
        self.level = 1
        self.cooldown = 0.0
        self.damage = float(self.base_damage)
        self.range_px = float(self.base_range)
        self.fire_rate = float(self.base_fire_rate)

    @property
    def center_px(self) -> Tuple[float, float]:
        return (self.col * self.tile_size + self.tile_size / 2,
                self.row * self.tile_size + self.tile_size / 2)

    @property
    def upgrade_cost(self) -> int:
        return self.base_cost * self.level

    def in_range(self, enemy) -> bool:
        cx, cy = self.center_px
        ex, ey = enemy.pos
        return math.hypot(ex - cx, ey - cy) <= self.range_px

    def get_target(self, enemies: list):
        candidates = [e for e in enemies if e.alive and self.in_range(e)]
        return max(candidates, key=lambda e: e.progress, default=None)

    def _shoot(self, target, projectiles: list) -> None:
        cx, cy = self.center_px
        projectiles.append(Projectile(
            x=cx, y=cy, target_enemy=target,
            damage=self.damage, speed=self.proj_speed,
            slow_factor=self.slow_factor, slow_duration=self.slow_duration,
            splash_radius=self.splash_radius,
        ))
        self.cooldown = 1.0 / self.fire_rate

    def update(self, dt: float, enemies: list, projectiles: list) -> None:
        self.cooldown = max(0.0, self.cooldown - dt)
        if self.cooldown == 0.0:
            target = self.get_target(enemies)
            if target:
                self._shoot(target, projectiles)

    def upgrade(self) -> None:
        if self.level >= 3:
            return
        self.level += 1
        self.damage *= 1.25
        self.range_px *= 1.25


class BasicTower(Tower):
    base_cost = 50; base_damage = 20; base_range = 120; base_fire_rate = 1.0

class IceTower(Tower):
    base_cost = 80; base_damage = 5; base_range = 100; base_fire_rate = 1.5
    slow_factor = 0.6; slow_duration = 2.0

class BombTower(Tower):
    base_cost = 120; base_damage = 60; base_range = 90; base_fire_rate = 0.4
    splash_radius = 60.0

class SniperTower(Tower):
    base_cost = 150; base_damage = 120; base_range = 250; base_fire_rate = 0.3
    proj_speed = 600.0
```

- [ ] **Step 4: Run — verify PASS**

```bash
pytest tests/test_tower.py -v
```

Expected: all 15 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/tower.py tests/test_tower.py
git commit -m "feat: add tower classes with targeting, projectiles, upgrades"
```

---

## Task 6: Wave Manager

**Files:**
- Create: `src/wave.py`
- Create: `tests/test_wave.py`

Wave definition: list of `(EnemyClass, count, spawn_interval_seconds)`. WaveManager spawns enemies at intervals and scales difficulty each wave.

- [ ] **Step 1: Write failing tests**

```python
# tests/test_wave.py
import pytest
from src.wave import WaveManager
from src.enemy import BasicEnemy, FastEnemy, TankEnemy, SwarmEnemy

PATH = [(i, 0) for i in range(20)]
TILE = 48

@pytest.fixture
def wm():
    return WaveManager(path=PATH, tile_size=TILE)

def test_initial_wave_number(wm):
    assert wm.wave_number == 0

def test_not_active_initially(wm):
    assert wm.active is False

def test_start_wave_increments_number(wm):
    wm.start_wave()
    assert wm.wave_number == 1

def test_start_wave_sets_active(wm):
    wm.start_wave()
    assert wm.active is True

def test_update_spawns_enemies(wm):
    wm.start_wave()
    spawned = []
    # Advance enough time to spawn first enemy
    for _ in range(100):
        spawned.extend(wm.update(dt=0.1))
    assert len(spawned) > 0

def test_spawned_enemies_are_enemy_instances(wm):
    wm.start_wave()
    spawned = []
    for _ in range(200):
        spawned.extend(wm.update(dt=0.1))
    from src.enemy import Enemy
    assert all(isinstance(e, Enemy) for e in spawned)

def test_wave_ends_after_all_spawned(wm):
    wm.start_wave()
    for _ in range(10000):
        wm.update(dt=0.1)
    assert wm.active is False

def test_wave_2_has_more_total_hp_than_wave_1(wm):
    def total_hp_spawned(wm_instance):
        wm_instance.start_wave()
        spawned = []
        for _ in range(10000):
            spawned.extend(wm_instance.update(dt=0.1))
        return sum(e.max_hp for e in spawned)

    hp1 = total_hp_spawned(wm)
    hp2 = total_hp_spawned(wm)
    assert hp2 > hp1

def test_total_enemies_per_wave_increases(wm):
    def count_spawned(wm_instance):
        wm_instance.start_wave()
        spawned = []
        for _ in range(10000):
            spawned.extend(wm_instance.update(dt=0.1))
        return len(spawned)

    n1 = count_spawned(wm)
    n2 = count_spawned(wm)
    assert n2 >= n1
```

- [ ] **Step 2: Run — verify FAIL**

```bash
pytest tests/test_wave.py -v
```

Expected: `ModuleNotFoundError: No module named 'src.wave'`

- [ ] **Step 3: Implement `src/wave.py`**

```python
from typing import List, Tuple, Type
from src.enemy import Enemy, BasicEnemy, FastEnemy, TankEnemy, SwarmEnemy

SpawnEntry = Tuple[Type[Enemy], int, float]  # (EnemyClass, count, interval)

def _wave_definition(wave_number: int) -> List[SpawnEntry]:
    base = [
        (BasicEnemy, 8 + wave_number * 2, 1.0),
    ]
    if wave_number >= 2:
        base.append((FastEnemy, 4 + wave_number, 0.6))
    if wave_number >= 3:
        base.append((SwarmEnemy, 10 + wave_number * 2, 0.3))
    if wave_number >= 4:
        base.append((TankEnemy, 1 + wave_number // 2, 2.0))
    return base

HP_SCALE = 1.15  # +15% HP per wave

class WaveManager:
    def __init__(self, path: list, tile_size: int):
        self.path = path
        self.tile_size = tile_size
        self.wave_number = 0
        self.active = False
        self._queue: List[Tuple[Type[Enemy], float]] = []  # (EnemyClass, time_until_spawn)
        self._timer = 0.0

    def start_wave(self) -> None:
        self.wave_number += 1
        self.active = True
        self._queue = []
        t = 0.0
        for enemy_cls, count, interval in _wave_definition(self.wave_number):
            for _ in range(count):
                self._queue.append((enemy_cls, t))
                t += interval
        self._queue.sort(key=lambda x: x[1])
        self._timer = 0.0

    def update(self, dt: float) -> List[Enemy]:
        if not self.active:
            return []
        self._timer += dt
        spawned = []
        while self._queue and self._queue[0][1] <= self._timer:
            enemy_cls, _ = self._queue.pop(0)
            e = enemy_cls(path=self.path, tile_size=self.tile_size)
            scale = HP_SCALE ** (self.wave_number - 1)
            e.hp = int(e.hp * scale)
            e.max_hp = e.hp
            spawned.append(e)
        if not self._queue:
            self.active = False
        return spawned
```

- [ ] **Step 4: Run — verify PASS**

```bash
pytest tests/test_wave.py -v
```

Expected: all 9 tests PASS.

- [ ] **Step 5: Run full test suite**

```bash
pytest -v
```

Expected: all tests PASS.

- [ ] **Step 6: Commit**

```bash
git add src/wave.py tests/test_wave.py
git commit -m "feat: add wave manager with scaling difficulty"
```

---

## Task 7: Renderer

**Files:**
- Create: `src/renderer.py`

No tests for renderer — it is pure drawing code. Verified visually during Task 9.

- [ ] **Step 1: Create `src/renderer.py`**

```python
import pygame
from src.map import GameMap
from src.enemy import Enemy
from src.tower import Tower, Projectile

COLORS = {
    "grass": (34, 139, 34),
    "path": (194, 154, 76),
    "basic_tower": (70, 130, 180),
    "ice_tower": (100, 200, 255),
    "bomb_tower": (200, 80, 40),
    "sniper_tower": (180, 60, 180),
    "basic_enemy": (220, 50, 50),
    "fast_enemy": (255, 165, 0),
    "tank_enemy": (100, 100, 200),
    "swarm_enemy": (200, 200, 50),
    "projectile": (255, 255, 0),
    "hp_bg": (180, 0, 0),
    "hp_fg": (0, 220, 0),
    "range_circle": (255, 255, 255, 60),
    "ui_bg": (30, 30, 30),
    "gold": (255, 215, 0),
    "text": (255, 255, 255),
    "selected": (255, 255, 100),
}

TOWER_COLORS = {
    "BasicTower": COLORS["basic_tower"],
    "IceTower": COLORS["ice_tower"],
    "BombTower": COLORS["bomb_tower"],
    "SniperTower": COLORS["sniper_tower"],
}
ENEMY_COLORS = {
    "BasicEnemy": COLORS["basic_enemy"],
    "FastEnemy": COLORS["fast_enemy"],
    "TankEnemy": COLORS["tank_enemy"],
    "SwarmEnemy": COLORS["swarm_enemy"],
}

def draw_map(surface: pygame.Surface, game_map: GameMap) -> None:
    ts = game_map.tile_size
    path_set = set(game_map.path)
    for r in range(game_map.rows):
        for c in range(game_map.cols):
            color = COLORS["path"] if (c, r) in path_set else COLORS["grass"]
            pygame.draw.rect(surface, color, (c * ts, r * ts, ts, ts))
            pygame.draw.rect(surface, (0, 0, 0), (c * ts, r * ts, ts, ts), 1)

def draw_towers(surface: pygame.Surface, towers: list, selected: Tower | None, tile_size: int) -> None:
    for tower in towers:
        cx, cy = tower.center_px
        color = TOWER_COLORS.get(type(tower).__name__, (128, 128, 128))
        pygame.draw.circle(surface, color, (int(cx), int(cy)), tile_size // 2 - 4)
        pygame.draw.circle(surface, (0, 0, 0), (int(cx), int(cy)), tile_size // 2 - 4, 2)
        if tower is selected:
            pygame.draw.circle(surface, COLORS["selected"], (int(cx), int(cy)), int(tower.range_px), 2)
        # Level indicator dots
        for i in range(tower.level):
            pygame.draw.circle(surface, COLORS["gold"],
                               (int(cx) - 8 + i * 8, int(cy) + tile_size // 2 - 8), 3)

def draw_enemies(surface: pygame.Surface, enemies: list) -> None:
    for e in enemies:
        if not e.alive:
            continue
        px, py = e.pos
        color = ENEMY_COLORS.get(type(e).__name__, (200, 0, 0))
        radius = 10
        pygame.draw.circle(surface, color, (int(px), int(py)), radius)
        # HP bar
        bar_w = 24
        ratio = e.hp / e.max_hp
        pygame.draw.rect(surface, COLORS["hp_bg"], (int(px) - bar_w // 2, int(py) - radius - 6, bar_w, 4))
        pygame.draw.rect(surface, COLORS["hp_fg"], (int(px) - bar_w // 2, int(py) - radius - 6, int(bar_w * ratio), 4))

def draw_projectiles(surface: pygame.Surface, projectiles: list) -> None:
    for p in projectiles:
        if p.active:
            pygame.draw.circle(surface, COLORS["projectile"], (int(p.x), int(p.y)), 4)

def draw_hud(surface: pygame.Surface, font: pygame.font.Font,
             gold: int, lives: int, wave: int, score: int,
             screen_w: int) -> None:
    text = f"Gold: {gold}   Lives: {lives}   Wave: {wave}   Score: {score}"
    surf = font.render(text, True, COLORS["text"])
    surface.blit(surf, (10, 6))
```

- [ ] **Step 2: Commit**

```bash
git add src/renderer.py
git commit -m "feat: add pygame renderer (map, towers, enemies, projectiles, HUD)"
```

---

## Task 8: UI Panel + Input

**Files:**
- Create: `src/ui.py`

No automated tests — UI is verified interactively in Task 9.

- [ ] **Step 1: Create `src/ui.py`**

```python
import pygame
from src.tower import BasicTower, IceTower, BombTower, SniperTower, Tower
from src.economy import Economy
from src.renderer import COLORS

TOWER_CLASSES = [BasicTower, IceTower, BombTower, SniperTower]
TOWER_NAMES = ["Basic\n50g", "Ice\n80g", "Bomb\n120g", "Sniper\n150g"]

PANEL_HEIGHT = 80

class UI:
    def __init__(self, screen_w: int, screen_h: int, font: pygame.font.Font):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.font = font
        self.panel_rect = pygame.Rect(0, screen_h - PANEL_HEIGHT, screen_w, PANEL_HEIGHT)
        self._btn_rects: list[pygame.Rect] = []
        btn_w = 100
        for i in range(len(TOWER_CLASSES)):
            x = 10 + i * (btn_w + 10)
            self._btn_rects.append(pygame.Rect(x, screen_h - PANEL_HEIGHT + 10, btn_w, 60))
        # Start wave button
        self.start_btn = pygame.Rect(screen_w - 140, screen_h - PANEL_HEIGHT + 20, 130, 40)

    def draw(self, surface: pygame.Surface, economy: Economy,
             selected_cls, selected_tower: Tower | None,
             wave_active: bool, countdown: float) -> None:
        pygame.draw.rect(surface, COLORS["ui_bg"], self.panel_rect)

        for i, (cls, rect) in enumerate(zip(TOWER_CLASSES, self._btn_rects)):
            color = COLORS["selected"] if cls is selected_cls else (60, 60, 60)
            can = economy.can_afford(cls.base_cost)
            if not can:
                color = (40, 40, 40)
            pygame.draw.rect(surface, color, rect, border_radius=6)
            label = TOWER_NAMES[i].replace("\n", " ")
            surf = self.font.render(label, True, COLORS["text"] if can else (100, 100, 100))
            surface.blit(surf, (rect.x + 4, rect.y + 8))

        if selected_tower:
            info = (f"{type(selected_tower).__name__} Lv{selected_tower.level}  "
                    f"DMG:{selected_tower.damage:.0f}  RNG:{selected_tower.range_px:.0f}")
            if selected_tower.level < 3:
                info += f"  [U] Upgrade {selected_tower.upgrade_cost}g"
            surf = self.font.render(info, True, COLORS["gold"])
            surface.blit(surf, (10, self.panel_rect.y - 24))

        btn_color = (80, 80, 80) if wave_active else (50, 150, 50)
        pygame.draw.rect(surface, btn_color, self.start_btn, border_radius=6)
        if wave_active:
            label = "Wave active"
        elif countdown > 0:
            label = f"Next: {countdown:.1f}s"
        else:
            label = "Start Wave"
        surf = self.font.render(label, True, COLORS["text"])
        surface.blit(surf, (self.start_btn.x + 6, self.start_btn.y + 10))

    def handle_click(self, pos, economy: Economy) -> str | None:
        """Returns: tower class name, 'start_wave', or None."""
        for i, rect in enumerate(self._btn_rects):
            if rect.collidepoint(pos):
                cls = TOWER_CLASSES[i]
                if economy.can_afford(cls.base_cost):
                    return cls.__name__
        if self.start_btn.collidepoint(pos):
            return "start_wave"
        return None

    def is_in_panel(self, pos) -> bool:
        return self.panel_rect.collidepoint(pos)
```

- [ ] **Step 2: Commit**

```bash
git add src/ui.py
git commit -m "feat: add UI panel with tower shop and start wave button"
```

---

## Task 9: Game Loop

**Files:**
- Create: `src/game.py`
- Create: `main.py`

- [ ] **Step 1: Create `src/game.py`**

```python
import pygame
import sys
from src.economy import Economy
from src.map import GameMap
from src.wave import WaveManager
from src.tower import BasicTower, IceTower, BombTower, SniperTower, Tower
from src.ui import UI, TOWER_CLASSES
from src import renderer

COLS, ROWS = 20, 12
TILE = 48
SCREEN_W = COLS * TILE
SCREEN_H = ROWS * TILE + 80  # +80 for UI panel
FPS = 60
BETWEEN_WAVES = 5.0  # seconds between waves

TOWER_MAP = {cls.__name__: cls for cls in TOWER_CLASSES}

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption("Tower Defense")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("Arial", 16)
        self.state = "MENU"
        self._init_game()

    def _init_game(self):
        self.game_map = GameMap(cols=COLS, rows=ROWS, tile_size=TILE)
        self.economy = Economy()
        self.wave_mgr = WaveManager(path=self.game_map.path, tile_size=TILE)
        self.towers: list[Tower] = []
        self.enemies = []
        self.projectiles = []
        self.selected_cls = None
        self.selected_tower = None
        self.ui = UI(SCREEN_W, SCREEN_H, self.font)
        self.countdown = 0.0

    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            self._handle_events()
            self._update(dt)
            self._draw()

    def _handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit(); sys.exit()

            if self.state == "MENU":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                    self.state = "PLAYING"

            elif self.state == "PLAYING":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self._handle_click(event.pos)
                if event.type == pygame.KEYDOWN and event.key == pygame.K_u:
                    self._try_upgrade()

            elif self.state == "GAME_OVER":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                    self._init_game()
                    self.state = "PLAYING"

    def _handle_click(self, pos):
        if self.ui.is_in_panel(pos):
            action = self.ui.handle_click(pos, self.economy)
            if action == "start_wave" and not self.wave_mgr.active and self.countdown <= 0:
                self.wave_mgr.start_wave()
            elif action and action != "start_wave":
                self.selected_cls = TOWER_MAP.get(action)
                self.selected_tower = None
            return

        col = pos[0] // TILE
        row = pos[1] // TILE
        if row >= ROWS:
            return

        # Check if clicking existing tower
        clicked_tower = next(
            (t for t in self.towers if t.col == col and t.row == row), None)
        if clicked_tower:
            self.selected_tower = clicked_tower
            self.selected_cls = None
            return

        # Place new tower
        if self.selected_cls and self.game_map.is_buildable(col, row):
            cost = self.selected_cls.base_cost
            if self.economy.can_afford(cost):
                self.economy.spend(cost)
                self.towers.append(self.selected_cls(col=col, row=row, tile_size=TILE))

    def _try_upgrade(self):
        if self.selected_tower and self.selected_tower.level < 3:
            cost = self.selected_tower.upgrade_cost
            if self.economy.can_afford(cost):
                self.economy.spend(cost)
                self.selected_tower.upgrade()

    def _update(self, dt: float):
        if self.state != "PLAYING":
            return

        if not self.wave_mgr.active and self.countdown > 0:
            self.countdown -= dt
            if self.countdown <= 0:
                self.countdown = 0.0

        # Spawn
        new_enemies = self.wave_mgr.update(dt)
        self.enemies.extend(new_enemies)

        # Update enemies
        for e in self.enemies:
            e.update(dt)
            if e.reached_end:
                self.economy.lose_life(e.lives_damage)
                e.reached_end = False
                e.alive = False

        # Update towers
        for tower in self.towers:
            tower.update(dt, self.enemies, self.projectiles)

        # Update projectiles
        hits_all = []
        for p in self.projectiles:
            hits = p.update(dt, self.enemies)
            hits_all.extend(hits)

        # Earn gold for kills
        for e in hits_all:
            if not e.alive:
                self.economy.earn(e.reward)

        # Cleanup
        self.enemies = [e for e in self.enemies if e.alive or e.reached_end is False]
        self.enemies = [e for e in self.enemies if e.alive]
        self.projectiles = [p for p in self.projectiles if p.active]

        # Wave complete
        if not self.wave_mgr.active and self.countdown == 0 and not any(not e.alive is False for e in self.enemies):
            if self.wave_mgr.wave_number > 0:
                self.countdown = BETWEEN_WAVES

        if self.economy.game_over:
            self.state = "GAME_OVER"

    def _draw(self):
        self.screen.fill((0, 0, 0))

        if self.state == "MENU":
            self._draw_menu()
        elif self.state in ("PLAYING", "WAVE_CLEAR"):
            renderer.draw_map(self.screen, self.game_map)
            renderer.draw_towers(self.screen, self.towers, self.selected_tower, TILE)
            renderer.draw_enemies(self.screen, self.enemies)
            renderer.draw_projectiles(self.screen, self.projectiles)
            renderer.draw_hud(self.screen, self.font,
                               self.economy.gold, self.economy.lives,
                               self.wave_mgr.wave_number, self.economy.score,
                               SCREEN_W)
            self.ui.draw(self.screen, self.economy, self.selected_cls,
                         self.selected_tower, self.wave_mgr.active, self.countdown)
        elif self.state == "GAME_OVER":
            self._draw_game_over()

        pygame.display.flip()

    def _draw_menu(self):
        title = pygame.font.SysFont("Arial", 48).render("TOWER DEFENSE", True, (255, 255, 255))
        sub = self.font.render("Press ENTER to start", True, (180, 180, 180))
        self.screen.blit(title, (SCREEN_W // 2 - title.get_width() // 2, SCREEN_H // 2 - 60))
        self.screen.blit(sub, (SCREEN_W // 2 - sub.get_width() // 2, SCREEN_H // 2 + 10))

    def _draw_game_over(self):
        font_big = pygame.font.SysFont("Arial", 48)
        go = font_big.render("GAME OVER", True, (220, 50, 50))
        score = self.font.render(f"Score: {self.economy.score}   Wave: {self.wave_mgr.wave_number}", True, (255, 255, 255))
        restart = self.font.render("Press R to restart", True, (180, 180, 180))
        self.screen.blit(go, (SCREEN_W // 2 - go.get_width() // 2, SCREEN_H // 2 - 80))
        self.screen.blit(score, (SCREEN_W // 2 - score.get_width() // 2, SCREEN_H // 2))
        self.screen.blit(restart, (SCREEN_W // 2 - restart.get_width() // 2, SCREEN_H // 2 + 40))
```

- [ ] **Step 2: Create `main.py`**

```python
from src.game import Game

if __name__ == "__main__":
    Game().run()
```

- [ ] **Step 3: Run game and verify manually**

```bash
python main.py
```

Verify:
- Menu appears, ENTER starts game
- Map is randomly generated (restart to see new map)
- Tower panel at bottom: click a tower type → click buildable cell to place
- "Start Wave" button spawns enemies
- Enemies walk the path
- Towers shoot at enemies in range
- Gold increases on kills
- Lives decrease when enemies reach end
- Game Over screen at 0 lives, R restarts

- [ ] **Step 4: Run full test suite**

```bash
pytest -v
```

Expected: all tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/game.py main.py
git commit -m "feat: add game loop with menu, playing, and game over states"
```

---

## Task 10: Build macOS .app

**Files:**
- Create: `build.sh`

- [ ] **Step 1: Create `build.sh`**

```bash
#!/usr/bin/env bash
set -e
pip install pyinstaller --quiet
pyinstaller --onefile --windowed \
  --name "TowerDefense" \
  --hidden-import pygame \
  main.py
echo "Build complete: dist/TowerDefense.app"
```

- [ ] **Step 2: Run build**

```bash
chmod +x build.sh && bash build.sh
```

Expected: `dist/TowerDefense.app` created.

- [ ] **Step 3: Verify app launches**

```bash
open dist/TowerDefense.app
```

Expected: game window opens, identical to `python main.py`.

- [ ] **Step 4: Commit**

```bash
git add build.sh
git commit -m "chore: add PyInstaller build script for macOS .app"
```

---

## Verification Summary

| Check | Command | Expected |
|-------|---------|----------|
| Unit tests | `pytest -v` | All PASS |
| Game runs | `python main.py` | Window opens, playable |
| macOS bundle | `bash build.sh && open dist/TowerDefense.app` | App opens, playable |
| New map each game | Restart 3×, compare maps | All different |
| Economy | Kill enemies, check gold | Increases by enemy.reward |
| Upgrade | Place tower, press U | Damage + range increase |
| Game over | Let lives hit 0 | GAME OVER screen shows |
