# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-14 (v10.2.1 completata)

## Piano Attivo

- Nessun piano attivo.

## Ultimo Piano Completato

- `v10.2.1` — Codex Click Bugfix
- Spec: `docs/superpowers/implemented/specs/2026-05-14-v10.2.1-codex-click-bugfix-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-14-v10.2.1-codex-click-bugfix.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.2.1`
- Artifact desktop corrente: `dist/current/TowerDefense.app`
- Artifact desktop archiviato: `dist/implemented/TowerDefense-v10.2.1.app`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo
- Nota: bugfix UI Codex, build desktop aggiornata.

## Verifiche v10.2.1

- `python3 -m pytest tests/test_game.py tests/test_renderer.py -k codex -v` -> `12 passed`
- `python3 -m pytest tests/test_version.py -v` -> `3 passed`
- `bash scripts/check_doc_sync.sh` -> OK

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
