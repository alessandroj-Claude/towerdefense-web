# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-29 (v11.7 completato)

## Piano Attivo

`v11.8` — Neutral Territory Events

## Prossimi

- `v11.9` — Victory Conditions & End-game Screen (3 win condition, CampaignStats, CONQUEST_ENDGAME)
  - Spec: `docs/superpowers/current/specs/2026-05-29-v11.9-victory-conditions-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-29-v11.9-victory-conditions.md`

## Idee Future (non pianificate)

*(vuoto)*

## Ultimo Piano Completato

- `v11.7` — Resource Market (scambio risorse inter-turno, tasso 2:1 città / 3:1 base) — runtime v11.7
- Spec: `docs/superpowers/implemented/specs/2026-05-29-v11.7-resource-market-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-29-v11.7-resource-market.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v11.7`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.
- Test renderer/game falliscono quando eseguiti insieme per ordering/pygame init — passano tutti individualmente.
- `test_web_api_flow` (3 failures) e `test_web_news_sync` — pre-esistenti, non introdotti da v11.7.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
