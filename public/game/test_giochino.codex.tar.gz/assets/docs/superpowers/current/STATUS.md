# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-09 (v8.0 — panel polish + game over redesign + bug fixes)

### Aggiornamento Operativo (v8.0 — In-Game Panel Polish + Game Over Redesign, 2026-05-09)

- Bug fix auto-repair mid-wave: test di regressione aggiunto; logica già corretta.
- Bug fix mobile touch splash screen: IIFE JS in `index.html` setta `window.MM.UME` e dispatcha `pointerdown` sul canvas.
- GUI loadout buttons: width 60→72px, label abbreviate (AA/Eco/Rep), bordi colorati per tipo, icone rimosse.
- GUI queue add buttons: height 20→28px; targeting policy buttons: height 20→24px.
- Game Over screen: background menu, titolo 56px, score/wave colorati, hint condensato, leaderboard start_y 140.
- Leaderboard panels: badge difficoltà colorato, rank coloring (gold/silver/bronze), formato entry aggiornato.
- Spec: `docs/superpowers/implemented/specs/2026-05-09-v8.0-panel-scoreboard-polish-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-09-v8.0-panel-scoreboard-polish.md`

## Runtime / Build

- TowerDefense build/runtime corrente: `v8.0` (desktop + web, `src/game.py` runtime marker)
- Web backend: `v7.0+` (FastAPI su Render, endpoint pubblico attivo)
- Ultimo piano completato: `v8.0` (panel polish + game over redesign)
- Piano attuale in esecuzione: nessuno

## Prossima Milestone

- Da definire.

## Repository

- **Gioco (principale):** `https://github.com/alessandroj-Claude/tower-defense-pygame-CODEX`
- **Web frontend (Next.js):** `https://github.com/alessandroj-Claude/towerdefense-web` — deploy su Vercel
- **Backend (FastAPI):** deploy su Render — `https://tower-defense-cj.onrender.com`

## Dominio Web (registrato)

- Dominio principale registrato: `towerdefense-cj.online` (annotato il 2026-05-05).
