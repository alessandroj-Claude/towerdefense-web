# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-21 (v11.0 completato)

## Piano Attivo

- (nessuno)

## Prossimi

- **v11.0** — Conquest Mode: World Map & Strategic UI — `docs/superpowers/current/plans/2026-05-21-v11.0-conquest-world-map.md`
- **v11.1** — Conquest Mode: Strategic Layer (Turns, Budget, CPU AI) — `docs/superpowers/current/plans/2026-05-21-v11.1-conquest-strategic-layer.md`
- **v11.2** — Conquest Mode: Defense Battles — `docs/superpowers/current/plans/2026-05-21-v11.2-conquest-defense.md`
- **v11.3** — Conquest Mode: Attack Battles (Reverse TD) — `docs/superpowers/current/plans/2026-05-21-v11.3-conquest-attack.md`
- Spec: `docs/superpowers/current/specs/2026-05-21-v11.x-conquest-mode-design.md`

## Idee Future (non pianificate)

- **Tower Draft Mode** — ogni run ha accesso solo a 5–6 torri casuali dalla pool; il giocatore deve adattare la strategia. Candidata per v10.11+.
- **Risorse per terrain** — Desert=oro, Forest=legno, Mountain=pietra; alcune torri richiederebbero risorse specifiche oltre al gold. Da pianificare dopo v11.x.

## Ultimo Piano Completato

- `v11.0` — Conquest Mode: World Map & Strategic UI — runtime v11.0
- Spec: `docs/superpowers/current/specs/2026-05-21-v11.x-conquest-mode-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-21-v11.0-conquest-world-map.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.10`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.
- Test renderer/game falliscono quando eseguiti insieme per ordering/pygame init — passano tutti individualmente.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
