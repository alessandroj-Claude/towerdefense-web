# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-15 (v10.4 completata)

## Piano Attivo

Nessun piano attivo.

## Ultimo Piano Completato

- `v10.4` — i18n Completion + Web Localization + Smart Play Button
- Spec: `docs/superpowers/implemented/specs/2026-05-15-v10.4-i18n-web-completion-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-15-v10.4-i18n-web-completion.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.4`
- Web artifact: pubblicato su `towerdefense-cj.online` (683K APK, 574K tar.gz)
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
