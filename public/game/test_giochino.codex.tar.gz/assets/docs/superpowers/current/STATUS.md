# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-29 (piani v11.6–v11.9 pianificati)

## Piano Attivo

`v11.6` — Real CPU-Attack Defense Battles

## Prossimi

- `v11.7` — Resource Market (scambia risorse in-turn, tasso 2:1 città / 3:1 base)
  - Spec: `docs/superpowers/current/specs/2026-05-29-v11.7-resource-market-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-29-v11.7-resource-market.md`
- `v11.8` — Neutral Territory Events (4 tipi evento su conquista neutrale, modal overlay)
  - Spec: `docs/superpowers/current/specs/2026-05-29-v11.8-neutral-events-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-29-v11.8-neutral-events.md`
- `v11.9` — Victory Conditions & End-game Screen (3 win condition, CampaignStats, CONQUEST_ENDGAME)
  - Spec: `docs/superpowers/current/specs/2026-05-29-v11.9-victory-conditions-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-29-v11.9-victory-conditions.md`

## Idee Future (non pianificate)

*(vuoto)*

## Ultimo Piano Completato

- `v11.5` — Conquest: Terrain Resources MVP (passivo per turno, torri advanced richiedono risorse) — runtime v11.5
- Spec: `docs/superpowers/implemented/specs/2026-05-27-v11.5-conquest-resources-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-27-v11.5-conquest-resources.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v11.5`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.
- Test renderer/game falliscono quando eseguiti insieme per ordering/pygame init — passano tutti individualmente.
- `test_web_api_flow` (3 failures) e `test_web_news_sync` — pre-esistenti, non introdotti da v11.5.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
