# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-20 (piani v10.8–v10.10 creati)

## Piano Attivo

- `v10.8` — Scout Flyer + Progressive Tower Unlock (in corso)

## Prossimi

- `v10.8` — Scout Flyer + Progressive Tower Unlock
  - Spec: `docs/superpowers/current/specs/2026-05-20-v10.8-scout-tower-unlock-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-20-v10.8-scout-tower-unlock.md`
- `v10.9` — Tower XP / Veteran System
  - Spec: `docs/superpowers/current/specs/2026-05-20-v10.9-tower-xp-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-20-v10.9-tower-xp.md`
- `v10.10` — Mid-Run Events
  - Spec: `docs/superpowers/current/specs/2026-05-20-v10.10-run-events-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-20-v10.10-run-events.md`

## Idee Future (non pianificate)

- **Tower Draft Mode** — ogni run ha accesso solo a 5–6 torri casuali dalla pool; il giocatore deve adattare la strategia. Candidata per v10.11+.

## Ultimo Piano Completato

- `v10.7` — Key System Overhaul — runtime v10.7
- Spec: `docs/superpowers/implemented/specs/2026-05-18-v10.7-key-overhaul-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-18-v10.7-key-overhaul.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.7`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.
- Test renderer/game falliscono quando eseguiti insieme per ordering/pygame init — passano tutti individualmente.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
