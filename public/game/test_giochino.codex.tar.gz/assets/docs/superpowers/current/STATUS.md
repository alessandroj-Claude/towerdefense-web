# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-14 (v10.2 completata)

## Piano Attivo

- Nessun piano attivo.

## Ultimo Piano Completato

- `v10.2` — Web Game Auto Login
- Spec: `docs/superpowers/implemented/specs/2026-05-14-v10.2-web-game-auto-login-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-14-v10.2-web-game-auto-login.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.0`
- Artifact desktop corrente: `dist/current/TowerDefense.app`
- Artifact desktop archiviato: `dist/implemented/TowerDefense-v10.0.app`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo
- Nota: piano v10.2 e' web/game auth bridge; build desktop non richiesta.

## Verifiche v10.2

- `npm run lint` -> OK
- `npm run build` -> OK
- `bash scripts/build_web_clean.sh` -> OK
- Web artifact sanity: `build/web` 1.2M, `towerdefense-web/public/game` 1.2M, APK 620K, tar.gz 521K
- `python3 -m pytest tests/test_web_auto_login.py tests/test_web_api_flow.py -v` -> `21 passed`
- `python3 -m pytest tests/test_web_news_sync.py -v` -> `2 passed`
- `bash scripts/check_doc_sync.sh` -> OK

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
