# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-06 (v7.4.1 DB persistence free in pianificazione)

### Aggiornamento Operativo (v7.4.1 db persistence free, 2026-05-06)

- Obiettivo corrente: evitare reset DB ad ogni nuova versione/deploy web.
- Formalizzati i documenti correnti:
  - Spec: `docs/superpowers/current/specs/2026-05-06-v7.4.1-db-persistence-free-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-06-v7.4.1-db-persistence-free.md`
- Direzione tecnica scelta (fase iniziale gratuita): Postgres esterno free (`DATABASE_URL`) con fallback SQLite solo locale/dev.
- Stato implementazione v7.4.1:
  - Task 1-6 completati in codebase locale (abstraction DB + query portability + script migrazione + checklist cutover).
  - In attesa: esecuzione migrazione su DB Postgres reale e verifica persistenza dopo redeploy Render.

### Aggiornamento Operativo (v7.4 web deployment, 2026-05-05)

- Dominio pubblico attivo: `towerdefense-cj.online` (Vercel).
- Repo web separata operativa: `alessandroj-Claude/towerdefense-web` (Next.js).
- Landing/site base online con route:
  - `/` home minimal
  - `/news` aggiornamenti
  - `/play` embed-ready
- Build web gioco servita direttamente da Vercel in `towerdefense-web/public/game/` (no GitHub Pages per serving runtime).
- Backend pubblico FastAPI online su Render:
  - `https://tower-defense-cj.onrender.com`
  - health check: `/health`
- In corso verifica end-to-end: auth/save/load reali in web (eliminazione fallback locale lato gameplay web).

### Aggiornamento Operativo (hotfix locale, 2026-05-01)

- Consolidate fix post-v7.3 per debug web locale:
  - bootstrap pygame/wasm piu` robusto,
  - entrypoint web stabile su `main.py`,
  - `web_debug_loop.sh` migliorato (build pulita + reset server + gestione fallback).
- Nota runtime locale:
  - usare URL `http://127.0.0.1:8080/?v=...` (piu` stabile di `localhost` in questo setup).
  - evitare `?-i` nel loop standard (in questa configurazione puo` forzare CDN locale non disponibile).
- Stato backend in questa worktree:
  - cartella `backend/` ripristinata da stash temporaneo.
  - da fare: riallineare e riverificare end-to-end login/register/save/load via API reali (non solo fallback locale).

## Runtime / Build

- TowerDefense build/runtime corrente: `v7.1` (desktop, `src/game.py` runtime marker)
- Web backend: `v7.0+` (FastAPI su Render, endpoint pubblico attivo)
- Ultimo piano completato: `v7.3` (web API integration — login/register/save/load)
- Piano attuale in esecuzione: `v7.4` (web deployment: dominio + frontend + hosting backend)
- Piano desktop archiviato di riferimento: `docs/superpowers/implemented/plans/2026-04-29-v6.9-new-towers-boss-cost.md`

## Planning Attivo

- TowerDefense v6.0: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.1: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.2: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.3: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.4: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.5: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.6: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.7: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v6.8: ✅ completato — archiviato in `docs/superpowers/current/plans/`
- TowerDefense v6.9: ✅ completato — archiviato in `docs/superpowers/implemented/plans/`
- TowerDefense v7.0: ✅ completato — FastAPI backend REST (auth/saves/leaderboard/DLC/JWT)
- TowerDefense v7.0.1: ✅ completato — serializzazione/persistenza separate (`serialize_game_state`, `restore_game_state`)
- TowerDefense v7.1: ✅ completato — Pygbag client, `run_async`, `main_web.py`, workflow deploy Pages
- TowerDefense v7.2: ✅ completato — admin CLI + CORS env + warning JWT secret
- TowerDefense v7.3: ✅ completato — login/register/save/load web via REST API
- TowerDefense v7.4: 🔄 in corso — deploy web pubblico (Vercel + Render) e stabilizzazione auth cloud
- DLCKeygen: nessun piano corrente

## Milestone Completate (Sintesi)

- TowerDefense v6.9 (extra fuori piano, stessa versione): fix offset click vs rendering dopo resize (`window->game coords`), shop torri su 2 righe, miglioramento leggibilità font/scaling (`smoothscale` + font fallback), wrapping descrizioni perk dentro card, card torre estesa con elemento+matchup (`strong/neutral/weak`), nemici color-coded per elemento con intensità per tipo, tuning elementi con regole ±50% richieste (`FIRE↔AIR`, `FIRE↔EARTH`) e boss con elemento random a spawn.

- TowerDefense v5.5: terrain evolution dinamico (max 2-3 celle tra wave), HUD preview pre-wave dismissibile (tasto T), 3 powerup anti-air dedicati (`radar_pulse`, `aa_salvo`, `scramble`) da wave 5, pity counter 2, trigger evento a wave-start, durata doppia, `AnalyticsManager` persistente su `analytics.json`, schermata analytics menu principale top-5 + barchart, save/load v5.4-safe.
- TowerDefense v5.4: loadout presets (3 preset `anti-air/economy/repair`), targeting policies (furthest/strongest/lowest-hp/flying-first per torre), order queue (5 ordini pre-wave), wave report metriche, synergy badge HUD, adaptive rationale testo, save/load v5.4-safe, bugfix upgrade-all/gold multiplier/UI overlap.
- TowerDefense v5.3: `AntiAirTower` con targeting `flying-first` e bonus/malus dedicati, evento `Earthquake` (accuracy debuff + micro-stun + shake), nuovi terrain `high_wind/fortified`, evento positivo `Anti-Air Protocol`, save/load anti-air-safe.
- TowerDefense v5.2: auto-repair all wave-start toggle, `Upgrade All` per tipo torre con ordine deterministico `x,y`, selector placement `* / ** / ***`, tuning eventi (`+10%` relativo) e pity a 3, persistenza `qol_state`.
- TowerDefense v5.1.1: fix bilanciamento adaptive/spawn + tuning boss/adaptive downshift su perdita vite.
- TowerDefense v5.1: HUD espansa + mappa leggermente ridotta, tooltip powerup hover completa, nuovo enemy volante con movimento diretto e ranged attack, integrazione wave/save-load/render.
- TowerDefense v5.0: controlli speed simulazione, perk permanenti run-start (`PERK_SELECTION`), powerup acquistabili wave-based con persistenza save/load.
- TowerDefense v4.3: repair target mode + repair all, pity rule eventi midwave, score multiplier adaptive in HUD, leaderboard persistente top5 globale/personale con filtro versione.
- TowerDefense v4.1: map generator v2 con verticalita` moderata, terrain (`road/mud/wind`), blocked cells, effetti runtime terrain con cap speed/accuracy.
- TowerDefense v4.0: adaptive balancing cumulativo (`hp/speed/damage`), tracking progresso massimo wave, persistenza `adaptive_state`.
- TowerDefense v3.4: menu post-login con `Load`, UX menu ripulita, fix sovrapposizione layout.
- TowerDefense v3.3: eventi wave serializzabili, polish visuale torri/proiettili/HUD.
- TowerDefense v3.2: persistenza esterna stabile (`App Support` + fallback), migrazione legacy best-effort, soft-delete utenti con guard admin self-delete.
- TowerDefense v3.1: torri DLC reali (`StormTower`, `InfernoTower`), gating completo, save/load DLC-safe.
- DLCKeygen v1.0: app desktop separata per generazione/copia chiavi DLC compatibili v3.x.

## Prossima Milestone

- TowerDefense v7.4.1: DB persistence free (in preparazione implementazione).

## Dominio Web (registrato)

- Dominio principale registrato: `towerdefense-cj.online` (annotato il 2026-05-05).

## Backlog Vicino

- Da riesaminare dopo piani v5.2-v5.4:
  - terrain evolution dinamico tra wave con preavviso HUD (eventuale v5.4.x/v5.5).
  - estensione anti-air ecosystem con powerup dedicati extra.
  - report analytics multi-run oltre il report post-wave sintetico.

## Direzione v6.x (pianificata)

- v6.0: Design Language Foundation (`src/theme.py`, refactor colori renderer/ui)
- v6.1: In-game Visual Polish (mappa, terrain, torri, nemici, proiettili)
- v6.2: HUD & Panel Polish (layout HUD, hover state, damage numbers, placement ghost)
- v6.3: miglioramento dimensioni celle e torri
- Approccio: polish puro pygame draw API — no sprite/asset esterni.
- Spec: `docs/superpowers/implemented/specs/2026-04-27-v6.x-visual-polish-design.md`

## Piani Pronti ( implementati)

| Versione | Spec | Piano | Stato |
|----------|------|-------|-------|
| v6.4 | `docs/superpowers/implemented/specs/2026-04-28-v6.4-balance-sim-design.md` | `docs/superpowers/implemented/plans/2026-04-28-v6.4-balance-sim.md` | ✅ completato |
| v6.5 | `docs/superpowers/implemented/specs/2026-04-28-v6.5-renderer-refactor-design.md` | `docs/superpowers/implemented/plans/2026-04-28-v6.5-renderer-refactor.md` | ✅ completato |
| v6.6 | `docs/superpowers/implemented/specs/2026-04-28-v6.6-game-mixin-refactor-design.md` | `docs/superpowers/implemented/plans/2026-04-28-v6.6-game-mixin-refactor.md` | ✅ completato |
| v6.7 | `docs/superpowers/implemented/specs/2026-04-28-v6.7-ui-command-pattern-design.md` | `docs/superpowers/implemented/plans/2026-04-28-v6.7-ui-command-pattern.md` | ✅ completato |
| v6.8 | `docs/superpowers/implemented/specs/2026-04-29-v6.8-elemental-resize-repair-design.md` | `docs/superpowers/implemented/plans/2026-04-29-v6.8-elemental-resize-repair.md` | ✅ completato |
| v6.9 | `docs/superpowers/implemented/specs/2026-04-29-v6.9-new-towers-boss-cost-design.md` | `docs/superpowers/implemented/plans/2026-04-29-v6.9-new-towers-boss-cost.md` | ✅ completato |
| v7.0 | `docs/superpowers/implemented/specs/2026-04-30-v7.0-web-backend-design.md` | `docs/superpowers/implemented/plans/2026-04-30-v7.0-web-backend.md` | ✅ completato |
| v7.0.1 | `docs/superpowers/implemented/specs/2026-04-30-v7.0.1-save-refactor-design.md` | `docs/superpowers/implemented/plans/2026-04-30-v7.0.1-save-refactor.md` | ✅ completato |
| v7.1 | `docs/superpowers/implemented/specs/2026-04-30-v7.1-pygbag-client-design.md` | `docs/superpowers/implemented/plans/2026-04-30-v7.1-pygbag-client.md` | ✅ completato |
| v7.2 | `docs/superpowers/implemented/specs/2026-04-30-v7.2-hardening-design.md` | `docs/superpowers/implemented/plans/2026-04-30-v7.2-hardening.md` | ✅ completato |
