# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-14 (v10.3 completata)

## Piano Attivo

- `v10.4` — i18n Completion + Web Localization + Smart Play Button
- Spec: `docs/superpowers/current/specs/2026-05-15-v10.4-i18n-web-completion-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-15-v10.4-i18n-web-completion.md`

## Ultimo Piano Completato

- `v10.3` — Localizzazione EN/IT
- Spec: `docs/superpowers/implemented/specs/2026-05-14-v10.3-localization-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-14-v10.3-localization.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.3`
- Web artifact: pubblicato su `towerdefense-cj.online` (3.0MB APK)
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Backlog v10.4+

- **Localizzazione sito web Next.js** — traduzione contenuti pagine home, news, leaderboard in IT. Fuori scope v10.3 per decisione esplicita. `LanguageToggle` già scrive `td.lang` in localStorage; basta leggere quella preferenza lato React e rendere i testi condizionali.
- l'HUD di gioco (sotto la mappa) contiene stringhe non tradotte nei pulsanti delle torri e dei powerup.
- il bottone 'play' nella pagina web dovrebbe essere dipendente dal checkDB.. penso che possiamo integrare il check db in play, magari clicchi il pulsante play, esce una piccola scritta (nel bottone fra parentesi checking.. -> checkOK) e poi apre il gioco.

## Verifiche v10.2.1

- `python3 -m pytest tests/test_game.py tests/test_renderer.py -k codex -v` -> `12 passed`
- `python3 -m pytest tests/test_version.py -v` -> `3 passed`
- `bash scripts/check_doc_sync.sh` -> OK

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
