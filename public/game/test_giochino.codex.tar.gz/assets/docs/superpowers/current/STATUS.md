# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-11 (v8.3 completata; v8.4 piano aperto)

### Aggiornamento Operativo (v8.1 — Daily/Weekly Challenges + DPR Rendering Fix, 2026-05-11)

- Daily/Weekly Challenges: definizioni deterministiche, seed dedicati e modificatori `rich_start`, `fast_fliers`, `boss_pressure`.
- Mappa seeded per challenge tramite `GameMap(..., rng=...)`, con run standard backward-compatible.
- Menu principale con entry Daily/Weekly e badge HUD challenge durante la run.
- Save/load e leaderboard persistono `challenge_kind` + `challenge_id`; API backend/client espongono record/query filtrabili.
- Web DPR template consolidato: helper `towerDefenseDpr()`, clamp max 2, `imageRendering` automatico su HiDPI e dataset CSS per debug.
- Build desktop/web aggiornata a `v8.1`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.1.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.1-challenges-dpr-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.1-challenges-dpr.md`

### Aggiornamento Operativo (v8.2 — Codex + Meta Progression + Run Mutators, 2026-05-11)

- Codex: 37 entry immutabili (Towers/Enemies/Elements/Terrain/Events/Boss), schermata consultabile dal menu, offline.
- Mutators: 6 mutator (3 bonus + 3 malus), validazione max 1+1, flow DIFFICULTY→MUTATOR_SELECTION→PERK_SELECTION.
- Meta Progression: XP formula (capped 500), livello da sqrt, 4 badge, `profile_stats` DB locale + backend API autenticata.
- Leaderboard: `mutators_json` + `score_mult` su `score_runs`; backward compat su righe legacy.
- Game Over: XP/livello/badge mostrati in overlay; `_progression_recorded` per idempotenza.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.2-codex-progression-mutators-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.2-codex-progression-mutators.md`

### Aggiornamento Operativo (v8.3 — Map Preview + Boss Rework + Combat Recap, 2026-05-11)

- Map Preview: seed manuale/casuale, reroll limitati, preview deterministica e challenge seed locked.
- Boss Rework: fasi HP, abilita` telegrafate `summon_swarm`/`armor_pulse`, indicatori renderer e reward post-boss.
- Boss Reward: scelta tra `gold_cache`, `field_repair`, `overclock_token`, con save/load pending reward.
- Combat Recap: log wave con danni per torre, kill, gold, repair/upgrade, vite perse, eventi e boss ability.
- Build desktop/web aggiornata a `v8.3`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.3.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.3-map-boss-recap-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.3-map-boss-recap.md`

## Runtime / Build

- TowerDefense build/runtime corrente: `v8.3` (desktop + web, `src/game.py` runtime marker)
- Web backend: `v7.0+` (FastAPI su Render, endpoint pubblico attivo)
- Ultimo piano completato: `v8.3` (Map Preview + Boss Rework + Combat Recap)
- Piani attuali in esecuzione:
  - `v8.4` (Web Account Polish + Mobile Controls Pass)
- Spec correnti:
  - `docs/superpowers/current/specs/2026-05-11-v8.4-web-account-mobile-design.md`
- Plan correnti:
  - `docs/superpowers/current/plans/2026-05-11-v8.4-web-account-mobile.md`

## Prossima Milestone

- v8.4 — Web Account Polish + Mobile Controls Pass.

### Idee candidate da valutare

- **v8.2 Enemy/Tower Codex:** schermate consultabili con torri, nemici, elementi, matchup, boss powerup e terrain.
- **v8.2 Meta Progression leggera:** XP profilo, badge, statistiche permanenti e unlock cosmetici non gameplay-breaking.
- **v8.2 Run Modifiers / Mutators:** scelta pre-run di bonus/malus per aumentare replay value.
- **v8.3 Map Preview + Seed Selection:** preview mappa, seed casuale/manuale e reroll limitato prima della run.
- **v8.3 Boss Rework:** boss con fasi, abilita` telegrafate, reward/scelte dopo kill.
- **v8.3 Event Log / Combat Recap:** recap fine wave con danni per torre, gold speso, riparazioni, leak ed eventi.
- **v8.4 Web Account Polish:** pagina profilo web con statistiche, best score, DLC attivi e save status.
- **v8.4 Mobile Controls Pass:** layout e touch target dedicati per telefono/tablet.

Priorita` consigliata: prossimo passo naturale **v8.4 Web Account Polish + Mobile Controls Pass**, per rifinire profilo web e UX touch dopo le feature gameplay v8.1-v8.3.

## Repository

- **Gioco (principale):** `https://github.com/alessandroj-Claude/tower-defense-pygame-CODEX`
- **Web frontend (Next.js):** `https://github.com/alessandroj-Claude/towerdefense-web` — deploy su Vercel
- **Backend (FastAPI):** deploy su Render — `https://tower-defense-cj.onrender.com`

## Dominio Web (registrato)

- Dominio principale registrato: `towerdefense-cj.online` (annotato il 2026-05-05).
