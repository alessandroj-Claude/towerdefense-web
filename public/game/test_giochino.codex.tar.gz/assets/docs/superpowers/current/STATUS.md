# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-19 (v10.7 completato)

## Piano Attivo

(nessuno pianificato)

## Prossimi

(nessuno pianificato)

## Ultimo Piano Completato

- `v10.7` — Key System Overhaul — runtime v10.7
- Spec: `docs/superpowers/implemented/specs/2026-05-18-v10.7-key-overhaul-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-18-v10.7-key-overhaul.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.7`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.
- Test renderer/game falliscono quando eseguiti insieme per ordering/pygame init — passano tutti individualmente.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
