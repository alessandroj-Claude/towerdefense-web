# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-13 (v9.3 completata)

### Aggiornamento Operativo (v8.1 — Daily/Weekly Challenges + DPR Rendering Fix, 2026-05-11)

- Daily/Weekly Challenges: definizioni deterministiche, seed dedicati e modificatori `rich_start`, `fast_fliers`, `boss_pressure`.
- Mappa seeded per challenge tramite `GameMap(..., rng=...)`, con run standard backward-compatible.
- Menu principale con entry Daily/Weekly e badge HUD challenge durante la run.
- Save/load e leaderboard persistono `challenge_kind` + `challenge_id`; API backend/client espongono record/query filtrabili.
- Web DPR template consolidato: helper `towerDefenseDpr()`, clamp max 2, `imageRendering` automatico su HiDPI e dataset CSS per debug.
- Build desktop/web aggiornata a `v8.1`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.1.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.1-challenges-dpr-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.1-challenges-dpr.md`

### Aggiornamento Operativo (v8.2 — Codex + Meta Progression + Run Mutators, 2026-05-11)

- Codex: 37 entry immutabili (Towers/Enemies/Elements/Terrain/Events/Boss), schermata consultabile dal menu, offline.
- Mutators: 6 mutator (3 bonus + 3 malus), validazione max 1+1, flow DIFFICULTY→MUTATOR_SELECTION→PERK_SELECTION.
- Meta Progression: XP formula (capped 500), livello da sqrt, 4 badge, `profile_stats` DB locale + backend API autenticata.
- Leaderboard: `mutators_json` + `score_mult` su `score_runs`; backward compat su righe legacy.
- Game Over: XP/livello/badge mostrati in overlay; `_progression_recorded` per idempotenza.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.2-codex-progression-mutators-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.2-codex-progression-mutators.md`

### Aggiornamento Operativo (v8.3 — Map Preview + Boss Rework + Combat Recap, 2026-05-11)

- Map Preview: seed manuale/casuale, reroll limitati, preview deterministica e challenge seed locked.
- Boss Rework: fasi HP, abilita` telegrafate `summon_swarm`/`armor_pulse`, indicatori renderer e reward post-boss.
- Boss Reward: scelta tra `gold_cache`, `field_repair`, `overclock_token`, con save/load pending reward.
- Combat Recap: log wave con danni per torre, kill, gold, repair/upgrade, vite perse, eventi e boss ability.
- Build desktop/web aggiornata a `v8.3`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.3.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.3-map-boss-recap-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.3-map-boss-recap.md`

### Aggiornamento Operativo (v8.10 — Achievement System, 2026-05-12)

- `src/achievements.py`: 25 achievement (frozen dataclass), `check_run_achievements` pura, `unlock_achievements`/`get_unlocked` con lazy DB import.
- `src/db.py`: tabella `user_achievements` + migration `_ensure_user_achievements_table`.
- `src/game.py`: `_run_stats` accumulator + hooks (towers/synergy/powerup/repair/lives/boss); achievement unlock a game over; badge row in `_draw_game_over`.
- `backend/achievements.py`: `GET /achievements/{user_id}` owner-only + auth.
- `towerdefense-web`: `getAchievements` in api.ts; griglia "Obiettivi" in /account.
- 1026 test passing.
- Build desktop/web aggiornata a `v8.10`; artifact archiviato in `dist/implemented/TowerDefense-v8.10.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-12-v8.10-achievements-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-12-v8.10-achievements.md`

### Aggiornamento Operativo (v8.9 — Wave Preview Panel, 2026-05-12)

- `src/wave.py`: `wave_preview(wave_number) -> dict` pura. Composizione nemici per tipo (nome/icona/count), flag boss, totale.
- `src/renderer/hud.py`: `draw_wave_preview_panel()` overlay durante countdown. Bordo rosso se boss, icone nemici, countdown hint.
- `src/game.py`: `_wave_preview` + `_refresh_wave_preview()` chiamato a ogni inizio countdown; panel in entrambi i path draw.
- 1010 test passing.
- Build desktop/web aggiornata a `v8.9`; artifact archiviato in `dist/implemented/TowerDefense-v8.9.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-12-v8.9-wave-preview-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-12-v8.9-wave-preview.md`

### Aggiornamento Operativo (v8.8 — Endless/Survival Mode, 2026-05-11)

- `src/adaptive.py`: endless caps (hp 5.0/speed 4.0/dmg 4.0), exp aggressivo post-wave 30, `is_endless()` helper.
- `src/economy.py`: preset `"endless"` (5 lives, 200 gold).
- `src/renderer/menus.py`: pulsante "Endless" (viola) nella schermata difficoltà.
- `src/game.py`: leaderboard dicts con chiave "endless"; `wave=` passato ad `apply_adaptive_increment`; `_compute_endless_score()`; HUD wave counter colorato per lives (verde/giallo/arancio/rosso); override score a GAME_OVER endless.
- `src/db.py`: colonna `mode TEXT DEFAULT 'normal'` su `score_runs` + migration.
- `src/leaderboard.py`: "endless" in `VALID_DIFFICULTIES`; filtro `mode` in record/query.
- `backend/models.py` + `backend/leaderboard.py`: campo `mode` in POST/GET leaderboard.
- 1001 test passing.
- Build desktop/web aggiornata a `v8.8`; artifact archiviato in `dist/implemented/TowerDefense-v8.8.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.8-endless-mode-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.8-endless-mode.md`

### Aggiornamento Operativo (v8.7 — Tower Synergy System, 2026-05-11)

- `src/synergy.py`: modulo puro, 6 regole synergy, `compute_synergies`/`apply_synergy_bonuses`/`reset_synergy_bonuses` idempotente. Bonus runtime-only (no mutazione class attrs).
- `src/game.py`: `_refresh_synergies()` dopo ogni place/remove torre; `_active_synergies` lista corrente.
- `src/ui.py`: badge synergy (max 2, amber) nel panel quando torre selezionata. `draw()` accetta `active_synergies`.
- 990 test passing.
- Build desktop/web aggiornata a `v8.7`; artifact archiviato in `dist/implemented/TowerDefense-v8.7.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.7-tower-synergy-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.7-tower-synergy.md`

### Aggiornamento Operativo (v8.6 — Retina Canvas Clarity + PWA, 2026-05-11)

- `index.html`: rimosso override bilinear → `imageRendering = "pixelated"` sempre. `tdWatchCanvasRendering()` con MutationObserver. Viewport unificato con `user-scalable=no, viewport-fit=cover`.
- `site.webmanifest`: nuovo file PWA (standalone, start_url=/play, theme #1a1a2e).
- `layout.tsx`: manifest + themeColor viewport + apple-mobile-web-app meta.
- 979 test passing (+3 nuovi test_web_template).
- Build desktop/web aggiornata a `v8.6`; artifact archiviato in `dist/implemented/TowerDefense-v8.6.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.6-retina-pwa-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.6-retina-pwa.md`

### Aggiornamento Operativo (v8.5 — Web Leaderboard + Run History, 2026-05-11)

- Backend: `src/leaderboard.py` `top5_global`/`top5_user` con `limit` param (era hardcoded 5). `GET /leaderboard/global` reso pubblico (no auth). `LeaderboardEntry` aggiunto `created_at`.
- Web: pagina `/leaderboard` pubblica con tab Normal/Hard, tabella top-20, fallback backend unavailable. Nav aggiornata con link Leaderboard.
- `/account` dashboard: sezione "Partite recenti" (ultime 10 run), fetch parallela. `getUserRuns` + `LeaderboardEntry` type in `api.ts`.
- 976 test passing.
- Build desktop/web aggiornata a `v8.5`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.5.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.5-leaderboard-run-history-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.5-leaderboard-run-history.md`

### Aggiornamento Operativo (v8.4 — Web Account Polish + Mobile Controls Pass, 2026-05-11)

- Web frontend (`towerdefense-web`): `/account` dashboard (login/register, profilo, cloud save, DLC, stats, logout). Nav con link Account. `/play` overlay auth status.
- Helper `src/lib/api.ts` + `src/lib/auth.ts`: login/register/getSavesMeta/getAuthMe/getProfileStats con localStorage `td.auth`.
- Backend (`backend/`): FastAPI + SQLite, HMAC token. Nuovi endpoint `GET /auth/me` e `GET /saves/{user_id}/meta` (owner-only).
- Web template mobile: `applyTouchMetadata()` con body classes `td-touch`/`td-portrait`/`td-landscape` + datasets touch/orientation/viewport.
- Runtime touch UI: `UI(touch_mode=True)` — primary buttons >= 36px, spacing >= 6px.
- Sell button: `SellTowerCommand` in `ui_commands.py`; pulsante Sell visibile quando torre selezionata; game.py handler con rimborso 75%.
- 976 test passing.
- Build desktop/web aggiornata a `v8.4`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.4.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.4-web-account-mobile-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.4-web-account-mobile.md`

## Runtime / Build

- TowerDefense build/runtime corrente: `v8.10` (desktop + web, `src/game.py` runtime marker)
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo
- Ultimo piano completato: `v8.10` (Achievement System)
- Piani aperti: nessuno

## Prossima Milestone

da definire.

## Roadmap v8.5–v8.8

- **v8.5 — Web Leaderboard + Run History:** pagina `/leaderboard` su towerdefense-web (top globale, filtri difficoltà/challenge). Sezione "Run History" in `/account` (ultime N partite con score/wave/mutatori). Backend: endpoint paginato `/leaderboard/global` + `/leaderboard/user/{id}/history`.
- **v8.6 — Retina Canvas Clarity + PWA:** piano aperto. Rimozione override bilinear, MutationObserver canvas, viewport unificato, site.webmanifest + theme-color.
- **v8.7 — Tower Synergy System:** piano aperto. `src/synergy.py` puro, 6 coppie (Ice+Sniper, Ice+Storm, Bomb+Inferno, Medic+Sentinel, Venom+Basic, AntiAir+Sniper), badge UI quando tower selezionata.
- **v8.8 — Endless/Survival Mode:** piano aperto. Modalità senza fine wave con difficoltà crescente esponenziale, leaderboard separata (`mode="endless"`), `adaptive.py` esteso con cap removal e scaling aggressivo post-wave 30.

### Piano v9.1 — Navbar Active State + Homepage Refresh (COMPLETATA, 2026-05-13)

### Piano v9.2 — Account Stats Card Fix (COMPLETATA, 2026-05-13)

### Piano v9.8 — Run Stats Live Overlay (IN CORSO, 2026-05-13)

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.8-run-stats-overlay-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.8-run-stats-overlay.md`

### Piano v9.7 — LightningTower (COMPLETATA, 2026-05-13)

- `src/tower.py`: `LightningTower` (element=AIR, base_cost=160, chain_count=2, chain_range=80, chain_damage_mult=0.5)
- `src/elements.py`: AIR vs EARTH 1.4, AIR vs FIRE 0.8
- `src/synergy.py`: "Storm Surge" (LightningTower+AntiAirTower → Lightning +20% DMG) — 7 synergy totali
- `src/achievements.py`: all_synergies threshold 6→7
- `src/game.py`: `_chain_visuals`, chain mechanic dopo hit primario (max 2 target, 50% dmg, elem_mult), tick + draw
- `src/renderer/entities.py`: visual_kind "lightning" + `draw_chain_visuals` (archi SRCALPHA fade)
- `src/ui.py`: LightningTower in TOWER_CLASSES/SHOP_INFO/SPECIALS
- `src/game_codex.py`: CodexEntry tower_lightning
- 1040 test passing. Web build 610K.
- Spec: `docs/superpowers/current/specs/2026-05-13-v9.7-lightning-tower-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.7-lightning-tower.md`

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.7-lightning-tower-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.7-lightning-tower.md`

### Piano v9.6 — Audio System (COMPLETATA, 2026-05-13)

- `src/audio.py`: `AudioManager` singleton, `_make_tone_buf` stdlib (array+math), 8 suoni sintetici (tower_fire, enemy_death, wave_start, wave_complete, boss_arrival, achievement_unlock, game_over, level_up)
- `src/game.py`: import, `_audio_fire_cooldown`, hook su tower_fire (rate-limited 0.05s), enemy_death, boss_arrival, wave_complete, game_over, achievement_unlock; M-key mute toggle
- `src/game_wave_mixin.py`: wave_start in `_on_wave_started`
- 1032 test passing. Web build 608K.
- Spec: `docs/superpowers/current/specs/2026-05-13-v9.6-audio-system-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.6-audio-system.md`

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.6-audio-system-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.6-audio-system.md`

### Piano v9.5 — Achievement Toast Mid-Game (COMPLETATA, 2026-05-13)

- `src/achievements.py`: `check_partial_achievements(run_stats, trigger)` + `_TRIGGER_CHECKS` mapping 9 trigger → achievement IDs
- `src/game.py`: `_achievement_toast_queue`, `_achievement_toast_timer`, `_achievement_toast_shown`; `_queue_partial_achievements(trigger)` + `_update_toast_queue(real_dt)`; hook su tower_placed/synergy/boss_kill/wave_complete; draw call durante PLAYING
- `src/renderer/hud.py`: `draw_achievement_toast(surface, achievement, timer, duration, font)` — pannello top-right, gold border, fade-out ultimi 0.5s
- 1026 test passing.
- Spec: `docs/superpowers/current/specs/2026-05-13-v9.5-achievement-toast-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.5-achievement-toast.md`

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.5-achievement-toast-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.5-achievement-toast.md`

### Piano v9.4 — Dark Mode (COMPLETATA, 2026-05-13)

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.4-dark-mode-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.4-dark-mode.md`

### Piano v9.3 — News System Static JSON (COMPLETATA, 2026-05-13)

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.3-news-system-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.3-news-system.md`

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.2-account-stats-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.2-account-stats.md`

- Spec: `docs/superpowers/current/specs/2026-05-13-v9.1-navbar-homepage-design.md`
- Plan: `docs/superpowers/current/plans/2026-05-13-v9.1-navbar-homepage.md`

## Repository

- **Gioco (principale):** `https://github.com/alessandroj-Claude/tower-defense-pygame-CODEX`
- **Web frontend (Next.js):** `https://github.com/alessandroj-Claude/towerdefense-web` — deploy su Vercel
- **Backend (FastAPI):** deploy su Render — `https://tower-defense-cj.onrender.com`

## Dominio Web (registrato)

- Dominio principale registrato: `towerdefense-cj.online` (annotato il 2026-05-05).
