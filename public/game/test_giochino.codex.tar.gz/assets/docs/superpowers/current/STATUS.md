# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-21 (v10.10 in corso)

## Piano Attivo

- `v10.10` — Mid-Run Events (in corso)
  - Spec: `docs/superpowers/current/specs/2026-05-20-v10.10-run-events-design.md`
  - Plan: `docs/superpowers/current/plans/2026-05-20-v10.10-run-events.md`

## Prossimi

## Idee Future (non pianificate)

- **Tower Draft Mode** — ogni run ha accesso solo a 5–6 torri casuali dalla pool; il giocatore deve adattare la strategia. Candidata per v10.11+.

## Ultimo Piano Completato

- `v10.9` — Tower XP / Veteran System — runtime v10.9
- Spec: `docs/superpowers/implemented/specs/2026-05-20-v10.9-tower-xp-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-20-v10.9-tower-xp.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.9`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.
- Test renderer/game falliscono quando eseguiti insieme per ordering/pygame init — passano tutti individualmente.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
