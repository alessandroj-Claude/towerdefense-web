# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-13 (v10.0 completata)

## Piano Attivo

- Nessuno.
- Ultimo piano completato: `v10.0` — Architecture Maintenance Pass
- Spec: `docs/superpowers/implemented/specs/2026-05-13-v10.0-architecture-maintenance-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-13-v10.0-architecture-maintenance.md`

## Runtime / Build

- TowerDefense runtime/build corrente: `v10.0`
- Artifact desktop corrente: `dist/current/TowerDefense.app`
- Artifact desktop archiviato: `dist/implemented/TowerDefense-v10.0.app`
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo

## Risultato v10.0

Ridotto il rischio di manutenzione senza cambiare gameplay, UX pubblica, backend contract o formato dei salvataggi.

Completato:
- `src/game_tutorial.py`: helper tutorial first-run estratti da `src/game.py`
- `src/game_run_stats.py`: aggregazione run stats estratta da `src/game.py`
- `src/renderer/tutorial.py`: renderer tutorial estratto da `src/renderer/menus.py`
- test dedicati per tutorial/run stats/tutorial renderer
- `tests/test_game.py` alleggerito
- audit mirato degli `except Exception` critici
- build desktop v10.0 archiviata

## Verifiche v10.0

- `python3 -m pytest -v` -> `1068 passed`
- `bash scripts/check_doc_sync.sh` -> OK
- `bash build.sh` -> OK, con warning PyInstaller di code signing manuale
- `dist/implemented/TowerDefense-v10.0.app` creato

## Note QA Correnti

- Smoke `backend/tests`: non green per failure non introdotte dal piano v10.0 (`backend.main.ALLOWED_ORIGINS` mancante e 401 su route DLC/profile stats). La suite principale configurata da `pytest.ini` resta `tests/`.

## Storico

Storico completo versioni e piani completati: `docs/VERSION_HISTORY.md` e `docs/superpowers/implemented/`.
