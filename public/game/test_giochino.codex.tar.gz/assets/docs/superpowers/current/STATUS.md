# Stato Corrente (Fonte Unica)

Ultimo aggiornamento: 2026-05-11 (v8.4 completata)

### Aggiornamento Operativo (v8.1 — Daily/Weekly Challenges + DPR Rendering Fix, 2026-05-11)

- Daily/Weekly Challenges: definizioni deterministiche, seed dedicati e modificatori `rich_start`, `fast_fliers`, `boss_pressure`.
- Mappa seeded per challenge tramite `GameMap(..., rng=...)`, con run standard backward-compatible.
- Menu principale con entry Daily/Weekly e badge HUD challenge durante la run.
- Save/load e leaderboard persistono `challenge_kind` + `challenge_id`; API backend/client espongono record/query filtrabili.
- Web DPR template consolidato: helper `towerDefenseDpr()`, clamp max 2, `imageRendering` automatico su HiDPI e dataset CSS per debug.
- Build desktop/web aggiornata a `v8.1`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.1.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.1-challenges-dpr-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.1-challenges-dpr.md`

### Aggiornamento Operativo (v8.2 — Codex + Meta Progression + Run Mutators, 2026-05-11)

- Codex: 37 entry immutabili (Towers/Enemies/Elements/Terrain/Events/Boss), schermata consultabile dal menu, offline.
- Mutators: 6 mutator (3 bonus + 3 malus), validazione max 1+1, flow DIFFICULTY→MUTATOR_SELECTION→PERK_SELECTION.
- Meta Progression: XP formula (capped 500), livello da sqrt, 4 badge, `profile_stats` DB locale + backend API autenticata.
- Leaderboard: `mutators_json` + `score_mult` su `score_runs`; backward compat su righe legacy.
- Game Over: XP/livello/badge mostrati in overlay; `_progression_recorded` per idempotenza.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.2-codex-progression-mutators-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.2-codex-progression-mutators.md`

### Aggiornamento Operativo (v8.3 — Map Preview + Boss Rework + Combat Recap, 2026-05-11)

- Map Preview: seed manuale/casuale, reroll limitati, preview deterministica e challenge seed locked.
- Boss Rework: fasi HP, abilita` telegrafate `summon_swarm`/`armor_pulse`, indicatori renderer e reward post-boss.
- Boss Reward: scelta tra `gold_cache`, `field_repair`, `overclock_token`, con save/load pending reward.
- Combat Recap: log wave con danni per torre, kill, gold, repair/upgrade, vite perse, eventi e boss ability.
- Build desktop/web aggiornata a `v8.3`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.3.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.3-map-boss-recap-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.3-map-boss-recap.md`

### Aggiornamento Operativo (v8.5 — Web Leaderboard + Run History, 2026-05-11)

- Backend: `src/leaderboard.py` `top5_global`/`top5_user` con `limit` param (era hardcoded 5). `GET /leaderboard/global` reso pubblico (no auth). `LeaderboardEntry` aggiunto `created_at`.
- Web: pagina `/leaderboard` pubblica con tab Normal/Hard, tabella top-20, fallback backend unavailable. Nav aggiornata con link Leaderboard.
- `/account` dashboard: sezione "Partite recenti" (ultime 10 run), fetch parallela. `getUserRuns` + `LeaderboardEntry` type in `api.ts`.
- 976 test passing.
- Build desktop/web aggiornata a `v8.5`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.5.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.5-leaderboard-run-history-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.5-leaderboard-run-history.md`

### Aggiornamento Operativo (v8.4 — Web Account Polish + Mobile Controls Pass, 2026-05-11)

- Web frontend (`towerdefense-web`): `/account` dashboard (login/register, profilo, cloud save, DLC, stats, logout). Nav con link Account. `/play` overlay auth status.
- Helper `src/lib/api.ts` + `src/lib/auth.ts`: login/register/getSavesMeta/getAuthMe/getProfileStats con localStorage `td.auth`.
- Backend (`backend/`): FastAPI + SQLite, HMAC token. Nuovi endpoint `GET /auth/me` e `GET /saves/{user_id}/meta` (owner-only).
- Web template mobile: `applyTouchMetadata()` con body classes `td-touch`/`td-portrait`/`td-landscape` + datasets touch/orientation/viewport.
- Runtime touch UI: `UI(touch_mode=True)` — primary buttons >= 36px, spacing >= 6px.
- Sell button: `SellTowerCommand` in `ui_commands.py`; pulsante Sell visibile quando torre selezionata; game.py handler con rimborso 75%.
- 976 test passing.
- Build desktop/web aggiornata a `v8.4`; artifact desktop archiviato in `dist/implemented/TowerDefense-v8.4.app`.
- Spec: `docs/superpowers/implemented/specs/2026-05-11-v8.4-web-account-mobile-design.md`
- Plan: `docs/superpowers/implemented/plans/2026-05-11-v8.4-web-account-mobile.md`

## Runtime / Build

- TowerDefense build/runtime corrente: `v8.5` (desktop + web, `src/game.py` runtime marker)
- Web backend: FastAPI su Render (`https://tower-defense-cj.onrender.com`) + backend/ locale in repo
- Ultimo piano completato: `v8.5` (Web Leaderboard + Run History)
- Piani attuali in esecuzione: v8.6, v8.7, v8.8
- Spec correnti:
  - docs/superpowers/current/specs/2026-05-11-v8.6-retina-pwa-design.md
  - docs/superpowers/current/specs/2026-05-11-v8.7-tower-synergy-design.md
  - docs/superpowers/current/specs/2026-05-11-v8.8-endless-mode-design.md
- Plan correnti:
  - docs/superpowers/current/plans/2026-05-11-v8.6-retina-pwa.md
  - docs/superpowers/current/plans/2026-05-11-v8.7-tower-synergy.md
  - docs/superpowers/current/plans/2026-05-11-v8.8-endless-mode.md

## Prossima Milestone

v8.6 — Retina Canvas Clarity + PWA (piano aperto).

## Roadmap v8.5–v8.8

- **v8.5 — Web Leaderboard + Run History:** pagina `/leaderboard` su towerdefense-web (top globale, filtri difficoltà/challenge). Sezione "Run History" in `/account` (ultime N partite con score/wave/mutatori). Backend: endpoint paginato `/leaderboard/global` + `/leaderboard/user/{id}/history`.
- **v8.6 — Retina Canvas Clarity + PWA:** piano aperto. Rimozione override bilinear, MutationObserver canvas, viewport unificato, site.webmanifest + theme-color.
- **v8.7 — Tower Synergy System:** piano aperto. `src/synergy.py` puro, 6 coppie (Ice+Sniper, Ice+Storm, Bomb+Inferno, Medic+Sentinel, Venom+Basic, AntiAir+Sniper), badge UI quando tower selezionata.
- **v8.8 — Endless/Survival Mode:** piano aperto. Modalità senza fine wave con difficoltà crescente esponenziale, leaderboard separata (`mode="endless"`), `adaptive.py` esteso con cap removal e scaling aggressivo post-wave 30.

## Repository

- **Gioco (principale):** `https://github.com/alessandroj-Claude/tower-defense-pygame-CODEX`
- **Web frontend (Next.js):** `https://github.com/alessandroj-Claude/towerdefense-web` — deploy su Vercel
- **Backend (FastAPI):** deploy su Render — `https://tower-defense-cj.onrender.com`

## Dominio Web (registrato)

- Dominio principale registrato: `towerdefense-cj.online` (annotato il 2026-05-05).
