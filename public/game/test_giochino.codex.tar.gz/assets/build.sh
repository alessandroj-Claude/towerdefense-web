#!/usr/bin/env bash
set -e
echo "Installing dependencies..."
pip3 install -r requirements-build.txt --quiet 2>/dev/null || python3 -m pip install -r requirements-build.txt --quiet
echo "Building TowerDefense.app..."
mkdir -p dist/current build/current
pyinstaller -y --windowed \
  --name "TowerDefense" \
  --distpath "dist/current" \
  --workpath "build/current" \
  --hidden-import pygame \
  --hidden-import _tkinter \
  main.py 2>/dev/null || \
python3 -m PyInstaller -y --windowed \
  --name "TowerDefense" \
  --distpath "dist/current" \
  --workpath "build/current" \
  --hidden-import pygame \
  --hidden-import _tkinter \
  main.py
echo "Build complete: dist/current/TowerDefense.app"
