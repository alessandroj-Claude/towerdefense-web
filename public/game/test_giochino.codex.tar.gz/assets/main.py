import asyncio
import os
import sys

# Pygbag scans __main__ imports to resolve wasm wheels.
# Keep this explicit so pygame runtime modules (display/font/...) are available on web.
if sys.platform == "emscripten":
    import pygame  # noqa: F401

from src.game import Game


def _run_desktop() -> None:
    # Desktop startup splash (not supported on emscripten/web)
    splash_pid = os.fork()

    if splash_pid == 0:
        import signal
        import tkinter as tk
        from tkinter import ttk

        signal.alarm(30)  # hard kill if parent dies before us
        root = tk.Tk()
        root.title("Tower Defense")
        root.configure(bg="#0d1117")
        root.resizable(False, False)
        width, height = 460, 148
        screen_w = root.winfo_screenwidth()
        screen_h = root.winfo_screenheight()
        root.geometry(f"{width}x{height}+{(screen_w - width) // 2}+{(screen_h - height) // 2}")

        tk.Label(root, text="TOWER DEFENSE", fg="white", bg="#0d1117", font=("Arial", 26, "bold")).pack(
            pady=(18, 5)
        )
        tk.Label(root, text="Caricamento...", fg="#909090", bg="#0d1117", font=("Arial", 12)).pack()

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("S.Horizontal.TProgressbar", background="#50c864", troughcolor="#1e2a1e", bordercolor="#0d1117")
        progress = ttk.Progressbar(root, style="S.Horizontal.TProgressbar", length=380, mode="indeterminate")
        progress.pack(pady=10)
        progress.start(12)
        root.mainloop()
        sys.exit(0)

    try:
        os.kill(splash_pid, 9)
        os.waitpid(splash_pid, os.WNOHANG)
    except OSError:
        pass

    Game().run()


async def _run_web() -> None:
    game = Game()
    await game.run_async()


if __name__ == "__main__":
    if sys.platform == "emscripten":
        asyncio.run(_run_web())
    else:
        _run_desktop()
