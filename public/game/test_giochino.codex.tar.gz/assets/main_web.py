import asyncio

import src.i18n as i18n
from src.game import Game


def _read_web_locale() -> str:
    try:
        import platform as _plat
        val = _plat.window.localStorage.getItem("td.lang")
        if val in ("en", "it"):
            return val
    except Exception:
        pass
    return "en"


async def main() -> None:
    i18n.init(_read_web_locale())
    game = Game()
    await game.run_async()


if __name__ == "__main__":
    asyncio.run(main())
