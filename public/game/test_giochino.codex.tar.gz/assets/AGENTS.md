# AGENTS.md

Questo file fornisce linee guida a Codex (Codex.ai/code) quando lavora sul codice di questo repository.

## Nota di migrazione

`AGENTS.md` è la fonte unica di verità per le regole del progetto nelle sessioni Codex.

Riferimenti legacy:
- `CLAUDE.md` era il file equivalente per le sessioni Claude.
- File di piano storici possono ancora esistere in `.claude/plans/`.
- Per i workflow Codex, usa `docs/superpowers/...` come posizione canonica per piani/spec.

Archivio legacy:
- `legacy_files/` contiene file dell'era Claude mantenuti solo per archivio.
- Nelle sessioni Codex, ignora tutto in `legacy_files/` a meno che l'utente non chieda esplicitamente di usarlo.

## Setup sessione

Attiva la modalità `/caveman ultra` all'inizio di ogni sessione in questo progetto.

### Stato operativo corrente (2026-05-05)

- Milestone corrente: **v7.4 web deployment** (in corso).
- Dominio pubblico: `towerdefense-cj.online` (Vercel).
- Backend pubblico: `https://tower-defense-cj.onrender.com` (Render).
- Repo web separata: `towerdefense-web` (Next.js), annidata localmente ma con git indipendente.
- Focus operativo: validazione auth/register/save/load cloud in web e riduzione fallback locale.

Quando si eseguono comandi Bash con Python: impostare sempre un timeout esplicito a livello comando/tooling. Non lanciare processi bloccanti in background senza kill esplicito: i processi orfani consumano RAM illimitata.

Quando si entra in **plan mode**, attivare sempre la skill `superpowers` pertinente (es. `systematic-debugging`, `brainstorming`, ecc.) prima di qualsiasi altra azione.

**Efficienza token:** non rileggere file già letti nella stessa sessione. Usa `offset`/`limit` per file grandi. Dopo un'edit, rileggi solo le righe modificate.

## Skill locali

Quando rilevanti, usa le skill locali in `skills/`:
- `skills/repo-scout/SKILL.md`: da usare all'inizio di task su aree poco familiari o prima di modifiche strutturali, per mappare entrypoint, config, test e file coinvolti.
- `skills/bug-triage/SKILL.md`: da usare per bug/test failing/regressioni; seguire il flusso riproduzione -> root cause probabile -> fix minimo -> validazione mirata -> rischi.
- `skills/parallel-investigation/SKILL.md`: da usare solo quando il problema è divisibile in filoni indipendenti e la delega a subagenti porta evidenza complementare utile alla decisione.
- `skills/parallel-plan-execution/SKILL.md`: dopo aver formulato un piano, usarla quando possibile per eseguire task indipendenti in parallelo con ownership disgiunta, TDD e integrazione controllata.
- `skills/context-budget-keeper/SKILL.md`: da usare per minimizzare token in task lunghi (selezione file minimi, budget per fase, summary incrementale).
- `skills/plan-doc-sync/SKILL.md`: da usare quando apri/chiudi task o piani per allineare `AGENTS.md`, `CURRENT_VERSION`, `STATUS.md`, `ARCHITECTURE.md`, `VERSION_HISTORY.md`.
- `skills/prompt-delta-logger/SKILL.md`: da usare per riportare solo delta tecnico tra task consecutivi (niente riassunti ridondanti).
- `skills/targeted-test-runner/SKILL.md`: da usare per scegliere subset `pytest` minimo in base ai file toccati.

Regola operativa: evita uso automatico delle skill su task piccoli o fortemente sequenziali; applicale quando aumentano chiarezza, velocità o qualità della decisione.

### Auto-attivazione skill
- Non aspettare sempre input manuale: se il task corrisponde chiaramente a una skill locale, attivala automaticamente.
- In caso di dubbio su codebase/entrypoint prima di modificare codice: esegui prima `repo-scout`.
- In presenza di bug regressivi o test failing: esegui `bug-triage` come default.
- Dopo formulazione di un piano: valuta sempre `parallel-plan-execution`; se i task sono indipendenti, usala.

### Policy subagenti
- Quando crei subagenti, assegna esplicitamente la skill da usare (nome + path `skills/.../SKILL.md`) nel prompt del subagente.
- Il subagente deve seguire formato output della skill assegnata e restituire evidenze verificabili (file, test, rischi).
- Evita subagenti senza skill quando esiste una skill chiaramente pertinente al loro scope.
- Se il task del subagente è piccolo o sequenziale, documenta perché non stai usando skill specifiche.

---

## Repository

GitHub: https://github.com/alessandroj-Claude/tower-defense-pygame-CODEX (privato)

Architettura dettagliata + file tree: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)

---

## Progetto

Tower defense (Python + Pygame → macOS `.app`). Mappa procedurale, 5 nemici, 4 torri, ondate, economia, difficoltà. Vedi [`docs/VERSION_HISTORY.md`](docs/VERSION_HISTORY.md) per funzionalità complete.

---

## Piano di implementazione

Metodologia: **Sviluppo guidato da subagenti** con **TDD**, i subagenti devono essere configurati sia nel model che nell'effort.
- **Policy modelli obbligatoria:** non usare `gpt-5.4`. Modelli consentiti: solo `gpt-5.3-codex` o `gpt-5.4-mini`.
- **Policy effort obbligatoria:** effort massimo consentito `medium` (mai `high`/`xhigh`).
- **Workflow obbligatorio per nuove richieste:** prima di qualunque implementazione, creare sempre **spec** + **plan** sotto `docs/superpowers/current/` (seguendo formato dei piani precedenti). Non iniziare modifiche codice finché questi file non esistono e non sono allineati con l'utente.
- **Task design per subagenti:** ogni piano deve includere task implementativi pensati per subagenti, con ownership chiara dei file e strategia di parallelizzazione quando possibile.
- **Model planning obbligatorio nei docs:** durante creazione di spec/plan, per ogni task indica sempre in anticipo `model` + `reasoning_effort` consigliati, rispettando la policy: `gpt-5.4-mini` per task piccoli/isolati, `gpt-5.3-codex` per task piu` complessi su runtime/shared files. Effort massimo `medium`. Questo mapping va scritto esplicitamente nel piano prima di iniziare l'implementazione.
- **Default operativo:** usare subagenti per i task di piano ogni volta che è tecnicamente possibile; se un task viene eseguito inline, documentare esplicitamente nel log/piano perché è sequenziale o troppo piccolo per la delega.
- Ogni task: subagente dedicato → scrivi test → FAIL → implementa → PASS → commit
- Dopo ogni task: spec + quality review **inline** (no subagent reviewer — troppo costoso)
- **Dopo ogni task completato:** aggiorna `[ ]` → `[x]` nel piano worktree + copia su `main` + commit su entrambi + `git push origin main`
- **Fine di ogni piano (nuova versione):** `git merge feature/vX.Y` su main → push → `bash build.sh` (output diretto in `dist/current/TowerDefense.app`) → copia obbligatoria in `dist/implemented/TowerDefense-vX.Y.app`.
- **Post-build artifact policy (`dist/`):** dopo ogni build finale riuscita, archivia la build versionata in `dist/implemented/` (es. `TowerDefense-vX.Y.app`) e aggiorna la build corrente in `dist/current/` (es. `TowerDefense.app`) tramite spostamento/copia.
- **Regola hard release artifact:** anche se il build produce direttamente `dist/current/TowerDefense.app`, a fine piano va sempre creato/aggiornato anche `dist/implemented/TowerDefense-vX.Y.app` coerente con la versione del piano.
- **Version marker separati (`current`):** mantieni aggiornati i marker di versione indipendenti:
  - `docs/superpowers/current/CURRENT_VERSION` per piani/spec correnti
  - `dist/current/CURRENT_VERSION` per build corrente
  Nota: docs e dist possono essere volutamente su versioni diverse.
- **Build principale (TowerDefense):** chiedere esplicitamente se vuoi aggiornare anche `DLCKeygen.app` nello stesso giro **solo se** nel piano corrente sono stati modificati file relativi a DLCKeygen (es. `keygen_main.py`, `build_keygen.sh`, test/docs dedicati).
- **Fine di un piano di bugfix:** `bash build.sh` direttamente
- **Fine di ogni piano (a implementazione completata, dopo build app riuscita):** aggiorna `docs/VERSION_HISTORY.md` + `docs/ARCHITECTURE.md` (file tree + moduli) + sezione "Versione corrente" qui sotto

### Piano del piano
- **Inizio:** crea ogni nuovo piano in `docs/superpowers/current/plans/YYYY-MM-DD-vX.Y.md` + spec in `docs/superpowers/current/specs/` nel worktree, committa copia su `main`, aggiorna "Versione corrente" qui sotto
- **Dopo formulazione piano:** se possibile usa `skills/parallel-plan-execution/SKILL.md` per orchestrare task parallelizzabili
- **Dopo ogni task:** marca `[x]` solo dopo spec ✅ + quality ✅ — aggiorna piano worktree, copia su main, commit+push — poi **chiedi permesso prima del task successivo**
- **Fine di ogni piano:** aggiorna la RUNTIME_VERSION in src/game.py
- **Chiusura piano (dopo build finale riuscita):** sposta piano+spec da `docs/superpowers/current/` a `docs/superpowers/implemented/`, aggiorna i riferimenti (`AGENTS.md`, `VERSION_HISTORY.md`, `ARCHITECTURE.md`, eventuali link nel piano), poi commit+push.
- **Gate hard di chiusura:** non dichiarare mai un piano completato se `docs/ARCHITECTURE.md` non è stato verificato e aggiornato (file tree/moduli/wiring) quando necessario.
- **Dopo apertura/chiusura piano:** aggiorna sempre `docs/superpowers/current/CURRENT_VERSION` in base al nuovo stato.


> Storico versioni completo: [`docs/VERSION_HISTORY.md`](docs/VERSION_HISTORY.md)

### Versione corrente e piani attivi

- Fonte unica stato corrente: [`docs/superpowers/current/STATUS.md`](docs/superpowers/current/STATUS.md)
- Marker operativo rapido: [`docs/superpowers/current/CURRENT_VERSION`](docs/superpowers/current/CURRENT_VERSION)

---

## Comandi

```bash
pip install -r requirements.txt
python3 -m pytest -v          # sempre python3 -m pytest, mai bare pytest
python3 main.py

pip install -r requirements-build.txt
bash build.sh                 # risultato: dist/current/TowerDefense.app

git push origin main
```
