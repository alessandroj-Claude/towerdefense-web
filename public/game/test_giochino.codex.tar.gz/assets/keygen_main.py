from __future__ import annotations

from src.license import AVAILABLE_DLCS, generate_key


def supported_dlc_ids() -> list[str]:
    return list(AVAILABLE_DLCS)


class DLCKeygenApp:
    def __init__(self, root):
        import tkinter as tk

        self.root = root
        self.generate_fn = generate_key
        dlc_ids = supported_dlc_ids()
        initial_dlc = dlc_ids[0] if dlc_ids else ""

        self.username_var = tk.StringVar(master=root, value="")
        self.tipo_var = tk.StringVar(master=root, value="DLC")
        self.dlc_var = tk.StringVar(master=root, value=initial_dlc)
        self.importo_var = tk.IntVar(master=root, value=50)
        self.key_var = tk.StringVar(master=root, value="")
        self.status_var = tk.StringVar(master=root, value="Pronto" if dlc_ids else "Errore: nessun DLC")

        root.title("DLCKeygen")
        root.resizable(False, False)

        frame = tk.Frame(root, padx=16, pady=16)
        frame.grid(row=0, column=0, sticky="nsew")

        tk.Label(frame, text="Username").grid(row=0, column=0, sticky="w")
        tk.Entry(frame, textvariable=self.username_var, width=32).grid(
            row=1, column=0, columnspan=2, sticky="ew", pady=(4, 12)
        )

        tk.Label(frame, text="Tipo").grid(row=2, column=0, sticky="w")
        tipo_menu = tk.OptionMenu(frame, self.tipo_var, "DLC", "Crediti", command=self._on_tipo_change)
        tipo_menu.config(width=24)
        tipo_menu.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(4, 12))

        tk.Label(frame, text="DLC").grid(row=4, column=0, sticky="w")
        self.dlc_menu = tk.OptionMenu(frame, self.dlc_var, *dlc_ids) if dlc_ids else tk.OptionMenu(frame, self.dlc_var, "")
        self.dlc_menu.config(width=24)
        self.dlc_menu.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(4, 12))

        tk.Label(frame, text="Importo (✦)").grid(row=6, column=0, sticky="w")
        self.importo_spin = tk.Spinbox(frame, textvariable=self.importo_var, values=(10, 25, 50, 100, 200, 500), width=10)
        self.importo_spin.grid(row=7, column=0, columnspan=2, sticky="w", pady=(4, 12))
        self.importo_spin.grid_remove()

        tk.Label(frame, text="Chiave").grid(row=8, column=0, sticky="w")
        self.key_entry = tk.Entry(frame, textvariable=self.key_var, width=52, state="readonly")
        self.key_entry.grid(row=9, column=0, columnspan=2, sticky="ew", pady=(4, 12))

        tk.Button(frame, text="Genera", command=self.on_generate).grid(row=10, column=0, sticky="ew", padx=(0, 6))
        tk.Button(frame, text="Copia", command=self.on_copy).grid(row=10, column=1, sticky="ew", padx=(6, 0))

        tk.Label(frame, textvariable=self.status_var).grid(row=11, column=0, columnspan=2, sticky="w", pady=(12, 0))
        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)

    def _on_tipo_change(self, value):
        if value == "Crediti":
            self.dlc_menu.grid_remove()
            self.importo_spin.grid()
        else:
            self.importo_spin.grid_remove()
            self.dlc_menu.grid()

    def on_generate(self):
        username = self.username_var.get().strip()
        if not username:
            self.key_var.set("")
            self.status_var.set("Errore: username obbligatorio")
            return

        tipo = self.tipo_var.get()
        try:
            if tipo == "DLC":
                dlc_id = self.dlc_var.get().strip()
                if dlc_id not in AVAILABLE_DLCS:
                    self.key_var.set("")
                    self.status_var.set(f"Errore: DLC non supportato: {dlc_id}")
                    return
                key = self.generate_fn(username, "dlc", dlc_id)
                self.status_var.set(f"Chiave DLC generata per {username} → {AVAILABLE_DLCS[dlc_id]}")
            else:
                amount = int(self.importo_var.get())
                key = self.generate_fn(username, "credits", str(amount))
                self.status_var.set(f"Chiave Crediti generata per {username} → ✦{amount}")
        except Exception as exc:
            self.key_var.set("")
            self.status_var.set(f"Errore generazione: {exc}")
            return

        self.key_var.set(key)

    def on_copy(self):
        key = self.key_var.get().strip()
        if not key:
            self.status_var.set("Errore: nessuna chiave da copiare")
            return
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(key)
            if hasattr(self.root, "update_idletasks"):
                self.root.update_idletasks()
        except Exception as exc:
            self.status_var.set(f"Errore clipboard: {exc}")
            return
        self.status_var.set("Chiave copiata negli appunti")


def main():
    import tkinter as tk

    root = tk.Tk()
    DLCKeygenApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
