from __future__ import annotations

from src.license import AVAILABLE_DLCS, generate_dlc_key


def supported_dlc_ids() -> list[str]:
    return list(AVAILABLE_DLCS)


class DLCKeygenApp:
    def __init__(self, root):
        import tkinter as tk

        self.root = root
        dlc_ids = supported_dlc_ids()
        initial_dlc = dlc_ids[0] if dlc_ids else ""
        self.dlc_var = tk.StringVar(master=root, value=initial_dlc)
        self.key_var = tk.StringVar(master=root, value="")
        status = "Pronto" if dlc_ids else "Errore: nessun DLC disponibile"
        self.status_var = tk.StringVar(master=root, value=status)
        self.generate_fn = generate_dlc_key

        root.title("DLCKeygen")
        root.resizable(False, False)

        frame = tk.Frame(root, padx=16, pady=16)
        frame.grid(row=0, column=0, sticky="nsew")

        tk.Label(frame, text="DLC").grid(row=0, column=0, sticky="w")
        if dlc_ids:
            self.dlc_menu = tk.OptionMenu(frame, self.dlc_var, *dlc_ids)
            self.dlc_menu.config(width=24)
        else:
            self.dlc_menu = tk.OptionMenu(frame, self.dlc_var, "")
            self.dlc_menu.config(width=24, state="disabled")
        self.dlc_menu.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(4, 12))

        tk.Label(frame, text="Chiave").grid(row=2, column=0, sticky="w")
        self.key_entry = tk.Entry(frame, textvariable=self.key_var, width=42, state="readonly")
        self.key_entry.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(4, 12))

        self.generate_button = tk.Button(frame, text="Genera", command=self.on_generate)
        self.generate_button.grid(row=4, column=0, sticky="ew", padx=(0, 6))

        self.copy_button = tk.Button(frame, text="Copia", command=self.on_copy)
        self.copy_button.grid(row=4, column=1, sticky="ew", padx=(6, 0))

        tk.Label(frame, textvariable=self.status_var).grid(
            row=5, column=0, columnspan=2, sticky="w", pady=(12, 0)
        )

        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)

    def on_generate(self):
        dlc_id = self.dlc_var.get().strip()
        if dlc_id not in AVAILABLE_DLCS:
            self.key_var.set("")
            self.status_var.set(f"Errore: DLC non supportato: {dlc_id}")
            return

        try:
            key = self.generate_fn(dlc_id)
        except ValueError:
            self.key_var.set("")
            self.status_var.set(f"Errore: DLC non supportato: {dlc_id}")
            return
        except Exception as exc:  # pragma: no cover - defensive UI guard
            self.key_var.set("")
            self.status_var.set(f"Errore generazione chiave: {exc}")
            return

        self.key_var.set(key)
        self.status_var.set(f"Chiave generata per {AVAILABLE_DLCS[dlc_id]}")

    def on_copy(self):
        key = self.key_var.get().strip()
        if not key:
            self.status_var.set("Errore: nessuna chiave da copiare")
            return

        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(key)
            if hasattr(self.root, "update_idletasks"):
                self.root.update_idletasks()
        except Exception as exc:  # pragma: no cover - defensive UI guard
            self.status_var.set(f"Errore clipboard: {exc}")
            return

        self.status_var.set("Chiave copiata negli appunti")


def main():
    import tkinter as tk

    root = tk.Tk()
    DLCKeygenApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
