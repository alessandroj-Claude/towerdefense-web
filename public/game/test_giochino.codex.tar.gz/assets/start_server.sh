#!/usr/bin/env bash
# Avvia TowerDefense backend + Cloudflare Tunnel
# Prerequisiti: pip install -r backend/requirements.txt
#               brew install cloudflared
#               cloudflared tunnel login (una volta sola)
#               cloudflared tunnel create tower-defense (una volta sola)

set -e

REPO_DIR="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="$REPO_DIR"

# JWT secret — cambia con un valore sicuro in prod
# SETUP UNA TANTUM:
# python3 -c "import secrets; print(secrets.token_hex(32))"
# export JWT_SECRET="<valore generato>"
# (opzionale: salvarlo in ~/.zshrc per persistenza)
export JWT_SECRET="${JWT_SECRET:-change-me-in-prod-32chars-minimum!}"

# CORS — impostare l'URL GitHub Pages reale in produzione
# Esempio: export CORS_ORIGINS="https://tuousername.github.io"
export CORS_ORIGINS="${CORS_ORIGINS:-*}"

echo "=== TowerDefense Backend ==="
echo "PYTHONPATH: $PYTHONPATH"
echo ""

# Avvia uvicorn in background
echo "[1/2] Avvio FastAPI su http://127.0.0.1:8000 ..."
uvicorn backend.main:app --host 127.0.0.1 --port 8000 &
UVICORN_PID=$!

# Aspetta che il server sia pronto
sleep 2

# Avvia cloudflared tunnel
echo "[2/2] Avvio Cloudflare Tunnel 'tower-defense' ..."
cloudflared tunnel run tower-defense &
CF_PID=$!

echo ""
echo "Server avviato. Premi Ctrl+C per fermare tutto."
echo ""

# Cleanup su Ctrl+C
trap "echo 'Fermo server...'; kill $UVICORN_PID $CF_PID 2>/dev/null; exit 0" SIGINT SIGTERM

wait $UVICORN_PID $CF_PID
