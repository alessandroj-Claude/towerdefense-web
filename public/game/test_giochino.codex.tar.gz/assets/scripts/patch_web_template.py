#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path


CANVAS_PATCH = r'''
function towerDefenseDpr() {
    var raw = Number(window.devicePixelRatio || 1);
    if (!raw || raw < 1) {
        return 1;
    }
    return Math.min(raw, 2);
}

function tdIsTouch() {
    return Boolean(
        ("ontouchstart" in window) ||
        (navigator.maxTouchPoints && navigator.maxTouchPoints > 0)
    );
}

function applyTouchMetadata(canvas) {
    if (!canvas || !document.body) {
        return;
    }
    var isTouch = tdIsTouch();
    var orientation = window.innerHeight > window.innerWidth ? "portrait" : "landscape";
    document.body.classList.toggle("td-touch", isTouch);
    document.body.classList.toggle("td-portrait", orientation === "portrait");
    document.body.classList.toggle("td-landscape", orientation === "landscape");
    canvas.dataset.tdTouch = String(isTouch);
    canvas.dataset.tdOrientation = orientation;
    canvas.dataset.tdViewportWidth = String(window.innerWidth);
    canvas.dataset.tdViewportHeight = String(window.innerHeight);
}

function applyTowerDefenseCanvasScale() {
    var canvas = document.getElementById("canvas");
    if (!canvas) {
        return;
    }
    var dpr = towerDefenseDpr();
    var TD_BASE_WIDTH = 1280;
    var TD_BASE_HEIGHT = 720;
    var w = Math.min(window.innerWidth, TD_BASE_WIDTH);
    var h = Math.min(window.innerHeight, TD_BASE_HEIGHT);
    canvas.style.imageRendering = "pixelated";
    canvas.dataset.tdDpr = String(dpr);
    canvas.dataset.tdBaseWidth = String(TD_BASE_WIDTH);
    canvas.dataset.tdBaseHeight = String(TD_BASE_HEIGHT);
    canvas.dataset.tdCssWidth = String(w);
    canvas.dataset.tdCssHeight = String(h);
    applyTouchMetadata(canvas);
}

function tdWatchCanvasRendering() {
    var canvas = document.getElementById("canvas");
    if (!canvas || typeof MutationObserver === "undefined") {
        return;
    }
    var observer = new MutationObserver(function() {
        if (canvas.style.imageRendering !== "pixelated") {
            canvas.style.imageRendering = "pixelated";
        }
    });
    observer.observe(canvas, { attributes: true, attributeFilter: ["style", "width", "height"] });
}

window.addEventListener("resize", applyTowerDefenseCanvasScale);
window.addEventListener("orientationchange", applyTowerDefenseCanvasScale);
'''


def patch_template(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    text = re.sub(
        r'\s*<meta name="viewport" content="width=device-width, initial-scale=1\.0">\s*'
        r'<meta name="viewport" content="height=device-height, initial-scale=1\.0">',
        '\n    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">',
        text,
        count=1,
    )
    if "function towerDefenseDpr()" not in text:
        text = text.replace(
            "    async function custom_onload(debug_hidden) {",
            CANVAS_PATCH + "\n    async function custom_onload(debug_hidden) {",
            1,
        )
    if "applyTowerDefenseCanvasScale()" not in text.split("function custom_prerun()", 1)[0]:
        text = text.replace(
            '        console.log(__FILE__, "custom_onload")',
            '        console.log(__FILE__, "custom_onload")\n        applyTowerDefenseCanvasScale()\n        tdWatchCanvasRendering()',
            1,
        )
    path.write_text(text, encoding="utf-8")


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: patch_web_template.py PATH", file=sys.stderr)
        return 2
    patch_template(Path(argv[1]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
