#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

PID_FILES=(
  "/tmp/towerdefense_web_8080.pid"
  "/tmp/towerdefense_api_9000.pid"
  "/tmp/towerdefense_api_8000.pid"
)

PORTS=(8080 9000 8000)

stop_pid_file() {
  local pid_file="$1"
  if [[ ! -f "$pid_file" ]]; then
    return
  fi
  local pid
  pid="$(cat "$pid_file" 2>/dev/null || true)"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
    sleep 0.2
    if kill -0 "$pid" 2>/dev/null; then
      kill -9 "$pid" 2>/dev/null || true
    fi
    echo "Stopped pid $pid (from $pid_file)"
  fi
  rm -f "$pid_file"
}

stop_port() {
  local port="$1"
  if ! command -v lsof >/dev/null 2>&1; then
    return
  fi
  local pids
  pids="$(lsof -tiTCP:"$port" -sTCP:LISTEN || true)"
  if [[ -n "${pids:-}" ]]; then
    kill $pids 2>/dev/null || true
    sleep 0.2
    local still
    still="$(lsof -tiTCP:"$port" -sTCP:LISTEN || true)"
    if [[ -n "${still:-}" ]]; then
      kill -9 $still 2>/dev/null || true
    fi
    echo "Stopped listeners on :$port"
  fi
}

for f in "${PID_FILES[@]}"; do
  stop_pid_file "$f"
done

for p in "${PORTS[@]}"; do
  stop_port "$p"
done

echo "Done. Active listeners check:"
lsof -nP -iTCP:8000 -sTCP:LISTEN || true
lsof -nP -iTCP:8080 -sTCP:LISTEN || true
lsof -nP -iTCP:9000 -sTCP:LISTEN || true

