#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

# pygbag 0.9.3 ignoreDirs controlla solo la scansione import, non il tar archive step.
# .worktrees viene comunque packato -> archivio enorme. Nascondiamolo temporaneamente.
# Pre-seed CDN cache so pygbag never attempts network download.
# If version.txt mismatches pygbag will wipe the cache — re-seed after that.
_seed_cache() {
  local cache_dir="$ROOT_DIR/build/web-cache"
  local version_file="$ROOT_DIR/build/version.txt"
  local cdn="https://pygame-web.github.io/cdn/0.9.3"
  mkdir -p "$cache_dir"
  if [[ ! -f "$cache_dir/27613e24ba16d44f2a5c88150c6d64e5.tmpl" ]]; then
    curl -fsSL --connect-timeout 15 "$cdn/default.tmpl" -o "$cache_dir/27613e24ba16d44f2a5c88150c6d64e5.tmpl" || \
      { echo "WARN: CDN unreachable, template not cached — build may fail" >&2; }
  fi
  if [[ ! -f "$cache_dir/29a2a48092f8c1a6595a20019f830691.png" ]]; then
    curl -fsSL --connect-timeout 15 "$cdn/favicon.png" -o "$cache_dir/29a2a48092f8c1a6595a20019f830691.png" || true
  fi
  printf '0.9.3' > "$version_file"
}
_seed_cache

if [[ -d ".worktrees" ]]; then
  rm -rf /tmp/worktrees_bak_pygbag
  mv .worktrees /tmp/worktrees_bak_pygbag
  trap 'mv /tmp/worktrees_bak_pygbag "$ROOT_DIR/.worktrees" 2>/dev/null || true' EXIT
fi

python3 -m pygbag --build main_web.py

# pygbag may have wiped and re-created the cache dir; re-seed so next run is also offline-safe
_seed_cache

TAR_PATH="build/web/test_giochino.codex.tar.gz"
APK_PATH="build/web/test_giochino.codex.apk"

if [[ ! -f "$TAR_PATH" || ! -f "$APK_PATH" ]]; then
  echo "Build incompleta: artifact mancanti in build/web" >&2
  exit 1
fi

echo "Build web completata:"
ls -lh "$TAR_PATH" "$APK_PATH"
