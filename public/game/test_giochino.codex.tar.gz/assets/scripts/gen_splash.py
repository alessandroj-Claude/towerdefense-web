#!/usr/bin/env python3
"""Generate assets/splash.png for PyInstaller splash screen."""
import os

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

import pygame
pygame.init()
pygame.display.set_mode((1, 1))

W, H = 600, 320
surf = pygame.Surface((W, H))

BG        = (13,  17,  23)
GREEN     = (80, 200, 100)
GREEN_DIM = (40, 100,  55)
WHITE     = (255, 255, 255)
GREY      = (120, 120, 130)
BORDER    = (50,  55,  70)
BAR_BG    = (25,  30,  40)

surf.fill(BG)
pygame.draw.rect(surf, GREEN, (0, 0, W, 5))

font_title = pygame.font.SysFont("Arial", 54, bold=True)
title = font_title.render("TOWER DEFENSE", True, WHITE)
surf.blit(title, (W // 2 - title.get_width() // 2, 55))

font_med = pygame.font.SysFont("Arial", 20)
ver = font_med.render("v1.1", True, GREEN)
surf.blit(ver, (W // 2 - ver.get_width() // 2, 122))

pygame.draw.line(surf, BORDER, (80, 158), (W - 80, 158), 1)

bar_w, bar_h = 440, 22
bar_x = W // 2 - bar_w // 2
bar_y = 178
pygame.draw.rect(surf, BAR_BG, (bar_x, bar_y, bar_w, bar_h), border_radius=5)
pygame.draw.rect(surf, BORDER, (bar_x, bar_y, bar_w, bar_h), 2, border_radius=5)

font_sm = pygame.font.SysFont("Arial", 16)
hint = font_sm.render("Caricamento...", True, GREY)
surf.blit(hint, (W // 2 - hint.get_width() // 2, 214))

pygame.draw.rect(surf, GREEN_DIM, (0, H - 3, W, 3))

os.makedirs("assets", exist_ok=True)
pygame.image.save(surf, "assets/splash.png")
print("Generated assets/splash.png")
pygame.quit()
