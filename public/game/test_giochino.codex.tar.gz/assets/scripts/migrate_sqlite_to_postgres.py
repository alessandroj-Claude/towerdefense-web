#!/usr/bin/env python3
"""One-shot migration from SQLite tower_defense.db to PostgreSQL.

Usage:
  DATABASE_URL=postgresql://... python3 scripts/migrate_sqlite_to_postgres.py
  DATABASE_URL=postgresql://... python3 scripts/migrate_sqlite_to_postgres.py --dry-run
  DATABASE_URL=postgresql://... python3 scripts/migrate_sqlite_to_postgres.py --sqlite-path /path/to/tower_defense.db
"""

from __future__ import annotations

import argparse
import json
import os
import sqlite3
from pathlib import Path
from typing import Any

from src.data_paths import data_path

TABLES = ("users", "saves", "licenses", "score_runs")


def _default_sqlite_path() -> Path:
    return data_path("tower_defense.db")


def _load_rows(conn: sqlite3.Connection, table: str) -> list[sqlite3.Row]:
    cur = conn.execute(f"SELECT * FROM {table}")
    return cur.fetchall()


def _count_rows_sqlite(conn: sqlite3.Connection, table: str) -> int:
    return int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])


def _count_rows_pg(conn: Any, table: str) -> int:
    return int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])


def _ensure_psycopg():
    try:
        import psycopg  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            "psycopg is required for PostgreSQL migration. Install psycopg[binary]."
        ) from exc
    return psycopg


def _insert_users(pg_conn: Any, rows: list[sqlite3.Row]) -> int:
    inserted = 0
    for r in rows:
        cur = pg_conn.execute(
            """
            INSERT INTO users (id, username, password_hash, is_active, created_at)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (id) DO UPDATE
            SET username = EXCLUDED.username,
                password_hash = EXCLUDED.password_hash,
                is_active = EXCLUDED.is_active,
                created_at = EXCLUDED.created_at
            """,
            (int(r["id"]), str(r["username"]), str(r["password_hash"]), int(r["is_active"]), r["created_at"]),
        )
        inserted += int(cur.rowcount or 0)
    return inserted


def _insert_saves(pg_conn: Any, rows: list[sqlite3.Row]) -> int:
    inserted = 0
    for r in rows:
        cur = pg_conn.execute(
            """
            INSERT INTO saves (id, user_id, data, saved_at)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (id) DO UPDATE
            SET user_id = EXCLUDED.user_id,
                data = EXCLUDED.data,
                saved_at = EXCLUDED.saved_at
            """,
            (int(r["id"]), int(r["user_id"]), str(r["data"]), r["saved_at"]),
        )
        inserted += int(cur.rowcount or 0)
    return inserted


def _insert_licenses(pg_conn: Any, rows: list[sqlite3.Row]) -> int:
    inserted = 0
    for r in rows:
        cur = pg_conn.execute(
            """
            INSERT INTO licenses (id, user_id, dlc_id, activated_at)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (id) DO UPDATE
            SET user_id = EXCLUDED.user_id,
                dlc_id = EXCLUDED.dlc_id,
                activated_at = EXCLUDED.activated_at
            """,
            (int(r["id"]), int(r["user_id"]), str(r["dlc_id"]), r["activated_at"]),
        )
        inserted += int(cur.rowcount or 0)
    return inserted


def _insert_score_runs(pg_conn: Any, rows: list[sqlite3.Row]) -> int:
    inserted = 0
    for r in rows:
        difficulty = (r["difficulty"] or "normal") if "difficulty" in r.keys() else "normal"
        cur = pg_conn.execute(
            """
            INSERT INTO score_runs (id, user_id, score, wave, version, difficulty, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (id) DO UPDATE
            SET user_id = EXCLUDED.user_id,
                score = EXCLUDED.score,
                wave = EXCLUDED.wave,
                version = EXCLUDED.version,
                difficulty = EXCLUDED.difficulty,
                created_at = EXCLUDED.created_at
            """,
            (
                int(r["id"]),
                int(r["user_id"]),
                int(r["score"]),
                int(r["wave"]),
                str(r["version"]),
                str(difficulty),
                r["created_at"],
            ),
        )
        inserted += int(cur.rowcount or 0)
    return inserted


def _reset_sequences(pg_conn: Any) -> None:
    # Keep Postgres sequences aligned after explicit id inserts.
    pg_conn.execute("SELECT setval(pg_get_serial_sequence('users', 'id'), COALESCE((SELECT MAX(id) FROM users), 1), true)")
    pg_conn.execute("SELECT setval(pg_get_serial_sequence('saves', 'id'), COALESCE((SELECT MAX(id) FROM saves), 1), true)")
    pg_conn.execute("SELECT setval(pg_get_serial_sequence('licenses', 'id'), COALESCE((SELECT MAX(id) FROM licenses), 1), true)")
    pg_conn.execute("SELECT setval(pg_get_serial_sequence('score_runs', 'id'), COALESCE((SELECT MAX(id) FROM score_runs), 1), true)")


def _migrate(sqlite_path: Path, database_url: str, dry_run: bool) -> dict[str, Any]:
    if not sqlite_path.exists():
        raise FileNotFoundError(f"SQLite DB not found: {sqlite_path}")

    psycopg = _ensure_psycopg()

    sqlite_conn = sqlite3.connect(str(sqlite_path))
    sqlite_conn.row_factory = sqlite3.Row

    before_sqlite = {t: _count_rows_sqlite(sqlite_conn, t) for t in TABLES}
    payloads = {t: _load_rows(sqlite_conn, t) for t in TABLES}

    if dry_run:
        sqlite_conn.close()
        return {
            "mode": "dry-run",
            "sqlite_path": str(sqlite_path),
            "sqlite_counts": before_sqlite,
            "postgres_counts_before": None,
            "postgres_counts_after": None,
            "rows_processed": {t: len(payloads[t]) for t in TABLES},
        }

    with psycopg.connect(database_url) as pg_conn:
        before_pg = {t: _count_rows_pg(pg_conn, t) for t in TABLES}

        # Foreign keys require users first.
        affected = {
            "users": _insert_users(pg_conn, payloads["users"]),
            "saves": _insert_saves(pg_conn, payloads["saves"]),
            "licenses": _insert_licenses(pg_conn, payloads["licenses"]),
            "score_runs": _insert_score_runs(pg_conn, payloads["score_runs"]),
        }
        _reset_sequences(pg_conn)
        pg_conn.commit()

        after_pg = {t: _count_rows_pg(pg_conn, t) for t in TABLES}

    sqlite_conn.close()

    return {
        "mode": "execute",
        "sqlite_path": str(sqlite_path),
        "sqlite_counts": before_sqlite,
        "postgres_counts_before": before_pg,
        "postgres_counts_after": after_pg,
        "rows_processed": {t: len(payloads[t]) for t in TABLES},
        "rows_affected": affected,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Migrate SQLite tower_defense.db into PostgreSQL")
    parser.add_argument("--sqlite-path", default=str(_default_sqlite_path()), help="Path to source SQLite DB")
    parser.add_argument("--database-url", default=os.getenv("DATABASE_URL", ""), help="Postgres DATABASE_URL")
    parser.add_argument("--dry-run", action="store_true", help="Read and report only; do not write to Postgres")
    args = parser.parse_args()

    database_url = (args.database_url or "").strip()
    if not database_url:
        raise SystemExit("DATABASE_URL is required (flag --database-url or env var)")
    if not database_url.lower().startswith("postgres"):
        raise SystemExit("DATABASE_URL must be a postgres URL")

    report = _migrate(Path(args.sqlite_path).expanduser(), database_url, args.dry_run)
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
