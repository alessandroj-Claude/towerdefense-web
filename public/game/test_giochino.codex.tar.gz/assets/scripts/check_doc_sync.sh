#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

FAIL=0

info() {
  printf '[check-doc-sync] %s\n' "$1"
}

error() {
  printf '[check-doc-sync][ERROR] %s\n' "$1" >&2
  FAIL=1
}

extract_paths() {
  local file="$1"
  local kind="$2"
  sed -n "s#.*\\(docs/superpowers/current/${kind}/[^ ]*\\.md\\).*#\\1#p" "$file" | sort -u
}

require_file() {
  local path="$1"
  if [[ ! -f "$path" ]]; then
    error "Missing file: $path"
  fi
}

require_file "AGENTS.md"
require_file "docs/ARCHITECTURE.md"
require_file "docs/superpowers/current/CURRENT_VERSION"
require_file "docs/superpowers/current/STATUS.md"

if ! grep -q 'docs/superpowers/current/STATUS.md' AGENTS.md; then
  error "AGENTS.md must point to docs/superpowers/current/STATUS.md as source of current status."
fi

if grep -q '(vuoto quando nessun piano è attivo)' docs/ARCHITECTURE.md; then
  error "ARCHITECTURE.md still has outdated hardcoded empty-current-plans note."
fi

if grep -q '(vuoto quando nessuna spec è attiva)' docs/ARCHITECTURE.md; then
  error "ARCHITECTURE.md still has outdated hardcoded empty-current-specs note."
fi

TMP_CUR_PLANS="$(mktemp)"
TMP_STA_PLANS="$(mktemp)"
TMP_CUR_SPECS="$(mktemp)"
TMP_STA_SPECS="$(mktemp)"
trap 'rm -f "$TMP_CUR_PLANS" "$TMP_STA_PLANS" "$TMP_CUR_SPECS" "$TMP_STA_SPECS"' EXIT

extract_paths "docs/superpowers/current/CURRENT_VERSION" "plans" > "$TMP_CUR_PLANS"
extract_paths "docs/superpowers/current/STATUS.md" "plans" > "$TMP_STA_PLANS"
extract_paths "docs/superpowers/current/CURRENT_VERSION" "specs" > "$TMP_CUR_SPECS"
extract_paths "docs/superpowers/current/STATUS.md" "specs" > "$TMP_STA_SPECS"

while IFS= read -r path; do
  [[ -z "$path" ]] && continue
  require_file "$path"
done < "$TMP_CUR_PLANS"

while IFS= read -r path; do
  [[ -z "$path" ]] && continue
  require_file "$path"
done < "$TMP_CUR_SPECS"

while IFS= read -r path; do
  [[ -z "$path" ]] && continue
  require_file "$path"
done < "$TMP_STA_SPECS"

if ! diff -u "$TMP_CUR_PLANS" "$TMP_STA_PLANS" >/dev/null; then
  error "Plan paths mismatch between CURRENT_VERSION and STATUS.md."
fi

if [[ -s "$TMP_CUR_SPECS" ]]; then
  if ! diff -u "$TMP_CUR_SPECS" "$TMP_STA_SPECS" >/dev/null; then
    error "Spec paths mismatch between CURRENT_VERSION and STATUS.md."
  fi
fi

if [[ "$FAIL" -eq 0 ]]; then
  info "OK: docs sync checks passed."
else
  exit 1
fi
