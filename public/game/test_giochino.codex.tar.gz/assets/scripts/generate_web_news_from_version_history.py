#!/usr/bin/env python3
"""Generate towerdefense-web/public/news.json from docs/VERSION_HISTORY.md."""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION_HISTORY_PATH = ROOT / "docs" / "VERSION_HISTORY.md"
NEWS_PATH = ROOT / "towerdefense-web" / "public" / "news.json"

VERSION_RE = re.compile(r"v(\d+(?:\.\d+)+)")
DATE_RE = re.compile(r"20\d{2}-\d{2}-\d{2}")
SECTION_RE = re.compile(r"^##\s+(v\d+(?:\.\d+)+)\s+[-—]\s*(.*)$")

RECENT_TITLES = {
    "v10.0": "Architecture Maintenance Pass",
    "v9.9": "Tutorial",
    "v9.8": "Run Stats Overlay",
    "v9.7": "Lightning Tower",
    "v9.6": "Audio System",
    "v9.5": "Achievement Toast",
    "v9.4": "Dark Mode",
    "v9.3": "News System",
    "v9.2": "Account Stats",
    "v9.1": "Navbar Homepage",
}

RECENT_DATES = {
    "v10.0": "2026-05-13",
    "v9.9": "2026-05-13",
    "v9.8": "2026-05-13",
    "v9.7": "2026-05-13",
    "v9.6": "2026-05-13",
    "v9.5": "2026-05-13",
    "v9.4": "2026-05-13",
    "v9.3": "2026-05-13",
    "v9.2": "2026-05-13",
    "v9.1": "2026-05-13",
}

DEFAULT_DATE = "2026-05-13"
MAX_ITEMS = 20
MAX_BODY_LEN = 180


@dataclass(frozen=True)
class VersionSection:
    version: str
    raw_title: str
    date: str
    bullets: list[str]


def _parse_version_tuple(version: str) -> tuple[int, ...]:
    match = VERSION_RE.search(version)
    if not match:
        return (0,)
    return tuple(int(part) for part in match.group(1).split("."))


def _strip_markdown(text: str) -> str:
    text = re.sub(r"`+", "", text)
    text = re.sub(r"\[(.*?)\]\((.*?)\)", r"\1", text)
    text = re.sub(r"[*_#>~]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _normalize_body(bullets: list[str]) -> str:
    if not bullets:
        return "Aggiornamenti tecnici e miglioramenti di stabilita."
    joined = " ".join(_strip_markdown(line) for line in bullets if line.strip())
    if not joined:
        return "Aggiornamenti tecnici e miglioramenti di stabilita."
    if len(joined) <= MAX_BODY_LEN:
        return joined
    trimmed = joined[: MAX_BODY_LEN - 1].rstrip()
    if " " in trimmed:
        trimmed = trimmed.rsplit(" ", 1)[0]
    return f"{trimmed}."


def _clean_title(raw_title: str) -> str:
    title = _strip_markdown(raw_title)
    date_match = DATE_RE.search(title)
    if date_match:
        title = title[: date_match.start()].rstrip(" ()-—")
    return title or "Aggiornamento"


def parse_version_history(text: str) -> list[VersionSection]:
    sections: list[VersionSection] = []
    current_version = ""
    current_title = ""
    current_date = DEFAULT_DATE
    current_bullets: list[str] = []

    def flush() -> None:
        if not current_version:
            return
        sections.append(
            VersionSection(
                version=current_version,
                raw_title=current_title,
                date=current_date,
                bullets=list(current_bullets),
            )
        )

    for line in text.splitlines():
        section_match = SECTION_RE.match(line.strip())
        if section_match:
            flush()
            current_bullets = []
            current_version = section_match.group(1)
            current_title = section_match.group(2).strip()
            explicit_date = DATE_RE.search(line)
            if explicit_date:
                current_date = explicit_date.group(0)
            elif current_version in RECENT_DATES:
                current_date = RECENT_DATES[current_version]
            else:
                current_date = DEFAULT_DATE
            continue

        if current_version and line.lstrip().startswith("- "):
            current_bullets.append(line.lstrip()[2:].strip())

    flush()
    return sections


def generate_news_entries(history_text: str) -> list[dict[str, str]]:
    sections = parse_version_history(history_text)
    entries: list[dict[str, str]] = []
    for section in sections:
        title = RECENT_TITLES.get(section.version, _clean_title(section.raw_title))
        entries.append(
            {
                "date": section.date,
                "version": section.version,
                "title": title,
                "body": _normalize_body(section.bullets),
            }
        )

    entries.sort(
        key=lambda item: (_parse_version_tuple(item["version"]), item["date"]),
        reverse=True,
    )
    return entries[:MAX_ITEMS]


def render_news_json(entries: list[dict[str, str]]) -> str:
    return json.dumps(entries, ensure_ascii=True, indent=2) + "\n"


def run(check: bool) -> int:
    history_text = VERSION_HISTORY_PATH.read_text(encoding="utf-8")
    rendered = render_news_json(generate_news_entries(history_text))

    if check:
        current = NEWS_PATH.read_text(encoding="utf-8")
        if current != rendered:
            print("news.json is out of sync. Run: python3 scripts/generate_web_news_from_version_history.py")
            return 1
        print("news.json is in sync.")
        return 0

    NEWS_PATH.write_text(rendered, encoding="utf-8")
    print(f"Updated {NEWS_PATH}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="fail if news.json differs from generated output")
    args = parser.parse_args()
    return run(check=args.check)


if __name__ == "__main__":
    raise SystemExit(main())
