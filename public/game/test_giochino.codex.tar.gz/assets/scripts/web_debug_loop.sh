#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

PORT="${1:-8080}"
LOG_FILE="/tmp/towerdefense_web_${PORT}.log"
PID_FILE="/tmp/towerdefense_web_${PORT}.pid"
API_PORT="${API_PORT:-9000}"
API_LOG_FILE="/tmp/towerdefense_api_${API_PORT}.log"
API_PID_FILE="/tmp/towerdefense_api_${API_PORT}.pid"

stop_server() {
  if [[ -f "$PID_FILE" ]]; then
    OLD_PID="$(cat "$PID_FILE" || true)"
    if [[ -n "${OLD_PID:-}" ]] && kill -0 "$OLD_PID" 2>/dev/null; then
      kill "$OLD_PID" 2>/dev/null || true
      sleep 0.3
    fi
    rm -f "$PID_FILE"
  fi
  # Fallback: stop any stray http.server on selected port.
  if command -v lsof >/dev/null 2>&1; then
    PIDS="$(lsof -ti :"$PORT" || true)"
    if [[ -n "${PIDS:-}" ]]; then
      kill $PIDS 2>/dev/null || true
      sleep 0.3
    fi
  fi
}

stop_api_server() {
  if [[ -f "$API_PID_FILE" ]]; then
    OLD_PID="$(cat "$API_PID_FILE" || true)"
    if [[ -n "${OLD_PID:-}" ]] && kill -0 "$OLD_PID" 2>/dev/null; then
      kill "$OLD_PID" 2>/dev/null || true
      sleep 0.3
    fi
    rm -f "$API_PID_FILE"
  fi
  if command -v lsof >/dev/null 2>&1; then
    PIDS="$(lsof -ti :"$API_PORT" || true)"
    if [[ -n "${PIDS:-}" ]]; then
      kill $PIDS 2>/dev/null || true
      sleep 0.3
    fi
  fi
}

echo "[1/4] Build web pulito..."
# CDN cache preservata intenzionalmente: cancellare build/web-cache manualmente
# se si vuole forzare un rebuild CDN completo (es. upgrade pygbag).
# Cancellarla ad ogni run rompe il build quando pygame-web.github.io non e' raggiungibile
# -> default.tmpl invalido -> platform.request() assente -> api_client sempre in fallback locale.
bash scripts/build_web_clean.sh

echo "[2/4] Reset backend localhost:${API_PORT}..."
stop_api_server
LOCAL_CORS_ORIGINS="${CORS_ORIGINS:-http://127.0.0.1:${PORT},http://localhost:${PORT}}"
if [[ -f "$ROOT_DIR/backend/main.py" ]]; then
  nohup env \
    CORS_ORIGINS="$LOCAL_CORS_ORIGINS" \
    ROOT_DIR="$ROOT_DIR" \
    API_PORT="$API_PORT" \
    python3 -c 'import os, sys; sys.path.insert(0, os.environ["ROOT_DIR"]); import uvicorn; uvicorn.run("backend.main:app", host="127.0.0.1", port=int(os.environ["API_PORT"]))' >"$API_LOG_FILE" 2>&1 &
  API_PID=$!
  echo "$API_PID" >"$API_PID_FILE"

  READY=0
  for _ in {1..25}; do
    if curl -fsS "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
      READY=1
      break
    fi
    sleep 0.2
  done

  if [[ "$READY" -ne 1 ]]; then
    echo "Attenzione: backend API non raggiungibile su :${API_PORT}" >&2
    echo "Log backend: ${API_LOG_FILE}" >&2
    tail -n 40 "$API_LOG_FILE" >&2 || true
    echo "Continuo senza backend (fallback locale attivo)." >&2
  fi
else
  echo "Backend non presente in questa worktree (manca backend/main.py)." >&2
  echo "Continuo senza backend (fallback locale attivo)." >&2
fi

echo "[3/4] Reset server localhost:${PORT}..."
stop_server
nohup python3 -m http.server "$PORT" --directory build/web >"$LOG_FILE" 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" >"$PID_FILE"
sleep 0.6

if ! kill -0 "$SERVER_PID" 2>/dev/null; then
  echo "Attenzione: server non partito automaticamente (ambiente con bind limitato)." >&2
  echo "Build completata comunque. Avvia manualmente:" >&2
  echo "  python3 -m http.server ${PORT} --directory build/web" >&2
  echo "Log tentativo: ${LOG_FILE}" >&2
  exit 0
fi

TS="$(date +%s)"
URL_BASE="http://127.0.0.1:${PORT}/?v=${TS}"
echo "[4/4] Pronto."
echo
echo "CORS_ORIGINS backend:"
echo "  ${LOCAL_CORS_ORIGINS}"
echo
echo "Apri in browser:"
echo "  ${URL_BASE}"
echo "Nota debug:"
echo "  evita '?-i' in questo setup (forza rewrite CDN su /cdn locale non presente)"
echo
echo "Log server locale:"
echo "  tail -f ${LOG_FILE}"
echo "Log backend API:"
echo "  tail -f ${API_LOG_FILE}"
echo
echo "Per fermare il server:"
echo "  kill \$(cat ${PID_FILE})"
echo "Per fermare backend API:"
echo "  kill \$(cat ${API_PID_FILE})"
