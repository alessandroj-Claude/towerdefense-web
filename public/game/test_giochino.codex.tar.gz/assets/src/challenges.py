from dataclasses import dataclass
from datetime import date
import hashlib
import random
from typing import Tuple

SUPPORTED_MODIFIERS = (
    "fast_fliers",
    "rich_start",
    "boss_pressure",
)


@dataclass(frozen=True)
class ChallengeDefinition:
    kind: str
    challenge_id: str
    seed: int
    label: str
    modifiers: Tuple[str, ...]


def challenge_seed(kind: str, challenge_id: str) -> int:
    digest = hashlib.sha256(f"tower-defense-cj:{kind}:{challenge_id}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big", signed=False)


def modifier_set_for_seed(seed: int) -> Tuple[str, ...]:
    rng = random.Random(seed)
    count = rng.randint(0, 2)
    if count == 0:
        return ()
    choices = list(SUPPORTED_MODIFIERS)
    rng.shuffle(choices)
    return tuple(choices[:count])


def daily_challenge(day: date) -> ChallengeDefinition:
    challenge_id = day.isoformat()
    seed = challenge_seed("daily", challenge_id)
    return ChallengeDefinition(
        kind="daily",
        challenge_id=challenge_id,
        label=f"Daily {challenge_id}",
        seed=seed,
        modifiers=modifier_set_for_seed(seed),
    )


def weekly_challenge(day: date) -> ChallengeDefinition:
    year, week, _ = day.isocalendar()
    challenge_id = f"{year}-W{week:02d}"
    seed = challenge_seed("weekly", challenge_id)
    return ChallengeDefinition(
        kind="weekly",
        challenge_id=challenge_id,
        label=f"Weekly {challenge_id}",
        seed=seed,
        modifiers=modifier_set_for_seed(seed),
    )
