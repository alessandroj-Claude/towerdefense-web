from __future__ import annotations

import os
import shutil
from pathlib import Path

APP_DIR_NAME = "TowerDefense"
APP_SUPPORT_ENV = "TOWER_DEFENSE_DATA_DIR"
_REPO_ROOT = Path(__file__).resolve().parent.parent


def get_data_dir() -> Path:
    """Return persistent app data dir (macOS App Support by default)."""
    override = os.getenv(APP_SUPPORT_ENV, "").strip()
    if override:
        return Path(override).expanduser()
    return Path.home() / "Library" / "Application Support" / APP_DIR_NAME


def ensure_data_dir() -> Path:
    data_dir = get_data_dir()
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        return data_dir
    except PermissionError:
        fallback = _REPO_ROOT / ".tower_defense_data"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback


def data_path(filename: str) -> Path:
    return ensure_data_dir() / filename


def _legacy_candidates(filename: str) -> list[Path]:
    # Legacy locations from pre-v3.2 builds/runs.
    return [
        _REPO_ROOT / filename,
        Path.cwd() / filename,
    ]


def migrate_legacy_file(filename: str) -> Path:
    """Best-effort migration: copy first found legacy file into data dir."""
    ensure_data_dir()
    target = data_path(filename)
    if target.exists():
        return target
    for legacy in _legacy_candidates(filename):
        try:
            if legacy.exists() and legacy.resolve() != target.resolve():
                shutil.copy2(legacy, target)
                return target
        except Exception:
            continue
    return target
