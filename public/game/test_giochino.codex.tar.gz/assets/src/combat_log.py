from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(frozen=True)
class WaveCombatStats:
    wave: int
    damage_by_tower_type: Dict[str, int] = field(default_factory=dict)
    kills_by_enemy_type: Dict[str, int] = field(default_factory=dict)
    gold_earned: int = 0
    gold_spent: int = 0
    repairs: int = 0
    upgrades: int = 0
    lives_lost: int = 0
    events: List[str] = field(default_factory=list)
    boss_abilities: List[str] = field(default_factory=list)


class CombatLog:
    def __init__(self) -> None:
        self._wave = 0
        self._damage_by_tower_type: Dict[str, int] = {}
        self._kills_by_enemy_type: Dict[str, int] = {}
        self._gold_earned = 0
        self._gold_spent = 0
        self._repairs = 0
        self._upgrades = 0
        self._lives_lost = 0
        self._events: List[str] = []
        self._boss_abilities: List[str] = []

    def start_wave(self, wave_num: int) -> None:
        self._wave = int(wave_num)
        self._damage_by_tower_type = {}
        self._kills_by_enemy_type = {}
        self._gold_earned = 0
        self._gold_spent = 0
        self._repairs = 0
        self._upgrades = 0
        self._lives_lost = 0
        self._events = []
        self._boss_abilities = []

    def record_damage(self, tower_type: str, amount: int) -> None:
        self._damage_by_tower_type[tower_type] = self._damage_by_tower_type.get(tower_type, 0) + int(amount)

    def record_kill(self, enemy_type: str) -> None:
        self._kills_by_enemy_type[enemy_type] = self._kills_by_enemy_type.get(enemy_type, 0) + 1

    def record_gold_earned(self, amount: int) -> None:
        self._gold_earned += int(amount)

    def record_gold_spent(self, amount: int, reason: str) -> None:
        self._gold_spent += int(amount)

    def record_repair(self) -> None:
        self._repairs += 1

    def record_upgrade(self) -> None:
        self._upgrades += 1

    def record_lives_lost(self, amount: int) -> None:
        self._lives_lost += int(amount)

    def record_event(self, label: str) -> None:
        self._events.append(str(label))

    def record_boss_ability(self, label: str) -> None:
        self._boss_abilities.append(str(label))

    def finish_wave(self) -> WaveCombatStats:
        return WaveCombatStats(
            wave=self._wave,
            damage_by_tower_type=dict(self._damage_by_tower_type),
            kills_by_enemy_type=dict(self._kills_by_enemy_type),
            gold_earned=self._gold_earned,
            gold_spent=self._gold_spent,
            repairs=self._repairs,
            upgrades=self._upgrades,
            lives_lost=self._lives_lost,
            events=list(self._events),
            boss_abilities=list(self._boss_abilities),
        )
