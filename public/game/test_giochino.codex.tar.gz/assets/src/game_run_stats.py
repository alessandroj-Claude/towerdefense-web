from __future__ import annotations

from typing import Dict, Iterable

from src.combat_log import WaveCombatStats


def empty_run_totals() -> dict:
    return {
        "waves_completed": 0,
        "total_damage": 0,
        "total_kills": 0,
        "total_gold_earned": 0,
        "total_gold_spent": 0,
        "gold_earned": 0,
        "gold_spent": 0,
        "lives_lost": 0,
        "damage_by_tower": {},
        "kills_by_enemy": {},
        "per_wave_kills": [],
    }


def compute_run_totals(combat_log_history: Iterable[WaveCombatStats]) -> dict:
    totals = empty_run_totals()

    for stats in combat_log_history:
        totals["waves_completed"] += 1

        wave_damage = sum(int(amount) for amount in stats.damage_by_tower_type.values())
        wave_kills = sum(int(count) for count in stats.kills_by_enemy_type.values())

        totals["total_damage"] += wave_damage
        totals["total_kills"] += wave_kills
        totals["total_gold_earned"] += int(stats.gold_earned)
        totals["total_gold_spent"] += int(stats.gold_spent)
        totals["gold_earned"] += int(stats.gold_earned)
        totals["gold_spent"] += int(stats.gold_spent)
        totals["lives_lost"] += int(stats.lives_lost)

        for tower, dmg in stats.damage_by_tower_type.items():
            totals["damage_by_tower"][tower] = totals["damage_by_tower"].get(tower, 0) + int(dmg)

        for enemy, kills in stats.kills_by_enemy_type.items():
            totals["kills_by_enemy"][enemy] = totals["kills_by_enemy"].get(enemy, 0) + int(kills)

        totals["per_wave_kills"].append({"wave": int(stats.wave), "kills": wave_kills})

    return totals
