from __future__ import annotations
from typing import List, Tuple
import math
import random

BOSS_POWERUP_POOL = ["ARMORED", "SWIFT", "REGENERATOR", "RESISTANT"]
BOSS_ELEMENT_POOL = ["FIRE", "ICE", "LIGHTNING", "EARTH", "AIR"]

Cell = Tuple[int, int]

class Enemy:
    element: str = "ARCANE"
    BASE_SLOW_RESISTANCE = 0.0  # 0 = no resistance, 1 = full immunity

    def __init__(self, path: List[Cell], tile_size: int,
                 hp: int, speed: float, reward: int, lives_damage: int = 1):
        self.path = path
        self.tile_size = tile_size
        self.hp = hp
        self.max_hp = hp
        self._base_speed = speed
        self.speed = speed
        self.reward = reward
        self.lives_damage = lives_damage
        self.progress = 0.0
        self.alive = True
        self.reached_end = False
        self._slow_timer = 0.0
        self._slow_factor = 1.0
        self.damage_taken_mult = 1.0
        self.poison_dps: float = 0.0
        self.poison_timer: float = 0.0

    def take_damage(self, amount: float) -> None:
        damage_mult = max(0.0, float(getattr(self, "damage_taken_mult", 1.0)))
        self.hp = max(0, self.hp - (amount * damage_mult))
        if self.hp == 0:
            self.alive = False

    def apply_slow(self, factor: float, duration: float) -> None:
        effective = max(factor, self.BASE_SLOW_RESISTANCE)
        self._slow_factor = effective
        self._slow_timer = duration
        self.speed = self._base_speed * effective

    def update(self, dt: float) -> None:
        if not self.alive or self.reached_end:
            return

        if self._slow_timer > 0:
            self._slow_timer -= dt
            if self._slow_timer <= 0:
                self._slow_timer = 0
                self._slow_factor = 1.0
                self.speed = self._base_speed

        if self.poison_timer > 0:
            self.take_damage(self.poison_dps * dt)
            self.poison_timer = max(0.0, self.poison_timer - dt)
            if self.poison_timer <= 0:
                self.poison_dps = 0.0

        self.progress += self.speed * dt
        if self.progress >= len(self.path) - 1:
            self.progress = len(self.path) - 1
            self.reached_end = True

    @property
    def pos(self) -> Tuple[float, float]:
        idx = min(int(self.progress), len(self.path) - 2)
        frac = self.progress - idx
        c1, r1 = self.path[idx]
        c2, r2 = self.path[idx + 1] if idx + 1 < len(self.path) else self.path[idx]
        px = (c1 + (c2 - c1) * frac) * self.tile_size + self.tile_size // 2
        py = (r1 + (r2 - r1) * frac) * self.tile_size + self.tile_size // 2
        return px, py


class BasicEnemy(Enemy):
    def __init__(self, path, tile_size):
        super().__init__(path, tile_size, hp=100, speed=1.0, reward=10, lives_damage=1)

class FastEnemy(Enemy):
    element = "AIR"
    def __init__(self, path, tile_size):
        super().__init__(path, tile_size, hp=60, speed=2.0, reward=15, lives_damage=1)

class TankEnemy(Enemy):
    element = "EARTH"
    BASE_SLOW_RESISTANCE = 0.7
    def __init__(self, path, tile_size):
        super().__init__(path, tile_size, hp=400, speed=0.5, reward=40, lives_damage=3)

class SwarmEnemy(Enemy):
    def __init__(self, path, tile_size):
        super().__init__(path, tile_size, hp=30, speed=1.5, reward=5, lives_damage=1)

class HeavyEnemy(Enemy):
    element = "EARTH"
    shoot_range = 120
    shoot_damage = 15
    shoot_cooldown = 3.0

    def __init__(self, path, tile_size):
        super().__init__(path, tile_size, hp=200, speed=0.5, reward=25, lives_damage=2)
        self._shoot_timer = 0.0

    def update_shoot(self, towers: list, dt: float):
        self._shoot_timer -= dt
        if self._shoot_timer > 0:
            return None
        ex, ey = self.pos
        in_range = [t for t in towers if math.hypot(t.center_px[0] - ex, t.center_px[1] - ey) <= self.shoot_range]
        if not in_range:
            self._shoot_timer = self.shoot_cooldown
            return None
        # Prefer sentinel towers (nearest sentinel if available)
        sentinels = [t for t in in_range if getattr(t, "is_sentinel", False)]
        if sentinels:
            target = min(sentinels, key=lambda t: math.hypot(t.center_px[0] - ex, t.center_px[1] - ey))
        else:
            target = min(in_range, key=lambda t: math.hypot(t.center_px[0] - ex, t.center_px[1] - ey))
        self._shoot_timer = self.shoot_cooldown
        return EnemyProjectile(ex, ey, target, self.shoot_damage)


class FlyingEnemy(Enemy):
    element = "AIR"
    shoot_range = 140
    shoot_damage = 10
    shoot_cooldown = 2.5

    def __init__(self, path, tile_size):
        super().__init__(path, tile_size, hp=162, speed=(1.7 * (2.0 / 3.0) * 0.8), reward=20, lives_damage=1)
        self._flight_start = path[0]
        self._flight_end = path[-1]
        self._flight_dx = self._flight_end[0] - self._flight_start[0]
        self._flight_dy = self._flight_end[1] - self._flight_start[1]
        self._flight_distance = math.hypot(self._flight_dx, self._flight_dy)
        self._shoot_timer = 0.0

    def update(self, dt: float) -> None:
        if not self.alive or self.reached_end:
            return

        if self._slow_timer > 0:
            self._slow_timer -= dt
            if self._slow_timer <= 0:
                self._slow_timer = 0
                self._slow_factor = 1.0
                self.speed = self._base_speed

        if self.poison_timer > 0:
            self.take_damage(self.poison_dps * dt)
            self.poison_timer = max(0.0, self.poison_timer - dt)
            if self.poison_timer <= 0:
                self.poison_dps = 0.0

        self.progress += self.speed * dt
        if self.progress >= self._flight_distance:
            self.progress = self._flight_distance
            self.reached_end = True

    @property
    def pos(self) -> Tuple[float, float]:
        if self._flight_distance == 0:
            c1, r1 = self._flight_start
            return (c1 * self.tile_size + self.tile_size // 2, r1 * self.tile_size + self.tile_size // 2)

        frac = min(max(self.progress / self._flight_distance, 0.0), 1.0)
        c1, r1 = self._flight_start
        c2, r2 = self._flight_end
        px = (c1 + (c2 - c1) * frac) * self.tile_size + self.tile_size // 2
        py = (r1 + (r2 - r1) * frac) * self.tile_size + self.tile_size // 2
        return px, py

    def update_shoot(self, towers: list, dt: float):
        self._shoot_timer -= dt
        if self._shoot_timer > 0:
            return None
        ex, ey = self.pos
        in_range = [t for t in towers if math.hypot(t.center_px[0] - ex, t.center_px[1] - ey) <= self.shoot_range]
        if not in_range:
            self._shoot_timer = self.shoot_cooldown
            return None
        target = min(in_range, key=lambda t: math.hypot(t.center_px[0] - ex, t.center_px[1] - ey))
        self._shoot_timer = self.shoot_cooldown
        return EnemyProjectile(ex, ey, target, self.shoot_damage)


class BossEnemy(Enemy):
    element = "FIRE"
    shoot_range = 180
    shoot_damage = 40
    shoot_cooldown = 6.0

    def __init__(self, path, tile_size, powerups=None, boss_element=None):
        super().__init__(path, tile_size, hp=1600, speed=0.25, reward=500, lives_damage=5)
        if boss_element is None:
            self.element = random.choice(BOSS_ELEMENT_POOL)
        else:
            self.element = str(boss_element)
        if powerups is None:
            self.active_powerups = random.sample(BOSS_POWERUP_POOL, random.randint(1, 2))
        else:
            self.active_powerups = list(powerups)
        self._damage_reduction = 0.0
        self._regen_rate = 0.0
        self._shoot_timer = 0.0
        # Phase state
        self._current_phase_id: str = "phase_1"
        self._phase_telegraphed: set[str] = set()
        self.telegraph_timer: float = 0.0
        self.telegraph_active: bool = False
        self.telegraph_ability_id: str = ""
        self.ability_pending: str = ""
        self._armor_pulse_timer: float = 0.0
        self._apply_powerups()

    def update_shoot(self, towers: list, dt: float):
        self._shoot_timer -= dt
        if self._shoot_timer > 0:
            return None
        ex, ey = self.pos
        in_range = [t for t in towers if math.hypot(t.center_px[0] - ex, t.center_px[1] - ey) <= self.shoot_range]
        if not in_range:
            self._shoot_timer = self.shoot_cooldown
            return None
        target = min(in_range, key=lambda t: math.hypot(t.center_px[0] - ex, t.center_px[1] - ey))
        self._shoot_timer = self.shoot_cooldown
        return BossProjectile(ex, ey, target, self.shoot_damage)

    def _apply_powerups(self) -> None:
        if "ARMORED" in self.active_powerups:
            self._damage_reduction = 0.5
        if "SWIFT" in self.active_powerups:
            self._base_speed *= 1.5
            self.speed *= 1.5
        if "REGENERATOR" in self.active_powerups:
            self._regen_rate = 5.0
        if "RESISTANT" in self.active_powerups:
            self.BASE_SLOW_RESISTANCE = 0.9  # instance attribute — does NOT touch TankEnemy

    def _tick_phase(self, dt: float) -> None:
        from src.bosses import phase_for_hp_ratio
        if not self.alive:
            return
        if self.max_hp > 0:
            hp_ratio = self.hp / self.max_hp
        else:
            hp_ratio = 0.0
        target_phase = phase_for_hp_ratio(hp_ratio)
        if (target_phase.id != self._current_phase_id
                and target_phase.id not in self._phase_telegraphed):
            self._current_phase_id = target_phase.id
            self._phase_telegraphed.add(target_phase.id)
            if target_phase.ability_id != "none":
                self.telegraph_timer = 1.2
                self.telegraph_active = True
                self.telegraph_ability_id = target_phase.ability_id
        if self.telegraph_timer > 0:
            self.telegraph_timer -= dt
            if self.telegraph_timer <= 0:
                self.telegraph_timer = 0.0
                self.telegraph_active = False
                self.ability_pending = self.telegraph_ability_id
                self.telegraph_ability_id = ""
        if self._armor_pulse_timer > 0:
            self._armor_pulse_timer -= dt
            if self._armor_pulse_timer <= 0:
                self._armor_pulse_timer = 0.0

    def take_damage(self, amount: float) -> None:
        if not self.alive:
            return
        if "ARMORED" in self.active_powerups:
            amount = amount * (1 - self._damage_reduction)
        if self._armor_pulse_timer > 0:
            amount = amount * 0.5
        super().take_damage(amount)

    def update(self, dt: float) -> None:
        super().update(dt)
        if "REGENERATOR" in self.active_powerups and self.alive:
            self.hp = min(self.max_hp, self.hp + self._regen_rate * dt)
        self._tick_phase(dt)


class EnemyProjectile:
    """A projectile fired by an enemy toward a target tower."""

    def __init__(self, x: float, y: float, target_tower, damage: int, speed: float = 300.0):
        self.x = x
        self.y = y
        self.target_tower = target_tower
        self.damage = damage
        self.speed = speed
        self.alive = True

    def update(self, dt: float) -> bool:
        """Move toward target_tower. Return True when projectile hits (alive→False), else False."""
        if not self.alive:
            return False

        tx, ty = self.target_tower.center_px
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)

        if dist <= self.speed * dt:
            self.alive = False
            return True

        self.x += (dx / dist) * self.speed * dt
        self.y += (dy / dist) * self.speed * dt
        return False


class BossProjectile(EnemyProjectile):
    """Projectile fired by BossEnemy with splash damage. Caller must invoke on_hit(towers) when update() returns True."""
    splash_radius = 80

    def on_hit(self, towers: list, damage_mult: float = 1.0) -> None:
        """Deal self.damage to all towers within splash_radius of the primary target."""
        tx, ty = self.target_tower.center_px
        scaled_damage = self.damage * max(0.0, float(damage_mult))
        for tower in towers:
            if tower.hp > 0 and math.hypot(tower.center_px[0] - tx, tower.center_px[1] - ty) <= self.splash_radius:
                tower.take_damage(scaled_damage)
