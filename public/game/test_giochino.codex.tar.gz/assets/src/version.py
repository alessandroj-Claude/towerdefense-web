import re
from pathlib import Path
from typing import Iterable, Optional

_VERSION_RE = re.compile(r"v\d+\.\d+")


def _extract_version(text: str) -> Optional[str]:
    for line in text.splitlines():
        if "TowerDefense" not in line:
            continue
        m = _VERSION_RE.search(line)
        if m:
            return m.group(0)
    m = _VERSION_RE.search(text)
    return m.group(0) if m else None


def detect_runtime_version(default: str = "v4.3", marker_paths: Optional[Iterable[Path]] = None) -> str:
    if marker_paths is None:
        root = Path(__file__).resolve().parents[1]
        marker_paths = (
            root / "dist" / "current" / "CURRENT_VERSION",
            root / "docs" / "superpowers" / "current" / "CURRENT_VERSION",
        )

    for marker in marker_paths:
        try:
            text = Path(marker).read_text(encoding="utf-8")
        except OSError:
            continue
        version = _extract_version(text)
        if version:
            return version

    return default
