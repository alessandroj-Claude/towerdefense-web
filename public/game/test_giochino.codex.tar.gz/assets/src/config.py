from __future__ import annotations

import os
import sys


IS_WEB = sys.platform == "emscripten"
BACKEND_URL = os.getenv("TOWER_DEFENSE_BACKEND_URL", "http://127.0.0.1:9000").rstrip("/")
