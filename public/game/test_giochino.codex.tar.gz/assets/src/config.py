from __future__ import annotations

import os
import sys


IS_WEB = sys.platform == "emscripten"
if IS_WEB:
    BACKEND_URL = os.getenv(
        "TOWER_DEFENSE_BACKEND_URL",
        "https://tower-defense-cj.onrender.com",
    ).rstrip("/")
else:
    BACKEND_URL = os.getenv(
        "TOWER_DEFENSE_BACKEND_URL",
        "http://127.0.0.1:9000",
    ).rstrip("/")
