from src.powerups import POWERUP_BY_ID, try_activate_powerup
from src.tower import towers_sorted_xy_for_type
from src.ui import TOWER_CLASSES, repair_hp

TOWER_MAP = {cls.__name__: cls for cls in TOWER_CLASSES}


class OrderQueueMixin:
    """Pre-wave order queue: parse, add, remove, execute. Loadout preset application."""

    def _apply_loadout_preset(self, name: str) -> None:
        if self.wave_mgr.active:
            return

        self._loadout_preset = name if name != "repair" else None

        if name == "anti-air":
            from src.tower import AntiAirTower

            self.selected_cls = AntiAirTower
            for t in self.towers:
                if isinstance(t, AntiAirTower):
                    t.targeting_policy = "flying-first"

        elif name == "economy":
            self.auto_repair_all_enabled = True

        elif name == "repair":
            for t in self.towers:
                if t.hp < t.max_hp:
                    amount = repair_hp(t, self.difficulty)
                    cost = int(t.base_cost * 0.3)
                    if self.economy.can_afford(cost) and amount > 0:
                        self.economy.spend(cost)
                        t.hp = min(t.max_hp, t.hp + amount)

    def _parse_order_spec(self, order_spec: str) -> dict:
        parts = order_spec.split(":", 1)
        order = {"type": parts[0]}
        if len(parts) > 1:
            params_str = parts[1]
            for param in params_str.split(","):
                if "=" in param:
                    key, val = param.split("=", 1)
                    order[key.strip()] = val.strip()
        return order

    def _add_order(self, order: dict) -> None:
        if self.wave_mgr.active:
            return
        if len(self._order_queue) >= 5:
            return
        self._order_queue.append(order)

    def _remove_order(self, index: int) -> None:
        if self.wave_mgr.active:
            return
        if 0 <= index < len(self._order_queue):
            self._order_queue.pop(index)

    def _execute_single_order(self, order: dict) -> str:
        otype = order.get("type", "")

        if otype == "auto-repair-all":
            self.auto_repair_all_enabled = True
            return "ok"

        elif otype == "upgrade-all":
            tower_cls_name = order.get("tower_cls", "")
            cls = TOWER_MAP.get(tower_cls_name)
            if cls is None:
                return "skipped:unknown_type"

            ordered = towers_sorted_xy_for_type(self.towers, cls)
            if not ordered:
                return "skipped:no_towers"

            upgraded = False
            for tower in ordered:
                result = tower.try_shop_upgrade(self.economy)
                if result == "ok":
                    upgraded = True
                    continue
                if result == "insufficient_gold":
                    return "skipped:insufficient_gold"
                if result == "max_level":
                    continue

            return "ok" if upgraded else "skipped:no_towers"

        elif otype == "powerup":
            powerup_id = order.get("powerup_id", "")
            powerup = POWERUP_BY_ID.get(powerup_id)
            if powerup is None:
                return "skipped:unknown_powerup"

            if not self.economy.can_afford(powerup.cost):
                return "skipped:insufficient_gold"

            powerup_ctx = self._powerup_context()
            result = try_activate_powerup(powerup_id, powerup_ctx)
            self.economy.gold = int(powerup_ctx["gold"])
            return "ok" if result == "ok" else f"skipped:{result}"

        return "skipped:unknown_order"

    def _execute_order_queue(self) -> None:
        self._order_queue_log = []
        for order in self._order_queue:
            result = self._execute_single_order(order)
            self._order_queue_log.append(result)
