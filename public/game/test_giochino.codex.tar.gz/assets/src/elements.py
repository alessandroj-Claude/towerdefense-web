# src/elements.py
ELEMENTS = ("ARCANE", "FIRE", "ICE", "LIGHTNING", "EARTH", "AIR")

_ELEMENT_MULT: dict[str, dict[str, float]] = {
    "FIRE": {
        "EARTH": 0.5,
        "FIRE":  0.4,
        "AIR":   1.5,
    },
    "ICE": {
        "EARTH": 1.5,
        "FIRE":  1.5,
        "AIR":   0.8,
    },
    "LIGHTNING": {
        "AIR":   2.0,
        "EARTH": 1.3,
        "FIRE":  0.7,
    },
    "EARTH": {
        "AIR":  0.5,
        "FIRE": 1.5,
    },
    "ARCANE": {},
    "AIR": {
        "FIRE": 0.5,
    },
}


def get_damage_mult(attacker: str, defender: str) -> float:
    """Return elemental damage multiplier for attacker hitting defender."""
    row = _ELEMENT_MULT.get(attacker)
    if row is None:
        return 1.0
    return row.get(defender, 1.0)
