from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, MutableMapping, Tuple


@dataclass(frozen=True)
class Powerup:
    id: str
    cost: int
    duration: float
    cooldown: float
    min_wave: int = 0


POWERUP_POOL: Tuple[Powerup, ...] = (
    Powerup(id="overcharge", cost=120, duration=10.0, cooldown=20.0, min_wave=0),
    Powerup(id="field_repairs", cost=90, duration=0.0, cooldown=18.0, min_wave=0),
    Powerup(id="radar_pulse", cost=40, duration=8.0, cooldown=30.0, min_wave=5),
    Powerup(id="aa_salvo", cost=60, duration=0.0, cooldown=45.0, min_wave=5),
    Powerup(id="scramble", cost=50, duration=10.0, cooldown=40.0, min_wave=5),
)

POWERUP_BY_ID: Dict[str, Powerup] = {powerup.id: powerup for powerup in POWERUP_POOL}


@dataclass
class PowerupRuntimeState:
    active_timers: Dict[str, float] = field(default_factory=dict)
    cooldown_timers: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Dict[str, float]]:
        return {
            "active_timers": {key: float(value) for key, value in self.active_timers.items()},
            "cooldown_timers": {key: float(value) for key, value in self.cooldown_timers.items()},
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "PowerupRuntimeState":
        active = payload.get("active_timers", {})
        cooldowns = payload.get("cooldown_timers", {})
        return cls(
            active_timers={str(key): float(value) for key, value in dict(active).items()},
            cooldown_timers={str(key): float(value) for key, value in dict(cooldowns).items()},
        )


def _state_from_ctx(ctx: MutableMapping[str, Any]) -> PowerupRuntimeState:
    state = ctx.get("powerup_state")
    if isinstance(state, PowerupRuntimeState):
        return state

    if isinstance(state, Mapping):
        restored = PowerupRuntimeState.from_dict(state)
        ctx["powerup_state"] = restored
        return restored

    created = PowerupRuntimeState()
    ctx["powerup_state"] = created
    return created


def _modifiers_from_ctx(ctx: MutableMapping[str, Any]) -> MutableMapping[str, float]:
    modifiers = ctx.get("modifiers")
    if isinstance(modifiers, MutableMapping):
        return modifiers

    created: Dict[str, float] = {}
    ctx["modifiers"] = created
    return created


def _apply_overcharge_modifier(ctx: MutableMapping[str, Any], state: PowerupRuntimeState) -> None:
    modifiers = _modifiers_from_ctx(ctx)
    if state.active_timers.get("overcharge", 0.0) > 0.0:
        modifiers["tower_fire_rate_mult"] = 1.35
    else:
        modifiers.pop("tower_fire_rate_mult", None)


def _heal_tower(tower: Any, amount: int) -> None:
    heal = getattr(tower, "heal", None)
    if callable(heal):
        heal(amount)
        return

    hp = getattr(tower, "hp", None)
    max_hp = getattr(tower, "max_hp", None)
    if hp is None or max_hp is None:
        return

    new_hp = min(int(max_hp), int(hp) + int(amount))
    setattr(tower, "hp", new_hp)


def _apply_field_repairs(ctx: MutableMapping[str, Any], heal_amount: int = 35) -> None:
    towers: Iterable[Any] = ctx.get("towers", [])
    for tower in towers:
        _heal_tower(tower, heal_amount)


def _apply_radar_pulse(ctx: MutableMapping[str, Any]) -> None:
    enemies: Iterable[Any] = ctx.get("enemies", [])
    for enemy in enemies:
        if _is_flying_enemy(enemy):
            setattr(enemy, "revealed", True)


def _apply_aa_salvo(ctx: MutableMapping[str, Any], damage: int = 50) -> None:
    enemies: Iterable[Any] = ctx.get("enemies", [])
    for enemy in enemies:
        if _is_flying_enemy(enemy):
            take_damage = getattr(enemy, "take_damage", None)
            if callable(take_damage):
                take_damage(damage)
            else:
                hp = getattr(enemy, "hp", None)
                if hp is not None:
                    setattr(enemy, "hp", max(0, int(hp) - damage))


def _apply_scramble(ctx: MutableMapping[str, Any], speed_factor: float = 0.5, duration: float = 10.0) -> None:
    enemies: Iterable[Any] = ctx.get("enemies", [])
    for enemy in enemies:
        if _is_flying_enemy(enemy):
            apply_debuff = getattr(enemy, "apply_speed_debuff", None)
            if callable(apply_debuff):
                apply_debuff(speed_factor, duration)
            else:
                # Fallback: set speed directly if method doesn't exist
                base_speed = getattr(enemy, "_base_speed", 1.0)
                setattr(enemy, "speed", base_speed * speed_factor)
                setattr(enemy, "_speed_debuff_active", True)
                setattr(enemy, "_speed_debuff_timer", duration)


def _is_flying_enemy(enemy: Any) -> bool:
    from src.enemy import FlyingEnemy
    return isinstance(enemy, FlyingEnemy) or getattr(enemy, "_is_flying", False)


def try_activate_powerup(powerup_id: str, ctx: MutableMapping[str, Any]) -> str:
    powerup = POWERUP_BY_ID.get(powerup_id)
    if powerup is None:
        return "unknown_powerup"

    state = _state_from_ctx(ctx)

    if state.active_timers.get(powerup_id, 0.0) > 0.0:
        return "already_active"

    if state.cooldown_timers.get(powerup_id, 0.0) > 0.0:
        return "cooldown"

    current_gold = int(ctx.get("gold", 0))
    if current_gold < powerup.cost:
        return "insufficient_gold"

    ctx["gold"] = current_gold - powerup.cost
    state.cooldown_timers[powerup_id] = float(powerup.cooldown)

    if powerup.id == "field_repairs":
        _apply_field_repairs(ctx)
        return "ok"

    if powerup.id == "radar_pulse":
        _apply_radar_pulse(ctx)
        if powerup.duration > 0.0:
            state.active_timers[powerup_id] = float(powerup.duration)
        return "ok"

    if powerup.id == "aa_salvo":
        _apply_aa_salvo(ctx)
        return "ok"

    if powerup.id == "scramble":
        _apply_scramble(ctx)
        if powerup.duration > 0.0:
            state.active_timers[powerup_id] = float(powerup.duration)
        return "ok"

    if powerup.duration > 0.0:
        state.active_timers[powerup_id] = float(powerup.duration)

    if powerup.id == "overcharge":
        _apply_overcharge_modifier(ctx, state)

    return "ok"


def _decay_timers(timers: Dict[str, float], dt: float) -> None:
    expired = []
    for key, remaining in timers.items():
        updated = max(0.0, float(remaining) - dt)
        timers[key] = updated
        if updated == 0.0:
            expired.append(key)

    for key in expired:
        timers.pop(key, None)


def update_powerups(dt: float, ctx: MutableMapping[str, Any]) -> None:
    if dt <= 0.0:
        return

    state = _state_from_ctx(ctx)
    _decay_timers(state.active_timers, float(dt))
    _decay_timers(state.cooldown_timers, float(dt))
    _apply_overcharge_modifier(ctx, state)


def end_wave_powerups(ctx: MutableMapping[str, Any]) -> None:
    state = _state_from_ctx(ctx)
    state.active_timers.clear()
    _apply_overcharge_modifier(ctx, state)
