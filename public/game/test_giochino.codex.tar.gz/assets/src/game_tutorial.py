from __future__ import annotations

from pathlib import Path

from src.config import IS_WEB
from src.data_paths import get_data_dir

TUTORIAL_STEPS = [
    {
        "id": "welcome",
        "title": "Benvenuto!",
        "text": "Difendi la base dagli nemici piazzando torrette sul percorso.",
        "highlight": None,
        "advance": "button",
    },
    {
        "id": "tower_shop",
        "title": "Negozio Torrette",
        "text": "Seleziona una torretta dal pannello a destra e cliccala per posizionarla.",
        "highlight": "shop",
        "advance": "button",
    },
    {
        "id": "place_tower",
        "title": "Piazza una torretta",
        "text": "Clicca su un quadrato vuoto del terreno per posizionare la torretta selezionata.",
        "highlight": "map",
        "advance": "tower_placed",
    },
    {
        "id": "start_wave",
        "title": "Inizia la wave",
        "text": "Premi SPAZIO o il pulsante 'Start Wave' per far partire la prima ondata di nemici.",
        "highlight": "wave_btn",
        "advance": "button",
    },
]


def tutorial_done_path() -> Path:
    return get_data_dir() / "tutorial_done"


def is_tutorial_done() -> bool:
    if IS_WEB:
        return True
    try:
        return tutorial_done_path().exists()
    except Exception:
        return False


def mark_tutorial_done() -> None:
    if IS_WEB:
        return
    try:
        path = tutorial_done_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch(exist_ok=True)
    except Exception:
        pass


def advance_tutorial_step(current_step: int, step_count: int) -> tuple[int, bool]:
    if current_step < 0:
        return -1, False
    next_step = current_step + 1
    if next_step >= step_count:
        return -1, True
    return next_step, False
