"""Mutator domain for tower defense runs."""
from dataclasses import dataclass
from typing import Iterable, Optional


@dataclass(frozen=True)
class Mutator:
    """Immutable mutator configuration."""

    id: str
    label: str
    kind: str  # "bonus" | "malus"
    description: str
    score_mult: float
    xp_bonus: int


# Bonus pool definitions
_BONUS_MUTATORS = (
    Mutator(
        id="gold_rush",
        label="Gold Rush",
        kind="bonus",
        description="Starting gold +75",
        score_mult=0.95,
        xp_bonus=0,
    ),
    Mutator(
        id="reinforced_towers",
        label="Reinforced Towers",
        kind="bonus",
        description="Tower max HP +20%",
        score_mult=0.95,
        xp_bonus=0,
    ),
    Mutator(
        id="slow_opening",
        label="Slow Opening",
        kind="bonus",
        description="First 3 waves enemy speed -10%",
        score_mult=0.95,
        xp_bonus=0,
    ),
)

# Malus pool definitions
_MALUS_MUTATORS = (
    Mutator(
        id="glass_towers",
        label="Glass Towers",
        kind="malus",
        description="Tower max HP -20%",
        score_mult=1.10,
        xp_bonus=30,
    ),
    Mutator(
        id="scarce_gold",
        label="Scarce Gold",
        kind="malus",
        description="Starting gold -50",
        score_mult=1.15,
        xp_bonus=40,
    ),
    Mutator(
        id="elite_bosses",
        label="Elite Bosses",
        kind="malus",
        description="Boss HP +20%",
        score_mult=1.20,
        xp_bonus=50,
    ),
)

# Combined pool
_ALL_MUTATORS = _BONUS_MUTATORS + _MALUS_MUTATORS

# Index for fast lookup
_MUTATORS_BY_ID = {m.id: m for m in _ALL_MUTATORS}


def available_mutators(kind: Optional[str] = None) -> tuple[Mutator, ...]:
    """Return all mutators or filtered by kind.

    Args:
        kind: Optional filter by "bonus" or "malus". None returns all.

    Returns:
        Tuple of matching Mutator objects.
    """
    if kind is None:
        return _ALL_MUTATORS
    elif kind == "bonus":
        return _BONUS_MUTATORS
    elif kind == "malus":
        return _MALUS_MUTATORS
    else:
        raise ValueError(f"Invalid kind: {kind}")


def mutator_by_id(id: str) -> Optional[Mutator]:
    """Look up mutator by id.

    Args:
        id: The mutator id.

    Returns:
        Mutator if found, None otherwise.
    """
    return _MUTATORS_BY_ID.get(id)


def validate_selection(ids: Iterable[str]) -> tuple[str, ...]:
    """Validate mutator selection per rules.

    Rules:
    - Max 1 bonus
    - Max 1 malus
    - Unknown IDs raise ValueError
    - Empty selection is valid

    Args:
        ids: Iterable of mutator ids.

    Returns:
        Stable tuple of validated ids.

    Raises:
        ValueError: If more than 1 bonus, more than 1 malus, or unknown id.
    """
    ids_list = list(ids)
    bonuses = []
    maluses = []

    for id in ids_list:
        m = mutator_by_id(id)
        if m is None:
            raise ValueError(f"Unknown mutator id: {id}")

        if m.kind == "bonus":
            bonuses.append(id)
        elif m.kind == "malus":
            maluses.append(id)

    if len(bonuses) > 1:
        raise ValueError(
            f"Too many bonuses: {len(bonuses)}. Max 1 allowed."
        )

    if len(maluses) > 1:
        raise ValueError(
            f"Too many maluses: {len(maluses)}. Max 1 allowed."
        )

    # Return stable tuple (bonuses first, then maluses for consistency)
    return tuple(bonuses + maluses)


def score_multiplier_for(ids: Iterable[str]) -> float:
    """Calculate score multiplier product.

    Args:
        ids: Iterable of mutator ids.

    Returns:
        Product of all score_mult values. Empty = 1.0.
    """
    result = 1.0
    for id in ids:
        m = mutator_by_id(id)
        if m is not None:
            result *= m.score_mult
    return result


def xp_bonus_for(ids: Iterable[str]) -> int:
    """Calculate XP bonus sum (only from malus).

    Args:
        ids: Iterable of mutator ids.

    Returns:
        Sum of xp_bonus from malus mutators, capped at 100.
    """
    total = 0
    for id in ids:
        m = mutator_by_id(id)
        if m is not None and m.kind == "malus":
            total += m.xp_bonus
    return min(total, 100)
