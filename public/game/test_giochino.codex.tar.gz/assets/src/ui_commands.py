from dataclasses import dataclass


@dataclass(frozen=True)
class UICommand:
    """Base class for all UI panel commands."""


@dataclass(frozen=True)
class PowerupCommand(UICommand):
    powerup_id: str


@dataclass(frozen=True)
class TowerSelectCommand(UICommand):
    cls_name: str


@dataclass(frozen=True)
class TowerLevelSelectCommand(UICommand):
    cls_name: str
    level: int


@dataclass(frozen=True)
class LoadoutCommand(UICommand):
    preset_name: str


@dataclass(frozen=True)
class QueueAddCommand(UICommand):
    order_spec: str


@dataclass(frozen=True)
class QueueRemoveCommand(UICommand):
    index: int


@dataclass(frozen=True)
class PolicyCommand(UICommand):
    policy: str
    bulk: bool = False


@dataclass(frozen=True)
class LockedCommand(UICommand):
    dlc_id: str


@dataclass(frozen=True)
class SpeedCommand(UICommand):
    value: float


@dataclass(frozen=True)
class StartWaveCommand(UICommand):
    pass


@dataclass(frozen=True)
class RepairToggleCommand(UICommand):
    pass


@dataclass(frozen=True)
class RepairAllCommand(UICommand):
    pass


@dataclass(frozen=True)
class UpgradeAllCommand(UICommand):
    pass


@dataclass(frozen=True)
class AutoRepairAllToggleCommand(UICommand):
    pass
