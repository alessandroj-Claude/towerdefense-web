import random

from src import renderer
from src.perks import choices_allowed_for_difficulty, selected_perk_modifiers
from src.powerups import POWERUP_BY_ID


class PerkPowerupMixin:
    """Perk selection lifecycle and powerup context/HUD entries."""

    def _start_perk_selection(self) -> None:
        from src import game as game_module

        offers = game_module.generate_perk_offer(random.Random(), count=3)
        self._perk_offer_ids = [perk.id for perk in offers]
        self._selected_perk_ids = []
        self._perk_required_choices = choices_allowed_for_difficulty(self.difficulty)
        self._perk_card_rects = {}
        self._perk_confirm_rect = None
        self._perk_selection_feedback = ""

    def _toggle_selected_perk(self, perk_id: str) -> None:
        if perk_id in self._selected_perk_ids:
            self._selected_perk_ids.remove(perk_id)
            self._perk_selection_feedback = ""
            return
        if len(self._selected_perk_ids) >= self._perk_required_choices:
            self._perk_selection_feedback = f"Max {self._perk_required_choices} perks"
            return
        self._selected_perk_ids.append(perk_id)
        self._perk_selection_feedback = ""

    def _apply_run_start_perk_modifiers(self) -> None:
        self._perk_modifiers = selected_perk_modifiers(self._selected_perk_ids)
        start_gold_pct = float(self._perk_modifiers.get("starting_gold_pct", 0.0))
        if start_gold_pct > 0.0:
            bonus_gold = int(self.economy.gold * start_gold_pct)
            if bonus_gold > 0:
                self.economy.gold += bonus_gold

    def _confirm_perk_selection(self) -> None:
        self._apply_run_start_perk_modifiers()
        self._perk_selection_feedback = ""
        self.state = "PLAYING"

    def _powerup_context(self) -> dict:
        return {
            "gold": self.economy.gold,
            "modifiers": self._powerup_modifiers,
            "towers": self.towers,
            "enemies": self.enemies,
            "powerup_state": self._powerup_state,
        }

    def _active_powerup_hud_entries(self) -> list[dict]:
        entries = []
        for powerup_id, timer in self._powerup_state.active_timers.items():
            if float(timer) <= 0.0:
                continue
            powerup = POWERUP_BY_ID.get(powerup_id)
            if powerup is None:
                label = powerup_id.replace("_", " ").title()
            else:
                label = powerup.id.replace("_", " ").title()
            entries.append({"id": powerup_id, "label": label, "timer": float(timer)})
        entries.sort(key=lambda item: item["id"])
        return entries

    def _draw_powerup_tooltip(self, mouse_pos: tuple[int, int]) -> None:
        hovered = self.ui.get_hovered_powerup_slot(mouse_pos, current_wave=self.wave_mgr.wave_number)
        if hovered is None:
            return
        tooltip = self.ui.get_powerup_tooltip(hovered["id"], self.economy, self._powerup_state)
        surf = getattr(self, "_game_surface", self.screen)
        renderer.draw_powerup_tooltip(
            surf,
            self.font,
            mouse_pos=mouse_pos,
            tooltip=tooltip,
            screen_w=surf.get_width(),
            screen_h=surf.get_height(),
        )
