"""Pure data module for Codex entries — no pygame, no game state."""

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class CodexEntry:
    """Immutable Codex entry with id, title, category, summary, stats, and optional notes."""
    id: str
    title: str
    category: str
    summary: str
    stats: tuple
    notes: tuple = ()


# ============================================================================
# TOWERS
# ============================================================================

_TOWER_ENTRIES = (
    CodexEntry(
        id="tower_basic",
        title="Basic Tower",
        category="Towers",
        summary="Standard tower with balanced stats.",
        stats=(
            ("Cost", "50"),
            ("Damage", "25"),
            ("Range", "120"),
            ("Fire Rate", "1.0"),
            ("Max HP", "150"),
        ),
    ),
    CodexEntry(
        id="tower_ice",
        title="Ice Tower",
        category="Towers",
        summary="Slows enemies while dealing reduced damage.",
        stats=(
            ("Cost", "80"),
            ("Damage", "5"),
            ("Range", "100"),
            ("Fire Rate", "1.5"),
            ("Slow Factor", "0.6"),
            ("Slow Duration", "2.0s"),
            ("Max HP", "100"),
        ),
    ),
    CodexEntry(
        id="tower_bomb",
        title="Bomb Tower",
        category="Towers",
        summary="High damage with splash radius.",
        stats=(
            ("Cost", "120"),
            ("Damage", "60"),
            ("Range", "90"),
            ("Fire Rate", "0.5"),
            ("Splash Radius", "60"),
            ("Max HP", "180"),
        ),
    ),
    CodexEntry(
        id="tower_sniper",
        title="Sniper Tower",
        category="Towers",
        summary="Extreme range and damage, slow fire rate.",
        stats=(
            ("Cost", "150"),
            ("Damage", "120"),
            ("Range", "250"),
            ("Fire Rate", "0.3"),
            ("Proj Speed", "600"),
            ("Max HP", "80"),
        ),
    ),
    CodexEntry(
        id="tower_antiair",
        title="Anti-Air Tower",
        category="Towers",
        summary="Specializes in downing flying enemies with bonus damage.",
        stats=(
            ("Cost", "130"),
            ("Damage", "40"),
            ("Range", "165"),
            ("Fire Rate", "1.8"),
            ("Bonus to Flying", "1.5x"),
            ("Proj Speed", "420"),
            ("Max HP", "120"),
        ),
        notes=("Targets flying enemies first.",),
    ),
    CodexEntry(
        id="tower_storm",
        title="Storm Tower",
        category="Towers",
        summary="Lightning element with trails and moderate splash.",
        stats=(
            ("Cost", "110"),
            ("Damage", "35"),
            ("Range", "135"),
            ("Fire Rate", "1.4"),
            ("Proj Speed", "340"),
            ("Max HP", "130"),
        ),
    ),
    CodexEntry(
        id="tower_inferno",
        title="Inferno Tower",
        category="Towers",
        summary="Fire element with heavy splash damage.",
        stats=(
            ("Cost", "180"),
            ("Damage", "85"),
            ("Range", "110"),
            ("Fire Rate", "0.55"),
            ("Splash Radius", "70"),
            ("Max HP", "220"),
        ),
    ),
    CodexEntry(
        id="tower_venom",
        title="Venom Tower",
        category="Towers",
        summary="Applies poison DoT over time.",
        stats=(
            ("Cost", "140"),
            ("Damage", "5"),
            ("Range", "110"),
            ("Fire Rate", "0.8"),
            ("Poison Duration", "3.0s"),
            ("Poison DPS", "2% of max_hp/s"),
            ("Max HP", "100"),
        ),
    ),
    CodexEntry(
        id="tower_medic",
        title="Medic Tower",
        category="Towers",
        summary="Heals nearby towers instead of attacking.",
        stats=(
            ("Cost", "110"),
            ("Damage", "0"),
            ("Healing Rate", "8 HP/pulse"),
            ("Heal Interval", "1.0s"),
            ("Heal Radius", "1.5 tiles"),
            ("Max HP", "180"),
        ),
        notes=("Does not attack enemies. Heals other towers.",),
    ),
    CodexEntry(
        id="tower_sentinel",
        title="Sentinel Tower",
        category="Towers",
        summary="Heavily armored tower with moderate damage output.",
        stats=(
            ("Cost", "200"),
            ("Damage", "15"),
            ("Range", "100"),
            ("Fire Rate", "0.6"),
            ("Max HP", "400"),
        ),
        notes=("Attracts enemy fire; can be targeted by Heavy Enemy.",),
    ),
)

# ============================================================================
# ENEMIES
# ============================================================================

_ENEMY_ENTRIES = (
    CodexEntry(
        id="enemy_basic",
        title="Basic Enemy",
        category="Enemies",
        summary="Standard enemy with balanced hp and speed.",
        stats=(
            ("HP", "100"),
            ("Speed", "1.0"),
            ("Reward", "10"),
            ("Lives Damage", "1"),
        ),
    ),
    CodexEntry(
        id="enemy_fast",
        title="Fast Enemy",
        category="Enemies",
        summary="Quick and weak.",
        stats=(
            ("HP", "60"),
            ("Speed", "2.0"),
            ("Reward", "15"),
            ("Lives Damage", "1"),
            ("Element", "Air"),
        ),
    ),
    CodexEntry(
        id="enemy_tank",
        title="Tank Enemy",
        category="Enemies",
        summary="Heavy and slow, resistant to slow effects.",
        stats=(
            ("HP", "400"),
            ("Speed", "0.5"),
            ("Reward", "40"),
            ("Lives Damage", "3"),
            ("Element", "Earth"),
            ("Slow Resist", "0.7"),
        ),
    ),
    CodexEntry(
        id="enemy_swarm",
        title="Swarm Enemy",
        category="Enemies",
        summary="Weak but numerous.",
        stats=(
            ("HP", "30"),
            ("Speed", "1.5"),
            ("Reward", "5"),
            ("Lives Damage", "1"),
        ),
    ),
    CodexEntry(
        id="enemy_heavy",
        title="Heavy Enemy",
        category="Enemies",
        summary="Attacks towers directly. Prefers Sentinels.",
        stats=(
            ("HP", "200"),
            ("Speed", "0.5"),
            ("Reward", "25"),
            ("Lives Damage", "2"),
            ("Element", "Earth"),
            ("Shoot Range", "120"),
            ("Shoot Damage", "15"),
        ),
        notes=("Shoots towers. Targets Sentinel towers first.",),
    ),
    CodexEntry(
        id="enemy_flying",
        title="Flying Enemy",
        category="Enemies",
        summary="Fast flyer that shoots towers.",
        stats=(
            ("HP", "162"),
            ("Speed", "0.906"),
            ("Reward", "20"),
            ("Lives Damage", "1"),
            ("Element", "Air"),
            ("Shoot Range", "140"),
            ("Shoot Damage", "10"),
        ),
        notes=("Anti-Air towers are more effective. Avoids ground obstacles.",),
    ),
    CodexEntry(
        id="enemy_boss",
        title="Boss Enemy",
        category="Enemies",
        summary="Powerful elite enemy with random powerups.",
        stats=(
            ("HP", "1600"),
            ("Speed", "0.25"),
            ("Reward", "500"),
            ("Lives Damage", "5"),
            ("Element", "Random"),
            ("Shoot Range", "180"),
            ("Shoot Damage", "40"),
        ),
        notes=(
            "Spawns with 1-2 random powerups: ARMORED, SWIFT, REGENERATOR, RESISTANT.",
            "Shoots with splash damage.",
        ),
    ),
)

# ============================================================================
# ELEMENTS
# ============================================================================

_ELEMENT_ENTRIES = (
    CodexEntry(
        id="elem_fire",
        title="Fire",
        category="Elements",
        summary="Deals extra damage to Air enemies.",
        stats=(
            ("Strong Against", "Air"),
            ("Weak Against", "Earth, Water"),
        ),
    ),
    CodexEntry(
        id="elem_ice",
        title="Ice",
        category="Elements",
        summary="Slows targets.",
        stats=(
            ("Strong Against", "Air, Water"),
            ("Weak Against", "Fire"),
            ("Effect", "Reduces speed"),
        ),
    ),
    CodexEntry(
        id="elem_lightning",
        title="Lightning",
        category="Elements",
        summary="Fast projectiles with chain potential.",
        stats=(
            ("Strong Against", "Water"),
            ("Weak Against", "Earth"),
        ),
    ),
    CodexEntry(
        id="elem_earth",
        title="Earth",
        category="Elements",
        summary="Heavy damage with splash.",
        stats=(
            ("Strong Against", "Fire, Lightning"),
            ("Weak Against", "Air"),
            ("Effect", "Splash damage"),
        ),
    ),
    CodexEntry(
        id="elem_arcane",
        title="Arcane",
        category="Elements",
        summary="Neutral element with stable damage.",
        stats=(
            ("Strong Against", "All equally"),
            ("Weak Against", "None"),
        ),
    ),
    CodexEntry(
        id="elem_air",
        title="Air",
        category="Elements",
        summary="Fast and light.",
        stats=(
            ("Strong Against", "Earth"),
            ("Weak Against", "Fire, Lightning"),
        ),
    ),
)

# ============================================================================
# TERRAIN
# ============================================================================

_TERRAIN_ENTRIES = (
    CodexEntry(
        id="terrain_road",
        title="Road",
        category="Terrain",
        summary="Default path for enemies.",
        stats=(
            ("Type", "Path"),
            ("Speed Modifier", "1.0x"),
        ),
    ),
    CodexEntry(
        id="terrain_mud",
        title="Mud",
        category="Terrain",
        summary="Slows enemies traversing it.",
        stats=(
            ("Type", "Hazard"),
            ("Speed Modifier", "0.5x"),
        ),
    ),
    CodexEntry(
        id="terrain_wind",
        title="Wind Aura",
        category="Terrain",
        summary="Weak wind effect on passing enemies.",
        stats=(
            ("Type", "Effect"),
            ("Speed Modifier", "0.8x"),
        ),
    ),
    CodexEntry(
        id="terrain_high_wind",
        title="High Wind",
        category="Terrain",
        summary="Strong wind pushback on enemies.",
        stats=(
            ("Type", "Effect"),
            ("Speed Modifier", "0.6x"),
        ),
    ),
    CodexEntry(
        id="terrain_fortified",
        title="Fortified",
        category="Terrain",
        summary="Protective terrain for towers.",
        stats=(
            ("Type", "Defense"),
            ("Tower Armor", "+25%"),
        ),
    ),
)

# ============================================================================
# EVENTS
# ============================================================================

_EVENT_ENTRIES = (
    CodexEntry(
        id="event_sandstorm",
        title="Sandstorm",
        category="Events",
        summary="Reduces tower accuracy.",
        stats=(
            ("Effect", "Accuracy -30%"),
            ("Duration", "Variable"),
        ),
    ),
    CodexEntry(
        id="event_fog",
        title="Fog",
        category="Events",
        summary="Reduces tower range.",
        stats=(
            ("Effect", "Range -20%"),
            ("Duration", "Variable"),
        ),
    ),
    CodexEntry(
        id="event_supply_drop",
        title="Supply Drop",
        category="Events",
        summary="Grants bonus gold.",
        stats=(
            ("Effect", "Gold +50%"),
            ("Duration", "Single wave"),
        ),
    ),
    CodexEntry(
        id="event_earthquake",
        title="Earthquake",
        category="Events",
        summary="Damages all towers slightly.",
        stats=(
            ("Effect", "Tower damage -10% max HP"),
            ("Duration", "Instant"),
        ),
    ),
    CodexEntry(
        id="event_antiair_protocol",
        title="Anti-Air Protocol",
        category="Events",
        summary="Boosts all Anti-Air towers.",
        stats=(
            ("Effect", "Anti-Air damage +40%"),
            ("Duration", "Variable"),
        ),
    ),
)

# ============================================================================
# BOSS POWER-UPS
# ============================================================================

_BOSS_ENTRIES = (
    CodexEntry(
        id="boss_armored",
        title="Armored",
        category="Boss",
        summary="Reduces incoming damage.",
        stats=(
            ("Damage Reduction", "50%"),
        ),
    ),
    CodexEntry(
        id="boss_swift",
        title="Swift",
        category="Boss",
        summary="Increases movement speed.",
        stats=(
            ("Speed Multiplier", "1.5x"),
        ),
    ),
    CodexEntry(
        id="boss_regenerator",
        title="Regenerator",
        category="Boss",
        summary="Heals over time.",
        stats=(
            ("Regen Rate", "5.0 HP/s"),
        ),
    ),
    CodexEntry(
        id="boss_resistant",
        title="Resistant",
        category="Boss",
        summary="Highly resistant to slow effects.",
        stats=(
            ("Slow Resistance", "90%"),
        ),
    ),
)

# ============================================================================
# PUBLIC API
# ============================================================================

_ALL_ENTRIES = (
    _TOWER_ENTRIES
    + _ENEMY_ENTRIES
    + _ELEMENT_ENTRIES
    + _TERRAIN_ENTRIES
    + _EVENT_ENTRIES
    + _BOSS_ENTRIES
)

_ENTRIES_BY_ID = {entry.id: entry for entry in _ALL_ENTRIES}


def codex_categories() -> tuple:
    """Return all Codex categories."""
    return ("Towers", "Enemies", "Elements", "Terrain", "Events", "Boss")


def entries_for_category(category: str) -> tuple:
    """Return all entries for a given category."""
    return tuple(entry for entry in _ALL_ENTRIES if entry.category == category)


def entry_by_id(entry_id: str) -> Optional[CodexEntry]:
    """Return entry by id, or None if not found."""
    return _ENTRIES_BY_ID.get(entry_id)
