import json
import sqlite3
from collections import deque
from pathlib import Path
from typing import Optional, Any
from src.shares import SHARE_3  # Shamir share distribution
import src.tower as tm
import src.enemy as em
from src.db import get_connection, sql
from src.data_paths import data_path, migrate_legacy_file
from src.events import EventDirector, event_chance_for_difficulty
from src.adaptive import default_adaptive_state
from src.perks import deserialize_perk_state, selected_perk_modifiers, serialize_perk_state
from src.powerups import PowerupRuntimeState
from src.challenges import ChallengeDefinition, SUPPORTED_MODIFIERS

# Keep SAVE_PATH for backward-compat with legacy tests that monkeypatch it
SAVE_PATH = data_path("savegame.json")
LEGACY_SAVE_PATH = Path(__file__).parent.parent / "savegame.json"

TOWER_CLASSES = {
    "BasicTower": tm.BasicTower, "IceTower": tm.IceTower,
    "BombTower": tm.BombTower, "SniperTower": tm.SniperTower,
    "AntiAirTower": tm.AntiAirTower,
    "StormTower": tm.StormTower, "InfernoTower": tm.InfernoTower,
    "VenomTower": tm.VenomTower, "MedicTower": tm.MedicTower, "SentinelTower": tm.SentinelTower,
}
ENEMY_CLASSES = {
    "BasicEnemy": em.BasicEnemy, "FastEnemy": em.FastEnemy,
    "TankEnemy": em.TankEnemy, "SwarmEnemy": em.SwarmEnemy,
    "BossEnemy": em.BossEnemy, "HeavyEnemy": em.HeavyEnemy,
    "FlyingEnemy": em.FlyingEnemy,
}


def _normalize_adaptive_state(state) -> dict:
    base = default_adaptive_state()
    if not isinstance(state, dict):
        return base
    for key in ("hp_mult", "speed_mult", "damage_mult", "last_wave_max_progress"):
        try:
            base[key] = float(state.get(key, base[key]))
        except (TypeError, ValueError):
            pass
    return base


def _resolve_tower_class(type_name: str):
    """Resolve saved tower classes from canonical definitions, not unlock state.

    The save blob must stay loadable even if the current runtime has a filtered
    tower registry, so we fall back to the concrete class exported by
    ``src.tower`` when the local registry is incomplete.
    """
    tower_cls = TOWER_CLASSES.get(type_name)
    if tower_cls is None:
        tower_cls = getattr(tm, type_name, None)
    return tower_cls


def _safe_setattr(obj, name: str, value) -> None:
    try:
        setattr(obj, name, value)
    except Exception:
        pass


def _normalize_perk_state(state) -> dict:
    if not isinstance(state, dict):
        return serialize_perk_state([], [])
    try:
        offered_ids, selected_ids = deserialize_perk_state(state)
    except (TypeError, ValueError, KeyError):
        offered_ids, selected_ids = [], []
    return serialize_perk_state(offered_ids, selected_ids)


def _normalize_powerup_state(state) -> dict:
    if isinstance(state, PowerupRuntimeState):
        return state.to_dict()
    if isinstance(state, dict):
        try:
            return PowerupRuntimeState.from_dict(state).to_dict()
        except (TypeError, ValueError, KeyError):
            return PowerupRuntimeState().to_dict()
    return PowerupRuntimeState().to_dict()


def _serialize_enemy_state(enemy) -> dict:
    state = {}
    for attr, default in (
        ("_shoot_timer", 0.0),
        ("_slow_timer", 0.0),
        ("_slow_factor", 1.0),
    ):
        value = getattr(enemy, attr, None)
        if value is None:
            continue
        try:
            numeric_value = float(value)
        except (TypeError, ValueError):
            continue
        if numeric_value != default:
            state[attr] = numeric_value
    return state


def _restore_enemy_state(enemy, state) -> None:
    if not isinstance(state, dict):
        return
    for attr in ("_shoot_timer", "_slow_timer", "_slow_factor"):
        if attr not in state:
            continue
        try:
            _safe_setattr(enemy, attr, float(state[attr]))
        except (TypeError, ValueError):
            continue
    flight_distance = getattr(enemy, "_flight_distance", None)
    if flight_distance is not None:
        try:
            if float(getattr(enemy, "progress", 0.0)) >= float(flight_distance):
                _safe_setattr(enemy, "reached_end", True)
        except (TypeError, ValueError):
            pass


def _serialize_enemy_record(enemy) -> dict:
    record = {
        "type": type(enemy).__name__,
        "progress": enemy.progress,
        "hp": enemy.hp,
    }
    state = _serialize_enemy_state(enemy)
    if state:
        record["state"] = state
    return record


def _restore_perk_runtime_state(game, state) -> None:
    perk_state = _normalize_perk_state(state)
    offered_ids, selected_ids = deserialize_perk_state(perk_state)
    _safe_setattr(game, "_perk_offer_ids", offered_ids)
    _safe_setattr(game, "_selected_perk_ids", selected_ids)
    _safe_setattr(game, "_perk_modifiers", selected_perk_modifiers(selected_ids))


def _restore_powerup_runtime_state(game, state) -> None:
    payload = _normalize_powerup_state(state)
    restored = PowerupRuntimeState.from_dict(payload)
    _safe_setattr(game, "_powerup_state", restored)

    modifiers = getattr(game, "_powerup_modifiers", None)
    if isinstance(modifiers, dict):
        modifiers.clear()
        if restored.active_timers.get("overcharge", 0.0) > 0.0:
            modifiers["tower_fire_rate_mult"] = 1.35
    else:
        created = {}
        if restored.active_timers.get("overcharge", 0.0) > 0.0:
            created["tower_fire_rate_mult"] = 1.35
        _safe_setattr(game, "_powerup_modifiers", created)


def _reset_simulation_speed_after_load(game) -> None:
    setter = getattr(game, "_set_simulation_speed", None)
    if callable(setter):
        try:
            setter(1.0)
            return
        except Exception:
            pass
    _safe_setattr(game, "simulation_speed", 1.0)


def _normalize_qol_state(state) -> dict:
    if not isinstance(state, dict):
        return {"auto_repair_all_enabled": False}
    return {"auto_repair_all_enabled": bool(state.get("auto_repair_all_enabled", False))}


def _serialize_challenge_state(game) -> Optional[dict]:
    challenge = getattr(game, "active_challenge", None)
    if not isinstance(challenge, ChallengeDefinition):
        return None
    return {
        "kind": challenge.kind,
        "challenge_id": challenge.challenge_id,
        "seed": int(challenge.seed),
        "label": challenge.label,
        "modifiers": list(challenge.modifiers),
    }


def _restore_challenge_state(state) -> Optional[ChallengeDefinition]:
    if not isinstance(state, dict):
        return None
    kind = str(state.get("kind", "")).strip().lower()
    challenge_id = str(state.get("challenge_id", "")).strip()
    if kind not in {"daily", "weekly"} or not challenge_id:
        return None
    try:
        seed = int(state.get("seed"))
    except (TypeError, ValueError):
        return None
    label = str(state.get("label", "")).strip() or f"{kind.title()} {challenge_id}"
    raw_modifiers = state.get("modifiers", ())
    if not isinstance(raw_modifiers, (list, tuple)):
        raw_modifiers = ()
    modifiers = tuple(
        str(name) for name in raw_modifiers if str(name) in SUPPORTED_MODIFIERS
    )
    return ChallengeDefinition(
        kind=kind,
        challenge_id=challenge_id,
        seed=seed,
        label=label,
        modifiers=modifiers,
    )


def _serialize_map_state(game_map) -> dict:
    path = [[int(c), int(r)] for c, r in getattr(game_map, "path", [])]
    terrain_entries = []
    for (c, r), terrain in getattr(game_map, "terrain_by_cell", {}).items():
        terrain_entries.append([int(c), int(r), str(terrain)])
    blocked = [[int(c), int(r)] for c, r in getattr(game_map, "blocked_cells", set())]
    return {
        "path": path,
        "terrain_by_cell": terrain_entries,
        "blocked_cells": blocked,
    }


def _restore_map_state(game, map_state) -> None:
    if not isinstance(map_state, dict):
        return
    game_map = getattr(game, "game_map", None)
    if game_map is None:
        return
    try:
        restored_path = [(int(c), int(r)) for c, r in map_state.get("path", [])]
    except (TypeError, ValueError):
        return
    if not restored_path:
        return

    terrain_by_cell = {}
    for entry in map_state.get("terrain_by_cell", []):
        if not isinstance(entry, (list, tuple)) or len(entry) != 3:
            continue
        c, r, terrain = entry
        try:
            terrain_by_cell[(int(c), int(r))] = str(terrain)
        except (TypeError, ValueError):
            continue

    blocked_cells = set()
    for cell in map_state.get("blocked_cells", []):
        if not isinstance(cell, (list, tuple)) or len(cell) != 2:
            continue
        c, r = cell
        try:
            blocked_cells.add((int(c), int(r)))
        except (TypeError, ValueError):
            continue

    game_map.path = restored_path
    game_map._path_set = set(restored_path)
    if terrain_by_cell:
        game_map.terrain_by_cell = terrain_by_cell
    else:
        game_map.terrain_by_cell = {cell: "road" for cell in restored_path}
    game_map.blocked_cells = blocked_cells
    all_cells = {(c, r) for c in range(game_map.cols) for r in range(game_map.rows)}
    game_map.buildable = all_cells - game_map._path_set - game_map.blocked_cells
    if hasattr(game, "wave_mgr"):
        game.wave_mgr.path = game_map.path


def save_exists(user_id: Optional[int] = None,
                _conn: Optional[Any] = None) -> bool:
    if user_id is None:
        # Legacy path: check JSON file
        migrate_legacy_file("savegame.json")
        return SAVE_PATH.exists()
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        return conn.execute(
            sql("SELECT 1 FROM saves WHERE user_id = ?"), (user_id,)
        ).fetchone() is not None
    finally:
        if owns_conn:
            conn.close()


def serialize_game_state(game) -> dict:
    """Serializza lo stato del gioco in un dict JSON-serializable."""
    last_combat_recap = getattr(game, "last_combat_recap", None)
    if not isinstance(last_combat_recap, dict):
        last_combat_recap = None
    selected_boss_reward = getattr(game, "selected_boss_reward_id", None)
    if not isinstance(selected_boss_reward, str):
        selected_boss_reward = None
    boss_reward_screen_state = getattr(game, "state", None)
    if not isinstance(boss_reward_screen_state, str):
        boss_reward_screen_state = None
    data = {
        "economy": {
            "gold": game.economy.gold,
            "lives": game.economy.lives,
            "score": game.economy.score,
        },
        "difficulty": game.economy.difficulty,
        "wave_number": game.wave_mgr.wave_number,
        "wave_state": {
            "active": bool(getattr(game.wave_mgr, "active", False)),
            "timer": float(getattr(game.wave_mgr, "_timer", 0.0)),
            "spawned_count": int(getattr(game.wave_mgr, "spawned_count", 0)),
            "total_to_spawn": int(getattr(game.wave_mgr, "total_to_spawn", 0)),
            "queue": [
                {"type": enemy_cls.__name__, "spawn_time": spawn_time}
                for enemy_cls, spawn_time in getattr(game.wave_mgr, "_queue", ())
            ],
        },
        "towers": [
            {"type": type(t).__name__, "col": t.col, "row": t.row,
             "level": t.level, "gold_invested": t.gold_invested, "hp": t.hp}
            for t in game.towers
        ],
        "enemies": [
            _serialize_enemy_record(e)
            for e in game.enemies if e.alive
        ],
        "adaptive_state": _normalize_adaptive_state(getattr(game, "adaptive_state", None)),
        "perk_state": _normalize_perk_state(
            serialize_perk_state(
                getattr(game, "_perk_offer_ids", []),
                getattr(game, "_selected_perk_ids", []),
            )
        ),
        "powerup_state": _normalize_powerup_state(getattr(game, "_powerup_state", None)),
        "qol_state": _normalize_qol_state(
            {
                "auto_repair_all_enabled": getattr(game, "auto_repair_all_enabled", False),
            }
        ),
        "map_state": _serialize_map_state(game.game_map),
        "v5_4_state": {
            "loadout_preset": getattr(game, "_loadout_preset", None),
            "tower_targeting": {
                f"{t.col}_{t.row}": getattr(t, "targeting_policy", "furthest")
                for t in game.towers
            },
            "order_queue": list(getattr(game, "_order_queue", [])),
            "wave_report": getattr(game, "_wave_report", None),
            "last_combat_recap": last_combat_recap,
        },
        "boss_reward_state": {
            "pending": list(getattr(game, "pending_boss_rewards", []) or []),
            "selected": selected_boss_reward,
            "state": boss_reward_screen_state,
        },
    }
    director = getattr(game, "event_director", None)
    if director is not None and hasattr(director, "to_state"):
        event_state = director.to_state()
        if isinstance(event_state, dict):
            data["event_state"] = event_state
    challenge_state = _serialize_challenge_state(game)
    if challenge_state is not None:
        data["challenge_state"] = challenge_state
    data["mutator_state"] = {
        "active": list(getattr(game, "active_mutators", [])),
        "score_mult": float(getattr(game, "run_score_mult", 1.0)),
    }
    return data


def save_game(game, user_id: Optional[int] = None,
              _conn: Optional[Any] = None) -> bool:
    if game.economy.game_over:
        return False
    conn = None
    owns_conn = False
    try:
        data = serialize_game_state(game)
        if user_id is None:
            # Legacy path: write JSON file
            SAVE_PATH.parent.mkdir(parents=True, exist_ok=True)
            SAVE_PATH.write_text(json.dumps(data, indent=2))
            return True
        conn = _conn or get_connection()
        owns_conn = _conn is None
        conn.execute(sql("DELETE FROM saves WHERE user_id = ?"), (user_id,))
        conn.execute(
            sql("INSERT INTO saves (user_id, data, saved_at) VALUES (?, ?, CURRENT_TIMESTAMP)"),
            (user_id, json.dumps(data))
        )
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        if owns_conn and conn is not None:
            conn.close()


def load_game(game, user_id: Optional[int] = None,
              _conn: Optional[Any] = None) -> bool:
    if user_id is None:
        # Legacy path: read JSON file
        migrate_legacy_file("savegame.json")
        if not SAVE_PATH.exists():
            return False
        try:
            data = json.loads(SAVE_PATH.read_text())
        except (OSError, json.JSONDecodeError, TypeError, ValueError):
            return False
    else:
        conn = _conn or get_connection()
        owns_conn = _conn is None
        try:
            row = conn.execute(
                sql("SELECT data FROM saves WHERE user_id = ? ORDER BY id DESC LIMIT 1"),
                (user_id,)
            ).fetchone()
        finally:
            if owns_conn:
                conn.close()
        if row is None:
            return False
        try:
            data = json.loads(row["data"])
        except (json.JSONDecodeError, TypeError, ValueError):
            return False

    return restore_game_state(game, data)


def restore_game_state(game, data: dict) -> bool:
    """Applica un dict di stato al gioco. Non tocca SQLite."""

    try:
        eco = data["economy"]
        _restore_map_state(game, data.get("map_state"))
        new_towers = []
        for td in data["towers"]:
            tower_cls = _resolve_tower_class(td["type"])
            if tower_cls is None:
                raise KeyError(td["type"])
            t = tower_cls(
                col=td["col"], row=td["row"], tile_size=game.game_map.tile_size
            )
            t.level = td["level"]
            t.gold_invested = td["gold_invested"]
            m = 1.25 ** (td["level"] - 1)
            t.damage = t.base_damage * m
            t.range_px = t.base_range * m
            t.hp = td.get("hp", t.max_hp)
            new_towers.append(t)
        new_enemies = []
        for ed in data["enemies"]:
            e = ENEMY_CLASSES[ed["type"]](
                path=game.game_map.path, tile_size=game.game_map.tile_size
            )
            e.progress = ed["progress"]
            e.hp = ed["hp"]
            if e.hp <= 0:
                e.alive = False
            _restore_enemy_state(e, ed.get("state"))
            new_enemies.append(e)
        difficulty = data.get("difficulty", "normal")
        game.difficulty = difficulty
        game.economy.difficulty = difficulty
        from src.economy import DIFFICULTY_PRESETS
        preset = DIFFICULTY_PRESETS[difficulty]
        game.economy.reward_mult = preset["reward_mult"]
        game.economy.hp_scale = preset["hp_scale"]
        game.economy.meteor_enemy_pct = preset["meteor_enemy_pct"]
        game.economy.meteor_tower_pct = preset["meteor_tower_pct"]
        game.wave_mgr.hp_scale = preset["hp_scale"]
        game.economy.gold = eco["gold"]
        game.economy.lives = eco["lives"]
        game.economy.score = eco["score"]
        game.wave_mgr.wave_number = data["wave_number"]
        adaptive_state = _normalize_adaptive_state(data.get("adaptive_state"))
        game.adaptive_state = adaptive_state
        game.wave_mgr.adaptive_hp_mult = adaptive_state["hp_mult"]
        game._current_wave_max_progress = adaptive_state["last_wave_max_progress"]
        game._adaptive_last_applied_wave = game.wave_mgr.wave_number
        wave_state = data.get("wave_state")
        if wave_state is None:
            game.wave_mgr.active = False
            game.wave_mgr._timer = 0.0
            game.wave_mgr.spawned_count = 0
            game.wave_mgr.total_to_spawn = 0
            game.wave_mgr._queue = deque()
        else:
            game.wave_mgr.active = bool(wave_state.get("active", False))
            game.wave_mgr._timer = float(wave_state.get("timer", 0.0))
            game.wave_mgr.spawned_count = int(wave_state.get("spawned_count", 0))
            game.wave_mgr.total_to_spawn = int(wave_state.get("total_to_spawn", 0))
            restored_queue = deque()
            for entry in wave_state.get("queue", []):
                enemy_cls = ENEMY_CLASSES[entry["type"]]
                restored_queue.append((enemy_cls, float(entry["spawn_time"])))
            game.wave_mgr._queue = restored_queue
        game.towers = new_towers
        game.enemies = new_enemies
        game.projectiles = []
        event_state = data.get("event_state")
        if not hasattr(game, "_event_modifiers") or not isinstance(game._event_modifiers, dict):
            game._event_modifiers = {}
        game._event_modifiers.clear()
        if isinstance(event_state, dict):
            game.event_director = EventDirector.from_state(
                event_state,
                event_chance=event_chance_for_difficulty(difficulty),
            )
            event_ctx = _event_context_for(game)
            game.event_director.reapply_active_effects(event_ctx)
        else:
            game.event_director = EventDirector(
                event_chance=event_chance_for_difficulty(difficulty),
            )
        sync_display = getattr(game, "_sync_event_display", None)
        if callable(sync_display):
            sync_display()
        else:
            active = game.event_director.active_event
            game._event_label = active.label if active is not None else None
            game._event_timer = game.event_director.remaining_time if active is not None else 0.0
            game._event_tint = active.overlay_rgba if active is not None else None
        _restore_perk_runtime_state(game, data.get("perk_state"))
        _restore_powerup_runtime_state(game, data.get("powerup_state"))
        qol_state = _normalize_qol_state(data.get("qol_state"))
        _safe_setattr(game, "auto_repair_all_enabled", qol_state["auto_repair_all_enabled"])
        # v5.4 state restoration
        v5_4 = data.get("v5_4_state", {})
        _safe_setattr(game, "_loadout_preset", v5_4.get("loadout_preset", None))
        _safe_setattr(game, "_order_queue", list(v5_4.get("order_queue", [])))
        _safe_setattr(game, "_wave_report", v5_4.get("wave_report", None))
        _safe_setattr(game, "last_combat_recap", v5_4.get("last_combat_recap", None))
        boss_reward_state = data.get("boss_reward_state", {})
        pending_boss_rewards = list(boss_reward_state.get("pending", []) or [])
        _safe_setattr(game, "pending_boss_rewards", pending_boss_rewards)
        _safe_setattr(game, "selected_boss_reward_id", boss_reward_state.get("selected", None))
        if pending_boss_rewards and boss_reward_state.get("state", "BOSS_REWARD") == "BOSS_REWARD":
            _safe_setattr(game, "state", "BOSS_REWARD")
        # Restore tower targeting policies
        tower_targeting = v5_4.get("tower_targeting", {})
        for t in game.towers:
            key = f"{t.col}_{t.row}"
            if key in tower_targeting:
                t.targeting_policy = tower_targeting[key]
        restored_challenge = _restore_challenge_state(data.get("challenge_state"))
        _safe_setattr(game, "active_challenge", restored_challenge)
        _safe_setattr(game, "pending_challenge", None)
        mut_state = data.get("mutator_state", {})
        _safe_setattr(game, "active_mutators", list(mut_state.get("active", [])))
        _safe_setattr(game, "run_score_mult", float(mut_state.get("score_mult", 1.0)))
        _reset_simulation_speed_after_load(game)
        return True
    except Exception:
        return False


def _event_context_for(game) -> dict:
    event_context = getattr(game, "_event_context", None)
    if callable(event_context):
        return event_context()
    ctx = {
        "modifiers": game._event_modifiers,
        "economy": game.economy,
    }
    earn = getattr(game.economy, "earn", None)
    if callable(earn):
        ctx["grant_gold"] = earn
    return ctx
