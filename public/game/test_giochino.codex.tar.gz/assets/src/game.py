from __future__ import annotations
import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass
import sys
import random
import math
import importlib
from datetime import date
from typing import Optional
from src.adaptive import apply_adaptive_increment, default_adaptive_state, is_endless
from src.economy import Economy
from src.events import EventDirector, event_chance_for_difficulty
from src.map import (
    GameMap,
    TERRAIN_MUD,
    TERRAIN_WIND,
    TERRAIN_HIGH_WIND,
    TERRAIN_FORTIFIED,
)
from src.wave import WaveManager, wave_preview
from src.tower import (
    BasicTower,
    IceTower,
    BombTower,
    SniperTower,
    AntiAirTower,
    build_tower_for_placement,
    placement_cost_for_level,
    towers_sorted_xy_for_type,
)
from src.enemy import BossEnemy, BossProjectile, FlyingEnemy, SwarmEnemy
from src.ui import (UI, TOWER_CLASSES, PANEL_HEIGHT, HUD_BAR_HEIGHT, repair_cost, repair_hp,
                    handle_dlc_menu_click,
                    tower_requires_dlc, tower_is_unlocked)
from src import renderer
from src import save as save_module
from src.profile import (
    create_user, authenticate_user, user_exists,
    list_user_records, ensure_default_admin, soft_delete_user
)
from src.license import (
    activate_dlc, is_dlc_unlocked, get_user_dlcs,
    set_dlc_state, AVAILABLE_DLCS
)
from src.version import detect_runtime_version
from src.config import IS_WEB
from src.perks import (
    PERK_BY_ID,
    generate_perk_offer,
)
from src.challenges import ChallengeDefinition, daily_challenge, weekly_challenge
from src.map_seed import MapSeedState, initial_seed_state, reroll_seed
from src.bosses import boss_reward_pool
from src.combat_log import CombatLog
from src.synergy import compute_synergies, apply_synergy_bonuses, reset_synergy_bonuses
from src.achievements import check_run_achievements, unlock_achievements, get_achievement
from src.powerups import (
    POWERUP_BY_ID,
    PowerupRuntimeState,
    end_wave_powerups,
    try_activate_powerup,
    update_powerups,
)
from src.terrain import TerrainEvolutionEngine
from src.game_codex import codex_categories, entries_for_category, entry_by_id
from src.game_tower_mixin import TowerControllerMixin
from src.game_wave_mixin import WaveControllerMixin
from src.game_profile_mixin import ProfileControllerMixin
from src.game_perk_mixin import PerkPowerupMixin
from src.game_order_mixin import OrderQueueMixin
from src.leaderboard import record_score_run, top5_global, top5_user
from src.ui_commands import (
    UICommand, PowerupCommand, TowerSelectCommand, TowerLevelSelectCommand,
    LoadoutCommand, QueueAddCommand, QueueRemoveCommand, PolicyCommand,
    LockedCommand, SpeedCommand, StartWaveCommand, RepairToggleCommand,
    RepairAllCommand, UpgradeAllCommand, AutoRepairAllToggleCommand,
    SellTowerCommand,
)
from src.renderer._fonts import fonts

COLS, ROWS = 18, 10
TILE = 64
ENTITY_VISUAL_TILE = 56
SCREEN_W = COLS * TILE
SCREEN_H = ROWS * TILE + PANEL_HEIGHT
FPS = 60
BETWEEN_WAVES = 5.0
TERRAIN_SPEED_MULT = {
    TERRAIN_MUD: 0.85,
    TERRAIN_WIND: 1.12,
    TERRAIN_HIGH_WIND: 1.0,
    TERRAIN_FORTIFIED: 1.0,
}
TERRAIN_ACCURACY_MULT = {
    TERRAIN_WIND: 0.90,
    TERRAIN_HIGH_WIND: 0.80,
}
TERRAIN_FLYING_SPEED_MULT = {
    TERRAIN_HIGH_WIND: 1.08,
}
TERRAIN_GROUND_DAMAGE_MULT = {
    TERRAIN_FORTIFIED: 0.80,
}
SPEED_MULT_MIN = 0.4
SPEED_MULT_MAX = 2.5
ACCURACY_MULT_MIN = 0.3
ACCURACY_MULT_MAX = 1.0
RUNTIME_VERSION = "v8.10"

TOWER_MAP = {cls.__name__: cls for cls in TOWER_CLASSES}


def _safe_pygame_init() -> None:
    if hasattr(pygame, "init"):
        pygame.init()
        return

    # Web fallback: some pygame wasm builds expose only submodules.
    for mod_name in ("display", "font", "time", "event", "mixer"):
        try:
            sub = getattr(pygame, mod_name, None)
            if sub is None:
                sub = importlib.import_module(f"pygame.{mod_name}")
                setattr(pygame, mod_name, sub)
            init_fn = getattr(sub, "init", None)
            if callable(init_fn):
                init_fn()
        except Exception:
            pass


class Game(TowerControllerMixin, WaveControllerMixin, ProfileControllerMixin, PerkPowerupMixin, OrderQueueMixin):
    _wasm_clipboard_js_injected: bool = False

    def __init__(self):
        from src.db import init_db
        from src.analytics import AnalyticsManager
        init_db()
        ensure_default_admin()
        _safe_pygame_init()
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H), pygame.RESIZABLE)
        self._game_surface = pygame.Surface((SCREEN_W, SCREEN_H))
        self._win_w: int = SCREEN_W
        self._win_h: int = SCREEN_H
        pygame.display.set_caption("Tower Defense")
        self.clock = pygame.time.Clock()
        self.font = fonts.sized(16)
        self.state = "PROFILE_IDENTIFY"
        self.analytics_manager = AnalyticsManager()
        self._init_with_loading()

    def _draw_loading(self, progress: float):
        self.screen.fill((0, 0, 0))
        font_big = fonts.sized_bold(48)
        title = font_big.render("TOWER DEFENSE", True, (255, 255, 255))
        self.screen.blit(title, (SCREEN_W // 2 - title.get_width() // 2, SCREEN_H // 2 - 80))
        sub = self.font.render("Caricamento...", True, (180, 180, 180))
        self.screen.blit(sub, (SCREEN_W // 2 - sub.get_width() // 2, SCREEN_H // 2 - 10))
        bar_w, bar_h = 300, 20
        bar_x = SCREEN_W // 2 - bar_w // 2
        bar_y = SCREEN_H // 2 + 20
        pygame.draw.rect(self.screen, (60, 60, 60), (bar_x, bar_y, bar_w, bar_h), border_radius=4)
        fill_w = int(bar_w * progress)
        if fill_w > 0:
            pygame.draw.rect(self.screen, (80, 160, 80), (bar_x, bar_y, fill_w, bar_h), border_radius=4)
        pygame.draw.rect(self.screen, (120, 120, 120), (bar_x, bar_y, bar_w, bar_h), 2, border_radius=4)
        pygame.display.flip()
        pygame.event.pump()

    def _init_with_loading(self):
        self._draw_loading(0.0)
        self.game_map = GameMap(cols=COLS, rows=ROWS, tile_size=TILE)
        self._draw_loading(0.5)
        self.terrain_evolution = TerrainEvolutionEngine(self.game_map, max_mutations=2)
        self.economy = Economy()
        self.adaptive_state = default_adaptive_state()
        self._current_wave_max_progress: float = 0.0
        self._adaptive_last_applied_wave: int = 0
        self._adaptive_last_delta: dict[str, float] = {
            "hp_mult": 0.0,
            "speed_mult": 0.0,
            "damage_mult": 0.0,
        }
        self._wave_lives_lost: bool = False
        self._synergy_active: bool = False
        self._synergy_label: str = ""
        self._adaptive_rationale: str = ""
        self.terrain_preview_visible: bool = True
        self._update_adaptive_rationale()
        self.wave_mgr = WaveManager(
            path=self.game_map.path,
            tile_size=TILE,
            hp_scale=self.economy.hp_scale,
            adaptive_hp_mult=self.adaptive_state["hp_mult"],
        )
        self._draw_loading(0.75)
        self.towers = []
        self._active_synergies: list = []
        self.enemies = []
        self.projectiles = []
        self.enemy_projectiles = []
        self.selected_cls = None
        self._placement_levels: dict[type, int] = {}  # per-tower memory, default 1
        self.selected_tower = None
        self.ui = UI(SCREEN_W, SCREEN_H, self.font)
        self._draw_loading(1.0)
        self.countdown = 0.0
        self._wave_preview: dict = {}
        self._toast = ""
        self._toast_timer = 0.0
        self._shop_notice = ""
        self._shop_notice_timer = 0.0
        self._pause_rects = {}
        self._floating_texts = []
        self.difficulty = "normal"
        self.current_user_id = None  # type: Optional[int]
        self.current_username: str = ""
        self.unlocked_dlcs: set[str] = set()
        self.login_username: str = ""
        self.text_input: str = ""
        self.text_input2: str = ""
        self._profile_active_field: str = "password"
        self.profile_error: str = ""
        self.selected_dlc: str = ""
        self.dlc_error: str = ""
        self._profile_rects: dict = {}
        self._dlc_rects: dict = {}
        self._menu_load_rect = None
        self._menu_load_enabled: bool = False
        self._menu_dlc_rect = None
        self._menu_daily_rect = None
        self._menu_weekly_rect = None
        self._menu_admin_rect = None
        self._menu_codex_rect = None
        self._codex_category: str = "Towers"
        self._codex_entry_index: int = 0
        self._admin_user_rects: dict[int, pygame.Rect] = {}
        self._admin_dlc_rects: dict[str, pygame.Rect] = {}
        self._admin_users: list[tuple[int, str]] = []
        self._admin_users_full: list[dict] = []
        self._admin_selected_user_id: Optional[int] = None
        self._admin_selected_user_dlcs: set[str] = set()
        self._admin_notice: str = ""
        self._admin_delete_rect = pygame.Rect(0, 0, 0, 0)
        self._key_paste_rect = pygame.Rect(0, 0, 0, 0)
        self._difficulty_rects = {}
        self._meteor_triggered: bool = False
        self._meteor_shower = None
        self._meteor_display_timer: float = 0.0
        self._auto_repair_timer: float = 0.0
        self.repair_mode_active: bool = False
        self.auto_repair_all_enabled: bool = False
        self.runtime_version: str = detect_runtime_version(default=RUNTIME_VERSION)
        self._run_score_recorded: bool = False
        self._progression_recorded: bool = False
        self._last_xp_result: Optional[dict] = None
        self.last_error: str = ""
        self._leaderboard_filter: str = "all"
        self._leaderboard_global_by_difficulty: dict[str, list[dict]] = {
            "easy": [],
            "normal": [],
            "hard": [],
            "endless": [],
        }
        self._leaderboard_user_by_difficulty: dict[str, list[dict]] = {
            "easy": [],
            "normal": [],
            "hard": [],
            "endless": [],
        }
        self._leaderboard_global_top: list[dict] = []
        self._leaderboard_user_top: list[dict] = []
        self.event_director = EventDirector(
            rng=random.Random(),
            event_chance=event_chance_for_difficulty(self.difficulty),
        )
        self._event_modifiers: dict[str, float] = {}
        self._event_label: Optional[str] = None
        self._event_timer: float = 0.0
        self._event_tint: Optional[tuple] = None
        self.simulation_speed: float = 1.0
        self._perk_offer_ids: list[str] = []
        self._selected_perk_ids: list[str] = []
        self._perk_required_choices: int = 0
        self._perk_card_rects: dict[str, pygame.Rect] = {}
        self._perk_confirm_rect: Optional[pygame.Rect] = None
        self._perk_selection_feedback: str = ""
        self._perk_modifiers: dict[str, float] = {}
        self._powerup_state = PowerupRuntimeState()
        self._powerup_modifiers: dict[str, float] = {}
        self._hud_speed_rects: list = []
        self._loadout_preset: Optional[str] = None
        self._order_queue: list[dict] = []
        self._order_queue_log: list[str] = []
        # v5.4 wave report tracking
        self._wave_report: Optional[dict] = None
        self._wave_report_dmg: dict[str, int] = {}
        self._wave_report_flying_kills: int = 0
        self._wave_report_lives_lost: int = 0
        self._wave_report_gold_earned: int = 0
        # L5: Analytics screen state
        self._analytics_top_runs: list[dict] = []
        self._menu_analytics_rect: Optional[pygame.Rect] = None
        self.damage_floats: list[tuple[float, float, int, float]] = []
        self._hover_cell: Optional[tuple[int, int]] = None
        self._api_client = None
        self._web_pending: Optional[dict] = None
        self._web_loading_msg: str = ""
        self._prev_state: str = "PAUSED"
        self.pending_challenge: Optional[ChallengeDefinition] = None
        self.active_challenge: Optional[ChallengeDefinition] = None
        self.challenge_fast_fliers_mult: float = 1.0
        self.challenge_boss_hp_mult: float = 1.0
        self.challenge_boss_reward_bonus: int = 0
        self.pending_mutators: list[str] = []
        self.active_mutators: list[str] = []
        self.run_score_mult: float = 1.0
        self._mutator_card_rects: dict[str, pygame.Rect] = {}
        self._mutator_confirm_rect: Optional[pygame.Rect] = None
        self.map_seed_state: Optional[MapSeedState] = None
        self.preview_map: Optional[GameMap] = None
        self._map_preview_button_rects: dict = {}
        self.pending_boss_rewards: list[str] = []
        self.selected_boss_reward_id: Optional[str] = None
        self._boss_reward_card_rects: dict[str, pygame.Rect] = {}
        self._boss_reward_confirm_rect: Optional[pygame.Rect] = None
        self._boss_reward_triggered_wave: Optional[int] = None
        self._combat_log = CombatLog()
        self.last_combat_recap: Optional[dict] = None
        self._run_stats: dict = {}
        self._run_achievements_unlocked: list = []

    def _set_web_leaderboards_fallback(self) -> None:
        self._leaderboard_global_by_difficulty = {"easy": [], "normal": [], "hard": [], "endless": []}
        self._leaderboard_user_by_difficulty = {"easy": [], "normal": [], "hard": [], "endless": []}
        self._leaderboard_global_top = []
        self._leaderboard_user_top = []

    def _set_simulation_speed(self, value: float) -> None:
        speed = float(value)
        if speed <= 0.0:
            speed = 1.0
        self.simulation_speed = speed

    def _init_run_stats(self) -> None:
        self._run_stats = {
            "wave": 0,
            "score": 0,
            "difficulty": self.difficulty,
            "lives_remaining": 0,
            "max_lives": getattr(self.economy, "max_lives", 0) if hasattr(self, "economy") else 0,
            "lives_lost_this_wave": 0,
            "boss_killed": False,
            "boss_wave_lives_lost": 0,
            "synergy_ids_activated": set(),
            "towers_placed": 0,
            "towers_sold": 0,
            "max_tower_level": 0,
            "powerup_used": False,
            "tower_repaired": False,
            "mutators_active": len(self.active_mutators) if hasattr(self, "active_mutators") else 0,
            "challenge_kind": getattr(self.active_challenge, "kind", None) if getattr(self, "active_challenge", None) else None,
            "endless": False,
        }
        self._run_achievements_unlocked = []

    def _init_game(self, difficulty: str = "normal"):
        self.difficulty = difficulty
        challenge = self.pending_challenge
        self.active_challenge = challenge
        self.pending_challenge = None
        self.challenge_fast_fliers_mult = 1.0
        self.challenge_boss_hp_mult = 1.0
        self.challenge_boss_reward_bonus = 0
        if challenge is not None:
            self.map_seed_state = MapSeedState(
                seed_text=str(challenge.seed),
                seed_value=challenge.seed,
                rerolls_left=0,
                locked=True,
            )
        else:
            self.map_seed_state = initial_seed_state()
        map_rng = random.Random(self.map_seed_state.seed_value)
        self.game_map = GameMap(cols=COLS, rows=ROWS, tile_size=TILE, rng=map_rng)
        self.preview_map = self.game_map
        self.terrain_evolution = TerrainEvolutionEngine(self.game_map, max_mutations=2)
        # Analytics: reset accumulator for new run
        try:
            self.analytics_manager.reset()
        except Exception:
            pass
        self.economy = Economy(difficulty=difficulty)
        if self._is_admin():
            self.economy.gold = 10000
        if challenge is not None:
            modifiers = set(challenge.modifiers)
            if "rich_start" in modifiers:
                self.economy.gold += 50
            if "fast_fliers" in modifiers:
                self.challenge_fast_fliers_mult = 1.10
            if "boss_pressure" in modifiers:
                self.challenge_boss_hp_mult = 1.10
                self.challenge_boss_reward_bonus = 100
        self.adaptive_state = default_adaptive_state()
        self._current_wave_max_progress = 0.0
        self._adaptive_last_applied_wave = 0
        self._adaptive_last_delta = {
            "hp_mult": 0.0,
            "speed_mult": 0.0,
            "damage_mult": 0.0,
        }
        self._wave_lives_lost = False
        self._synergy_active: bool = False
        self._synergy_label: str = ""
        self._adaptive_rationale: str = ""
        self.terrain_preview_visible: bool = True
        self._update_adaptive_rationale()
        self.wave_mgr = WaveManager(
            path=self.game_map.path,
            tile_size=TILE,
            hp_scale=self.economy.hp_scale,
            adaptive_hp_mult=self.adaptive_state["hp_mult"],
        )
        self.towers = []
        self._active_synergies: list = []
        self.enemies = []
        self.projectiles = []
        self.enemy_projectiles = []
        self.selected_cls = None
        self._placement_levels = {}
        self.selected_tower = None
        self.ui = UI(SCREEN_W, SCREEN_H, self.font)
        self.countdown = 0.0
        self._wave_preview: dict = {}
        self._toast = ""
        self._toast_timer = 0.0
        self._shop_notice = ""
        self._shop_notice_timer = 0.0
        self._pause_rects = {}
        self._floating_texts = []
        self._difficulty_rects = {}
        self._meteor_triggered: bool = False
        self._meteor_shower = None
        self._meteor_display_timer: float = 0.0
        self._auto_repair_timer: float = 0.0
        self.repair_mode_active = False
        self.auto_repair_all_enabled = False
        self._run_score_recorded = False
        self._progression_recorded = False
        self._last_xp_result = None
        self._leaderboard_filter = "all"
        self._leaderboard_global_by_difficulty = {
            "easy": [],
            "normal": [],
            "hard": [],
            "endless": [],
        }
        self._leaderboard_user_by_difficulty = {
            "easy": [],
            "normal": [],
            "hard": [],
            "endless": [],
        }
        self._leaderboard_global_top = []
        self._leaderboard_user_top = []
        self.event_director = EventDirector(
            rng=random.Random(),
            event_chance=event_chance_for_difficulty(difficulty),
        )
        self._event_modifiers = {}
        self._event_label = None
        self._event_timer = 0.0
        self._event_tint = None
        self._set_simulation_speed(1.0)
        self.pending_mutators = []
        self.active_mutators = []
        self.run_score_mult = 1.0
        self._perk_offer_ids = []
        self._selected_perk_ids = []
        self._perk_required_choices = 0
        self._perk_card_rects = {}
        self._perk_confirm_rect = None
        self._perk_selection_feedback = ""
        self._perk_modifiers = {}
        self._powerup_state = PowerupRuntimeState()
        self._powerup_modifiers = {}
        self._hud_speed_rects: list = []
        self._loadout_preset: Optional[str] = None
        self._order_queue: list[dict] = []
        self._order_queue_log: list[str] = []
        self.damage_floats = []
        self._hover_cell = None
        self.pending_boss_rewards = []
        self.selected_boss_reward_id = None
        self._boss_reward_card_rects = {}
        self._boss_reward_confirm_rect = None
        self._boss_reward_triggered_wave = None
        self._combat_log = CombatLog()
        self.last_combat_recap = None
        self._init_run_stats()

    def _add_damage_float(self, x: float, y: float, value: int) -> None:
        amount = int(value)
        if amount <= 0:
            return
        self.damage_floats.append((float(x), float(y), amount, 0.0))
        if len(self.damage_floats) > 8:
            self.damage_floats = self.damage_floats[-8:]

    def _window_to_game_pos(self, pos: tuple[int, int]) -> tuple[int, int]:
        wx = max(0, int(pos[0]))
        wy = max(0, int(pos[1]))
        if self._win_w == SCREEN_W and self._win_h == SCREEN_H:
            return wx, wy
        sx = SCREEN_W / max(1, self._win_w)
        sy = SCREEN_H / max(1, self._win_h)
        gx = min(SCREEN_W - 1, int(wx * sx))
        gy = min(SCREEN_H - 1, int(wy * sy))
        return gx, gy

    def _current_mouse_game_pos(self) -> tuple[int, int]:
        return self._window_to_game_pos(pygame.mouse.get_pos())

    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            self._handle_events()
            self._update(dt)
            self._draw()

    async def _dispatch_web_pending(self) -> None:
        import src.save as save_module
        pending = self._web_pending
        action = pending["action"]
        args = pending["args"]

        if action == "paste_key":
            pasted = await self._read_web_clipboard_text()
            if pasted:
                clean = "".join(ch for ch in pasted if ch.isprintable())
                if clean and len(self.text_input) < 64:
                    self.text_input += clean[: 64 - len(self.text_input)]
                    self.dlc_error = ""
                else:
                    self.dlc_error = "Clipboard letta ma testo non valido"
            else:
                self.dlc_error = (
                    "Clipboard non accessibile dal browser. "
                    "Incolla manualmente nel campo chiave."
                )
            self.state = "KEY_INPUT"
            return

        if action == "exists":
            username = args[0]
            exists = await self._api_client.check_user_exists(username)
            if exists is None:
                self.profile_error = "Backend offline: riprova tra qualche secondo"
                self.state = "PROFILE_IDENTIFY"
                return
            self.login_username = username
            self.text_input2 = ""
            self.profile_error = ""
            self.state = "PROFILE_LOGIN" if exists else "PROFILE_CREATE"

        elif action == "register":
            username, password = args
            result = await self._api_client.register(username, password)
            if result and isinstance(result, dict) and "user_id" in result:
                self.current_user_id = result["user_id"]
                self.current_username = result.get("username", username)
                dlcs = set(result.get("dlcs", [])) if isinstance(result.get("dlcs", []), list) else set()
                self._set_unlocked_dlcs(dlcs)
                self.profile_error = ""
                self.text_input = ""
                self.text_input2 = ""
                self.state = "MENU"
            else:
                self.profile_error = "Registrazione fallita (backend non raggiungibile o username già usato)"
                self.state = "PROFILE_CREATE"

        elif action == "login":
            username, password = args
            result = await self._api_client.login(username, password)
            if result and isinstance(result, dict) and "user_id" in result:
                self.current_user_id = result["user_id"]
                self.current_username = result.get("username", username)
                dlcs = set(result.get("dlcs", [])) if isinstance(result.get("dlcs", []), list) else set()
                self._set_unlocked_dlcs(dlcs)
                self.profile_error = ""
                self.text_input = ""
                self.text_input2 = ""
                self.state = "MENU"
            else:
                self.profile_error = "Login fallito (backend non raggiungibile o credenziali errate)"
                self.state = "PROFILE_LOGIN"

        elif action == "save":
            user_id = args[0]
            data = save_module.serialize_game_state(self)
            ok = await self._api_client.save_game(user_id, data)
            if ok:
                self._toast = "Salvato!"
            else:
                detail = getattr(self._api_client, "last_error", "") or "errore sconosciuto"
                self._toast = "Errore salvataggio" if detail == "errore sconosciuto" else f"Errore salvataggio ({detail})"
            self._toast_timer = 1.5
            self.state = getattr(self, "_prev_state", "PAUSED")

        elif action == "load":
            user_id = args[0]
            data = await self._api_client.load_game(user_id)
            if data and save_module.restore_game_state(self, data):
                self.state = "PLAYING"
            else:
                detail = getattr(self._api_client, "last_error", "") or "errore sconosciuto"
                self._toast = f"Errore caricamento ({detail})"
                self._toast_timer = 1.5
                self.state = "MENU"

        elif action == "admin_enter":
            users_raw = await self._api_client.admin_list_users()
            self._apply_admin_users(users_raw, keep_selection=False)
            self._admin_notice = "" if self._admin_users else "Nessun utente"
            self.state = "ADMIN_PANEL"

        elif action == "admin_delete":
            target_uid = args[0]
            ok = await self._api_client.admin_soft_delete(target_uid)
            if ok:
                users_raw = await self._api_client.admin_list_users()
                self._apply_admin_users(users_raw, keep_selection=False)
                self._admin_notice = f"Utente disattivato (id:{target_uid})"
            else:
                self._admin_notice = "Operazione negata"
            self.state = "ADMIN_PANEL"

        elif action == "admin_dlc":
            target_uid, dlc_id, want_unlock = args[0], args[1], args[2]
            ok = await self._api_client.admin_dlc_toggle(target_uid, dlc_id, want_unlock)
            if ok:
                users_raw = await self._api_client.admin_list_users()
                self._apply_admin_users(users_raw, keep_selection=True, selected_uid=target_uid)
                if target_uid == self.current_user_id:
                    self._set_unlocked_dlcs(self._admin_selected_user_dlcs)
                state_txt = "ON" if want_unlock else "OFF"
                self._admin_notice = f"{AVAILABLE_DLCS.get(dlc_id, dlc_id)} -> {state_txt}"
            else:
                self._admin_notice = "Operazione fallita"
            self.state = "ADMIN_PANEL"

        elif action == "dlc_activate":
            dlc_id, license_key = args[0], args[1]
            ok = await self._api_client.activate_dlc(dlc_id, license_key)
            if ok:
                if dlc_id:
                    self.unlocked_dlcs.add(dlc_id)
                self.dlc_error = ""
                self.text_input = ""
                self.state = "DLC_MENU"
            else:
                self.dlc_error = "Chiave non valida"
                self.state = "KEY_INPUT"

    async def _read_web_clipboard_text(self) -> str:
        if not IS_WEB:
            return ""
        try:
            import platform as _plat  # noqa: PLC0415

            if not Game._wasm_clipboard_js_injected:
                _plat.window.eval(
                    "window._pygameReadClipboard = function * _pygameReadClipboard() {"
                    "  var done = false;"
                    "  var out = '';"
                    "  try {"
                    "    if (navigator.clipboard && navigator.clipboard.readText) {"
                    "      navigator.clipboard.readText()"
                    "        .then(function(t){ out = t || ''; done = true; })"
                    "        .catch(function(){ done = true; });"
                    "    } else { done = true; }"
                    "  } catch (e) { done = true; }"
                    "  while (!done) { yield; }"
                    "  yield out;"
                    "}"
                )
                Game._wasm_clipboard_js_injected = True

            txt = await _plat.jsiter(_plat.window._pygameReadClipboard())
            return txt or ""
        except Exception:
            return ""

    async def run_async(self) -> None:
        """Game loop asincrono per Pygbag (WASM)."""
        import asyncio

        self._api_client = None
        self._web_pending = None
        self._web_loading_msg = ""
        self._prev_state = "PAUSED"
        if IS_WEB:
            from src.api_client import APIClient
            from src.config import BACKEND_URL

            self._api_client = APIClient(BACKEND_URL)

        self._running = True
        while self._running:
            dt = self.clock.tick(FPS) / 1000.0
            self._handle_events()
            self._update(dt)
            self._draw()
            if self.state == "WEB_LOADING" and self._web_pending is not None:
                try:
                    await self._dispatch_web_pending()
                except Exception:
                    self._toast = "Errore di rete"
                    self._toast_timer = 2.0
                    self.state = getattr(self, "_prev_state", "MENU")
                finally:
                    self._web_pending = None
            await asyncio.sleep(0)

    def _handle_events(self):
        for event in pygame.event.get():
            event_pos = None
            if hasattr(event, "pos"):
                event_pos = self._window_to_game_pos(event.pos)
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.VIDEORESIZE:
                self._win_w = max(400, event.w)
                self._win_h = max(300, event.h)
                self.screen = pygame.display.set_mode(
                    (self._win_w, self._win_h), pygame.RESIZABLE
                )
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                escape_state = self.state
                if self.state == "PLAYING":
                    self.state = "PAUSED"
                elif self.state == "PAUSED":
                    self.state = "PLAYING"
                elif self.state == "DIFFICULTY":
                    self.state = "MENU"
                elif self.state == "DLC_MENU":
                    self.state = "MENU"
                elif self.state == "KEY_INPUT":
                    self.state = "DLC_MENU"
                elif self.state == "PROFILE_CREATE":
                    self.state = "PROFILE_IDENTIFY"
                elif self.state == "PROFILE_LOGIN":
                    self.state = "PROFILE_IDENTIFY"
                elif self.state == "ADMIN_PANEL":
                    self.state = "MENU"
                elif self.state == "ANALYTICS":
                    self.state = "MENU"
                elif self.state == "CODEX":
                    self.state = "MENU"
                elif self.state == "MENU":
                    self._logout_to_profile_identify()
                elif self.state == "MUTATOR_SELECTION":
                    self.state = "DIFFICULTY"
                elif self.state == "PERK_SELECTION":
                    self.state = "DIFFICULTY"
                elif self.state == "MAP_PREVIEW":
                    self.state = "MUTATOR_SELECTION"
                if escape_state in {
                    "PLAYING",
                    "PAUSED",
                    "DIFFICULTY",
                    "DLC_MENU",
                    "KEY_INPUT",
                    "PROFILE_CREATE",
                    "PROFILE_LOGIN",
                    "ADMIN_PANEL",
                    "ANALYTICS",
                    "CODEX",
                    "MENU",
                    "MUTATOR_SELECTION",
                    "PERK_SELECTION",
                    "MAP_PREVIEW",
                }:
                    continue

            if self.state == "MENU":
                if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                    self.state = "DIFFICULTY"
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if (self._menu_load_rect
                            and self._menu_load_rect.collidepoint(event_pos)
                            and self._menu_load_enabled
                            and self.current_user_id is not None):
                        if IS_WEB and self._api_client and self.current_user_id is not None:
                            self._web_pending = {"action": "load", "args": (self.current_user_id,)}
                            self._web_loading_msg = "Caricamento..."
                            self.state = "WEB_LOADING"
                        elif save_module.load_game(self, self.current_user_id):
                            self.state = "PLAYING"
                    elif self._menu_dlc_rect and self._menu_dlc_rect.collidepoint(event_pos):
                        self.dlc_error = ""
                        self.state = "DLC_MENU"
                    elif self._menu_analytics_rect and self._menu_analytics_rect.collidepoint(event_pos):
                        self._analytics_top_runs = self.analytics_manager.load_top_n(n=5)
                        self._refresh_game_over_leaderboard()
                        self.state = "ANALYTICS"
                    elif self._menu_codex_rect and self._menu_codex_rect.collidepoint(event_pos):
                        self._codex_category = codex_categories()[0]
                        self._codex_entry_index = 0
                        self.state = "CODEX"
                    elif self._menu_daily_rect and self._menu_daily_rect.collidepoint(event_pos):
                        self.pending_challenge = daily_challenge(date.today())
                        self.state = "DIFFICULTY"
                    elif self._menu_weekly_rect and self._menu_weekly_rect.collidepoint(event_pos):
                        self.pending_challenge = weekly_challenge(date.today())
                        self.state = "DIFFICULTY"
                    elif (self._menu_admin_rect
                          and self._menu_admin_rect.collidepoint(event_pos)
                          and self._is_admin()):
                        self._enter_admin_panel()

            elif self.state == "DIFFICULTY":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for diff_name, rect in self._difficulty_rects.items():
                        if rect.collidepoint(event_pos):
                            self._init_game(difficulty=diff_name)
                            self.pending_mutators = []
                            self.state = "MUTATOR_SELECTION"
                            break

            elif self.state == "MUTATOR_SELECTION":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for mut_id, rect in self._mutator_card_rects.items():
                        if rect.collidepoint(event_pos):
                            self._toggle_mutator(mut_id)
                            break
                    if self._mutator_confirm_rect and self._mutator_confirm_rect.collidepoint(event_pos):
                        self._apply_mutators()
                        self._enter_map_preview()

            elif self.state == "PERK_SELECTION":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    clicked_perk = False
                    for perk_id, rect in self._perk_card_rects.items():
                        if rect.collidepoint(event_pos):
                            self._toggle_selected_perk(perk_id)
                            clicked_perk = True
                            break
                    if not clicked_perk and self._perk_confirm_rect and self._perk_confirm_rect.collidepoint(event_pos):
                        self._confirm_perk_selection()

            elif self.state == "MAP_PREVIEW":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    btns = self._map_preview_button_rects
                    if btns.get("confirm") and btns["confirm"].collidepoint(event_pos):
                        self.game_map = self.preview_map
                        self.wave_mgr.path = self.game_map.path
                        self.terrain_evolution = TerrainEvolutionEngine(self.game_map, max_mutations=2)
                        self._start_perk_selection()
                        self.state = "PERK_SELECTION"
                    elif btns.get("back") and btns["back"].collidepoint(event_pos):
                        self.state = "MUTATOR_SELECTION"
                    elif btns.get("reroll") and btns["reroll"].collidepoint(event_pos):
                        if self.map_seed_state is not None:
                            self.map_seed_state = reroll_seed(self.map_seed_state)
                            self.preview_map = GameMap(
                                cols=COLS, rows=ROWS, tile_size=TILE,
                                rng=random.Random(self.map_seed_state.seed_value),
                            )
                    elif btns.get("random") and btns["random"].collidepoint(event_pos):
                        if self.map_seed_state is not None and not self.map_seed_state.locked:
                            self.map_seed_state = reroll_seed(self.map_seed_state)
                            self.preview_map = GameMap(
                                cols=COLS, rows=ROWS, tile_size=TILE,
                                rng=random.Random(self.map_seed_state.seed_value),
                            )

            elif self.state == "BOSS_REWARD":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for reward_id, rect in self._boss_reward_card_rects.items():
                        if rect.collidepoint(event_pos):
                            self.selected_boss_reward_id = reward_id
                            break
                    if (
                        self._boss_reward_confirm_rect is not None
                        and self._boss_reward_confirm_rect.collidepoint(event_pos)
                        and self.selected_boss_reward_id
                    ):
                        self._apply_boss_reward(self.selected_boss_reward_id)
                        self.pending_boss_rewards = []
                        self.selected_boss_reward_id = None
                        self._boss_reward_card_rects = {}
                        self._boss_reward_confirm_rect = None
                        self.state = "PLAYING"

            elif self.state == "PLAYING":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self._handle_click(event_pos)
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                    self._handle_right_click(event_pos)
                if event.type == pygame.KEYDOWN:
                    speed_by_key = {
                        pygame.K_1: 1.0,
                        pygame.K_2: 1.5,
                        pygame.K_3: 2.0,
                        pygame.K_4: 3.0,
                    }
                    if event.key in speed_by_key:
                        self._set_simulation_speed(speed_by_key[event.key])
                    elif event.key == pygame.K_u:
                        self._try_upgrade()
                    elif event.key == pygame.K_t:
                        self.terrain_preview_visible = not self.terrain_preview_visible

            elif self.state == "PAUSED":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self._handle_pause_click(event_pos)

            elif self.state == "GAME_OVER":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.state = "DIFFICULTY"
                    elif event.key == pygame.K_m:
                        self.state = "MENU"
                    elif event.key == pygame.K_ESCAPE:
                        if IS_WEB:
                            import platform as _plat
                            _plat.window.navigateHome()
                        else:
                            pygame.quit()
                            sys.exit()
                    elif event.key == pygame.K_v:
                        self._leaderboard_filter = "current" if self._leaderboard_filter == "all" else "all"
                        if IS_WEB:
                            self._set_web_leaderboards_fallback()
                        else:
                            self._refresh_game_over_leaderboard()

            elif self.state == "PROFILE_IDENTIFY":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        if IS_WEB:
                            import platform as _plat
                            _plat.window.navigateHome()
                        else:
                            pygame.quit()
                            sys.exit()
                    elif event.key == pygame.K_RETURN:
                        username = self.text_input.strip()
                        if not username:
                            self.profile_error = "Inserisci username"
                        elif IS_WEB and self._api_client:
                            self.login_username = username
                            self._web_pending = {"action": "exists", "args": (username,)}
                            self._web_loading_msg = "Controllo utente..."
                            self.state = "WEB_LOADING"
                        elif user_exists(username):
                            self.login_username = username
                            self.text_input2 = ""
                            self.profile_error = ""
                            self.state = "PROFILE_LOGIN"
                        else:
                            self.login_username = username
                            self.text_input2 = ""
                            self.profile_error = ""
                            self.state = "PROFILE_CREATE"
                    elif event.key == pygame.K_BACKSPACE:
                        self.text_input = self.text_input[:-1]
                    else:
                        ch = getattr(event, "unicode", "")
                        if ch and ch.isprintable() and len(self.text_input) < 20:
                            self.text_input += ch

            elif self.state == "PROFILE_CREATE":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        if IS_WEB and self._api_client:
                            if self.login_username and self.text_input2:
                                self._web_pending = {"action": "register", "args": (self.login_username, self.text_input2)}
                                self._web_loading_msg = "Registrazione..."
                                self.state = "WEB_LOADING"
                            else:
                                self.profile_error = "Inserisci password"
                        elif self.login_username and self.text_input2:
                            uid = create_user(self.login_username, self.text_input2)
                            if uid is not None:
                                self.current_user_id = uid
                                self.current_username = self.login_username
                                self._set_unlocked_dlcs(get_user_dlcs(uid))
                                self.profile_error = ""
                                self.text_input = ""
                                self.text_input2 = ""
                                self.state = "MENU"
                            else:
                                self.profile_error = "Username già in uso"
                        else:
                            self.profile_error = "Inserisci password"
                    elif event.key == pygame.K_BACKSPACE:
                        self.text_input2 = self.text_input2[:-1]
                    else:
                        ch = getattr(event, "unicode", "")
                        if ch and ch.isprintable() and len(self.text_input2) < 50:
                            self.text_input2 += ch

            elif self.state == "PROFILE_LOGIN":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        if IS_WEB and self._api_client:
                            if self.text_input2:
                                self._web_pending = {"action": "login", "args": (self.login_username, self.text_input2)}
                                self._web_loading_msg = "Accesso..."
                                self.state = "WEB_LOADING"
                            else:
                                self.profile_error = "Inserisci password"
                        else:
                            uid = authenticate_user(self.login_username, self.text_input2)
                            if uid is not None:
                                self.current_user_id = uid
                                self.current_username = self.login_username
                                self._set_unlocked_dlcs(get_user_dlcs(uid))
                                self.profile_error = ""
                                self.text_input = ""
                                self.text_input2 = ""
                                self.state = "MENU"
                            else:
                                self.profile_error = "Password errata"
                    elif event.key == pygame.K_BACKSPACE:
                        self.text_input2 = self.text_input2[:-1]
                    else:
                        ch = getattr(event, "unicode", "")
                        if ch and ch.isprintable() and len(self.text_input2) < 50:
                            self.text_input2 += ch

            elif self.state == "ADMIN_PANEL":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if self._admin_delete_rect.collidepoint(event_pos):
                        if self._admin_selected_user_id is None:
                            self._admin_notice = "Nessun utente selezionato"
                        elif IS_WEB:
                            self._web_pending = {"action": "admin_delete", "args": (self._admin_selected_user_id,)}
                            self.state = "WEB_LOADING"
                        else:
                            ok = soft_delete_user(
                                self._admin_selected_user_id,
                                actor_user_id=self.current_user_id,
                                actor_username=self.current_username,
                            )
                            if ok:
                                deleted_uid = self._admin_selected_user_id
                                self._admin_users = list_user_records()
                                if self._admin_users:
                                    self._admin_selected_user_id = self._admin_users[0][0]
                                    self._admin_selected_user_dlcs = get_user_dlcs(self._admin_selected_user_id)
                                else:
                                    self._admin_selected_user_id = None
                                    self._admin_selected_user_dlcs = set()
                                self._admin_notice = f"Utente disattivato (id:{deleted_uid})"
                            else:
                                self._admin_notice = "Operazione negata"
                        continue
                    for uid, rect in self._admin_user_rects.items():
                        if rect.collidepoint(event_pos):
                            self._admin_selected_user_id = uid
                            if IS_WEB:
                                dlcs_raw = next(
                                    (u["dlcs"] for u in self._admin_users_full if int(u["user_id"]) == uid),
                                    [],
                                )
                                self._admin_selected_user_dlcs = set(dlcs_raw)
                            else:
                                self._admin_selected_user_dlcs = get_user_dlcs(uid)
                            self._admin_notice = ""
                            break
                    else:
                        if self._admin_selected_user_id is not None:
                            for dlc_id, rect in self._admin_dlc_rects.items():
                                if rect.collidepoint(event_pos):
                                    want_unlock = dlc_id not in self._admin_selected_user_dlcs
                                    if IS_WEB:
                                        self._web_pending = {"action": "admin_dlc", "args": (self._admin_selected_user_id, dlc_id, want_unlock)}
                                        self.state = "WEB_LOADING"
                                    else:
                                        ok = set_dlc_state(self._admin_selected_user_id, dlc_id, want_unlock)
                                        if ok:
                                            self._admin_selected_user_dlcs = get_user_dlcs(self._admin_selected_user_id)
                                            if self._admin_selected_user_id == self.current_user_id:
                                                self._set_unlocked_dlcs(self._admin_selected_user_dlcs)
                                            state_txt = "ON" if want_unlock else "OFF"
                                            self._admin_notice = f"{AVAILABLE_DLCS[dlc_id]} -> {state_txt}"
                                        else:
                                            self._admin_notice = "Operazione fallita"
                                    break

            elif self.state == "DLC_MENU":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    dlc_id = self._handle_dlc_menu_click(event_pos)
                    if dlc_id:
                        if is_dlc_unlocked(self.current_user_id, dlc_id):
                            self.dlc_error = f"{AVAILABLE_DLCS[dlc_id]} già attivo"
                        else:
                            self.selected_dlc = dlc_id
                            self.text_input = ""
                            self.dlc_error = ""
                            self.state = "KEY_INPUT"

            elif self.state == "ANALYTICS":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Check for back button click
                    if hasattr(self, '_analytics_rects') and "back" in self._analytics_rects:
                        if self._analytics_rects["back"].collidepoint(event_pos):
                            self.state = "MENU"
                if event.type == pygame.KEYDOWN and event.key == pygame.K_v:
                    self._leaderboard_filter = "current" if self._leaderboard_filter == "all" else "all"
                    if IS_WEB:
                        self._set_web_leaderboards_fallback()
                    else:
                        self._refresh_game_over_leaderboard()

            elif self.state == "CODEX":
                if event.type == pygame.KEYDOWN:
                    cats = codex_categories()
                    cat_idx = cats.index(self._codex_category) if self._codex_category in cats else 0
                    if event.key == pygame.K_LEFT:
                        self._codex_category = cats[(cat_idx - 1) % len(cats)]
                        self._codex_entry_index = 0
                    elif event.key == pygame.K_RIGHT:
                        self._codex_category = cats[(cat_idx + 1) % len(cats)]
                        self._codex_entry_index = 0
                    entries = entries_for_category(self._codex_category)
                    n = len(entries)
                    if event.key == pygame.K_UP:
                        self._codex_entry_index = (self._codex_entry_index - 1) % max(n, 1)
                    elif event.key == pygame.K_DOWN:
                        self._codex_entry_index = (self._codex_entry_index + 1) % max(n, 1)

            elif self.state == "KEY_INPUT":
                if event.type == pygame.TEXTINPUT:
                    txt = event.text or ""
                    clean = "".join(ch for ch in txt if ch.isprintable())
                    if clean and len(self.text_input) < 64:
                        self.text_input += clean[: 64 - len(self.text_input)]
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if self._key_paste_rect and self._key_paste_rect.collidepoint(event_pos):
                        if IS_WEB:
                            self._web_pending = {"action": "paste_key", "args": ()}
                            self._web_loading_msg = "Accesso clipboard..."
                            self.state = "WEB_LOADING"
                        else:
                            self._paste_into_key_input()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                    self._paste_into_key_input()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        if IS_WEB and self._api_client:
                            self._web_pending = {
                                "action": "dlc_activate",
                                "args": (self.selected_dlc, self.text_input),
                            }
                            self._web_loading_msg = "Verifica chiave..."
                            self.state = "WEB_LOADING"
                        else:
                            if activate_dlc(self.current_user_id, self.selected_dlc, self.text_input):
                                if self.selected_dlc:
                                    self.unlocked_dlcs.add(self.selected_dlc)
                                self.dlc_error = ""
                                self.text_input = ""
                                self.state = "DLC_MENU"
                            else:
                                self.dlc_error = "Chiave non valida"
                    elif event.key == pygame.K_BACKSPACE:
                        self.text_input = self.text_input[:-1]
                    elif (event.key == pygame.K_v
                          and event.mod & (pygame.KMOD_META | pygame.KMOD_CTRL)):
                        if IS_WEB:
                            self._web_pending = {"action": "paste_key", "args": ()}
                            self._web_loading_msg = "Accesso clipboard..."
                            self.state = "WEB_LOADING"
                        else:
                            self._paste_into_key_input()
                    else:
                        ch = getattr(event, "unicode", "")
                        if ch and ch.isprintable() and len(self.text_input) < 64:
                            self.text_input += ch

            elif self.state == "WEB_LOADING":
                pass  # input blocked during API call

    def _handle_click(self, pos):
        for btn_info in self.ui._policy_btn_rects:
            if btn_info["rect"].collidepoint(pos):
                if btn_info["bulk"]:
                    self._bulk_set_targeting_policy(btn_info["policy"])
                elif self.selected_tower is not None:
                    self._set_tower_targeting_policy(self.selected_tower, btn_info["policy"])
                return
        for speed_value, rect in self._hud_speed_rects:
            if rect.collidepoint(pos):
                self._set_simulation_speed(speed_value)
                return
        if self.ui.is_in_panel(pos):
            unlocked_dlcs = self._get_unlocked_dlcs()
            cmd = self.ui.handle_click(
                pos, self.economy, self.selected_tower,
                selected_cls=self.selected_cls,
                towers=self.towers,
                unlocked_dlcs=unlocked_dlcs,
                selected_placement_level=self._placement_levels.get(self.selected_cls, 1)
            )
            if isinstance(cmd, LockedCommand):
                self._shop_notice = f"{AVAILABLE_DLCS.get(cmd.dlc_id, cmd.dlc_id)} locked"
                self._shop_notice_timer = 1.5
                return
            if isinstance(cmd, SpeedCommand):
                self._set_simulation_speed(cmd.value)
                return
            if isinstance(cmd, LoadoutCommand):
                self._apply_loadout_preset(cmd.preset_name)
                return
            if isinstance(cmd, QueueAddCommand):
                order = self._parse_order_spec(cmd.order_spec)
                self._add_order(order)
                return
            if isinstance(cmd, QueueRemoveCommand):
                self._remove_order(cmd.index)
                return
            if isinstance(cmd, PowerupCommand):
                powerup_ctx = self._powerup_context()
                result = try_activate_powerup(cmd.powerup_id, powerup_ctx)
                self.economy.gold = int(powerup_ctx["gold"])
                if result == "ok":
                    self._run_stats["powerup_used"] = True
                    self._shop_notice = f"{cmd.powerup_id.replace('_', ' ').title()} active"
                    self._shop_notice_timer = 1.2
                    try:
                        self.analytics_manager.track_event("powerup_used", {"type": cmd.powerup_id})
                    except Exception:
                        pass
                elif result == "insufficient_gold":
                    self._shop_notice = "Gold insufficiente"
                    self._shop_notice_timer = 1.2
                elif result == "cooldown":
                    self._shop_notice = "Powerup in cooldown"
                    self._shop_notice_timer = 1.2
                elif result == "already_active":
                    self._shop_notice = "Powerup già attivo"
                    self._shop_notice_timer = 1.2
                else:
                    self._shop_notice = "Powerup unavailable"
                    self._shop_notice_timer = 1.2
                return
            if isinstance(cmd, StartWaveCommand) and not self.wave_mgr.active and self.countdown <= 0:
                self._start_wave()
                self._shop_notice = ""
                self._shop_notice_timer = 0.0
            elif isinstance(cmd, RepairToggleCommand):
                self.repair_mode_active = not self.repair_mode_active
                if self.repair_mode_active:
                    self.selected_cls = None
            elif isinstance(cmd, RepairAllCommand):
                self._repair_all_towers()
            elif isinstance(cmd, UpgradeAllCommand):
                self._upgrade_all_selected_type()
            elif isinstance(cmd, AutoRepairAllToggleCommand):
                self.auto_repair_all_enabled = not self.auto_repair_all_enabled
            elif isinstance(cmd, SellTowerCommand):
                if self.selected_tower:
                    tower = self.selected_tower
                    refund = int(tower.gold_invested * 0.75)
                    self.economy.refund(refund)
                    cx, cy = tower.col * TILE + TILE // 2, tower.row * TILE + TILE // 2
                    self._floating_texts.append([f"+{refund}g", int(cx), int(cy), 1.0])
                    self.towers.remove(tower)
                    self._run_stats["towers_sold"] = self._run_stats.get("towers_sold", 0) + 1
                    self.selected_tower = None
                    self._refresh_synergies()
            elif isinstance(cmd, PolicyCommand):
                if cmd.bulk:
                    self._bulk_set_targeting_policy(cmd.policy)
                elif self.selected_tower is not None:
                    self._set_tower_targeting_policy(self.selected_tower, cmd.policy)
            elif isinstance(cmd, TowerLevelSelectCommand):
                chosen_cls = TOWER_MAP.get(cmd.cls_name)
                if chosen_cls is not None:
                    self.selected_cls = chosen_cls
                    self._placement_levels[chosen_cls] = max(1, min(3, cmd.level))
                    self.repair_mode_active = False
                    self.selected_tower = None
                    self._shop_notice = ""
                    self._shop_notice_timer = 0.0
            elif isinstance(cmd, TowerSelectCommand):
                chosen_cls = TOWER_MAP.get(cmd.cls_name)
                if self.selected_cls is chosen_cls:
                    self.selected_cls = None
                else:
                    self.selected_cls = chosen_cls
                self.repair_mode_active = False
                self.selected_tower = None
                self._shop_notice = ""
                self._shop_notice_timer = 0.0
            return

        col = pos[0] // TILE
        row = pos[1] // TILE
        if row >= ROWS:
            return

        clicked_tower = next(
            (t for t in self.towers if t.col == col and t.row == row), None
        )

        if clicked_tower and self.repair_mode_active and self.selected_cls is None:
            self._apply_targeted_repair(clicked_tower)
            return

        # Shop-click upgrade: same tower type selected in shop → upgrade instead of place
        if clicked_tower and self.selected_cls and isinstance(clicked_tower, self.selected_cls):
            result = clicked_tower.try_shop_upgrade(self.economy)
            cx, cy = col * TILE + TILE // 2, row * TILE + TILE // 2
            if result == "max_level":
                self._floating_texts.append(["Max livello!", int(cx), int(cy), 1.5])
            elif result == "insufficient_gold":
                self._floating_texts.append(["Oro insufficiente!", int(cx), int(cy), 1.5])
            return

        if clicked_tower:
            self.selected_tower = clicked_tower
            self.selected_cls = None
            return

        if self.selected_cls and self.game_map.is_buildable(col, row):
            if not tower_is_unlocked(self.selected_cls, self._get_unlocked_dlcs()):
                dlc_id = tower_requires_dlc(self.selected_cls)
                if dlc_id:
                    self._shop_notice = f"{AVAILABLE_DLCS.get(dlc_id, dlc_id)} locked"
                    self._shop_notice_timer = 1.5
                return
            placement_level = self._placement_levels.get(self.selected_cls, 1)
            cost = placement_cost_for_level(self.selected_cls, placement_level)
            if not self.economy.can_afford(cost):
                self._shop_notice = "Gold insufficiente"
                self._shop_notice_timer = 1.2
                return
            self.economy.spend(cost)
            self.towers.append(
                build_tower_for_placement(
                    self.selected_cls,
                    col=col,
                    row=row,
                    tile_size=TILE,
                    level=placement_level,
                )
            )
            self._run_stats["towers_placed"] = self._run_stats.get("towers_placed", 0) + 1
            self._refresh_synergies()
            try:
                self.analytics_manager.track_event(
                    "tower_built", {"type": self.selected_cls.__name__}
                )
            except Exception:
                pass

    def _refresh_synergies(self) -> None:
        reset_synergy_bonuses(self.towers)
        synergies = compute_synergies(self.towers)
        apply_synergy_bonuses(self.towers, synergies)
        self._active_synergies = synergies
        if self._active_synergies:
            self._run_stats.setdefault("synergy_ids_activated", set()).update(
                s.label for s in self._active_synergies
            )
        if self.towers:
            self._run_stats["max_tower_level"] = max(t.level for t in self.towers)

    def _refresh_wave_preview(self) -> None:
        self._wave_preview = wave_preview(self.wave_mgr.wave_number + 1)

    def _handle_pause_click(self, pos):
        if self._pause_rects.get("Riprendi", pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            self.state = "PLAYING"
        elif self._pause_rects.get("Salva", pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            if IS_WEB and self._api_client and self.current_user_id is not None:
                self._prev_state = "PAUSED"
                self._web_pending = {"action": "save", "args": (self.current_user_id,)}
                self._web_loading_msg = "Salvataggio..."
                self.state = "WEB_LOADING"
                return
            else:
                ok = save_module.save_game(self, self.current_user_id)
                self._toast = "Salvato!" if ok else "Errore salvataggio"
            self._toast_timer = 1.5
        elif self._pause_rects.get("Carica", pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            if IS_WEB and self._api_client and self.current_user_id is not None:
                self._prev_state = "PAUSED"
                self._web_pending = {"action": "load", "args": (self.current_user_id,)}
                self._web_loading_msg = "Caricamento..."
                self.state = "WEB_LOADING"
                return
            elif save_module.save_exists(self.current_user_id):
                ok = save_module.load_game(self, self.current_user_id)
                self._toast = "Caricato!" if ok else "Errore caricamento"
                self._toast_timer = 1.5
                if ok:
                    self.state = "PLAYING"
        elif self._pause_rects.get("Return to start menu", pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            self._init_game()
            self.state = "MENU"
        elif self._pause_rects.get("Esci", pygame.Rect(0, 0, 0, 0)).collidepoint(pos):
            if IS_WEB:
                import platform as _plat
                _plat.window.navigateHome()
            else:
                pygame.quit()
                sys.exit()
        elif not any(r.collidepoint(pos) for r in self._pause_rects.values()):
            self.state = "PLAYING"

    def _handle_right_click(self, pos):
        if self.ui.is_in_panel(pos):
            return
        col, row = pos[0] // TILE, pos[1] // TILE
        if row >= ROWS:
            return
        tower = next((t for t in self.towers if t.col == col and t.row == row), None)
        if tower:
            refund = int(tower.gold_invested * 0.75)
            self.economy.refund(refund)
            cx, cy = tower.col * TILE + TILE // 2, tower.row * TILE + TILE // 2
            self._floating_texts.append([f"+{refund}g", int(cx), int(cy), 1.0])
            self.towers.remove(tower)
            if self.selected_tower is tower:
                self.selected_tower = None
            self._refresh_synergies()

    def _handle_boss_ability(self, boss: "BossEnemy", ability_id: str) -> None:
        """Execute a boss ability after its telegraph expires."""
        if ability_id:
            try:
                self._combat_log.record_boss_ability(ability_id)
                self._combat_log.record_event(f"Boss {ability_id}")
            except Exception:
                pass
        if ability_id == "summon_swarm":
            path = boss.path
            base_idx = max(0, min(int(boss.progress), len(path) - 1))
            for i in range(3):
                swarm = SwarmEnemy(path=path, tile_size=boss.tile_size)
                # stagger progress slightly so they don't overlap
                swarm.progress = max(0.0, boss.progress - 0.1 * (i + 1))
                self.enemies.append(swarm)
        elif ability_id == "armor_pulse":
            boss._armor_pulse_timer = 4.0

    def _update(self, dt: float):
        if self.state != "PLAYING":
            self.repair_mode_active = False
            return

        real_dt = dt
        sim_dt = real_dt * self.simulation_speed
        ctx = self._event_context()
        if not self.wave_mgr.active and self.countdown > 0:
            self.countdown -= real_dt
            if self.countdown <= 0:
                # Use only frame remainder after countdown expiry for gameplay updates.
                sim_dt = (-self.countdown) * self.simulation_speed
                self.countdown = 0.0
                self._start_wave()
            else:
                sim_dt = 0.0

        powerup_ctx = self._powerup_context()
        update_powerups(sim_dt, powerup_ctx)
        self.economy.gold = int(powerup_ctx["gold"])

        new_enemies = self.wave_mgr.update(sim_dt)
        if self.challenge_boss_hp_mult != 1.0 or self.challenge_boss_reward_bonus:
            for enemy in new_enemies:
                if isinstance(enemy, BossEnemy):
                    enemy.hp = int(round(enemy.hp * self.challenge_boss_hp_mult))
                    enemy.max_hp = int(round(enemy.max_hp * self.challenge_boss_hp_mult))
                    enemy.reward += int(self.challenge_boss_reward_bonus)
        self.enemies.extend(new_enemies)

        # moved to wave_start (now called in _on_wave_started)
        # if (self.wave_mgr.active
        #         and not self.event_director.trigger_consumed
        #         and self.event_director.active_event is None):
        #     triggered = self.event_director.maybe_trigger(
        #         self.wave_mgr.spawned_count,
        #         self.wave_mgr.total_to_spawn,
        #         ctx,
        #     )
        #     if triggered is not None:
        #         self._sync_event_display()

        enemy_speed_mult = max(0.0, float(self._event_modifiers.get("enemy_speed_mult", 1.0)))
        adaptive_speed_mult = max(0.0, float(self.adaptive_state.get("speed_mult", 1.0)))
        adaptive_damage_mult = max(0.0, float(self.adaptive_state.get("damage_mult", 1.0)))
        quake_stun_chance = self._clamp(
            float(self._event_modifiers.get("earthquake_stun_chance", 0.0)),
            0.0,
            1.0,
        )
        quake_stun_budget = max(0, int(self._event_modifiers.get("earthquake_stun_max_per_tick", 0)))
        event_rng = getattr(self.event_director, "rng", None)
        for e in self.enemies:
            terrain_speed_mult = self._enemy_speed_multiplier(e)
            total_speed_mult = self._clamp(
                enemy_speed_mult * adaptive_speed_mult * terrain_speed_mult,
                SPEED_MULT_MIN,
                SPEED_MULT_MAX,
            )
            if isinstance(e, FlyingEnemy):
                total_speed_mult = self._clamp(
                    total_speed_mult * self.challenge_fast_fliers_mult,
                    SPEED_MULT_MIN,
                    SPEED_MULT_MAX,
                )
            enemy_dt = sim_dt * total_speed_mult
            if quake_stun_budget > 0 and quake_stun_chance > 0.0 and callable(getattr(event_rng, "random", None)):
                if event_rng.random() < quake_stun_chance:
                    enemy_dt = 0.0
                    quake_stun_budget -= 1
            e.update(enemy_dt)
            if isinstance(e, BossEnemy) and e.ability_pending:
                self._handle_boss_ability(e, e.ability_pending)
                e.ability_pending = ""
            if hasattr(e, "path") and len(e.path) > 1:
                ratio = max(0.0, min(1.0, float(e.progress) / float(len(e.path) - 1)))
                if ratio > self._current_wave_max_progress:
                    self._current_wave_max_progress = ratio
            if e.reached_end:
                lives_damage = max(0, int(math.ceil(float(e.lives_damage) * adaptive_damage_mult)))
                self.economy.lose_life(lives_damage)
                if lives_damage > 0:
                    self._wave_lives_lost = True
                    self._wave_report_lives_lost += lives_damage
                    self._run_stats["lives_lost_this_wave"] = self._run_stats.get("lives_lost_this_wave", 0) + lives_damage
                    try:
                        self._combat_log.record_lives_lost(lives_damage)
                        self._combat_log.record_event(f"Leak -{lives_damage} lives")
                    except Exception:
                        pass
                e.reached_end = False
                e.alive = False
            e.damage_taken_mult = self._enemy_damage_taken_multiplier(e)

        accuracy_modifier = self._clamp(
            float(self._event_modifiers.get("tower_accuracy_mult", 1.0)),
            ACCURACY_MULT_MIN,
            ACCURACY_MULT_MAX,
        )
        range_modifier = self._event_modifiers.get("tower_range_mult", 1.0)
        anti_air_range_mult = max(0.0, float(self._event_modifiers.get("anti_air_range_mult", 1.0)))
        anti_air_accuracy_mult = max(0.0, float(self._event_modifiers.get("anti_air_accuracy_mult", 1.0)))

        for tower in self.towers:
            is_anti_air_tower = getattr(type(tower), "__name__", "") == "AntiAirTower"
            tower_range_modifier = range_modifier * (anti_air_range_mult if is_anti_air_tower else 1.0)

            def _tower_accuracy_target_modifier(enemy, _tower=tower, _is_anti_air=is_anti_air_tower) -> float:
                terrain_mult = self._target_accuracy_multiplier(enemy, _tower)
                if accuracy_modifier <= 0:
                    return 0.0
                total = self._clamp(
                    accuracy_modifier * terrain_mult,
                    ACCURACY_MULT_MIN,
                    ACCURACY_MULT_MAX,
                )
                target_mult = total / accuracy_modifier
                if _is_anti_air and getattr(type(enemy), "__name__", "") == "FlyingEnemy":
                    target_mult *= anti_air_accuracy_mult
                return target_mult

            powerup_fire_rate_mult = max(0.0, float(self._powerup_modifiers.get("tower_fire_rate_mult", 1.0)))
            perk_fire_rate_mult = max(0.0, 1.0 + float(self._perk_modifiers.get("tower_fire_rate_pct", 0.0)))
            tower_dt = sim_dt * powerup_fire_rate_mult * perk_fire_rate_mult
            # Support towers with base_fire_rate=0 use real sim_dt, not multiplied tower_dt
            t_dt = sim_dt if getattr(tower, "base_fire_rate", 1) == 0 else tower_dt
            projectile_start = len(self.projectiles)
            tower.update(
                t_dt,
                self.enemies,
                self.projectiles,
                accuracy_modifier=accuracy_modifier,
                range_modifier=tower_range_modifier,
                accuracy_target_modifier=_tower_accuracy_target_modifier,
                towers=self.towers,
            )
            for projectile in self.projectiles[projectile_start:]:
                setattr(projectile, "tower_owner", tower)

        if self.auto_repair_all_enabled and self.wave_mgr.active:
            self._tick_auto_repair(sim_dt)

        hits_all = []
        for p in self.projectiles:
            hp_before = {
                id(e): float(getattr(e, "hp", 0.0))
                for e in self.enemies
                if hasattr(e, "hp")
            }
            hits = p.update(sim_dt, self.enemies)
            hits_all.extend(hits)
            for hit_enemy in hits:
                current_hp = getattr(hit_enemy, "hp", None)
                if current_hp is None:
                    continue
                prev_hp = hp_before.get(id(hit_enemy), float(current_hp))
                dealt = max(0, int(round(prev_hp - float(current_hp))))
                if dealt > 0:
                    tower_owner = getattr(p, "tower_owner", None)
                    tower_type = getattr(type(tower_owner), "__name__", "") if tower_owner is not None else ""
                    if not tower_type:
                        tower_type = "UnknownTower"
                    try:
                        self._combat_log.record_damage(tower_type, dealt)
                    except Exception:
                        pass
                    pos = getattr(hit_enemy, "pos", None)
                    if pos is None or len(pos) != 2:
                        continue
                    ex, ey = pos
                    self._add_damage_float(ex, ey, dealt)

        for e in hits_all:
            if not e.alive:
                self._award_enemy_reward(e.reward)
                try:
                    self._combat_log.record_kill(getattr(type(e), "__name__", "UnknownEnemy"))
                except Exception:
                    pass
                # Track flying kills
                if getattr(type(e), "__name__", "") == "FlyingEnemy":
                    self._wave_report_flying_kills += 1

        boss_killed_this_tick = any((not e.alive and isinstance(e, BossEnemy)) for e in self.enemies)
        if boss_killed_this_tick:
            self._run_stats["boss_killed"] = True
        self.enemies = [e for e in self.enemies if e.alive]
        self.projectiles = [p for p in self.projectiles if p.active]

        # Enemy counter-attack projectiles
        for e in self.enemies:
            if hasattr(e, "update_shoot"):
                proj = e.update_shoot(self.towers, sim_dt)
                if proj is not None:
                    self.enemy_projectiles.append(proj)

        for proj in self.enemy_projectiles:
            hit = proj.update(sim_dt)
            if hit:
                if isinstance(proj, BossProjectile):
                    proj.on_hit(self.towers, damage_mult=adaptive_damage_mult)
                else:
                    proj.target_tower.take_damage(proj.damage * adaptive_damage_mult)

        self.enemy_projectiles = [p for p in self.enemy_projectiles if p.alive]

        # Remove towers destroyed by enemy fire (no refund)
        dead_towers = [t for t in self.towers if t.hp <= 0]
        for t in dead_towers:
            if self.selected_tower is t:
                self.selected_tower = None
            self.towers.remove(t)
        if dead_towers:
            self._refresh_synergies()

        self.event_director.update(sim_dt, ctx)
        self._sync_event_display()

        if (not self.wave_mgr.active
                and self.countdown == 0.0
                and not self.enemies
                and self.wave_mgr.wave_number > 0):
            if self.wave_mgr.wave_number > self._adaptive_last_applied_wave:
                prev_state = dict(self.adaptive_state)
                if self._wave_lives_lost:
                    reduced = dict(self.adaptive_state)
                    for key in ("hp_mult", "speed_mult", "damage_mult"):
                        step = max(0.0, float(self._adaptive_last_delta.get(key, 0.0)))
                        reduced[key] = max(1.0, float(reduced.get(key, 1.0)) - step)
                    reduced["last_wave_max_progress"] = self._current_wave_max_progress
                    self.adaptive_state = reduced
                else:
                    self.adaptive_state = apply_adaptive_increment(
                        self.adaptive_state,
                        difficulty=self.difficulty,
                        wave_max_progress=self._current_wave_max_progress,
                        wave=self.wave_mgr.wave_number,
                    )
                self._adaptive_last_delta = {
                    key: max(0.0, float(prev_state.get(key, 1.0)) - float(self.adaptive_state.get(key, 1.0)))
                    if self._wave_lives_lost else
                    max(0.0, float(self.adaptive_state.get(key, 1.0)) - float(prev_state.get(key, 1.0)))
                    for key in ("hp_mult", "speed_mult", "damage_mult")
                }
                self._update_adaptive_rationale()
                self.wave_mgr.adaptive_hp_mult = self.adaptive_state["hp_mult"]
                self._adaptive_last_applied_wave = self.wave_mgr.wave_number
            if self.event_director.active_event is not None or self._event_modifiers or self._event_label:
                self.event_director.end_wave(ctx)
                self._event_modifiers.clear()
                self._sync_event_display()
            end_wave_powerups(self._powerup_context())
            self._finalize_wave_report()
            self.terrain_evolution.compute_delta(self.wave_mgr.wave_number + 1)
            self.terrain_preview_visible = True
            self.countdown = BETWEEN_WAVES
            self._refresh_wave_preview()
        if (
            boss_killed_this_tick
            and self._boss_reward_triggered_wave != self.wave_mgr.wave_number
            and not self.pending_boss_rewards
        ):
            rewards = list(boss_reward_pool())
            random.shuffle(rewards)
            self.pending_boss_rewards = rewards[:3]
            self.selected_boss_reward_id = self.pending_boss_rewards[0] if self.pending_boss_rewards else None
            self._boss_reward_triggered_wave = self.wave_mgr.wave_number
            self.state = "BOSS_REWARD"

        if self.economy.game_over:
            if is_endless(self.difficulty):
                self.economy.score = self._compute_endless_score(
                    self.wave_mgr.wave_number, self.economy.score
                )
            self.state = "GAME_OVER"
            self._run_stats.update({
                "wave": self.wave_mgr.wave_number,
                "score": self.economy.score,
                "difficulty": self.difficulty,
                "lives_remaining": self.economy.lives,
                "max_lives": getattr(self.economy, "max_lives", self.economy.lives),
                "endless": is_endless(self.difficulty),
                "challenge_kind": getattr(self.active_challenge, "kind", None) if self.active_challenge else None,
                "mutators_active": len(self.active_mutators),
            })
            try:
                ids = check_run_achievements(self._run_stats)
                uid = getattr(self, "current_user_id", None)
                if uid and ids:
                    self._run_achievements_unlocked = unlock_achievements(uid, ids)
                else:
                    self._run_achievements_unlocked = []
            except Exception:
                self._run_achievements_unlocked = []
            if IS_WEB:
                self._set_web_leaderboards_fallback()
            else:
                self._record_run_and_load_leaderboards()

        if self._toast_timer > 0:
            self._toast_timer = max(0.0, self._toast_timer - real_dt)
            if self._toast_timer == 0.0:
                self._toast = ""
        if self._shop_notice_timer > 0:
            self._shop_notice_timer = max(0.0, self._shop_notice_timer - real_dt)
            if self._shop_notice_timer == 0.0:
                self._shop_notice = ""
        self._floating_texts = [
            [t, cx, cy, timer - real_dt]
            for t, cx, cy, timer in self._floating_texts
            if timer - real_dt > 0
        ]

    def _draw(self):
        self._game_surface.fill((0, 0, 0))
        draw_dt = max(0.0, float(self.clock.get_time()) / 1000.0)
        if self.state == "MENU":
            self._draw_menu()
        elif self.state == "DIFFICULTY":
            self._draw_difficulty()
        elif self.state == "MUTATOR_SELECTION":
            self._draw_mutator_selection()
        elif self.state == "MAP_PREVIEW":
            self._draw_map_preview()
        elif self.state == "PERK_SELECTION":
            self._draw_perk_selection()
        elif self.state == "BOSS_REWARD":
            self._draw_boss_reward()
        elif self.state == "PLAYING":
            shake_strength = max(0.0, float(self._event_modifiers.get("screen_shake_px", 0.0)))
            shake_offset = renderer.compute_screen_shake_offset(
                shake_strength,
                rng=getattr(self.event_director, "rng", None),
            )
            world_surface = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            renderer.draw_map(world_surface, self.game_map)
            mx, my = self._current_mouse_game_pos()
            if self.selected_cls:
                if not self.ui.is_in_panel((mx, my)):
                    col, row = mx // TILE, my // TILE
                    if 0 <= col < COLS and 0 <= row < ROWS:
                        self._hover_cell = (col, row)
                        renderer.draw_placement_ghost(
                            world_surface,
                            self.selected_cls,
                            self._hover_cell,
                            self.game_map,
                        )
                        renderer.draw_range_preview(
                            world_surface, col, row,
                            self.selected_cls.base_range, TILE,
                            self.game_map.is_buildable(col, row)
                        )
                    else:
                        self._hover_cell = None
                else:
                    self._hover_cell = None
            else:
                self._hover_cell = None
            renderer.draw_towers(
                world_surface, self.towers, self.selected_tower, TILE,
                entity_scale=ENTITY_VISUAL_TILE,
            )
            renderer.draw_enemies(world_surface, self.enemies)
            renderer.draw_projectiles(world_surface, self.projectiles)
            renderer.draw_enemy_projectiles(world_surface, self.enemy_projectiles)
            renderer.draw_damage_floats(world_surface, self.damage_floats, draw_dt)
            self._game_surface.blit(world_surface, shake_offset)
            # Draw terrain preview if in pre-wave and preview is visible
            if not self.wave_mgr.active and self.countdown > 0 and self.terrain_preview_visible:
                pending_delta = self.terrain_evolution.get_pending_delta()
                if pending_delta:
                    renderer.draw_terrain_preview(self._game_surface, pending_delta, self.game_map, TILE)
            if not self.wave_mgr.active and self.countdown > 0 and self._wave_preview:
                renderer.draw_wave_preview_panel(
                    self._game_surface, self.font, self._wave_preview,
                    SCREEN_W, SCREEN_H - PANEL_HEIGHT, self.countdown,
                )
            self.ui.draw(self._game_surface, self.economy, self.selected_cls,
                         self.selected_tower, self.wave_mgr.active, self.countdown,
                         towers=self.towers, tile_size=TILE,
                         unlocked_dlcs=self._get_unlocked_dlcs(),
                         notice=self._shop_notice if self._shop_notice_timer > 0 else "",
                         show_tower_card=True,
                         repair_mode_active=self.repair_mode_active,
                         auto_repair_all_enabled=self.auto_repair_all_enabled,
                         selected_placement_level=self._placement_levels.get(self.selected_cls, 1),
                         simulation_speed=self.simulation_speed,
                         powerup_state=self._powerup_state,
                         adaptive_rationale=self._adaptive_rationale,
                         current_wave=self.wave_mgr.wave_number,
                         active_synergies=self._active_synergies)
            self._hud_speed_rects = renderer.draw_hud(self._game_surface, self.font,
                              self.economy.gold, self.economy.lives,
                              self.wave_mgr.wave_number, self.economy.score,
                              SCREEN_W,
                              simulation_speed=self.simulation_speed,
                              event_label=self._event_label,
                              score_multiplier=self._score_multiplier(),
                              event_timer=self._event_timer if self._event_label else None,
                              event_tint=self._event_tint,
                              active_powerups=self._active_powerup_hud_entries(),
                              challenge_label=(
                                  self.active_challenge.label if self.active_challenge is not None else None
                              ),
                              hud_y=SCREEN_H - PANEL_HEIGHT,
                              hud_h=HUD_BAR_HEIGHT,
                              synergy_label=self._synergy_label if self._synergy_active else None,
                              recent_events=getattr(self._combat_log, "_events", [])[-3:])
            if is_endless(self.difficulty):
                _el = self.economy.lives
                _ec = (50, 200, 50) if _el >= 4 else (200, 200, 50) if _el == 3 else (220, 150, 50) if _el == 2 else (220, 50, 50)
                _ef = fonts.sized_bold(22)
                _es = _ef.render(f"Wave {self.wave_mgr.wave_number}", True, _ec)
                self._game_surface.blit(_es, (SCREEN_W - _es.get_width() - 10, HUD_BAR_HEIGHT + 5))
            self._draw_powerup_tooltip((mx, my))
            if not self.ui.is_in_panel((mx, my)):
                col, row = mx // TILE, my // TILE
                if 0 <= col < COLS and 0 <= row < ROWS and self.game_map.is_path(col, row):
                    terrain = self.game_map.terrain_by_cell.get((col, row), "road")
                    effects = []
                    speed_mult = TERRAIN_SPEED_MULT.get(terrain, 1.0)
                    if terrain == TERRAIN_HIGH_WIND:
                        effects.append(f"Flying speed x{TERRAIN_FLYING_SPEED_MULT[TERRAIN_HIGH_WIND]:.2f}")
                        effects.append(f"Non-AA acc x{TERRAIN_ACCURACY_MULT[TERRAIN_HIGH_WIND]:.2f}")
                    else:
                        acc_mult = TERRAIN_ACCURACY_MULT.get(terrain, 1.0)
                        if acc_mult != 1.0:
                            effects.append(f"Tower acc x{acc_mult:.2f}")
                    if speed_mult != 1.0:
                        effects.append(f"Enemy speed x{speed_mult:.2f}")
                    dmg_mult = TERRAIN_GROUND_DAMAGE_MULT.get(terrain, 1.0)
                    if dmg_mult != 1.0:
                        effects.append(f"Ground dmg x{dmg_mult:.2f}")
                    if not effects:
                        effects.append("No effect")
                    renderer.draw_terrain_tooltip(
                        self._game_surface,
                        self.font,
                        mouse_pos=(mx, my),
                        title=terrain.upper(),
                        effects=effects,
                        screen_w=SCREEN_W,
                        screen_h=SCREEN_H,
                        panel_top=SCREEN_H - PANEL_HEIGHT,
                    )
        elif self.state == "PAUSED":
            shake_strength = max(0.0, float(self._event_modifiers.get("screen_shake_px", 0.0)))
            shake_offset = renderer.compute_screen_shake_offset(
                shake_strength,
                rng=getattr(self.event_director, "rng", None),
            )
            world_surface = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            renderer.draw_map(world_surface, self.game_map)
            mx, my = self._current_mouse_game_pos()
            renderer.draw_towers(
                world_surface, self.towers, self.selected_tower, TILE,
                entity_scale=ENTITY_VISUAL_TILE,
            )
            renderer.draw_enemies(world_surface, self.enemies)
            renderer.draw_projectiles(world_surface, self.projectiles)
            renderer.draw_enemy_projectiles(world_surface, self.enemy_projectiles)
            self._game_surface.blit(world_surface, shake_offset)
            if not self.wave_mgr.active and self.countdown > 0 and self._wave_preview:
                renderer.draw_wave_preview_panel(
                    self._game_surface, self.font, self._wave_preview,
                    SCREEN_W, SCREEN_H - PANEL_HEIGHT, self.countdown,
                )
            self.ui.draw(self._game_surface, self.economy, self.selected_cls,
                         self.selected_tower, self.wave_mgr.active, self.countdown,
                         towers=self.towers, tile_size=TILE,
                         unlocked_dlcs=self._get_unlocked_dlcs(),
                         notice=self._shop_notice if self._shop_notice_timer > 0 else "",
                         show_tower_card=False,
                         repair_mode_active=self.repair_mode_active,
                         auto_repair_all_enabled=self.auto_repair_all_enabled,
                         selected_placement_level=self._placement_levels.get(self.selected_cls, 1),
                         simulation_speed=self.simulation_speed,
                         powerup_state=self._powerup_state,
                         current_wave=self.wave_mgr.wave_number,
                         active_synergies=self._active_synergies)
            self._hud_speed_rects = renderer.draw_hud(self._game_surface, self.font,
                              self.economy.gold, self.economy.lives,
                              self.wave_mgr.wave_number, self.economy.score,
                              SCREEN_W,
                              simulation_speed=self.simulation_speed,
                              event_label=self._event_label,
                              score_multiplier=self._score_multiplier(),
                              event_timer=self._event_timer if self._event_label else None,
                              event_tint=self._event_tint,
                              active_powerups=self._active_powerup_hud_entries(),
                              challenge_label=(
                                  self.active_challenge.label if self.active_challenge is not None else None
                              ),
                              hud_y=SCREEN_H - PANEL_HEIGHT,
                              hud_h=HUD_BAR_HEIGHT,
                              synergy_label=self._synergy_label if self._synergy_active else None,
                              recent_events=getattr(self._combat_log, "_events", [])[-3:])
            if is_endless(self.difficulty):
                _el = self.economy.lives
                _ec = (50, 200, 50) if _el >= 4 else (200, 200, 50) if _el == 3 else (220, 150, 50) if _el == 2 else (220, 50, 50)
                _ef = fonts.sized_bold(22)
                _es = _ef.render(f"Wave {self.wave_mgr.wave_number}", True, _ec)
                self._game_surface.blit(_es, (SCREEN_W - _es.get_width() - 10, HUD_BAR_HEIGHT + 5))
            toast = self._toast if self._toast_timer > 0 else None
            self._pause_rects = renderer.draw_pause_overlay(
                self._game_surface, self.font, SCREEN_W, SCREEN_H,
                save_module.save_exists(self.current_user_id), toast
            )
            self._draw_powerup_tooltip((mx, my))
        elif self.state == "GAME_OVER":
            self._draw_game_over()
        elif self.state == "PROFILE_IDENTIFY":
            self._draw_profile_identify()
        elif self.state == "PROFILE_CREATE":
            self._draw_profile_create()
        elif self.state == "PROFILE_LOGIN":
            self._draw_profile_login()
        elif self.state == "ADMIN_PANEL":
            self._draw_admin_panel()
        elif self.state == "DLC_MENU":
            self._draw_dlc_menu()
        elif self.state == "ANALYTICS":
            self._draw_analytics()
        elif self.state == "KEY_INPUT":
            self._draw_dlc_menu()
            self._draw_key_input()
        elif self.state == "CODEX":
            self._draw_codex()
        elif self.state == "WEB_LOADING":
            from src.renderer.menus import render_web_loading
            render_web_loading(self._game_surface, self._web_loading_msg)
        if self._win_w != SCREEN_W or self._win_h != SCREEN_H:
            scaled = pygame.transform.smoothscale(self._game_surface, (self._win_w, self._win_h))
            self.screen.blit(scaled, (0, 0))
        else:
            self.screen.blit(self._game_surface, (0, 0))
        pygame.display.flip()

    def _draw_menu(self):
        btn_w = 360
        # In web mode saves are cloud-backed; local save_exists() can be stale/empty
        # and would incorrectly disable the Load button.
        if IS_WEB and self._api_client and self.current_user_id is not None:
            has_save = True
        else:
            has_save = (
                self.current_user_id is not None
                and save_module.save_exists(self.current_user_id)
            )
        rects = renderer.menus.draw_main_menu(
            self._game_surface,
            self.font,
            screen_w=SCREEN_W,
            screen_h=SCREEN_H,
            current_username=self.current_username,
            has_save=has_save,
            is_admin=self._is_admin(),
            button_width=btn_w,
        )
        self._menu_load_rect = rects.get("load")
        self._menu_load_enabled = has_save
        self._menu_dlc_rect = rects.get("dlc")
        self._menu_analytics_rect = rects.get("analytics")
        self._menu_codex_rect = rects.get("codex")
        self._menu_daily_rect = rects.get("daily")
        self._menu_weekly_rect = rects.get("weekly")
        self._menu_admin_rect = rects.get("admin")

    def _draw_codex(self):
        renderer.menus.draw_codex_screen(
            self._game_surface, self.font, SCREEN_W, SCREEN_H,
            category=self._codex_category,
            entry_index=self._codex_entry_index,
        )

    def _toggle_mutator(self, mut_id: str) -> None:
        if mut_id in self.pending_mutators:
            self.pending_mutators.remove(mut_id)
        else:
            from src.mutators import validate_selection
            try:
                validate_selection(self.pending_mutators + [mut_id])
                self.pending_mutators.append(mut_id)
            except ValueError:
                pass  # silently reject invalid combo

    def _apply_mutators(self) -> None:
        from src.mutators import validate_selection, score_multiplier_for
        ids = validate_selection(self.pending_mutators)
        self.active_mutators = list(ids)
        self.run_score_mult = score_multiplier_for(ids)
        for mid in ids:
            if mid == "gold_rush":
                self.economy.gold += 75
            elif mid == "scarce_gold":
                self.economy.gold = max(0, self.economy.gold - 50)

    def _enter_map_preview(self) -> None:
        """Enter MAP_PREVIEW state: regenerate preview_map from current seed."""
        if self.map_seed_state is not None:
            self.preview_map = GameMap(
                cols=COLS, rows=ROWS, tile_size=TILE,
                rng=random.Random(self.map_seed_state.seed_value),
            )
        self._map_preview_button_rects = {}
        self.state = "MAP_PREVIEW"

    def _draw_map_preview(self) -> None:
        rects = renderer.menus.draw_map_preview_screen(
            self._game_surface, self.font, SCREEN_W, SCREEN_H,
            self.map_seed_state, self.preview_map, tile_size=TILE,
        )
        self._map_preview_button_rects = rects

    def _draw_mutator_selection(self) -> None:
        rects = renderer.menus.draw_mutator_selection_screen(
            self._game_surface, self.font, SCREEN_W, SCREEN_H,
            pending_mutators=self.pending_mutators,
        )
        self._mutator_card_rects = rects.get("cards", {})
        self._mutator_confirm_rect = rects.get("confirm")

    def _draw_difficulty(self):
        self._difficulty_rects = renderer.draw_difficulty_screen(
            self._game_surface, self.font, SCREEN_W, SCREEN_H
        )

    def _draw_perk_selection(self):
        offers = []
        for perk_id in self._perk_offer_ids:
            perk = PERK_BY_ID.get(perk_id)
            if perk is None:
                offers.append(
                    {"id": perk_id, "label": perk_id.replace("_", " ").title(), "description": "", "category": "", "rarity": ""}
                )
                continue
            offers.append(
                {"id": perk.id, "label": perk.label, "description": perk.description, "category": perk.category, "rarity": perk.rarity}
            )

        rects = renderer.draw_perk_selection_screen(
            self._game_surface,
            self.font,
            screen_w=SCREEN_W,
            screen_h=SCREEN_H,
            perk_offers=offers,
            selected_ids=set(self._selected_perk_ids),
            required_choices=self._perk_required_choices,
            feedback=self._perk_selection_feedback,
        )
        self._perk_card_rects = rects.get("cards", {})
        self._perk_confirm_rect = rects.get("confirm")

    def _draw_boss_reward(self) -> None:
        rects = renderer.menus.draw_boss_reward_screen(
            surface=self._game_surface,
            font=self.font,
            screen_w=SCREEN_W,
            screen_h=SCREEN_H,
            reward_ids=self.pending_boss_rewards,
            selected_reward_id=self.selected_boss_reward_id,
        )
        self._boss_reward_card_rects = rects.get("cards", {})
        self._boss_reward_confirm_rect = rects.get("confirm")

    def _apply_boss_reward(self, reward_id: str) -> None:
        if reward_id == "gold_cache":
            self.economy.gold += 150
            return
        if reward_id == "field_repair":
            for tower in self.towers:
                repair_amount = int(tower.max_hp * 0.25)
                tower.hp = min(tower.max_hp, tower.hp + repair_amount)
            return
        if reward_id == "overclock_token":
            cooldowns = getattr(self._powerup_state, "cooldown_timers", {})
            if isinstance(cooldowns, dict):
                for key, value in list(cooldowns.items()):
                    try:
                        cooldowns[key] = max(0.0, float(value) * 0.8)
                    except Exception:
                        continue

    def _draw_analytics(self):
        """Draw analytics screen with top runs and kills barchart."""
        self._analytics_rects = renderer.draw_analytics_screen(
            self._game_surface,
            self._analytics_top_runs,
            self.font,
            SCREEN_W,
            SCREEN_H,
            leaderboard_global_by_difficulty=self._leaderboard_global_by_difficulty,
            leaderboard_user_by_difficulty=self._leaderboard_user_by_difficulty,
            leaderboard_filter=self._leaderboard_filter,
            runtime_version=self.runtime_version,
        )

    def _compute_endless_score(self, wave: int, gold_spent: int = 0) -> int:
        return wave * 100 + gold_spent

    def _draw_game_over(self):
        renderer.draw_menu_background(self._game_surface, SCREEN_W, SCREEN_H)
        font_big = fonts.sized_bold(56)
        go = font_big.render("GAME OVER", True, (220, 50, 50))
        cx = SCREEN_W // 2
        self._game_surface.blit(go, (cx - go.get_width() // 2, 20))
        font_score = fonts.sized_bold(20)
        score_surf = font_score.render(f"Score: ", True, (200, 200, 200))
        score_val  = font_score.render(str(self.economy.score), True, (255, 200, 80))
        wave_surf  = font_score.render(f"   Wave: ", True, (200, 200, 200))
        wave_val   = font_score.render(str(self.wave_mgr.wave_number), True, (180, 230, 255))
        score_line_parts = [score_surf, score_val, wave_surf, wave_val]
        total_w = sum(s.get_width() for s in score_line_parts)
        x = cx - total_w // 2
        for part in score_line_parts:
            self._game_surface.blit(part, (x, 88))
            x += part.get_width()
        hint_font = fonts.sized(13)
        hint = hint_font.render("M=Menu  R=Restart  ESC=Esci  V=Leaderboard", True, (140, 140, 140))
        self._game_surface.blit(hint, (cx - hint.get_width() // 2, 118))
        if self._last_xp_result:
            xp_font = fonts.sized(15)
            xp_line = f"+{self._last_xp_result['xp_earned']} XP  →  Level {self._last_xp_result['level']}"
            if self._last_xp_result.get("new_badges"):
                badges_str = ", ".join(self._last_xp_result["new_badges"])
                xp_line += f"  \U0001f3c5 {badges_str}"
            xp_surf = xp_font.render(xp_line, True, (180, 230, 150))
            self._game_surface.blit(xp_surf, (cx - xp_surf.get_width() // 2, 136))
        if self._run_achievements_unlocked:
            ach_font = fonts.sized(13)
            badges = self._run_achievements_unlocked[:4]
            badge_parts = []
            for aid in badges:
                a = get_achievement(aid)
                if a:
                    badge_parts.append(f"{a.icon} {a.name}")
            if badge_parts:
                badge_line = "  ".join(badge_parts)
                badge_surf = ach_font.render(badge_line, True, (255, 215, 80))
                y_pos = 158 if self._last_xp_result else 136
                self._game_surface.blit(badge_surf, (cx - badge_surf.get_width() // 2, y_pos))
        renderer.draw_game_over_leaderboards(
            self._game_surface,
            self.font,
            SCREEN_W,
            140,
            self._leaderboard_global_by_difficulty,
            self._leaderboard_user_by_difficulty,
            self._leaderboard_filter,
            self.runtime_version,
        )

    def _draw_profile_identify(self):
        renderer.render_profile_identify(
            self._game_surface, self.text_input, SCREEN_W, SCREEN_H, error=self.profile_error
        )

    def _draw_profile_create(self):
        renderer.render_profile_create(
            self._game_surface, self.login_username, len(self.text_input2),
            SCREEN_W, SCREEN_H,
            active_field="password",
            error=self.profile_error
        )

    def _draw_profile_login(self):
        renderer.render_profile_login(
            self._game_surface, self.login_username, len(self.text_input2),
            SCREEN_W, SCREEN_H, error=self.profile_error
        )

    def _draw_dlc_menu(self):
        self._dlc_rects = renderer.render_dlc_menu(
            self._game_surface, AVAILABLE_DLCS, self.unlocked_dlcs,
            SCREEN_W, SCREEN_H, error=self.dlc_error
        )

    def _draw_key_input(self):
        dlc_name = AVAILABLE_DLCS.get(self.selected_dlc, self.selected_dlc)
        self._key_paste_rect = renderer.render_key_input(
            self._game_surface, dlc_name, self.text_input,
            SCREEN_W, SCREEN_H, error=self.dlc_error
        )

    def _draw_admin_panel(self):
        self._admin_user_rects, self._admin_dlc_rects, self._admin_delete_rect = renderer.render_admin_panel(
            self._game_surface,
            self._admin_users,
            self._admin_selected_user_id,
            self._admin_selected_user_dlcs,
            AVAILABLE_DLCS,
            SCREEN_W,
            SCREEN_H,
            message=self._admin_notice
        )
