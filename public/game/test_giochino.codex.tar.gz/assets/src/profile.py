from __future__ import annotations

import sqlite3
import os
import hashlib
import hmac
from typing import Optional, Any
from src.db import get_connection, sql, is_postgres_enabled

try:
    import bcrypt  # type: ignore
except Exception:
    bcrypt = None


def _hash_password(password: str) -> str:
    if bcrypt is not None:
        return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    # Web-safe fallback when bcrypt wheel is unavailable on emscripten.
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return f"pbkdf2${salt.hex()}${digest.hex()}"


def _check_password(password: str, stored_hash: str) -> bool:
    if stored_hash.startswith("pbkdf2$"):
        try:
            _, salt_hex, digest_hex = stored_hash.split("$", 2)
            salt = bytes.fromhex(salt_hex)
            expected = bytes.fromhex(digest_hex)
        except Exception:
            return False
        got = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
        return hmac.compare_digest(got, expected)

    if bcrypt is None:
        return False
    return bool(bcrypt.checkpw(password.encode(), stored_hash.encode()))


def create_user(username: str, password: str,
                _conn: Optional[Any] = None) -> Optional[int]:
    conn = _conn or get_connection()
    pw_hash = _hash_password(password)
    try:
        if is_postgres_enabled():
            cur = conn.execute(
                "INSERT INTO users (username, password_hash, is_active) VALUES (%s, %s, 1) RETURNING id",
                (username, pw_hash),
            )
            row = cur.fetchone()
            conn.commit()
            return int(row["id"]) if row else None
        cur = conn.execute(
            "INSERT INTO users (username, password_hash, is_active) VALUES (?, ?, 1)",
            (username, pw_hash),
        )
        conn.commit()
        return cur.lastrowid
    except Exception:
        return None


def authenticate_user(username: str, password: str,
                      _conn: Optional[Any] = None) -> Optional[int]:
    conn = _conn or get_connection()
    row = conn.execute(
        sql("SELECT id, password_hash FROM users WHERE username = ? AND is_active = 1"),
        (username,),
    ).fetchone()
    if row is None:
        return None
    uid, pw_hash = row["id"], row["password_hash"]
    return uid if _check_password(password, str(pw_hash)) else None


def list_users(_conn: Optional[Any] = None) -> list:
    conn = _conn or get_connection()
    return [r["username"] for r in conn.execute(
        "SELECT username FROM users WHERE is_active = 1 ORDER BY username"
    ).fetchall()]


def user_exists(username: str,
                _conn: Optional[Any] = None) -> bool:
    conn = _conn or get_connection()
    row = conn.execute(
        sql("SELECT 1 FROM users WHERE username = ? AND is_active = 1"),
        (username,),
    ).fetchone()
    return row is not None


def list_user_records(_conn: Optional[Any] = None) -> list[tuple[int, str]]:
    conn = _conn or get_connection()
    return [(int(r["id"]), str(r["username"])) for r in conn.execute(
        "SELECT id, username FROM users WHERE is_active = 1 ORDER BY username"
    ).fetchall()]


def soft_delete_user(target_user_id: int,
                     actor_user_id: Optional[int],
                     actor_username: str,
                     _conn: Optional[Any] = None) -> bool:
    conn = _conn or get_connection()
    row = conn.execute(
        sql("SELECT username, is_active FROM users WHERE id = ?"),
        (target_user_id,),
    ).fetchone()
    if row is None:
        return False
    target_username, is_active = str(row["username"]), int(row["is_active"])
    if is_active == 0:
        return True
    if actor_username == "admin" and actor_user_id == target_user_id:
        return False
    if target_username == "admin" and actor_user_id == target_user_id:
        return False
    conn.execute(
        sql("UPDATE users SET is_active = 0 WHERE id = ?"),
        (target_user_id,),
    )
    conn.commit()
    return True


def ensure_default_admin(_conn: Optional[Any] = None) -> None:
    conn = _conn or get_connection()
    row = conn.execute(
        "SELECT id, is_active FROM users WHERE username = 'admin'"
    ).fetchone()
    if row is None:
        create_user("admin", "admin", _conn=conn)
        return
    if int(row["is_active"]) == 0:
        conn.execute(sql("UPDATE users SET is_active = 1 WHERE id = ?"), (int(row["id"]),))
        conn.commit()
