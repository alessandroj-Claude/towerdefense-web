"""Map seed state and domain logic.

Handles seed generation, stable hashing, and reroll mechanics.
"""
from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class MapSeedState:
    """Immutable map seed state."""

    seed_text: str
    seed_value: int
    rerolls_left: int
    locked: bool = False


def seed_value_from_text(text: str) -> int:
    """Generate stable cross-platform seed value from text.

    Uses SHA-256 hash (not Python's hash()) for deterministic behavior
    across platforms. Returns positive int.

    Args:
        text: Seed text (any string).

    Returns:
        Positive integer seed value.
    """
    hash_obj = hashlib.sha256(text.encode("utf-8"))
    hash_bytes = hash_obj.digest()
    # Take first 8 bytes, convert to unsigned int, ensure positive
    seed_int = int.from_bytes(hash_bytes[:8], byteorder="big", signed=False)
    return seed_int


def random_seed(rng: Optional[random.Random] = None) -> str:
    """Generate random seed text.

    Args:
        rng: Optional random.Random instance. If None, uses default random.

    Returns:
        Random seed text (8-char hex string).
    """
    if rng is None:
        rng = random.Random()
    # Generate 4 random bytes, convert to hex
    return rng.randbytes(4).hex()


def initial_seed_state(seed_text: Optional[str] = None, locked: bool = False) -> MapSeedState:
    """Create initial seed state.

    If seed_text is None or empty, generates random seed.
    rerolls_left defaults to 3 if not locked, 0 if locked.

    Args:
        seed_text: Seed text, or None/empty for random.
        locked: If True, rerolls_left=0 and seed cannot change.

    Returns:
        New MapSeedState.
    """
    if not seed_text:
        seed_text = random_seed()

    seed_value = seed_value_from_text(seed_text)
    rerolls_left = 0 if locked else 3

    return MapSeedState(
        seed_text=seed_text,
        seed_value=seed_value,
        rerolls_left=rerolls_left,
        locked=locked,
    )


def reroll_seed(state: MapSeedState, rng: Optional[random.Random] = None) -> MapSeedState:
    """Reroll seed if not locked.

    If locked, returns state unchanged.
    If not locked, generates new random seed and decrements rerolls_left by 1.

    Args:
        state: Current MapSeedState.
        rng: Optional random.Random instance for seed generation.

    Returns:
        Updated MapSeedState (new seed if unlocked, unchanged if locked).
    """
    if state.locked or state.rerolls_left <= 0:
        return state

    new_seed_text = random_seed(rng)
    new_seed_value = seed_value_from_text(new_seed_text)

    return MapSeedState(
        seed_text=new_seed_text,
        seed_value=new_seed_value,
        rerolls_left=state.rerolls_left - 1,
        locked=state.locked,
    )
