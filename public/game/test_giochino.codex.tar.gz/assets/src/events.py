import random
from typing import Any, Dict, Optional, Sequence, Type


class WaveEvent:
    event_id = "base"
    label = "Base Event"
    duration = 1.0
    overlay_rgba = (0, 0, 0, 0)

    def apply_start(self, ctx: Dict[str, Any]) -> None:
        pass

    def apply_tick(self, ctx: Dict[str, Any], dt: float) -> None:
        pass

    def apply_end(self, ctx: Dict[str, Any]) -> None:
        pass

    def export_state(self) -> Dict[str, Any]:
        return {}

    def import_state(self, state: Dict[str, Any]) -> None:
        _ = state

    def reapply(self, ctx: Dict[str, Any]) -> None:
        self.apply_start(ctx)


def _mods(ctx: Dict[str, Any]) -> Dict[str, float]:
    return ctx.setdefault("modifiers", {})


class SandstormEvent(WaveEvent):
    event_id = "sandstorm"
    label = "Sandstorm"
    duration = 12.0
    overlay_rgba = (186, 146, 90, 70)
    tower_accuracy_mult = 0.7
    enemy_speed_mult = 0.8

    def apply_start(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods["tower_accuracy_mult"] = self.tower_accuracy_mult
        mods["enemy_speed_mult"] = self.enemy_speed_mult

    def apply_end(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods.pop("tower_accuracy_mult", None)
        mods.pop("enemy_speed_mult", None)


class PrecisionFogEvent(WaveEvent):
    event_id = "precision_fog"
    label = "Precision Fog"
    duration = 12.0
    overlay_rgba = (160, 170, 180, 68)
    tower_accuracy_mult = 0.65
    tower_range_mult = 0.85

    def apply_start(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods["tower_accuracy_mult"] = self.tower_accuracy_mult
        mods["tower_range_mult"] = self.tower_range_mult

    def apply_end(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods.pop("tower_accuracy_mult", None)
        mods.pop("tower_range_mult", None)


class SupplyDropEvent(WaveEvent):
    event_id = "supply_drop"
    label = "Supply Drop"
    duration = 6.0
    overlay_rgba = (70, 150, 70, 60)
    gold_bonus = 40

    def __init__(self):
        self._awarded = False

    def _award(self, ctx: Dict[str, Any], amount: int) -> None:
        grant_gold = ctx.get("grant_gold")
        if callable(grant_gold):
            grant_gold(amount)
            return
        economy = ctx.get("economy")
        if economy is not None and hasattr(economy, "earn"):
            economy.earn(amount)

    def apply_start(self, ctx: Dict[str, Any]) -> None:
        if self._awarded:
            return
        bonus = int(ctx.get("supply_drop_gold", self.gold_bonus))
        self._award(ctx, bonus)
        self._awarded = True

    def export_state(self) -> Dict[str, Any]:
        return {"awarded": self._awarded}

    def import_state(self, state: Dict[str, Any]) -> None:
        self._awarded = bool(state.get("awarded", False))

    def reapply(self, ctx: Dict[str, Any]) -> None:
        _ = ctx


class EarthquakeEvent(WaveEvent):
    event_id = "earthquake"
    label = "Earthquake"
    duration = 10.0
    overlay_rgba = (128, 120, 110, 72)
    tower_accuracy_mult = 0.75
    stun_chance = 0.35
    stun_max_per_tick = 2
    screen_shake_px = 3.0

    def apply_start(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods["tower_accuracy_mult"] = self.tower_accuracy_mult
        mods["earthquake_stun_chance"] = self.stun_chance
        mods["earthquake_stun_max_per_tick"] = self.stun_max_per_tick
        mods["screen_shake_px"] = self.screen_shake_px

    def apply_end(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods.pop("tower_accuracy_mult", None)
        mods.pop("earthquake_stun_chance", None)
        mods.pop("earthquake_stun_max_per_tick", None)
        mods.pop("screen_shake_px", None)


class AntiAirProtocolEvent(WaveEvent):
    event_id = "anti_air_protocol"
    label = "Anti-Air Protocol"
    duration = 12.0
    overlay_rgba = (90, 150, 240, 78)
    anti_air_range_mult = 1.20
    anti_air_accuracy_mult = 1.30

    def apply_start(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods["anti_air_range_mult"] = self.anti_air_range_mult
        mods["anti_air_accuracy_mult"] = self.anti_air_accuracy_mult

    def apply_end(self, ctx: Dict[str, Any]) -> None:
        mods = _mods(ctx)
        mods.pop("anti_air_range_mult", None)
        mods.pop("anti_air_accuracy_mult", None)


EVENT_REGISTRY: Dict[str, Type[WaveEvent]] = {
    SandstormEvent.event_id: SandstormEvent,
    PrecisionFogEvent.event_id: PrecisionFogEvent,
    SupplyDropEvent.event_id: SupplyDropEvent,
    EarthquakeEvent.event_id: EarthquakeEvent,
    AntiAirProtocolEvent.event_id: AntiAirProtocolEvent,
}

EVENT_CHANCE_BY_DIFFICULTY = {
    "easy": 0.20,
    "normal": 0.30,
    "hard": 0.50,
}


def event_chance_for_difficulty(difficulty: str) -> float:
    base = float(EVENT_CHANCE_BY_DIFFICULTY.get(difficulty, EVENT_CHANCE_BY_DIFFICULTY["normal"]))
    return base * 1.1


class EventDirector:
    def __init__(
        self,
        event_types: Optional[Sequence[Type[WaveEvent]]] = None,
        rng: Optional[random.Random] = None,
        event_chance: float = 1.0,
    ):
        self.event_types = tuple(event_types or EVENT_REGISTRY.values())
        self.rng = rng or random.Random()
        self.event_chance = float(event_chance)
        self.current_wave = 0
        self.trigger_consumed = False
        self.active_event: Optional[WaveEvent] = None
        self.remaining_time = 0.0
        self.waves_without_event = 0
        self.force_event_this_wave = False
        self.wave_event_triggered = False

    def on_wave_start(self, wave_number: int) -> None:
        if self.current_wave > 0:
            if self.wave_event_triggered:
                self.waves_without_event = 0
            else:
                self.waves_without_event += 1
        self.current_wave = int(wave_number)
        self.force_event_this_wave = self.waves_without_event >= 2
        self.wave_event_triggered = False
        self.trigger_consumed = False
        self.active_event = None
        self.remaining_time = 0.0

    def maybe_trigger(
        self, spawned_count: int, total_to_spawn: int, ctx: Optional[Dict[str, Any]] = None
    ) -> Optional[WaveEvent]:
        if self.active_event is not None:
            return None
        if self.trigger_consumed:
            return None
        if total_to_spawn <= 0:
            return None

        checkpoint = max(1, total_to_spawn // 2)
        if spawned_count < checkpoint:
            return None

        self.trigger_consumed = True
        should_force = self.force_event_this_wave
        if not should_force and self.rng.random() >= self.event_chance:
            return None

        event_cls = self.rng.choice(self.event_types)
        event = event_cls()
        self.active_event = event
        self.remaining_time = float(event.duration)
        self.wave_event_triggered = True
        self.waves_without_event = 0
        self.force_event_this_wave = False
        event.apply_start(ctx or {})
        return event

    def update(self, dt: float, ctx: Optional[Dict[str, Any]] = None) -> None:
        if self.active_event is None:
            return
        ctx = ctx or {}
        self.active_event.apply_tick(ctx, dt)
        self.remaining_time = max(0.0, self.remaining_time - dt)
        if self.remaining_time <= 0.0:
            self._end_active_event(ctx)

    def end_wave(self, ctx: Optional[Dict[str, Any]] = None) -> None:
        if self.active_event is not None:
            self._end_active_event(ctx or {})

    def _end_active_event(self, ctx: Dict[str, Any]) -> None:
        if self.active_event is None:
            return
        self.active_event.apply_end(ctx)
        self.active_event = None
        self.remaining_time = 0.0

    def to_state(self) -> Dict[str, Any]:
        return {
            "current_wave": self.current_wave,
            "trigger_consumed": self.trigger_consumed,
            "active_event_id": self.active_event.event_id if self.active_event else None,
            "active_event_remaining": self.remaining_time,
            "active_event_state": self.active_event.export_state() if self.active_event else {},
            "waves_without_event": self.waves_without_event,
            "force_event_this_wave": self.force_event_this_wave,
            "wave_event_triggered": self.wave_event_triggered,
        }

    @classmethod
    def from_state(
        cls,
        state: Dict[str, Any],
        event_types: Optional[Sequence[Type[WaveEvent]]] = None,
        rng: Optional[random.Random] = None,
        event_chance: float = 1.0,
    ) -> "EventDirector":
        director = cls(event_types=event_types, rng=rng, event_chance=event_chance)
        director.current_wave = int(state.get("current_wave", 0))
        director.trigger_consumed = bool(state.get("trigger_consumed", False))
        director.remaining_time = float(state.get("active_event_remaining", 0.0))
        director.waves_without_event = int(state.get("waves_without_event", 0))
        director.force_event_this_wave = bool(state.get("force_event_this_wave", False))
        director.wave_event_triggered = bool(state.get("wave_event_triggered", False))
        event_id = state.get("active_event_id")
        event_cls = EVENT_REGISTRY.get(event_id)
        if event_cls is not None:
            ev = event_cls()
            ev.import_state(state.get("active_event_state", {}))
            director.active_event = ev
        else:
            director.active_event = None
            director.remaining_time = 0.0
        return director

    def reapply_active_effects(self, ctx: Dict[str, Any]) -> None:
        if self.active_event is None:
            return
        self.active_event.reapply(ctx)
