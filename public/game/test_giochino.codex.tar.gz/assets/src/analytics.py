"""
Analytics data layer for multi-run metrics persistence.

Completely independent from SaveManager/save.py.
Accumulates in-run events and flushes complete run summaries to analytics.json.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Optional, Union
from collections import defaultdict


class AnalyticsManager:
    """Manages analytics tracking and persistence for multiple runs."""

    def __init__(self, analytics_path: Union[str, None] = None):
        """
        Initialize AnalyticsManager.

        Args:
            analytics_path: Path to analytics.json file. If None, uses default App Support path.
        """
        if analytics_path is None:
            # Use App Support directory, fallback to local if not writable
            from src.data_paths import data_path
            self._analytics_path = data_path("analytics.json")
        else:
            self._analytics_path = Path(analytics_path)

        # In-run accumulators
        self._kills_by_type: dict = defaultdict(int)
        self._towers_by_type: dict = defaultdict(int)
        self._powerups_used: dict = defaultdict(int)
        self._gold_spent: int = 0
        self._lives_lost_total: int = 0
        self._wave_complete_count: int = 0

    def track_event(self, event_type: str, data: dict) -> None:
        """
        Accumulate in-run metrics.

        Supported event_types:
        - "enemy_killed": data = {"type": "EnemyClassName"}
        - "tower_built": data = {"type": "TowerClassName"}
        - "powerup_used": data = {"type": "powerup_id"}
        - "gold_spent": data = {"amount": int}
        - "life_lost": data = {"count": int}
        - "wave_complete": data = {"wave_num": int}

        Args:
            event_type: Type of event to track
            data: Event-specific data dict
        """
        if event_type == "enemy_killed":
            enemy_type = data.get("type", "Unknown")
            self._kills_by_type[enemy_type] += 1

        elif event_type == "tower_built":
            tower_type = data.get("type", "Unknown")
            self._towers_by_type[tower_type] += 1

        elif event_type == "powerup_used":
            powerup_type = data.get("type", "Unknown")
            self._powerups_used[powerup_type] += 1

        elif event_type == "gold_spent":
            amount = data.get("amount", 0)
            self._gold_spent += int(amount)

        elif event_type == "life_lost":
            count = data.get("count", 1)
            self._lives_lost_total += int(count)

        elif event_type == "wave_complete":
            self._wave_complete_count += 1

    def flush_run(self, run_summary: dict) -> None:
        """
        Flush completed run to analytics.json (append-only).

        Merges accumulated in-run metrics with run_summary and writes to file.

        Args:
            run_summary: Dict with run final state (difficulty, wave_max, final_score, etc.)
        """
        # Merge accumulated state with summary
        entry = {
            "timestamp": datetime.now().isoformat(),
            "difficulty": run_summary.get("difficulty", "normal"),
            "wave_max": run_summary.get("wave_max", 0),
            "final_score": run_summary.get("final_score", 0),
            "gold_spent": self._gold_spent,
            "lives_lost_total": self._lives_lost_total,
            "towers_by_type": dict(self._towers_by_type),
            "kills_by_type": dict(self._kills_by_type),
            "powerups_used": dict(self._powerups_used),
        }

        # Ensure parent directory exists
        self._analytics_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing entries or start with empty list
        entries = []
        if self._analytics_path.exists():
            try:
                with open(self._analytics_path, 'r') as f:
                    entries = json.load(f)
            except (json.JSONDecodeError, IOError):
                entries = []

        # Append new entry
        entries.append(entry)

        # Write back to file
        with open(self._analytics_path, 'w') as f:
            json.dump(entries, f, indent=2)

    def load_top_n(self, n: int = 5):
        """
        Load top N runs sorted by wave_max descending.

        Args:
            n: Number of top runs to return (default 5)

        Returns:
            List of top N runs, sorted by wave_max descending.
            Returns empty list if file doesn't exist or is empty.
        """
        if not self._analytics_path.exists():
            return []

        try:
            with open(self._analytics_path, 'r') as f:
                entries = json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

        if not isinstance(entries, list):
            return []

        # Sort by wave_max descending and return top N
        sorted_entries = sorted(entries, key=lambda e: e.get("wave_max", 0), reverse=True)
        return sorted_entries[:n]

    def reset(self) -> None:
        """Reset in-run accumulator state for a new run."""
        self._kills_by_type.clear()
        self._towers_by_type.clear()
        self._powerups_used.clear()
        self._gold_spent = 0
        self._lives_lost_total = 0
        self._wave_complete_count = 0
