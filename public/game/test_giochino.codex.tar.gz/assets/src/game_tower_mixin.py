from src.tower import towers_sorted_xy_for_type
from src.ui import repair_cost, repair_hp


class TowerControllerMixin:
    """Tower repair, upgrade, targeting, and score operations."""

    def _score_multiplier(self) -> float:
        hp_mult = max(1.0, float(self.adaptive_state.get("hp_mult", 1.0)))
        speed_mult = max(1.0, float(self.adaptive_state.get("speed_mult", 1.0)))
        damage_mult = max(1.0, float(self.adaptive_state.get("damage_mult", 1.0)))
        return self._clamp((hp_mult + speed_mult + damage_mult) / 3.0, 1.0, 3.0)

    def _apply_targeted_repair(self, tower, silent: bool = False) -> bool:
        if tower.hp >= tower.max_hp:
            if not silent:
                self._shop_notice = "Tower full HP"
                self._shop_notice_timer = 1.2
            return False
        cost = repair_cost(tower)
        if not self.economy.can_afford(cost):
            if not silent:
                self._shop_notice = "Gold insufficiente"
                self._shop_notice_timer = 1.2
            return False
        amount = repair_hp(tower, self.difficulty)
        if amount <= 0:
            if not silent:
                self._shop_notice = "Tower full HP"
                self._shop_notice_timer = 1.2
            return False
        self.economy.spend(cost)
        tower.heal(amount)
        if not silent:
            self.selected_tower = tower
            self._shop_notice = ""
            self._shop_notice_timer = 0.0
        return True

    def _repair_all_towers(self) -> None:
        damaged = [t for t in self.towers if t.hp < t.max_hp]
        if not damaged:
            self._shop_notice = "Nessuna torre da riparare"
            self._shop_notice_timer = 1.2
            return
        did_repair = False
        while damaged:
            repaired_this_round = False
            for tower in list(damaged):
                if tower.hp >= tower.max_hp:
                    continue
                cost = repair_cost(tower)
                if not self.economy.can_afford(cost):
                    continue
                amount = repair_hp(tower, self.difficulty)
                if amount <= 0:
                    continue
                self.economy.spend(cost)
                tower.heal(amount)
                repaired_this_round = True
                did_repair = True
            damaged = [t for t in damaged if t.hp < t.max_hp]
            if not repaired_this_round:
                break
        if not did_repair:
            self._shop_notice = "Gold insufficiente"
            self._shop_notice_timer = 1.2
            return
        self._shop_notice = ""
        self._shop_notice_timer = 0.0

    def _upgrade_all_selected_type(self) -> None:
        if self.selected_cls is None:
            return
        ordered = towers_sorted_xy_for_type(self.towers, self.selected_cls)
        if not ordered:
            self._shop_notice = "Nessuna torre del tipo selezionato"
            self._shop_notice_timer = 1.2
            return

        did_upgrade = False
        for tower in ordered:
            result = tower.try_shop_upgrade(self.economy)
            if result == "ok":
                did_upgrade = True
                continue
            if result == "insufficient_gold":
                self._shop_notice = "Gold insufficiente"
                self._shop_notice_timer = 1.2
                return
            if result == "max_level":
                continue

        if did_upgrade:
            self._shop_notice = ""
            self._shop_notice_timer = 0.0

    def _set_tower_targeting_policy(self, tower, policy: str) -> None:
        tower.targeting_policy = policy

    def _bulk_set_targeting_policy(self, policy: str) -> None:
        if self.selected_cls is None:
            return
        for t in self.towers:
            if isinstance(t, self.selected_cls):
                t.targeting_policy = policy

    def _tick_auto_repair(self, dt: float) -> None:
        self._auto_repair_timer -= dt
        if self._auto_repair_timer > 0:
            return
        self._auto_repair_timer = 0.5
        for tower in self.towers:
            if tower.hp < tower.max_hp * 0.5:
                self._apply_targeted_repair(tower, silent=True)

    def _try_upgrade(self):
        if self.selected_tower and self.selected_tower.level < 3:
            cost = self.selected_tower.upgrade_cost
            if self.economy.can_afford(cost):
                self.economy.spend(cost)
                self.selected_tower.upgrade()
