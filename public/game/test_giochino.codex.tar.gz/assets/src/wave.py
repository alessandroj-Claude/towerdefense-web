from collections import deque
import random
from typing import Deque, List, Tuple, Type
from src.enemy import Enemy, BasicEnemy, FastEnemy, TankEnemy, SwarmEnemy, FlyingEnemy, BossEnemy, HeavyEnemy

SpawnEntry = Tuple[Type[Enemy], float]  # (EnemyClass, spawn_time)

def _wave_definition(wave_number: int) -> List[Tuple[Type[Enemy], int, float]]:
    base = [
        (BasicEnemy, 8 + wave_number * 2, 1.0),
    ]
    if wave_number >= 2:
        base.append((FastEnemy, 4 + wave_number, 0.6))
    if wave_number >= 3:
        base.append((SwarmEnemy, 10 + wave_number * 2, 0.3))
    if wave_number >= 4:
        base.append((TankEnemy, 1 + wave_number // 2, 2.0))
        base.append((FlyingEnemy, 2 * (1 + max(0, (wave_number - 4) // 2)), 1.4))
    if wave_number >= 6:
        base.append((HeavyEnemy, 1 + wave_number // 6, 1.5))
    if wave_number % 5 == 0:
        base.append((BossEnemy, 1, 0.0))
    return base

HP_SCALE = 1.15  # +15% HP per wave

class WaveManager:
    def __init__(
        self,
        path: list,
        tile_size: int,
        hp_scale: float = 1.15,
        adaptive_hp_mult: float = 1.0,
    ):
        self.path = path
        self.tile_size = tile_size
        self.hp_scale = hp_scale
        self.adaptive_hp_mult = adaptive_hp_mult
        self.wave_number = 0
        self.active = False
        self._queue: Deque[SpawnEntry] = deque()
        self._timer = 0.0
        self.spawned_count: int = 0
        self.total_to_spawn: int = 0

    def start_wave(self) -> None:
        if self.active:
            return
        self.wave_number += 1
        self.active = True
        self._queue = deque()
        t = 0.0
        definition = _wave_definition(self.wave_number)
        self.total_to_spawn = sum(count for _, count, _ in definition)
        self.spawned_count = 0
        if self.wave_number < 6:
            for enemy_cls, count, interval in definition:
                for _ in range(count):
                    self._queue.append((enemy_cls, t))
                    t += interval
        else:
            # Mix classes from wave 6+ to avoid long grouped blocks.
            rng = random.Random(self.wave_number)
            pools = {
                enemy_cls: {"count": int(count), "interval": float(interval)}
                for enemy_cls, count, interval in definition
            }
            remaining = self.total_to_spawn
            while remaining > 0:
                available = [cls for cls, meta in pools.items() if meta["count"] > 0]
                rng.shuffle(available)
                for enemy_cls in available:
                    meta = pools[enemy_cls]
                    if meta["count"] <= 0:
                        continue
                    self._queue.append((enemy_cls, t))
                    t += meta["interval"]
                    meta["count"] -= 1
                    remaining -= 1
        MAX_WAVE_DURATION = 15.0
        if self._queue:
            last_t = self._queue[-1][1]
            if last_t > MAX_WAVE_DURATION:
                scale = MAX_WAVE_DURATION / last_t
                self._queue = deque(
                    (cls, t * scale) for cls, t in self._queue
                )
        self._timer = 0.0

    def update(self, dt: float) -> List[Enemy]:
        if not self.active:
            return []
        self._timer += dt
        spawned = []
        while self._queue and self._queue[0][1] <= self._timer:
            enemy_cls, _ = self._queue.popleft()
            e = enemy_cls(path=self.path, tile_size=self.tile_size)
            scale = (self.hp_scale ** (self.wave_number - 1)) * self.adaptive_hp_mult
            e.hp = int(e.hp * scale)
            e.max_hp = e.hp
            self.spawned_count += 1
            spawned.append(e)
        if not self._queue:
            self.active = False
        return spawned
