from collections import deque
import random
from typing import Deque, List, Tuple, Type
from src.enemy import (BasicEnemy, FastEnemy, TankEnemy, SwarmEnemy,
                        HeavyEnemy, PathFlyer, ScoutFlyer, BossEnemy)
from src.enemy import Enemy, FlyingEnemy
FlyingEnemy = PathFlyer  # backward compat locale

SpawnEntry = Tuple[Type[Enemy], float]  # (EnemyClass, spawn_time)

def _wave_definition(wave_number: int) -> List[Tuple[Type[Enemy], int, float]]:
    base = [
        (BasicEnemy, 8 + wave_number * 2, 1.0),
    ]
    if wave_number >= 2:
        base.append((FastEnemy, 4 + wave_number, 0.6))
    if wave_number >= 3:
        base.append((SwarmEnemy, 10 + wave_number * 2, 0.3))
    if wave_number >= 4:
        base.append((TankEnemy, 1 + wave_number // 2, 2.0))
        base.append((PathFlyer, 2 * (1 + max(0, (wave_number - 4) // 2)), 1.4))
    if wave_number >= 5:
        base.append((ScoutFlyer, 1 + wave_number // 5, 1.2))
    if wave_number >= 6:
        base.append((HeavyEnemy, 1 + wave_number // 6, 1.5))
    if wave_number % 5 == 0:
        base.append((BossEnemy, 1, 0.0))
    return base


_ENEMY_META = {
    BasicEnemy: {"name": "Basic", "icon": "●"},
    FastEnemy: {"name": "Fast", "icon": "▲"},
    SwarmEnemy: {"name": "Swarm", "icon": "◆"},
    TankEnemy: {"name": "Tank", "icon": "■"},
    PathFlyer: {"name": "Flying", "icon": "✈"},
    ScoutFlyer: {"name": "Scout", "icon": "✦"},
    HeavyEnemy: {"name": "Heavy", "icon": "★"},
    BossEnemy: {"name": "Boss", "icon": "👑"},
}


def wave_preview(wave_number: int) -> dict:
    """
    Pure function: returns a dict describing enemy composition of a wave.

    Returns:
        {
            "wave": int,
            "total": int,
            "has_boss": bool,
            "enemies": [{"name": str, "count": int, "icon": str}, ...]
        }
    """
    definition = _wave_definition(wave_number)

    # Build enemy list in canonical order, skipping zero counts
    enemy_order = [BasicEnemy, FastEnemy, SwarmEnemy, TankEnemy, PathFlyer, ScoutFlyer, HeavyEnemy, BossEnemy]
    count_map = {cls: 0 for cls in enemy_order}

    for enemy_cls, count, _ in definition:
        count_map[enemy_cls] = count

    enemies = []
    total = 0
    has_boss = False

    for enemy_cls in enemy_order:
        cnt = count_map[enemy_cls]
        if cnt > 0:
            meta = _ENEMY_META[enemy_cls]
            enemies.append({
                "name": meta["name"],
                "count": cnt,
                "icon": meta["icon"]
            })
            total += cnt
            if enemy_cls == BossEnemy:
                has_boss = True

    return {
        "wave": wave_number,
        "total": total,
        "has_boss": has_boss,
        "enemies": enemies
    }


HP_SCALE = 1.15  # +15% HP per wave

class WaveManager:
    def __init__(
        self,
        path: list,
        tile_size: int,
        hp_scale: float = 1.15,
        adaptive_hp_mult: float = 1.0,
        map_height_px: int = 320,
    ):
        self.path = path
        self.tile_size = tile_size
        self.hp_scale = hp_scale
        self.adaptive_hp_mult = adaptive_hp_mult
        self.map_height_px = map_height_px
        self.wave_number = 0
        self.active = False
        self._queue: Deque[SpawnEntry] = deque()
        self._timer = 0.0
        self.spawned_count: int = 0
        self.total_to_spawn: int = 0

    def start_wave(self) -> None:
        if self.active:
            return
        self.wave_number += 1
        self.active = True
        self._queue = deque()
        t = 0.0
        definition = _wave_definition(self.wave_number)
        self.total_to_spawn = sum(count for _, count, _ in definition)
        self.spawned_count = 0
        if self.wave_number < 6:
            for enemy_cls, count, interval in definition:
                for _ in range(count):
                    self._queue.append((enemy_cls, t))
                    t += interval
        else:
            # Mix classes from wave 6+ to avoid long grouped blocks.
            rng = random.Random(self.wave_number)
            pools = {
                enemy_cls: {"count": int(count), "interval": float(interval)}
                for enemy_cls, count, interval in definition
            }
            remaining = self.total_to_spawn
            while remaining > 0:
                available = [cls for cls, meta in pools.items() if meta["count"] > 0]
                rng.shuffle(available)
                for enemy_cls in available:
                    meta = pools[enemy_cls]
                    if meta["count"] <= 0:
                        continue
                    self._queue.append((enemy_cls, t))
                    t += meta["interval"]
                    meta["count"] -= 1
                    remaining -= 1
        MAX_WAVE_DURATION = 15.0
        if self._queue:
            last_t = self._queue[-1][1]
            if last_t > MAX_WAVE_DURATION:
                scale = MAX_WAVE_DURATION / last_t
                self._queue = deque(
                    (cls, t * scale) for cls, t in self._queue
                )
        self._timer = 0.0

    def update(self, dt: float) -> List[Enemy]:
        if not self.active:
            return []
        self._timer += dt
        spawned = []
        while self._queue and self._queue[0][1] <= self._timer:
            enemy_cls, _ = self._queue.popleft()
            if enemy_cls is ScoutFlyer:
                e = enemy_cls(self.path, self.tile_size, map_height_px=self.map_height_px)
            else:
                e = enemy_cls(path=self.path, tile_size=self.tile_size)
            scale = (self.hp_scale ** (self.wave_number - 1)) * self.adaptive_hp_mult
            e.hp = int(e.hp * scale)
            e.max_hp = e.hp
            self.spawned_count += 1
            spawned.append(e)
        if not self._queue:
            self.active = False
        return spawned
