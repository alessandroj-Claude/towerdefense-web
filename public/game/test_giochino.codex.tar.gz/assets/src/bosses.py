"""Boss phase domain module. No pygame, no game state."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class BossPhase:
    """Boss phase config."""

    id: str
    hp_threshold: float  # HP ratio at which phase activates (<=)
    label: str
    ability_id: str  # "none" | "summon_swarm" | "armor_pulse"


def boss_phases() -> list[BossPhase]:
    """Return boss phases ordered descending by threshold."""
    return [
        BossPhase(
            id="phase_1",
            hp_threshold=1.0,
            label="Phase 1: Awakening",
            ability_id="none",
        ),
        BossPhase(
            id="phase_2",
            hp_threshold=0.66,
            label="Phase 2: Swarm",
            ability_id="summon_swarm",
        ),
        BossPhase(
            id="phase_3",
            hp_threshold=0.33,
            label="Phase 3: Armored",
            ability_id="armor_pulse",
        ),
    ]


def phase_for_hp_ratio(ratio: float, phases: Optional[list[BossPhase]] = None) -> BossPhase:
    """
    Return phase active at given HP ratio.

    Phase logic:
    - phase_1: ratio > 0.66
    - phase_2: 0.33 < ratio <= 0.66
    - phase_3: ratio <= 0.33
    """
    if phases is None:
        phases = boss_phases()

    # Iterate through phases in descending threshold order.
    # Return the first phase whose lower threshold has not been breached.
    for i, phase in enumerate(phases):
        # If this is the last phase, always return it
        if i == len(phases) - 1:
            return phase
        # Check if ratio is above the next phase's threshold
        next_threshold = phases[i + 1].hp_threshold
        if ratio > next_threshold:
            return phase

    # Fallback (shouldn't happen with valid ratio in [0, 1])
    return phases[-1]


def boss_ability_config() -> dict[str, dict]:
    """Return ability config dict."""
    return {
        "summon_swarm": {
            "telegraph_duration": 1.2,
            "effect": "spawn_swarm",
        },
        "armor_pulse": {
            "telegraph_duration": 1.2,
            "effect": "damage_reduction",
            "duration": 4.0,
        },
    }


def boss_reward_pool() -> list[str]:
    """Return boss reward pool."""
    return ["gold_cache", "field_repair", "overclock_token"]
