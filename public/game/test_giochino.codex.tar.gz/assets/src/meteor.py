import random
from typing import List, Tuple

METEOR_ENEMY_PCTS = {"easy": 1.00, "normal": 0.66, "hard": 0.33}
METEOR_TOWER_PCTS = {"easy": 0.33, "normal": 0.66, "hard": 1.00}


class MeteorShower:
    def __init__(self, path: List[Tuple[int, int]], wave_num: int, difficulty: str):
        self.path = path
        self.meteor_enemy_pct = METEOR_ENEMY_PCTS[difficulty]
        self.meteor_tower_pct = METEOR_TOWER_PCTS[difficulty]
        count = 3 + (min(wave_num, 50) - 1) * 10 // 49
        self.positions = self._generate_positions(count)

    def _generate_positions(self, count: int) -> List[Tuple[int, int]]:
        candidates = set(self.path)
        for col, row in self.path:
            for dc, dr in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                candidates.add((col + dc, row + dr))
        candidates = list(candidates)
        return random.sample(candidates, min(count, len(candidates)))

    def apply(self, enemies: list, towers: list) -> Tuple[list, list]:
        meteor_cells = set(self.positions)
        hit_enemies = []
        destroyed_towers = []

        for e in enemies:
            if not e.alive:
                continue
            cell = self.path[min(int(e.progress), len(self.path) - 1)]
            if cell in meteor_cells:
                dmg = int(e.hp * self.meteor_enemy_pct)
                e.take_damage(dmg)
                hit_enemies.append(e)

        for t in towers:
            if (t.col, t.row) in meteor_cells:
                dmg = int(t.max_hp * self.meteor_tower_pct)
                t.take_damage(dmg)
                if t.hp <= 0:
                    destroyed_towers.append(t)

        return hit_enemies, destroyed_towers
