"""
Visual constants and theme configuration for TowerDefense v6.0.

All color constants are RGB tuples (R, G, B) with values 0-255.
Typography and geometry constants are integers > 0.
"""

# ==================== COLOR PALETTE ====================

# Background/grid
BACKGROUND = (20, 20, 30)
GRID = (40, 40, 55)
PATH_BASE = (60, 55, 45)

# Terrain
ROAD = (74, 74, 74)
MUD = (92, 61, 30)
WIND = (126, 200, 227)
HIGH_WIND = (30, 144, 255)
FORTIFIED = (45, 80, 22)
BLOCKED = (50, 50, 60)

# Towers
TOWER_BASIC = (180, 180, 100)
TOWER_ICE = (100, 180, 255)
TOWER_BOMB = (220, 120, 50)
TOWER_SNIPER = (150, 80, 200)
TOWER_ANTI_AIR = (80, 200, 120)
TOWER_STORM = (255, 220, 50)
TOWER_INFERNO = (255, 80, 50)

# Enemies
ENEMY_BASIC = (200, 80, 80)
ENEMY_FAST = (255, 150, 50)
ENEMY_TANK = (100, 100, 180)
ENEMY_BOSS = (180, 50, 180)
ENEMY_HEAVY = (80, 140, 80)
ENEMY_FLYING = (50, 200, 220)

# UI
PANEL_BG = (30, 30, 45)
BUTTON_DEFAULT = (60, 60, 80)
BUTTON_HOVER = (80, 80, 110)
BUTTON_ACTIVE = (100, 100, 140)
ACCENT = (100, 180, 255)  # intentionally matches TOWER_ICE
SELECTED_BORDER = (80, 220, 255)  # bright cyan for selected UI elements (level boxes)
TEXT_PRIMARY = (240, 240, 240)
TEXT_SECONDARY = (160, 160, 180)

# Events
EVENT_POSITIVE = (80, 200, 120)
EVENT_NEGATIVE = (220, 80, 80)
EVENT_NEUTRAL = (160, 160, 160)

# Health bar
HP_HIGH = (80, 200, 80)
HP_MED = (220, 180, 50)
HP_LOW = (220, 80, 50)

# Renderer-specific colors (used by renderer submodules)
PATH_SANDY = (194, 154, 76)         # sandy path color (lighter than PATH_BASE)
PATH_TUBE_BORDER = (98, 82, 58)     # dark tan border around path tube
PATH_ARROW = (238, 226, 180)        # light cream direction arrows on path
TERRAIN_GRASS = (34, 139, 34)       # green grass terrain accent
BLOCKED_ACCENT = (96, 108, 96)      # muted green accent on blocked tiles
ENEMY_SWARM = (200, 200, 50)        # yellow-green swarm enemy
ENEMY_FLYING_RENDER = (120, 180, 255)  # render color for FlyingEnemy (lighter than ENEMY_FLYING)
ENEMY_HEAVY_RENDER = (90, 30, 120)  # render color for HeavyEnemy (deep purple)
PROJECTILE = (255, 255, 0)          # tower projectile (pure yellow)
HP_BAR_BG = (180, 0, 0)             # HP bar background (deep red)
GOLD_COLOR = (255, 215, 0)          # currency display gold
SELECTION_HIGHLIGHT = (255, 255, 100)  # bright yellow selection highlight

# ==================== TYPOGRAPHY ====================

FONT_HUD = 20
FONT_PANEL = 16
FONT_TOOLTIP = 15
FONT_MENU = 24
FONT_LABEL = 14

# ==================== GEOMETRY ====================

BORDER_THIN = 1
BORDER_MEDIUM = 2
BORDER_THICK = 3
OVERLAY_ALPHA_LIGHT = 80
OVERLAY_ALPHA_MED = 140
HEALTH_BAR_H = 4
TOWER_RING_W = 2

# ==================== ELEMENT COLORS ====================

ELEMENT_COLORS: dict[str, tuple[int, int, int]] = {
    "ARCANE":    (180, 130, 255),
    "FIRE":      (255, 100,  30),
    "ICE":       (100, 200, 255),
    "LIGHTNING": (255, 240,  50),
    "EARTH":     (140, 100,  60),
    "AIR":       (200, 230, 200),
}
