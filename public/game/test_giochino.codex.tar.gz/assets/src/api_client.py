from __future__ import annotations

import asyncio
import json
import platform
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Optional


class APIClient:
    def __init__(self, base_url: str):
        self._base_url = base_url.rstrip("/")
        self._token: Optional[str] = None
        self.last_error: str = ""

    def _auth_headers(self) -> dict[str, str]:
        if self._token:
            return {"Authorization": f"Bearer {self._token}"}
        return {}

    def set_token(self, token: str) -> None:
        self._token = token

    async def _request(self, method: str, path: str, body: Optional[dict[str, Any]] = None) -> Optional[Any]:
        url = f"{self._base_url}{path}"
        headers = {"Content-Type": "application/json", **self._auth_headers()}
        payload = None if body is None else json.dumps(body).encode("utf-8")

        try:
            if sys.platform == "emscripten":
                result = await self._request_wasm(method, url, headers, payload)
            else:
                result = await asyncio.to_thread(self._request_sync, method, url, headers, payload)
            if result is not None:
                self.last_error = ""
            return result
        except Exception as exc:
            self.last_error = f"request error: {exc}"
            return None

    _wasm_js_injected: bool = False

    async def _request_wasm(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        payload: Optional[bytes],
    ) -> Optional[Any]:
        import platform as _plat  # noqa: PLC0415 – emscripten platform

        # Inject JS helper once: generator function so platform.jsiter works.
        if not APIClient._wasm_js_injected:
            _plat.window.eval(
                "window._pygameHTTP = function * _pygameHTTP(url, method, headersJson, body) {"
                "  var hdr = JSON.parse(headersJson);"
                "  var opts = { method: method, headers: hdr };"
                "  if (body) opts.body = body;"
                "  var content = 'undefined';"
                "  fetch(url, opts)"
                "    .then(function(r){"
                "      return r.text().then(function(t){"
                "        content = JSON.stringify({ ok: r.ok, status: r.status, text: t });"
                "      });"
                "    })"
                "    .catch(function(e){ content = ''; });"
                "  while (content === 'undefined') { yield; }"
                "  yield content;"
                "}"
            )
            APIClient._wasm_js_injected = True

        body_str = payload.decode("utf-8", errors="ignore") if payload else ""
        envelope_text = await _plat.jsiter(
            _plat.window._pygameHTTP(url, method, json.dumps(headers), body_str)
        )
        if not envelope_text:
            return None
        try:
            envelope = json.loads(envelope_text)
        except json.JSONDecodeError:
            return None
        if not isinstance(envelope, dict):
            self.last_error = "invalid response envelope"
            return None
        if not envelope.get("ok"):
            status = envelope.get("status", "?")
            text = str(envelope.get("text", "") or "").strip()
            self.last_error = f"http {status}: {text[:120]}"
            return None
        result_text = str(envelope.get("text", "") or "")
        if not result_text:
            self.last_error = "empty response body"
            return None
        return json.loads(result_text)

    def _request_sync(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        payload: Optional[bytes],
    ) -> Optional[Any]:
        request = urllib.request.Request(url, data=payload, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8", errors="ignore").strip()
            except (OSError, UnicodeDecodeError):
                detail = ""
            self.last_error = f"http {exc.code}: {detail[:120]}"
            return None
        except Exception as exc:
            self.last_error = f"network error: {exc}"
            return None
        if not raw:
            self.last_error = "empty response body"
            return None
        return json.loads(raw)

    async def register(self, username: str, password: str) -> Optional[Any]:
        result = await self._request("POST", "/auth/register", {"username": username, "password": password})
        if isinstance(result, dict) and "access_token" in result:
            self._token = result["access_token"]
        return result

    async def login(self, username: str, password: str) -> Optional[Any]:
        result = await self._request("POST", "/auth/login", {"username": username, "password": password})
        if isinstance(result, dict) and "access_token" in result:
            self._token = result["access_token"]
        return result

    async def get_auth_me(self) -> Optional[Any]:
        return await self._request("GET", "/auth/me")

    async def save_game(self, user_id: int, data: dict[str, Any]) -> bool:
        result = await self._request("POST", f"/saves/{user_id}", {"data": data})
        return isinstance(result, dict) and isinstance(result.get("data"), dict)

    async def load_game(self, user_id: int) -> Optional[Any]:
        result = await self._request("GET", f"/saves/{user_id}")
        if isinstance(result, dict):
            return result.get("data")
        return None

    async def record_score(
        self,
        score: int,
        wave: int,
        difficulty: str = "normal",
        version: Optional[str] = None,
        challenge_kind: str = "",
        challenge_id: str = "",
    ) -> bool:
        body: dict[str, Any] = {"score": score, "wave": wave, "difficulty": difficulty}
        if version:
            body["version"] = version
        if challenge_kind:
            body["challenge_kind"] = challenge_kind
        if challenge_id:
            body["challenge_id"] = challenge_id
        return (await self._request("POST", "/leaderboard/record", body)) is not None

    async def get_leaderboard_global(
        self,
        difficulty: str = "normal",
        challenge_kind: str = "",
        challenge_id: str = "",
    ) -> list[Any]:
        query: dict[str, str] = {"difficulty": difficulty}
        if challenge_kind:
            query["challenge_kind"] = challenge_kind
        if challenge_id:
            query["challenge_id"] = challenge_id
        result = await self._request("GET", f"/leaderboard/global?{urllib.parse.urlencode(query)}")
        return result if isinstance(result, list) else []

    async def get_leaderboard_user(
        self,
        user_id: int,
        difficulty: str = "normal",
        challenge_kind: str = "",
        challenge_id: str = "",
    ) -> list[Any]:
        query: dict[str, str] = {"difficulty": difficulty}
        if challenge_kind:
            query["challenge_kind"] = challenge_kind
        if challenge_id:
            query["challenge_id"] = challenge_id
        result = await self._request("GET", f"/leaderboard/user/{user_id}?{urllib.parse.urlencode(query)}")
        return result if isinstance(result, list) else []

    async def validate_dlc(self, license_key: str) -> bool:
        result = await self._request(
            "POST", "/dlc/validate", {"dlc_id": "storm_pack", "license_key": license_key}
        )
        return bool(isinstance(result, dict) and result.get("valid"))

    async def activate_dlc(self, dlc_id: str, license_key: str) -> bool:
        result = await self._request(
            "POST",
            "/dlc/activate",
            {"dlc_id": dlc_id, "license_key": license_key},
        )
        return bool(isinstance(result, dict) and result.get("ok"))

    async def admin_list_users(self) -> list[Any]:
        result = await self._request("GET", "/auth/admin/users")
        return result if isinstance(result, list) else []

    async def admin_dlc_toggle(self, target_user_id: int, dlc_id: str, enabled: bool) -> bool:
        result = await self._request(
            "POST", "/auth/admin/dlc-toggle",
            {"target_user_id": target_user_id, "dlc_id": dlc_id, "enabled": enabled},
        )
        return bool(isinstance(result, dict) and result.get("ok"))

    async def admin_soft_delete(self, target_user_id: int) -> bool:
        result = await self._request(
            "POST", "/auth/admin/soft-delete",
            {"target_user_id": target_user_id},
        )
        return bool(isinstance(result, dict) and result.get("ok"))

    async def check_user_exists(self, username: str) -> bool:
        safe_username = urllib.parse.quote(username, safe="")
        result = await self._request("GET", f"/auth/exists/{safe_username}")
        if not isinstance(result, dict) or "exists" not in result:
            return False
        return bool(result.get("exists"))

    async def get_profile_stats(self) -> Optional[Any]:
        return await self._request("GET", "/profile/stats")

    async def award_profile_run(
        self,
        score: int,
        wave: int,
        difficulty: str = "normal",
        mutator_bonus: int = 0,
        mutator_count: int = 0,
    ) -> Optional[Any]:
        return await self._request("POST", "/profile/stats/award-run", {
            "score": score,
            "wave": wave,
            "difficulty": difficulty,
            "mutator_bonus": mutator_bonus,
            "mutator_count": mutator_count,
        })
