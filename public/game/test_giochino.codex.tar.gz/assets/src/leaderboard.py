import sqlite3
from typing import Optional, Any

from src.db import get_connection, sql

VALID_DIFFICULTIES = {"easy", "normal", "hard"}


def _normalize_difficulty(difficulty: str) -> str:
    value = str(difficulty).strip().lower()
    return value if value in VALID_DIFFICULTIES else "normal"


def record_score_run(
    user_id: int,
    score: int,
    wave: int,
    version: str,
    difficulty: str = "normal",
    _conn: Optional[Any] = None,
) -> bool:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        conn.execute(
            sql("INSERT INTO score_runs (user_id, score, wave, version, difficulty) VALUES (?, ?, ?, ?, ?)"),
            (int(user_id), int(score), int(wave), str(version), _normalize_difficulty(difficulty)),
        )
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        if owns_conn:
            conn.close()


def top5_global(
    difficulty: str = "normal",
    version: Optional[str] = None,
    _conn: Optional[Any] = None,
) -> list[dict]:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        query = (
            "SELECT u.username, r.score, r.wave, r.version, COALESCE(NULLIF(r.difficulty, ''), 'normal') AS difficulty, r.created_at "
            "FROM score_runs r "
            "JOIN users u ON u.id = r.user_id "
            "WHERE u.is_active = 1 AND COALESCE(NULLIF(r.difficulty, ''), 'normal') = ? "
        )
        params: tuple = (_normalize_difficulty(difficulty),)
        if version:
            query += "AND r.version = ? "
            params = (_normalize_difficulty(difficulty), version)
        query += "ORDER BY r.score DESC, r.wave DESC, r.id DESC LIMIT 5"
        rows = conn.execute(sql(query), params).fetchall()
        return [
            {
                "username": row[0],
                "score": int(row[1]),
                "wave": int(row[2]),
                "version": row[3],
                "difficulty": row[4],
                "created_at": row[5],
            }
            for row in rows
        ]
    finally:
        if owns_conn:
            conn.close()


def top5_user(
    user_id: int,
    difficulty: str = "normal",
    version: Optional[str] = None,
    _conn: Optional[Any] = None,
) -> list[dict]:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        query = (
            "SELECT score, wave, version, COALESCE(NULLIF(difficulty, ''), 'normal') AS difficulty, created_at "
            "FROM score_runs WHERE user_id = ? AND COALESCE(NULLIF(difficulty, ''), 'normal') = ? "
        )
        params: tuple = (int(user_id), _normalize_difficulty(difficulty))
        if version:
            query += "AND version = ? "
            params = (int(user_id), _normalize_difficulty(difficulty), version)
        query += "ORDER BY score DESC, wave DESC, id DESC LIMIT 5"
        rows = conn.execute(sql(query), params).fetchall()
        return [
            {
                "score": int(row[0]),
                "wave": int(row[1]),
                "version": row[2],
                "difficulty": row[3],
                "created_at": row[4],
            }
            for row in rows
        ]
    finally:
        if owns_conn:
            conn.close()
