import sqlite3
from typing import Optional

from src.db import get_connection

VALID_DIFFICULTIES = {"easy", "normal", "hard"}


def _normalize_difficulty(difficulty: str) -> str:
    value = str(difficulty).strip().lower()
    return value if value in VALID_DIFFICULTIES else "normal"


def record_score_run(
    user_id: int,
    score: int,
    wave: int,
    version: str,
    difficulty: str = "normal",
    _conn: Optional[sqlite3.Connection] = None,
) -> bool:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        conn.execute(
            "INSERT INTO score_runs (user_id, score, wave, version, difficulty) VALUES (?, ?, ?, ?, ?)",
            (int(user_id), int(score), int(wave), str(version), _normalize_difficulty(difficulty)),
        )
        conn.commit()
        return True
    except sqlite3.Error:
        return False
    finally:
        if owns_conn:
            conn.close()


def top5_global(
    difficulty: str = "normal",
    version: Optional[str] = None,
    _conn: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        sql = (
            "SELECT u.username, r.score, r.wave, r.version, COALESCE(NULLIF(r.difficulty, ''), 'normal') AS difficulty, r.created_at "
            "FROM score_runs r "
            "JOIN users u ON u.id = r.user_id "
            "WHERE u.is_active = 1 AND COALESCE(NULLIF(r.difficulty, ''), 'normal') = ? "
        )
        params: tuple = (_normalize_difficulty(difficulty),)
        if version:
            sql += "AND r.version = ? "
            params = (_normalize_difficulty(difficulty), version)
        sql += "ORDER BY r.score DESC, r.wave DESC, r.id DESC LIMIT 5"
        rows = conn.execute(sql, params).fetchall()
        return [
            {
                "username": row[0],
                "score": int(row[1]),
                "wave": int(row[2]),
                "version": row[3],
                "difficulty": row[4],
                "created_at": row[5],
            }
            for row in rows
        ]
    finally:
        if owns_conn:
            conn.close()


def top5_user(
    user_id: int,
    difficulty: str = "normal",
    version: Optional[str] = None,
    _conn: Optional[sqlite3.Connection] = None,
) -> list[dict]:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        sql = (
            "SELECT score, wave, version, COALESCE(NULLIF(difficulty, ''), 'normal') AS difficulty, created_at "
            "FROM score_runs WHERE user_id = ? AND COALESCE(NULLIF(difficulty, ''), 'normal') = ? "
        )
        params: tuple = (int(user_id), _normalize_difficulty(difficulty))
        if version:
            sql += "AND version = ? "
            params = (int(user_id), _normalize_difficulty(difficulty), version)
        sql += "ORDER BY score DESC, wave DESC, id DESC LIMIT 5"
        rows = conn.execute(sql, params).fetchall()
        return [
            {
                "score": int(row[0]),
                "wave": int(row[1]),
                "version": row[2],
                "difficulty": row[3],
                "created_at": row[4],
            }
            for row in rows
        ]
    finally:
        if owns_conn:
            conn.close()
