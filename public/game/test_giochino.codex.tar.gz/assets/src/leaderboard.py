import json
import sqlite3
from typing import Optional, Any

from src.db import get_connection, sql

VALID_DIFFICULTIES = {"easy", "normal", "hard", "endless"}
VALID_CHALLENGE_KINDS = {"daily", "weekly"}
VALID_MODES = {"normal", "endless"}


def _normalize_difficulty(difficulty: str) -> str:
    value = str(difficulty).strip().lower()
    return value if value in VALID_DIFFICULTIES else "normal"


def _normalize_mode(mode: str) -> str:
    value = str(mode).strip().lower()
    return value if value in VALID_MODES else "normal"


def _normalize_challenge_scope(
    challenge_kind: Optional[str],
    challenge_id: Optional[str],
) -> tuple[str, str]:
    kind = str(challenge_kind or "").strip().lower()
    cid = str(challenge_id or "").strip()
    if kind in VALID_CHALLENGE_KINDS and cid:
        return kind, cid
    return "", ""


def record_score_run(
    user_id: int,
    score: int,
    wave: int,
    version: str,
    difficulty: str = "normal",
    challenge_kind: Optional[str] = None,
    challenge_id: Optional[str] = None,
    mutators: Optional[list] = None,
    score_mult: float = 1.0,
    mode: str = "normal",
    _conn: Optional[Any] = None,
) -> bool:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        normalized_kind, normalized_id = _normalize_challenge_scope(challenge_kind, challenge_id)
        mutators_json = json.dumps(list(mutators or []))
        conn.execute(
            sql(
                "INSERT INTO score_runs "
                "(user_id, score, wave, version, difficulty, challenge_kind, challenge_id, mutators_json, score_mult, mode) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            ),
            (
                int(user_id),
                int(score),
                int(wave),
                str(version),
                _normalize_difficulty(difficulty),
                normalized_kind,
                normalized_id,
                mutators_json,
                float(score_mult),
                _normalize_mode(mode),
            ),
        )
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        if owns_conn:
            conn.close()


def top5_global(
    difficulty: str = "normal",
    version: Optional[str] = None,
    challenge_kind: Optional[str] = None,
    challenge_id: Optional[str] = None,
    limit: int = 20,
    mode: str = "normal",
    _conn: Optional[Any] = None,
) -> list[dict]:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        normalized_kind, normalized_id = _normalize_challenge_scope(challenge_kind, challenge_id)
        query = (
            "SELECT u.username, r.score, r.wave, r.version, "
            "COALESCE(NULLIF(r.difficulty, ''), 'normal') AS difficulty, "
            "COALESCE(r.challenge_kind, '') AS challenge_kind, "
            "COALESCE(r.challenge_id, '') AS challenge_id, "
            "r.created_at, "
            "COALESCE(r.mutators_json, '[]') AS mutators_json, "
            "COALESCE(r.score_mult, 1.0) AS score_mult "
            "FROM score_runs r "
            "JOIN users u ON u.id = r.user_id "
            "WHERE u.is_active = 1 AND COALESCE(NULLIF(r.difficulty, ''), 'normal') = ? "
        )
        params: tuple = (_normalize_difficulty(difficulty),)
        query += "AND COALESCE(r.mode, 'normal') = ? "
        params = params + (_normalize_mode(mode),)
        if normalized_kind and normalized_id:
            query += "AND COALESCE(r.challenge_kind, '') = ? AND COALESCE(r.challenge_id, '') = ? "
            params = params + (normalized_kind, normalized_id)
        else:
            query += "AND COALESCE(r.challenge_kind, '') = '' AND COALESCE(r.challenge_id, '') = '' "
        if version:
            query += "AND r.version = ? "
            params = params + (version,)
        query += f"ORDER BY r.score DESC, r.wave DESC, r.id DESC LIMIT {limit}"
        rows = conn.execute(sql(query), params).fetchall()
        return [
            {
                "username": row["username"],
                "score": int(row["score"]),
                "wave": int(row["wave"]),
                "version": row["version"],
                "difficulty": row["difficulty"],
                "challenge_kind": row["challenge_kind"],
                "challenge_id": row["challenge_id"],
                "created_at": row["created_at"],
                "mutators": json.loads(row["mutators_json"] or "[]"),
                "score_mult": float(row["score_mult"] or 1.0),
            }
            for row in rows
        ]
    finally:
        if owns_conn:
            conn.close()


def top5_user(
    user_id: int,
    difficulty: str = "normal",
    version: Optional[str] = None,
    challenge_kind: Optional[str] = None,
    challenge_id: Optional[str] = None,
    limit: int = 20,
    mode: str = "normal",
    _conn: Optional[Any] = None,
) -> list[dict]:
    conn = _conn or get_connection()
    owns_conn = _conn is None
    try:
        normalized_kind, normalized_id = _normalize_challenge_scope(challenge_kind, challenge_id)
        query = (
            "SELECT score, wave, version, COALESCE(NULLIF(difficulty, ''), 'normal') AS difficulty, "
            "COALESCE(challenge_kind, '') AS challenge_kind, COALESCE(challenge_id, '') AS challenge_id, created_at, "
            "COALESCE(mutators_json, '[]') AS mutators_json, "
            "COALESCE(score_mult, 1.0) AS score_mult "
            "FROM score_runs WHERE user_id = ? AND COALESCE(NULLIF(difficulty, ''), 'normal') = ? "
        )
        params: tuple = (int(user_id), _normalize_difficulty(difficulty))
        query += "AND COALESCE(mode, 'normal') = ? "
        params = params + (_normalize_mode(mode),)
        if normalized_kind and normalized_id:
            query += "AND COALESCE(challenge_kind, '') = ? AND COALESCE(challenge_id, '') = ? "
            params = params + (normalized_kind, normalized_id)
        else:
            query += "AND COALESCE(challenge_kind, '') = '' AND COALESCE(challenge_id, '') = '' "
        if version:
            query += "AND version = ? "
            params = params + (version,)
        query += f"ORDER BY score DESC, wave DESC, id DESC LIMIT {limit}"
        rows = conn.execute(sql(query), params).fetchall()
        return [
            {
                "score": int(row["score"]),
                "wave": int(row["wave"]),
                "version": row["version"],
                "difficulty": row["difficulty"],
                "challenge_kind": row["challenge_kind"],
                "challenge_id": row["challenge_id"],
                "created_at": row["created_at"],
                "mutators": json.loads(row["mutators_json"] or "[]"),
                "score_mult": float(row["score_mult"] or 1.0),
            }
            for row in rows
        ]
    finally:
        if owns_conn:
            conn.close()
