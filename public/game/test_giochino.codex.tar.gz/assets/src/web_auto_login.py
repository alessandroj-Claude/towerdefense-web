from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Optional

from src.config import IS_WEB


AUTH_STORAGE_KEY = "td.auth"
AUTO_LOGIN_STORAGE_KEY = "td.gameAutoLogin"


@dataclass(frozen=True)
class WebAutoLoginState:
    token: str
    user_id: int
    username: str
    dlcs: list[str]


def parse_web_auto_login_state(
    auth_raw: Optional[str],
    auto_login_raw: Optional[str],
) -> Optional[WebAutoLoginState]:
    if auto_login_raw == "false" or not auth_raw:
        return None

    try:
        data = json.loads(auth_raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None

    token = data.get("token")
    user_id = data.get("userId")
    username = data.get("username")
    dlcs = data.get("dlcs", [])
    if not isinstance(token, str) or not token.strip():
        return None
    if not isinstance(user_id, int):
        return None
    if not isinstance(username, str) or not username.strip():
        return None
    if not isinstance(dlcs, list) or not all(isinstance(d, str) for d in dlcs):
        return None
    return WebAutoLoginState(token=token, user_id=user_id, username=username, dlcs=dlcs)


def read_web_auto_login_state() -> Optional[WebAutoLoginState]:
    if not IS_WEB:
        return None
    try:
        import platform as _plat  # noqa: PLC0415

        storage = _plat.window.localStorage
        auth_raw = storage.getItem(AUTH_STORAGE_KEY)
        auto_login_raw = storage.getItem(AUTO_LOGIN_STORAGE_KEY)
        return parse_web_auto_login_state(auth_raw, auto_login_raw)
    except Exception:
        return None
