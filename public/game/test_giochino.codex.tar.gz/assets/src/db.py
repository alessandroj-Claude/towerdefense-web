import os
import sqlite3
from pathlib import Path
from typing import Any

from src.shares import SHARE_2  # Shamir share distribution (not used here directly)
from src.data_paths import data_path, migrate_legacy_file

DB_PATH = data_path("tower_defense.db")
LEGACY_DB_PATH = Path(__file__).parent.parent / "tower_defense.db"
DATABASE_URL_ENV = "DATABASE_URL"

SQLITE_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    is_admin INTEGER NOT NULL DEFAULT 0,
    dlcs TEXT NOT NULL DEFAULT '',
    deleted INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    credits INTEGER NOT NULL DEFAULT 100
);
CREATE TABLE IF NOT EXISTS saves (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    saved_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS licenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dlc_id TEXT NOT NULL,
    activated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, dlc_id)
);
CREATE TABLE IF NOT EXISTS score_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    wave INTEGER NOT NULL,
    version TEXT NOT NULL,
    difficulty TEXT NOT NULL DEFAULT 'normal',
    challenge_kind TEXT NOT NULL DEFAULT '',
    challenge_id TEXT NOT NULL DEFAULT '',
    mutators_json TEXT NOT NULL DEFAULT '[]',
    score_mult REAL NOT NULL DEFAULT 1.0,
    mode TEXT NOT NULL DEFAULT 'normal',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS profile_stats (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    total_xp INTEGER NOT NULL DEFAULT 0,
    runs_played INTEGER NOT NULL DEFAULT 0,
    best_score INTEGER NOT NULL DEFAULT 0,
    best_wave INTEGER NOT NULL DEFAULT 0,
    badges_json TEXT NOT NULL DEFAULT '[]',
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS user_achievements (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    achievement_id TEXT NOT NULL,
    unlocked_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, achievement_id)
);
CREATE TABLE IF NOT EXISTS used_keys (
    key_hash TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    used_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

# Backward compatibility for existing tests importing SCHEMA_SQL.
SCHEMA_SQL = SQLITE_SCHEMA_SQL

POSTGRES_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    is_admin INTEGER NOT NULL DEFAULT 0,
    dlcs TEXT NOT NULL DEFAULT '',
    deleted INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    credits INTEGER NOT NULL DEFAULT 100
);
CREATE TABLE IF NOT EXISTS saves (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS licenses (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dlc_id TEXT NOT NULL,
    activated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, dlc_id)
);
CREATE TABLE IF NOT EXISTS score_runs (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    wave INTEGER NOT NULL,
    version TEXT NOT NULL,
    difficulty TEXT NOT NULL DEFAULT 'normal',
    challenge_kind TEXT NOT NULL DEFAULT '',
    challenge_id TEXT NOT NULL DEFAULT '',
    mutators_json TEXT NOT NULL DEFAULT '[]',
    score_mult REAL NOT NULL DEFAULT 1.0,
    mode TEXT NOT NULL DEFAULT 'normal',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS profile_stats (
    user_id BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    total_xp INTEGER NOT NULL DEFAULT 0,
    runs_played INTEGER NOT NULL DEFAULT 0,
    best_score INTEGER NOT NULL DEFAULT 0,
    best_wave INTEGER NOT NULL DEFAULT 0,
    badges_json TEXT NOT NULL DEFAULT '[]',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS user_achievements (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    achievement_id TEXT NOT NULL,
    unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, achievement_id)
);
CREATE TABLE IF NOT EXISTS used_keys (
    key_hash TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


def get_database_url() -> str:
    return os.getenv(DATABASE_URL_ENV, "").strip()


def is_postgres_enabled() -> bool:
    return get_database_url().lower().startswith("postgres")


def sql(query: str) -> str:
    if not is_postgres_enabled():
        return query
    return query.replace("?", "%s")


def get_connection() -> Any:
    if is_postgres_enabled():
        try:
            import psycopg  # type: ignore
        except Exception as exc:  # pragma: no cover - depends on deploy env
            raise RuntimeError(
                "DATABASE_URL is set but psycopg is not installed. "
                "Install psycopg[binary] in backend requirements."
            ) from exc

        from psycopg.rows import dict_row  # type: ignore
        return psycopg.connect(get_database_url(), row_factory=dict_row)

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def insert_license_ignore(conn: Any, user_id: int, dlc_id: str) -> None:
    if is_postgres_enabled():
        conn.execute(
            "INSERT INTO licenses (user_id, dlc_id) VALUES (%s, %s) ON CONFLICT (user_id, dlc_id) DO NOTHING",
            (user_id, dlc_id),
        )
        return
    conn.execute(
        "INSERT OR IGNORE INTO licenses (user_id, dlc_id) VALUES (?, ?)",
        (user_id, dlc_id),
    )


def _list_columns(conn: Any, table_name: str) -> set[str]:
    if is_postgres_enabled():
        rows = conn.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema = 'public' AND table_name = %s",
            (table_name,),
        ).fetchall()
        return {str(row["column_name"]) for row in rows}

    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return {str(row["name"]) for row in rows}


def _ensure_users_is_active_column(conn: Any) -> None:
    columns = _list_columns(conn, "users")
    if "is_active" not in columns:
        conn.execute(
            "ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1"
        )


def _ensure_users_auth_columns(conn: Any) -> None:
    columns = _list_columns(conn, "users")
    if "is_admin" not in columns:
        conn.execute("ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")
    if "dlcs" not in columns:
        conn.execute("ALTER TABLE users ADD COLUMN dlcs TEXT NOT NULL DEFAULT ''")
    if "deleted" not in columns:
        conn.execute("ALTER TABLE users ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0")


def _ensure_score_runs_difficulty_column(conn: Any) -> None:
    columns = _list_columns(conn, "score_runs")
    if "difficulty" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN difficulty TEXT NOT NULL DEFAULT 'normal'"
            )
        except Exception as exc:
            # In some sqlite test/runtime environments the DB can be readonly.
            if not is_postgres_enabled() and "readonly" in str(exc).lower():
                return
            raise
    conn.execute(
        "UPDATE score_runs SET difficulty = 'normal' WHERE difficulty IS NULL OR difficulty = ''"
    )


def _ensure_score_runs_challenge_columns(conn: Any) -> None:
    columns = _list_columns(conn, "score_runs")
    if "challenge_kind" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN challenge_kind TEXT NOT NULL DEFAULT ''"
            )
        except Exception as exc:
            if not is_postgres_enabled() and "readonly" in str(exc).lower():
                return
            raise
    if "challenge_id" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN challenge_id TEXT NOT NULL DEFAULT ''"
            )
        except Exception as exc:
            if not is_postgres_enabled() and "readonly" in str(exc).lower():
                return
            raise
    conn.execute(
        "UPDATE score_runs SET challenge_kind = '' WHERE challenge_kind IS NULL"
    )
    conn.execute(
        "UPDATE score_runs SET challenge_id = '' WHERE challenge_id IS NULL"
    )


def _ensure_profile_stats_table(conn: Any) -> None:
    """Idempotent: create profile_stats table if it doesn't exist."""
    columns = _list_columns(conn, "profile_stats")
    if columns:
        # Table exists; nothing to do (schema already applied via CREATE TABLE IF NOT EXISTS)
        return
    if is_postgres_enabled():
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS profile_stats (
                user_id BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                total_xp INTEGER NOT NULL DEFAULT 0,
                runs_played INTEGER NOT NULL DEFAULT 0,
                best_score INTEGER NOT NULL DEFAULT 0,
                best_wave INTEGER NOT NULL DEFAULT 0,
                badges_json TEXT NOT NULL DEFAULT '[]',
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
    else:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS profile_stats (
                user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                total_xp INTEGER NOT NULL DEFAULT 0,
                runs_played INTEGER NOT NULL DEFAULT 0,
                best_score INTEGER NOT NULL DEFAULT 0,
                best_wave INTEGER NOT NULL DEFAULT 0,
                badges_json TEXT NOT NULL DEFAULT '[]',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


def _ensure_score_runs_mutator_columns(conn: Any) -> None:
    columns = _list_columns(conn, "score_runs")
    if "mutators_json" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN mutators_json TEXT NOT NULL DEFAULT '[]'"
            )
        except Exception as exc:
            if not is_postgres_enabled() and "readonly" in str(exc).lower():
                return
            raise
    if "score_mult" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN score_mult REAL NOT NULL DEFAULT 1.0"
            )
        except Exception as exc:
            if not is_postgres_enabled() and "readonly" in str(exc).lower():
                return
            raise


def _ensure_score_runs_mode_column(conn: Any) -> None:
    columns = _list_columns(conn, "score_runs")
    if "mode" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN mode TEXT NOT NULL DEFAULT 'normal'"
            )
        except Exception as exc:
            if not is_postgres_enabled() and "readonly" in str(exc).lower():
                return
            raise


def _ensure_user_achievements_table(conn: Any) -> None:
    """Idempotent: create user_achievements table if it doesn't exist."""
    columns = _list_columns(conn, "user_achievements")
    if columns:
        # Table exists; nothing to do (schema already applied via CREATE TABLE IF NOT EXISTS)
        return
    if is_postgres_enabled():
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS user_achievements (
                user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                achievement_id TEXT NOT NULL,
                unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, achievement_id)
            )
            """
        )
    else:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS user_achievements (
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                achievement_id TEXT NOT NULL,
                unlocked_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, achievement_id)
            )
            """
        )


def _migrate_credits(conn: Any) -> None:
    """Add credits column to existing users table if missing."""
    columns = _list_columns(conn, "users")
    if "credits" not in columns:
        conn.execute(
            "ALTER TABLE users ADD COLUMN credits INTEGER NOT NULL DEFAULT 100"
        )


def init_db() -> None:
    if not is_postgres_enabled():
        migrate_legacy_file("tower_defense.db")

    conn = get_connection()
    try:
        if is_postgres_enabled():
            conn.execute(POSTGRES_SCHEMA_SQL)
        else:
            conn.executescript(SQLITE_SCHEMA_SQL)
        _ensure_users_is_active_column(conn)
        _ensure_users_auth_columns(conn)
        _ensure_score_runs_difficulty_column(conn)
        _ensure_score_runs_challenge_columns(conn)
        _ensure_score_runs_mutator_columns(conn)
        _ensure_score_runs_mode_column(conn)
        _ensure_profile_stats_table(conn)
        _ensure_user_achievements_table(conn)
        _migrate_credits(conn)
        conn.commit()
    finally:
        conn.close()


def get_credits(user_id: int, _conn=None) -> int:
    """Get user credits. Return 0 if user not found."""
    conn = _conn or get_connection()
    row = conn.execute(
        sql("SELECT credits FROM users WHERE id = ?"), (user_id,)
    ).fetchone()
    if row is None:
        return 0
    return int(row[0] if not isinstance(row, dict) else row["credits"])


def adjust_credits(user_id: int, delta: int, _conn=None) -> int:
    """Adjust user credits by delta. Clamp to 0. Return new balance."""
    conn = _conn or get_connection()
    cur_bal = get_credits(user_id, conn)
    new_bal = max(0, cur_bal + delta)
    conn.execute(
        sql("UPDATE users SET credits = ? WHERE id = ?"), (new_bal, user_id)
    )
    if _conn is None:
        conn.commit()
    return new_bal


def purchase_dlc(user_id: int, dlc_id: str, price: int, _conn=None) -> tuple[bool, int]:
    """Purchase DLC: deduct price, add license, return (success, new_balance).
    Fails if insufficient credits or already owned. On error, return (False, current_balance).
    """
    conn = _conn or get_connection()
    try:
        cur_bal = get_credits(user_id, conn)
        if cur_bal < price:
            return False, cur_bal
        owned = conn.execute(
            sql("SELECT 1 FROM licenses WHERE user_id = ? AND dlc_id = ?"),
            (user_id, dlc_id),
        ).fetchone()
        if owned is not None:
            return False, cur_bal
        new_bal = cur_bal - price
        conn.execute(sql("UPDATE users SET credits = ? WHERE id = ?"), (new_bal, user_id))
        insert_license_ignore(conn, user_id, dlc_id)
        if _conn is None:
            conn.commit()
        return True, new_bal
    except Exception:
        if _conn is None:
            conn.close()
        return False, get_credits(user_id)


def is_key_used(key_hash: str, _conn=None) -> bool:
    """Check if a key has been used."""
    conn = _conn or get_connection()
    result = conn.execute(
        sql("SELECT 1 FROM used_keys WHERE key_hash = ?"), (key_hash,)
    ).fetchone()
    return result is not None


def mark_key_used(key_hash: str, username: str, _conn=None) -> None:
    """Mark a key as used by a username. Idempotent (uses INSERT OR IGNORE)."""
    conn = _conn or get_connection()
    try:
        if is_postgres_enabled():
            conn.execute(
                "INSERT INTO used_keys (key_hash, username) VALUES (%s, %s) ON CONFLICT (key_hash) DO NOTHING",
                (key_hash, username),
            )
        else:
            conn.execute(
                "INSERT OR IGNORE INTO used_keys (key_hash, username) VALUES (?, ?)",
                (key_hash, username),
            )
        if _conn is None:
            conn.commit()
    except Exception:
        pass
