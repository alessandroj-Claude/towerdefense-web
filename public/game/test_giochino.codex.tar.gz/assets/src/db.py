import sqlite3
from pathlib import Path
from src.shares import SHARE_2  # Shamir share distribution (not used here directly)
from src.data_paths import data_path, migrate_legacy_file

DB_PATH = data_path("tower_defense.db")
LEGACY_DB_PATH = Path(__file__).parent.parent / "tower_defense.db"

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS saves (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    saved_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS licenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dlc_id TEXT NOT NULL,
    activated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, dlc_id)
);
CREATE TABLE IF NOT EXISTS score_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    wave INTEGER NOT NULL,
    version TEXT NOT NULL,
    difficulty TEXT NOT NULL DEFAULT 'normal',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


def get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _ensure_users_is_active_column(conn: sqlite3.Connection) -> None:
    columns = {
        row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()
    }
    if "is_active" not in columns:
        conn.execute(
            "ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1"
        )


def _ensure_score_runs_difficulty_column(conn: sqlite3.Connection) -> None:
    columns = {
        row[1] for row in conn.execute("PRAGMA table_info(score_runs)").fetchall()
    }
    if "difficulty" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN difficulty TEXT NOT NULL DEFAULT 'normal'"
            )
        except sqlite3.OperationalError as exc:
            # In some test/runtime environments the DB file can be mounted readonly.
            # If schema migration cannot run there, skip startup failure and keep
            # operating in read-only mode.
            if "readonly" not in str(exc).lower():
                raise
            return
    conn.execute(
        "UPDATE score_runs SET difficulty = 'normal' WHERE difficulty IS NULL OR difficulty = ''"
    )


def init_db() -> None:
    migrate_legacy_file("tower_defense.db")
    conn = get_connection()
    conn.executescript(SCHEMA_SQL)
    _ensure_users_is_active_column(conn)
    _ensure_score_runs_difficulty_column(conn)
    conn.commit()
    conn.close()
