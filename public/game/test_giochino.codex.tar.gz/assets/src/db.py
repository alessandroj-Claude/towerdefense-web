import os
import sqlite3
from pathlib import Path
from typing import Any

from src.shares import SHARE_2  # Shamir share distribution (not used here directly)
from src.data_paths import data_path, migrate_legacy_file

DB_PATH = data_path("tower_defense.db")
LEGACY_DB_PATH = Path(__file__).parent.parent / "tower_defense.db"
DATABASE_URL_ENV = "DATABASE_URL"

SQLITE_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS saves (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    saved_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS licenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dlc_id TEXT NOT NULL,
    activated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, dlc_id)
);
CREATE TABLE IF NOT EXISTS score_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    wave INTEGER NOT NULL,
    version TEXT NOT NULL,
    difficulty TEXT NOT NULL DEFAULT 'normal',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

# Backward compatibility for existing tests importing SCHEMA_SQL.
SCHEMA_SQL = SQLITE_SCHEMA_SQL

POSTGRES_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS saves (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS licenses (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dlc_id TEXT NOT NULL,
    activated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, dlc_id)
);
CREATE TABLE IF NOT EXISTS score_runs (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    wave INTEGER NOT NULL,
    version TEXT NOT NULL,
    difficulty TEXT NOT NULL DEFAULT 'normal',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


def get_database_url() -> str:
    return os.getenv(DATABASE_URL_ENV, "").strip()


def is_postgres_enabled() -> bool:
    return get_database_url().lower().startswith("postgres")


def sql(query: str) -> str:
    if not is_postgres_enabled():
        return query
    return query.replace("?", "%s")


def get_connection() -> Any:
    if is_postgres_enabled():
        try:
            import psycopg  # type: ignore
        except Exception as exc:  # pragma: no cover - depends on deploy env
            raise RuntimeError(
                "DATABASE_URL is set but psycopg is not installed. "
                "Install psycopg[binary] in backend requirements."
            ) from exc

        return psycopg.connect(get_database_url())

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def insert_license_ignore(conn: Any, user_id: int, dlc_id: str) -> None:
    if is_postgres_enabled():
        conn.execute(
            "INSERT INTO licenses (user_id, dlc_id) VALUES (%s, %s) ON CONFLICT (user_id, dlc_id) DO NOTHING",
            (user_id, dlc_id),
        )
        return
    conn.execute(
        "INSERT OR IGNORE INTO licenses (user_id, dlc_id) VALUES (?, ?)",
        (user_id, dlc_id),
    )


def _list_columns(conn: Any, table_name: str) -> set[str]:
    if is_postgres_enabled():
        rows = conn.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema = 'public' AND table_name = %s",
            (table_name,),
        ).fetchall()
        return {str(row[0]) for row in rows}

    rows = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    return {str(row[1]) for row in rows}


def _ensure_users_is_active_column(conn: Any) -> None:
    columns = _list_columns(conn, "users")
    if "is_active" not in columns:
        conn.execute(
            "ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1"
        )


def _ensure_score_runs_difficulty_column(conn: Any) -> None:
    columns = _list_columns(conn, "score_runs")
    if "difficulty" not in columns:
        try:
            conn.execute(
                "ALTER TABLE score_runs ADD COLUMN difficulty TEXT NOT NULL DEFAULT 'normal'"
            )
        except Exception as exc:
            # In some sqlite test/runtime environments the DB can be readonly.
            if not is_postgres_enabled() and "readonly" in str(exc).lower():
                return
            raise
    conn.execute(
        "UPDATE score_runs SET difficulty = 'normal' WHERE difficulty IS NULL OR difficulty = ''"
    )


def init_db() -> None:
    if not is_postgres_enabled():
        migrate_legacy_file("tower_defense.db")

    conn = get_connection()
    try:
        if is_postgres_enabled():
            conn.execute(POSTGRES_SCHEMA_SQL)
        else:
            conn.executescript(SQLITE_SCHEMA_SQL)
        _ensure_users_is_active_column(conn)
        _ensure_score_runs_difficulty_column(conn)
        conn.commit()
    finally:
        conn.close()
