"""Progression domain: XP, levels, badges, and local DB persistence."""
from __future__ import annotations

import json
import math
from typing import Any
from src.db import sql

# ---------------------------------------------------------------------------
# Difficulty XP bonuses
# ---------------------------------------------------------------------------

_DIFFICULTY_BONUS: dict[str, int] = {
    "easy": 0,
    "normal": 25,
    "hard": 60,
}

XP_CAP = 500


# ---------------------------------------------------------------------------
# Pure functions
# ---------------------------------------------------------------------------

def xp_for_run(
    score: int,
    wave: int,
    difficulty: str,
    mutator_bonus: int = 0,
) -> int:
    """Return XP earned for a run (capped at XP_CAP=500).

    Formula: min(500, floor(score / 20) + wave * 10 + difficulty_bonus + mutator_bonus)
    """
    difficulty_bonus = _DIFFICULTY_BONUS.get(difficulty, 0)
    raw = math.floor(score / 20) + wave * 10 + difficulty_bonus + mutator_bonus
    return min(XP_CAP, raw)


def level_for_xp(total_xp: int) -> int:
    """Return player level for accumulated XP.

    Formula: 1 + floor(sqrt(total_xp / 100))
    """
    return 1 + math.floor(math.sqrt(total_xp / 100))


def badges_for_run(
    wave: int,
    difficulty: str,
    mutator_count: int = 0,
) -> list[str]:
    """Return list of badge IDs earned for a single run."""
    badges: list[str] = []

    # first_run: any completed run
    badges.append("first_run")

    # wave_10: reached wave >= 10
    if wave >= 10:
        badges.append("wave_10")

    # hard_survivor: reached wave >= 8 on hard
    if difficulty == "hard" and wave >= 8:
        badges.append("hard_survivor")

    # mutator_trial: completed with >= 1 mutator active
    if mutator_count >= 1:
        badges.append("mutator_trial")

    return badges


# ---------------------------------------------------------------------------
# DB functions (SQLite connection passed in — no global state)
# ---------------------------------------------------------------------------

def _ensure_profile_stats_row(conn: Any, user_id: int) -> None:
    """Insert a default profile_stats row if one doesn't exist yet."""
    from src.db import is_postgres_enabled
    if is_postgres_enabled():
        conn.execute(
            "INSERT INTO profile_stats (user_id, total_xp, runs_played, "
            "best_score, best_wave, badges_json) VALUES (%s, 0, 0, 0, 0, '[]') ON CONFLICT DO NOTHING",
            (user_id,),
        )
    else:
        conn.execute(
            "INSERT OR IGNORE INTO profile_stats (user_id, total_xp, runs_played, "
            "best_score, best_wave, badges_json) VALUES (?, 0, 0, 0, 0, '[]')",
            (user_id,),
        )


def award_run_local(
    conn: Any,
    user_id: int,
    score: int,
    wave: int,
    difficulty: str,
    mutator_bonus: int = 0,
    mutator_count: int = 0,
) -> dict:
    """Award XP and badges for a completed run, persisting to profile_stats.

    Returns {"xp_earned": int, "new_badges": list[str], "level": int, "total_xp": int}
    """
    _ensure_profile_stats_row(conn, user_id)

    # Fetch current stats
    row = conn.execute(
        sql("SELECT total_xp, runs_played, best_score, best_wave, badges_json "
            "FROM profile_stats WHERE user_id = ?"),
        (user_id,),
    ).fetchone()
    current_xp, runs_played, best_score, best_wave, badges_raw = (
        row["total_xp"], row["runs_played"], row["best_score"], row["best_wave"], row["badges_json"]
    )
    existing_badges: set[str] = set(json.loads(badges_raw))

    # Compute this run's rewards
    xp_earned = xp_for_run(score=score, wave=wave, difficulty=difficulty, mutator_bonus=mutator_bonus)
    run_badges = badges_for_run(wave=wave, difficulty=difficulty, mutator_count=mutator_count)

    new_badges = [b for b in run_badges if b not in existing_badges]
    all_badges = list(existing_badges | set(run_badges))
    all_badges.sort()  # deterministic ordering

    new_total_xp = current_xp + xp_earned
    new_runs = runs_played + 1
    new_best_score = max(best_score, score)
    new_best_wave = max(best_wave, wave)

    conn.execute(
        sql("UPDATE profile_stats SET total_xp = ?, runs_played = ?, best_score = ?, "
            "best_wave = ?, badges_json = ?, updated_at = CURRENT_TIMESTAMP "
            "WHERE user_id = ?"),
        (new_total_xp, new_runs, new_best_score, new_best_wave,
         json.dumps(all_badges), user_id),
    )
    conn.commit()

    return {
        "xp_earned": xp_earned,
        "new_badges": new_badges,
        "level": level_for_xp(new_total_xp),
        "total_xp": new_total_xp,
    }


def get_profile_stats_local(conn: Any, user_id: int) -> dict:
    """Return profile stats dict for user_id, with defaults if no row exists."""
    row = conn.execute(
        sql("SELECT total_xp, runs_played, best_score, best_wave, badges_json "
            "FROM profile_stats WHERE user_id = ?"),
        (user_id,),
    ).fetchone()

    if row is None:
        return {
            "total_xp": 0,
            "runs_played": 0,
            "best_score": 0,
            "best_wave": 0,
            "badges": [],
            "level": 1,
        }

    badges = json.loads(row["badges_json"])
    return {
        "total_xp": row["total_xp"],
        "runs_played": row["runs_played"],
        "best_score": row["best_score"],
        "best_wave": row["best_wave"],
        "badges": badges,
        "level": level_for_xp(row["total_xp"]),
    }
