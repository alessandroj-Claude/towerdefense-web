"""Localization singleton. Pure module — no pygame, no game state."""
from __future__ import annotations

import json
from pathlib import Path

try:
    _LOCALES_DIR = Path(__file__).resolve().parent.parent / "locales"
except (NameError, TypeError):
    _LOCALES_DIR = Path("locales")

_SUPPORTED = ("en", "it")
_locale: str = "en"
_strings: dict = {}
_fallback: dict = {}


def init(locale: str = "en") -> None:
    """Load locale JSON + EN fallback. Call once before Game()."""
    global _locale, _strings, _fallback
    _locale = locale if locale in _SUPPORTED else "en"
    _fallback = _load_json("en")
    _strings = _load_json(_locale) if _locale != "en" else _fallback


def _load_json(locale: str) -> dict:
    path = _LOCALES_DIR / f"{locale}.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _resolve(key: str, source: dict) -> str | None:
    parts = key.split(".")
    val: object = source
    for part in parts:
        if not isinstance(val, dict):
            return None
        val = val.get(part)
        if val is None:
            return None
    return val if isinstance(val, str) else None


def t(key: str, fallback: str = "") -> str:
    """Dot-notation lookup. Falls back to EN, then fallback param, then key."""
    result = _resolve(key, _strings)
    if result is not None:
        return result
    result = _resolve(key, _fallback)
    if result is not None:
        return result
    return fallback if fallback else key


def current_locale() -> str:
    """Return active locale code ('en' or 'it')."""
    return _locale


def set_locale(locale: str) -> None:
    """Change locale at runtime (e.g. from in-game picker)."""
    init(locale)
