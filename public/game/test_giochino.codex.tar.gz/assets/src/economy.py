DIFFICULTY_PRESETS = {
    "easy":   {"gold": 250, "lives": 30, "hp_scale": 1.10, "reward_mult": 1.25, "meteor_enemy_pct": 1.00, "meteor_tower_pct": 0.33},
    "normal": {"gold": 200, "lives": 20, "hp_scale": 1.15, "reward_mult": 1.10, "meteor_enemy_pct": 0.66, "meteor_tower_pct": 0.66},
    "hard":   {"gold": 175, "lives": 10, "hp_scale": 1.20, "reward_mult": 0.90, "meteor_enemy_pct": 0.33, "meteor_tower_pct": 1.00},
}


class Economy:
    def __init__(self, difficulty: str = "normal"):
        if difficulty not in DIFFICULTY_PRESETS:
            raise ValueError(f"Unknown difficulty: {difficulty!r}. Choose from {list(DIFFICULTY_PRESETS)}")
        preset = DIFFICULTY_PRESETS[difficulty]
        self.difficulty = difficulty
        self.gold = preset["gold"]
        self.lives = preset["lives"]
        self.hp_scale = preset["hp_scale"]
        self.reward_mult = preset["reward_mult"]
        self.meteor_enemy_pct = preset["meteor_enemy_pct"]
        self.meteor_tower_pct = preset["meteor_tower_pct"]
        self.score = 0

    def can_afford(self, cost: int) -> bool:
        return self.gold >= cost

    def spend(self, cost: int) -> None:
        if not self.can_afford(cost):
            raise ValueError("Not enough gold")
        self.gold -= cost

    def earn(self, amount: int) -> None:
        # score and gold both scale by difficulty — intentional: hard earns less score
        earned = int(amount * self.reward_mult)
        self.gold += earned
        self.score += earned

    def refund(self, amount: int) -> None:
        if amount < 0:
            raise ValueError("Refund amount must be non-negative")
        self.gold += amount

    def lose_life(self, amount: int = 1) -> None:
        self.lives = max(0, self.lives - amount)

    @property
    def game_over(self) -> bool:
        return self.lives <= 0
