from __future__ import annotations
import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass
import subprocess
from typing import Optional

from src.config import IS_WEB

class ProfileControllerMixin:
    """Profile auth, DLC management, admin panel, clipboard, leaderboard recording."""

    def _get_unlocked_dlcs(self) -> set:
        return set(self.unlocked_dlcs)

    def _set_unlocked_dlcs(self, dlcs: set) -> None:
        self.unlocked_dlcs = set(dlcs)

    def _is_admin(self) -> bool:
        return self.current_username == "admin"

    def _apply_admin_users(
        self,
        users_raw: list,
        keep_selection: bool = False,
        selected_uid: Optional[int] = None,
    ) -> None:
        """Parse admin_list_users response and update admin state fields."""
        self._admin_users_full = list(users_raw)
        self._admin_users = [(int(u["user_id"]), str(u["username"])) for u in users_raw]
        target = selected_uid if keep_selection and selected_uid is not None else None
        if not keep_selection or target is None:
            target = self._admin_users[0][0] if self._admin_users else None
        if target is not None:
            dlcs_raw = next(
                (u["dlcs"] for u in users_raw if int(u["user_id"]) == target), []
            )
            self._admin_selected_user_id = target
            self._admin_selected_user_dlcs = set(dlcs_raw)
        else:
            self._admin_selected_user_id = None
            self._admin_selected_user_dlcs = set()

    def _enter_admin_panel(self) -> None:
        if IS_WEB:
            self._admin_users = []
            self._admin_selected_user_id = None
            self._admin_selected_user_dlcs = set()
            self._admin_notice = "Caricamento..."
            self._admin_delete_rect = pygame.Rect(0, 0, 0, 0)
            self._web_pending = {"action": "admin_enter", "args": ()}
            self.state = "WEB_LOADING"
            return

        from src import game as game_module

        self._admin_users = game_module.list_user_records()
        self._admin_selected_user_id = self.current_user_id if self.current_user_id is not None else None
        if self._admin_selected_user_id is None and self._admin_users:
            self._admin_selected_user_id = self._admin_users[0][0]
        if self._admin_selected_user_id is not None:
            self._admin_selected_user_dlcs = game_module.get_user_dlcs(self._admin_selected_user_id)
        else:
            self._admin_selected_user_dlcs = set()
        self._admin_notice = ""
        self._admin_delete_rect = pygame.Rect(0, 0, 0, 0)
        self.state = "ADMIN_PANEL"

    def _logout_to_profile_identify(self) -> None:
        self.current_user_id = None
        self.current_username = ""
        self.login_username = ""
        self._set_unlocked_dlcs(set())
        self.text_input = ""
        self.text_input2 = ""
        self.profile_error = ""
        self.dlc_error = ""
        self.selected_dlc = ""
        self.state = "PROFILE_IDENTIFY"

    def _read_clipboard_text(self) -> str:
        # First try SDL clipboard API through pygame.
        try:
            if hasattr(pygame, "scrap"):
                if not pygame.scrap.get_init():
                    pygame.scrap.init()
                data = pygame.scrap.get(pygame.SCRAP_TEXT)
                if data:
                    if isinstance(data, bytes):
                        text = data.decode("utf-8", errors="ignore")
                    else:
                        text = str(data)
                    return text.replace("\x00", "")
        except Exception:
            pass

        # macOS fallback for packaged app/runtime differences.
        try:
            out = subprocess.run(
                ["pbpaste"],
                capture_output=True,
                text=True,
                timeout=0.2,
            )
            if out.returncode == 0:
                return out.stdout
        except Exception:
            pass
        return ""

    def _paste_into_key_input(self) -> None:
        raw = self._read_clipboard_text()
        if not raw:
            return
        clean = "".join(ch for ch in raw if ch.isprintable())
        if not clean:
            return
        remaining = max(0, 64 - len(self.text_input))
        if remaining > 0:
            self.text_input += clean[:remaining]

    def _handle_dlc_menu_click(self, pos):
        if IS_WEB:
            return None

        from src import game as game_module

        return game_module.handle_dlc_menu_click(pos, self._dlc_rects)

    def _refresh_game_over_leaderboard(self) -> None:
        from src import game as game_module

        version_filter = self.runtime_version if self._leaderboard_filter == "current" else None
        current_difficulty = getattr(self, "difficulty", "normal")
        global_rows: dict[str, list[dict]] = {}
        user_rows: dict[str, list[dict]] = {}
        for difficulty in ("easy", "normal", "hard"):
            try:
                global_rows[difficulty] = game_module.top5_global(difficulty=difficulty, version=version_filter)
            except Exception:
                global_rows[difficulty] = []
            if self.current_user_id is None:
                user_rows[difficulty] = []
                continue
            try:
                user_rows[difficulty] = game_module.top5_user(
                    self.current_user_id,
                    difficulty=difficulty,
                    version=version_filter,
                )
            except Exception:
                user_rows[difficulty] = []
        self._leaderboard_global_by_difficulty = global_rows
        self._leaderboard_user_by_difficulty = user_rows
        self._leaderboard_global_top = global_rows.get(current_difficulty, [])
        self._leaderboard_user_top = user_rows.get(current_difficulty, [])

    def _record_run_and_load_leaderboards(self) -> None:
        from src import game as game_module

        if not self._run_score_recorded and self.current_user_id is not None:
            game_module.record_score_run(
                self.current_user_id,
                score=self.economy.score,
                wave=self.wave_mgr.wave_number,
                version=self.runtime_version,
                difficulty=getattr(self, "difficulty", "normal"),
            )
        self._run_score_recorded = True
        # Analytics: flush run summary
        try:
            run_summary = {
                "difficulty": getattr(self, "difficulty", "normal"),
                "wave_max": self.wave_mgr.wave_number,
                "final_score": self.economy.score,
            }
            self.analytics_manager.flush_run(run_summary)
            self.analytics_manager.reset()
        except Exception:
            pass
        self._refresh_game_over_leaderboard()
