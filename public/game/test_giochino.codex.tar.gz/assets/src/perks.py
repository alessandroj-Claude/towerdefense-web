from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple


@dataclass(frozen=True)
class Perk:
    id: str
    label: str
    description: str
    modifiers: Mapping[str, float]


PERK_POOL: Tuple[Perk, ...] = (
    Perk(
        id="architect",
        label="Architect",
        description="First upgrade of each tower costs 15% less.",
        modifiers={"first_upgrade_cost_pct": -0.15},
    ),
    Perk(
        id="quartermaster",
        label="Quartermaster",
        description="Start each run with 15% more gold.",
        modifiers={"starting_gold_pct": 0.15},
    ),
    Perk(
        id="fortified_towers",
        label="Fortified Towers",
        description="Tower max HP +20%.",
        modifiers={"tower_max_hp_pct": 0.20},
    ),
    Perk(
        id="precision_optics",
        label="Precision Optics",
        description="Tower range +8%.",
        modifiers={"tower_range_pct": 0.08},
    ),
    Perk(
        id="rapid_calibration",
        label="Rapid Calibration",
        description="Tower fire rate +8%.",
        modifiers={"tower_fire_rate_pct": 0.08},
    ),
    Perk(
        id="emergency_fund",
        label="Emergency Fund",
        description="Gain emergency gold once when lives are critically low.",
        modifiers={"emergency_fund_gold": 80.0},
    ),
    Perk(
        id="bounty_charter",
        label="Bounty Charter",
        description="Gold and score rewards +8%.",
        modifiers={"reward_mult_pct": 0.08},
    ),
    Perk(
        id="repair_crew",
        label="Repair Crew",
        description="Repair costs reduced by 20%.",
        modifiers={"repair_cost_pct": -0.20},
    ),
    Perk(
        id="slow_mastery",
        label="Slow Mastery",
        description="Slow effects last 20% longer.",
        modifiers={"slow_duration_pct": 0.20},
    ),
    Perk(
        id="early_warning",
        label="Early Warning",
        description="Wave event alerts appear 1 second earlier.",
        modifiers={"event_preview_seconds": 1.0},
    ),
)

PERK_BY_ID: Dict[str, Perk] = {perk.id: perk for perk in PERK_POOL}


def choices_allowed_for_difficulty(difficulty: str) -> int:
    mapping = {
        "easy": 3,
        "normal": 2,
        "hard": 1,
    }
    if difficulty not in mapping:
        raise ValueError(f"Unsupported difficulty: {difficulty}")
    return mapping[difficulty]


def generate_perk_offer(rng: Any, count: int = 3) -> List[Perk]:
    if count < 0:
        raise ValueError("count must be >= 0")
    if count > len(PERK_POOL):
        raise ValueError("count cannot exceed perk pool size")
    return list(rng.sample(PERK_POOL, count))


def selected_perk_modifiers(selected_ids: Sequence[str]) -> Dict[str, float]:
    merged: Dict[str, float] = {}
    seen = set()

    for perk_id in selected_ids:
        if perk_id in seen:
            continue
        seen.add(perk_id)

        perk = PERK_BY_ID.get(perk_id)
        if perk is None:
            continue

        for key, value in perk.modifiers.items():
            merged[key] = merged.get(key, 0.0) + float(value)

    return merged


def serialize_perk_state(offered_ids: Iterable[str], selected_ids: Iterable[str]) -> Dict[str, List[str]]:
    return {
        "offered_perk_ids": list(offered_ids),
        "selected_perk_ids": list(selected_ids),
    }


def deserialize_perk_state(state: Mapping[str, Any]) -> Tuple[List[str], List[str]]:
    offered = [str(perk_id) for perk_id in state.get("offered_perk_ids", [])]
    selected = [str(perk_id) for perk_id in state.get("selected_perk_ids", [])]
    return offered, selected
