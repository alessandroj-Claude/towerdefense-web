"""Terrain Evolution Engine (Task L1 — v5.5).

Computes per-wave terrain mutations and applies them to GameMap.
"""
import random
from typing import List, Optional, Tuple


# Cycle: road → mud → high_wind → fortified → road
_TRANSITION: dict[str, str] = {
    "road": "mud",
    "mud": "high_wind",
    "high_wind": "fortified",
    "fortified": "road",
}

# Terrain types that should NOT be mutated
_SKIP_TERRAINS = {"normal"}


class TerrainEvolutionEngine:
    """Manages wave-by-wave terrain evolution on a GameMap.

    Args:
        game_map: A GameMap instance with ``path`` and ``terrain_by_cell`` attributes.
        max_mutations: Maximum number of cells mutated per wave (default 2).
        seed: Optional base seed for reproducible RNG. Each wave derives its
              own seed from ``seed ^ wave_number`` so results are wave-specific
              but reproducible.
    """

    def __init__(self, game_map, max_mutations: int = 2, seed: Optional[int] = None):
        self._game_map = game_map
        self._max_mutations = max_mutations
        self._seed = seed
        self._processed_waves: set[int] = set()
        self._pending_delta: List[Tuple[int, int, str]] = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compute_delta(self, wave_number: int) -> List[Tuple[int, int, str]]:
        """Return list of ``(col, row, new_terrain)`` for the given wave.

        Cells are chosen randomly (reproducible via seed) among path cells that:
        - are not the spawn cell (path[0]) or goal cell (path[-1])
        - have a mutable terrain type (not in ``_SKIP_TERRAINS``)

        If the wave has already been processed, returns an empty list.
        """
        if self.is_wave_processed(wave_number):
            self._pending_delta = []
            return []

        path = self._game_map.path
        if len(path) < 3:
            # Not enough cells to mutate (spawn + at least one inner + goal)
            self._pending_delta = []
            return []

        spawn = tuple(path[0])
        goal = tuple(path[-1])
        terrain = self._game_map.terrain_by_cell

        # Gather candidate cells (inner path cells with mutable terrain)
        candidates: List[Tuple[int, int]] = []
        for cell in path[1:-1]:
            key = (cell[0], cell[1])
            t = terrain.get(key, "road")
            if t not in _SKIP_TERRAINS and t in _TRANSITION:
                candidates.append(key)

        if not candidates:
            self._pending_delta = []
            return []

        # Deterministic RNG per (seed, wave_number)
        rng_seed = (self._seed ^ wave_number) if self._seed is not None else wave_number
        rng = random.Random(rng_seed)

        n = min(self._max_mutations, len(candidates))
        chosen = rng.sample(candidates, k=n)

        delta: List[Tuple[int, int, str]] = []
        for col, row in chosen:
            current = terrain.get((col, row), "road")
            new_terrain = _TRANSITION.get(current, current)
            delta.append((col, row, new_terrain))

        self._pending_delta = delta
        return delta

    def apply_delta(self, delta: List[Tuple[int, int, str]]) -> None:
        """Apply a delta (list of (col, row, new_terrain)) to game_map.terrain_by_cell."""
        for col, row, new_terrain in delta:
            self._game_map.terrain_by_cell[(col, row)] = new_terrain

    def mark_wave_processed(self, wave_number: int) -> None:
        """Mark a wave as already processed (prevents re-applying mutations)."""
        self._processed_waves.add(wave_number)

    def is_wave_processed(self, wave_number: int) -> bool:
        """Return True if this wave has already been processed."""
        return wave_number in self._processed_waves

    def get_pending_delta(self) -> List[Tuple[int, int, str]]:
        """Return the pre-computed delta from the last compute_delta call."""
        return list(self._pending_delta)
