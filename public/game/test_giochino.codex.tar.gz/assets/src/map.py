import random
from typing import Any, Dict, List, Optional, Set, Tuple

Cell = Tuple[int, int]

TERRAIN_ROAD = "road"
TERRAIN_MUD = "mud"
TERRAIN_WIND = "wind"
TERRAIN_HIGH_WIND = "high_wind"
TERRAIN_FORTIFIED = "fortified"

# Conquest mode terrain types
TERRAIN_SAND = "sand"
TERRAIN_ROCK = "rock"
TERRAIN_ICE = "ice"
TERRAIN_SNOW = "snow"
TERRAIN_TREE = "tree"
TERRAIN_GRASS = "grass"

# Conquest terrain config: maps terrain name → (allowed_types, forbidden_types, palette_name)
TERRAIN_MAP_CONFIG = {
    "desert": {
        "allowed": [TERRAIN_SAND, TERRAIN_ROCK, TERRAIN_WIND, TERRAIN_HIGH_WIND],
        "forbidden": [TERRAIN_MUD, TERRAIN_ICE],
        "palette": "desert"
    },
    "forest": {
        "allowed": [TERRAIN_WIND, TERRAIN_FORTIFIED, TERRAIN_ROAD, TERRAIN_MUD],
        "forbidden": [TERRAIN_SAND],
        "palette": "forest"
    },
    "swamp": {
        "allowed": [TERRAIN_MUD, TERRAIN_WIND, TERRAIN_ROAD],
        "forbidden": [TERRAIN_SAND, TERRAIN_ICE],
        "palette": "swamp"
    },
    "mountain": {
        "allowed": [TERRAIN_ROCK, TERRAIN_SNOW, TERRAIN_FORTIFIED, TERRAIN_WIND],
        "forbidden": [TERRAIN_MUD],
        "palette": "mountain"
    },
    "tundra": {
        "allowed": [TERRAIN_ICE, TERRAIN_SNOW, TERRAIN_WIND, TERRAIN_HIGH_WIND],
        "forbidden": [TERRAIN_SAND, TERRAIN_MUD],
        "palette": "tundra"
    },
    "plains": {
        "allowed": [TERRAIN_ROAD, TERRAIN_WIND, TERRAIN_MUD, TERRAIN_FORTIFIED],
        "forbidden": [],
        "palette": "plains"
    },
}

PATH_MIN_VERTICAL_RATIO = 0.22
PATH_MIN_ROW_CHANGES = 5
PATH_MAX_HORIZONTAL_STREAK = 6

_MAX_GENERATION_ATTEMPTS = 300
_TERRAIN_WEIGHTS = (
    (TERRAIN_ROAD, 0.58),
    (TERRAIN_MUD, 0.20),
    (TERRAIN_WIND, 0.08),
    (TERRAIN_HIGH_WIND, 0.08),
    (TERRAIN_FORTIFIED, 0.06),
)
_BLOCKED_DENSITY = 0.09
_BLOCKED_MIN = 6
_BLOCKED_MAX = 36

class GameMap:
    def __init__(
        self,
        cols: int = 16,
        rows: int = 12,
        tile_size: int = 56,
        rng: Optional[random.Random] = None,
        conquest_terrain: Optional[Any] = None,
    ):
        self.cols = cols
        self.rows = rows
        self.tile_size = tile_size
        self._rng: Any = rng if rng is not None else random
        self.path: List[Cell] = []
        self.terrain_by_cell: Dict[Cell, str] = {}
        self.blocked_cells: Set[Cell] = set()
        self.buildable: Set[Cell] = set()

        # Conquest mode setup
        self.conquest_terrain = conquest_terrain
        self.conquest_palette: Optional[str] = None
        self._conquest_allowed: Optional[List[str]] = None
        self._conquest_forbidden: List[str] = []

        if conquest_terrain is not None:
            # Get terrain key from enum or string
            terrain_key = (
                conquest_terrain.value
                if hasattr(conquest_terrain, "value")
                else str(conquest_terrain)
            )
            config = TERRAIN_MAP_CONFIG.get(terrain_key, {})
            self.conquest_palette = config.get("palette")
            self._conquest_allowed = config.get("allowed")
            self._conquest_forbidden = config.get("forbidden", [])

        self._generate()

    def _generate(self) -> None:
        for _ in range(_MAX_GENERATION_ATTEMPTS):
            path = self._random_walk()
            if path:
                self.path = path
                self._path_set = set(self.path)
                all_cells = {(c, r) for c in range(self.cols) for r in range(self.rows)}
                self.terrain_by_cell = self._assign_terrain(self.path)
                self.blocked_cells = self._generate_blocked_cells(all_cells - self._path_set)
                self.buildable = all_cells - self._path_set - self.blocked_cells
                return
        raise RuntimeError("Failed to generate a valid map with v4.1 constraints")

    def _random_walk(self) -> List[Cell]:
        row = self._rng.randint(1, self.rows - 2)
        path: List[Cell] = [(0, row)]
        visited: Set[Cell] = {(0, row)}
        vertical_moves = 0
        row_changes = 0
        horizontal_streak = 0

        while path[-1][0] < self.cols - 1:
            col, row = path[-1]
            weighted: List[Cell] = []
            east_weight = 3
            if horizontal_streak >= PATH_MAX_HORIZONTAL_STREAK - 1:
                east_weight = 0
            elif horizontal_streak >= PATH_MAX_HORIZONTAL_STREAK - 2:
                east_weight = 1
            if east_weight > 0:
                weighted.extend([(col + 1, row)] * east_weight)

            vertical_need = vertical_moves / max(1, len(path) - 1) < PATH_MIN_VERTICAL_RATIO
            vertical_weight = 3 if vertical_need else 2
            if row > 0:
                weighted.extend([(col, row - 1)] * vertical_weight)
            if row < self.rows - 1:
                weighted.extend([(col, row + 1)] * vertical_weight)
            self._rng.shuffle(weighted)
            moved = False
            for nc, nr in weighted:
                if (nc, nr) not in visited and 0 <= nr < self.rows:
                    path.append((nc, nr))
                    visited.add((nc, nr))
                    if nr != row:
                        vertical_moves += 1
                        row_changes += 1
                        horizontal_streak = 0
                    else:
                        horizontal_streak += 1
                    moved = True
                    break

            if not moved:
                return []  # dead end — retry

        if not self._path_meets_shape_constraints(path):
            return []
        return path

    def _path_meets_shape_constraints(self, path: List[Cell]) -> bool:
        vertical_moves = 0
        row_changes = 0
        horizontal_streak = 0
        max_horizontal_streak = 0
        for (c1, r1), (c2, r2) in zip(path, path[1:]):
            _ = c1, c2
            if r1 != r2:
                vertical_moves += 1
                row_changes += 1
                horizontal_streak = 0
            else:
                horizontal_streak += 1
                max_horizontal_streak = max(max_horizontal_streak, horizontal_streak)
        total_steps = max(1, len(path) - 1)
        vertical_ratio = vertical_moves / total_steps
        return (
            vertical_ratio >= PATH_MIN_VERTICAL_RATIO
            and row_changes >= PATH_MIN_ROW_CHANGES
            and max_horizontal_streak <= PATH_MAX_HORIZONTAL_STREAK
        )

    def _assign_terrain(self, path: List[Cell]) -> Dict[Cell, str]:
        terrain_by_cell: Dict[Cell, str] = {}

        if self._conquest_allowed is not None:
            # Filter _TERRAIN_WEIGHTS to only allowed types
            filtered = [
                (t, w) for t, w in _TERRAIN_WEIGHTS if t in self._conquest_allowed
            ]
            if not filtered:
                # Fallback to all weights if none match (shouldn't happen)
                filtered = list(_TERRAIN_WEIGHTS)
            kinds, weights = zip(*filtered)
        else:
            kinds, weights = zip(*_TERRAIN_WEIGHTS)

        for cell in path:
            terrain_by_cell[cell] = self._rng.choices(kinds, weights=list(weights), k=1)[0]

        return terrain_by_cell

    def _generate_blocked_cells(self, non_path_cells: Set[Cell]) -> Set[Cell]:
        if not non_path_cells:
            return set()
        candidates = list(non_path_cells)
        target = int(len(candidates) * _BLOCKED_DENSITY)
        target = max(_BLOCKED_MIN, target)
        target = min(_BLOCKED_MAX, target)
        target = min(target, len(candidates))
        return set(self._rng.sample(candidates, k=target))

    def is_path(self, col: int, row: int) -> bool:
        return (col, row) in self._path_set

    def is_buildable(self, col: int, row: int) -> bool:
        return (col, row) in self.buildable

    def pixel_center(self, col: int, row: int) -> Tuple[int, int]:
        return (col * self.tile_size + self.tile_size // 2,
                row * self.tile_size + self.tile_size // 2)
