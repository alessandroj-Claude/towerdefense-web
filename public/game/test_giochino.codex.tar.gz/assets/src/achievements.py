from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Any

@dataclass(frozen=True)
class Achievement:
    id: str
    name: str
    description: str
    icon: str
    hidden: bool = False

ACHIEVEMENTS: list[Achievement] = [
    Achievement("first_blood",      "First Blood",       "Completa la tua prima wave", "⚔️"),
    Achievement("survivor_10",      "Survivor",          "Raggiungi wave 10", "🛡️"),
    Achievement("survivor_25",      "Veteran",           "Raggiungi wave 25", "🏅"),
    Achievement("survivor_50",      "Elite",             "Raggiungi wave 50", "🏆"),
    Achievement("endless_start",    "Into the Void",     "Completa una run Endless", "∞"),
    Achievement("endless_wave_20",  "Endless Runner",    "Sopravvivi a wave 20 in Endless", "🌀"),
    Achievement("endless_wave_50",  "Infinity Walker",   "Sopravvivi a wave 50 in Endless", "💫"),
    Achievement("score_10k",        "High Scorer",       "Raggiungi score 10.000", "💰"),
    Achievement("score_50k",        "Score Master",      "Raggiungi score 50.000", "💎"),
    Achievement("no_lives_lost",    "Flawless",          "Vinci una wave senza perdere vite", "✨"),
    Achievement("full_lives_win",   "Perfect Run",       "Completa run con vite al massimo", "👑"),
    Achievement("hard_mode",        "Hardcore",          "Completa una run in Hard", "🔥"),
    Achievement("synergy_active",   "Synergist",         "Attiva una synergy tra torri", "🔗"),
    Achievement("all_synergies",    "Grand Synergist",   "Attiva tutte e 7 le synergy in una run", "🌟"),
    Achievement("sell_tower",       "Trader",            "Vendi una torre", "💱"),
    Achievement("max_upgrade",      "Maxed Out",         "Porta una torre al livello massimo", "⬆️"),
    Achievement("boss_kill",        "Boss Slayer",       "Sconfiggi un boss", "🗡️"),
    Achievement("boss_no_lives_lost","Untouchable",      "Sconfiggi un boss senza perdere vite in quella wave", "🛡"),
    Achievement("daily_complete",   "Daily Grind",       "Completa una Daily Challenge", "📅"),
    Achievement("weekly_complete",  "Weekly Warrior",    "Completa una Weekly Challenge", "📆"),
    Achievement("repair_tower",     "Field Engineer",    "Ripara una torre", "🔧"),
    Achievement("use_powerup",      "Power User",        "Usa un powerup", "⚡"),
    Achievement("place_10_towers",  "Builder",           "Piazza 10 torri in una run", "🏗️"),
    Achievement("mutator_run",      "Mutator",           "Completa una run con almeno un mutator attivo", "🎲"),
    Achievement("comeback",         "Comeback Kid",      "Vinci una wave con una sola vita rimasta", "❤️"),
]

_ACHIEVEMENT_BY_ID: dict[str, Achievement] = {a.id: a for a in ACHIEVEMENTS}

def get_achievement(id: str) -> Optional[Achievement]:
    return _ACHIEVEMENT_BY_ID.get(id)

def check_run_achievements(run_stats: dict) -> list[str]:
    """Pure: no DB. Returns list of achievement_ids earned by this run_stats."""
    ids = []
    wave = run_stats.get("wave", 0)
    score = run_stats.get("score", 0)
    difficulty = run_stats.get("difficulty", "")
    lives_remaining = run_stats.get("lives_remaining", 0)
    max_lives = run_stats.get("max_lives", 0)
    lives_lost_this_wave = run_stats.get("lives_lost_this_wave", 0)
    boss_killed = run_stats.get("boss_killed", False)
    boss_wave_lives_lost = run_stats.get("boss_wave_lives_lost", False)
    synergy_ids_activated = run_stats.get("synergy_ids_activated", set())
    towers_placed = run_stats.get("towers_placed", 0)
    towers_sold = run_stats.get("towers_sold", 0)
    max_tower_level = run_stats.get("max_tower_level", 0)
    powerup_used = run_stats.get("powerup_used", False)
    tower_repaired = run_stats.get("tower_repaired", False)
    mutators_active = run_stats.get("mutators_active", 0)
    challenge_kind = run_stats.get("challenge_kind", "")
    endless = run_stats.get("endless", False)

    if wave >= 1:
        ids.append("first_blood")
    if wave >= 10:
        ids.append("survivor_10")
    if wave >= 25:
        ids.append("survivor_25")
    if wave >= 50:
        ids.append("survivor_50")
    if endless and wave >= 1:
        ids.append("endless_start")
    if endless and wave >= 20:
        ids.append("endless_wave_20")
    if endless and wave >= 50:
        ids.append("endless_wave_50")
    if score >= 10000:
        ids.append("score_10k")
    if score >= 50000:
        ids.append("score_50k")
    if wave >= 1 and lives_lost_this_wave == 0:
        ids.append("no_lives_lost")
    if wave >= 1 and lives_remaining >= max_lives > 0:
        ids.append("full_lives_win")
    if difficulty == "hard" and wave >= 1:
        ids.append("hard_mode")
    if len(synergy_ids_activated) >= 1:
        ids.append("synergy_active")
    if len(synergy_ids_activated) >= 7:
        ids.append("all_synergies")
    if towers_sold >= 1:
        ids.append("sell_tower")
    if max_tower_level >= 3:
        ids.append("max_upgrade")
    if boss_killed:
        ids.append("boss_kill")
    if boss_killed and not boss_wave_lives_lost:
        ids.append("boss_no_lives_lost")
    if challenge_kind == "daily":
        ids.append("daily_complete")
    if challenge_kind == "weekly":
        ids.append("weekly_complete")
    if tower_repaired:
        ids.append("repair_tower")
    if powerup_used:
        ids.append("use_powerup")
    if towers_placed >= 10:
        ids.append("place_10_towers")
    if mutators_active >= 1 and wave >= 1:
        ids.append("mutator_run")
    if lives_remaining == 1 and wave >= 1:
        ids.append("comeback")

    return ids


# Trigger → achievement IDs mapping for in-game toast checks
_TRIGGER_CHECKS: dict[str, list[str]] = {
    "wave_complete": [
        "first_blood", "survivor_10", "survivor_25", "survivor_50",
        "endless_start", "endless_wave_20", "endless_wave_50",
        "no_lives_lost", "full_lives_win", "hard_mode", "comeback"
    ],
    "boss_kill": ["boss_kill", "boss_no_lives_lost"],
    "tower_placed": ["place_10_towers"],
    "tower_sold": ["sell_tower"],
    "tower_maxed": ["max_upgrade"],
    "synergy_active": ["synergy_active", "all_synergies"],
    "powerup_used": ["use_powerup"],
    "tower_repaired": ["repair_tower"],
    "score_updated": ["score_10k", "score_50k"],
}


def check_partial_achievements(run_stats: dict, trigger: str) -> list[str]:
    """Pure: checks only achievements relevant to trigger event. Returns matching IDs."""
    # Get achievement IDs to check for this trigger
    to_check = _TRIGGER_CHECKS.get(trigger, [])
    if not to_check:
        return []

    # Extract run_stats once
    wave = run_stats.get("wave", 0)
    score = run_stats.get("score", 0)
    difficulty = run_stats.get("difficulty", "")
    lives_remaining = run_stats.get("lives_remaining", 0)
    max_lives = run_stats.get("max_lives", 0)
    lives_lost_this_wave = run_stats.get("lives_lost_this_wave", 0)
    boss_killed = run_stats.get("boss_killed", False)
    boss_wave_lives_lost = run_stats.get("boss_wave_lives_lost", False)
    synergy_ids_activated = run_stats.get("synergy_ids_activated", set())
    towers_placed = run_stats.get("towers_placed", 0)
    towers_sold = run_stats.get("towers_sold", 0)
    max_tower_level = run_stats.get("max_tower_level", 0)
    powerup_used = run_stats.get("powerup_used", False)
    tower_repaired = run_stats.get("tower_repaired", False)
    mutators_active = run_stats.get("mutators_active", 0)
    challenge_kind = run_stats.get("challenge_kind", "")
    endless = run_stats.get("endless", False)

    ids = []

    # Check only the IDs relevant to this trigger
    for ach_id in to_check:
        if ach_id == "first_blood" and wave >= 1:
            ids.append(ach_id)
        elif ach_id == "survivor_10" and wave >= 10:
            ids.append(ach_id)
        elif ach_id == "survivor_25" and wave >= 25:
            ids.append(ach_id)
        elif ach_id == "survivor_50" and wave >= 50:
            ids.append(ach_id)
        elif ach_id == "endless_start" and endless and wave >= 1:
            ids.append(ach_id)
        elif ach_id == "endless_wave_20" and endless and wave >= 20:
            ids.append(ach_id)
        elif ach_id == "endless_wave_50" and endless and wave >= 50:
            ids.append(ach_id)
        elif ach_id == "score_10k" and score >= 10000:
            ids.append(ach_id)
        elif ach_id == "score_50k" and score >= 50000:
            ids.append(ach_id)
        elif ach_id == "no_lives_lost" and wave >= 1 and lives_lost_this_wave == 0:
            ids.append(ach_id)
        elif ach_id == "full_lives_win" and wave >= 1 and lives_remaining >= max_lives > 0:
            ids.append(ach_id)
        elif ach_id == "hard_mode" and difficulty == "hard" and wave >= 1:
            ids.append(ach_id)
        elif ach_id == "synergy_active" and len(synergy_ids_activated) >= 1:
            ids.append(ach_id)
        elif ach_id == "all_synergies" and len(synergy_ids_activated) >= 7:
            ids.append(ach_id)
        elif ach_id == "sell_tower" and towers_sold >= 1:
            ids.append(ach_id)
        elif ach_id == "max_upgrade" and max_tower_level >= 3:
            ids.append(ach_id)
        elif ach_id == "boss_kill" and boss_killed:
            ids.append(ach_id)
        elif ach_id == "boss_no_lives_lost" and boss_killed and not boss_wave_lives_lost:
            ids.append(ach_id)
        elif ach_id == "daily_complete" and challenge_kind == "daily":
            ids.append(ach_id)
        elif ach_id == "weekly_complete" and challenge_kind == "weekly":
            ids.append(ach_id)
        elif ach_id == "repair_tower" and tower_repaired:
            ids.append(ach_id)
        elif ach_id == "use_powerup" and powerup_used:
            ids.append(ach_id)
        elif ach_id == "place_10_towers" and towers_placed >= 10:
            ids.append(ach_id)
        elif ach_id == "mutator_run" and mutators_active >= 1 and wave >= 1:
            ids.append(ach_id)
        elif ach_id == "comeback" and lives_remaining == 1 and wave >= 1:
            ids.append(ach_id)

    return ids


def unlock_achievements(user_id: int, ids: list[str], conn: Optional[Any] = None) -> list[str]:
    """Persist new achievements. Returns only newly unlocked (skips already unlocked)."""
    from src.db import get_connection, sql, is_postgres_enabled
    owns_conn = conn is None
    conn = conn or get_connection()
    try:
        already = get_unlocked(user_id, conn)
        already_set = set(already)
        newly = [aid for aid in ids if aid in _ACHIEVEMENT_BY_ID and aid not in already_set]
        for aid in newly:
            if is_postgres_enabled():
                conn.execute(
                    "INSERT INTO user_achievements (user_id, achievement_id) VALUES (%s, %s) ON CONFLICT DO NOTHING",
                    (int(user_id), aid),
                )
            else:
                conn.execute(
                    "INSERT OR IGNORE INTO user_achievements (user_id, achievement_id) VALUES (?, ?)",
                    (int(user_id), aid),
                )
        conn.commit()
        return newly
    finally:
        if owns_conn:
            conn.close()


def get_unlocked(user_id: int, conn: Optional[Any] = None) -> list[str]:
    """Returns list of achievement_ids already unlocked by user_id."""
    from src.db import get_connection, sql
    owns_conn = conn is None
    conn = conn or get_connection()
    try:
        rows = conn.execute(
            sql("SELECT achievement_id FROM user_achievements WHERE user_id = ?"),
            (int(user_id),),
        ).fetchall()
        return [row["achievement_id"] for row in rows]
    finally:
        if owns_conn:
            conn.close()
