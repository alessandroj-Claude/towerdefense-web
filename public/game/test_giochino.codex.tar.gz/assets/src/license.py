import base64
import hashlib
import hmac
import json
import sqlite3
import time
from typing import Optional, Any
from src.db import get_connection, insert_license_ignore, sql
from src.shares import SHARE_1, SHARE_2

_P = 2**127 - 1

AVAILABLE_DLCS: dict[str, str] = {
    "storm_pack": "Storm Pack",
    "inferno_pack": "Inferno Pack",
}

DLC_PRICES: dict[str, int] = {dlc_id: 50 for dlc_id in AVAILABLE_DLCS}


def _reconstruct(s1: tuple, s2: tuple) -> int:
    x1, y1 = s1
    x2, y2 = s2
    l1 = y1 * pow(x1 - x2, _P - 2, _P) % _P * (-x2 % _P) % _P
    l2 = y2 * pow(x2 - x1, _P - 2, _P) % _P * (-x1 % _P) % _P
    return (l1 + l2) % _P


_SECRET: Optional[bytes] = None


def _get_secret() -> bytes:
    global _SECRET
    if _SECRET is None:
        _SECRET = _reconstruct(SHARE_1, SHARE_2).to_bytes(16, 'big')
    return _SECRET


def generate_dlc_key(dlc_id: str, _secret: Optional[bytes] = None) -> str:
    if dlc_id not in AVAILABLE_DLCS:
        raise ValueError(f"Unsupported DLC id: {dlc_id!r}")
    s = _secret if _secret is not None else _get_secret()
    return hmac.new(s, dlc_id.encode(), hashlib.sha256).hexdigest()[:32]


def validate_key(dlc_id: str, key: str,
                 _secret: Optional[bytes] = None) -> bool:
    if dlc_id not in AVAILABLE_DLCS:
        return False
    expected = generate_dlc_key(dlc_id, _secret)
    return hmac.compare_digest(key, expected)


def activate_dlc(user_id: int, dlc_id: str, key: str,
                 _conn: Optional[Any] = None,
                 _secret: Optional[bytes] = None) -> bool:
    if not validate_key(dlc_id, key, _secret):
        return False
    conn = _conn or get_connection()
    try:
        insert_license_ignore(conn, user_id, dlc_id)
        row = conn.execute(
            sql("SELECT dlcs FROM users WHERE id = ?"),
            (user_id,),
        ).fetchone()
        if row is not None:
            dlcs_raw = row["dlcs"] if isinstance(row, dict) else row[0]
            current = set(d for d in (dlcs_raw or "").split(",") if d)
            current.add(dlc_id)
            conn.execute(
                sql("UPDATE users SET dlcs = ? WHERE id = ?"),
                (",".join(sorted(current)), user_id),
            )
        conn.commit()
        return True
    except Exception:
        return False


def is_dlc_unlocked(user_id: int, dlc_id: str,
                    _conn: Optional[Any] = None) -> bool:
    conn = _conn or get_connection()
    return conn.execute(
        sql("SELECT 1 FROM licenses WHERE user_id = ? AND dlc_id = ?"),
        (user_id, dlc_id)
    ).fetchone() is not None


def get_user_dlcs(user_id: int,
                  _conn: Optional[Any] = None) -> set[str]:
    conn = _conn or get_connection()
    return {r[0] for r in conn.execute(
        sql("SELECT dlc_id FROM licenses WHERE user_id = ?"), (user_id,)
    ).fetchall()}


def set_dlc_state(user_id: int, dlc_id: str, unlocked: bool,
                  _conn: Optional[Any] = None) -> bool:
    if dlc_id not in AVAILABLE_DLCS:
        return False
    conn = _conn or get_connection()
    try:
        if unlocked:
            insert_license_ignore(conn, user_id, dlc_id)
        else:
            conn.execute(
                sql("DELETE FROM licenses WHERE user_id = ? AND dlc_id = ?"),
                (user_id, dlc_id)
            )
        conn.commit()
        return True
    except Exception:
        return False


def generate_key(username: str, key_type: str, payload: str) -> str:
    s = _get_secret()
    nonce = int(time.time() * 1000)
    data = {"u": username, "t": key_type, "p": payload, "n": nonce}
    payload_json = json.dumps(data, separators=(",", ":"))
    payload_b64 = base64.urlsafe_b64encode(payload_json.encode()).decode().rstrip("=")
    sig = hmac.new(s, payload_b64.encode(), hashlib.sha256).hexdigest()[:16]
    return f"{payload_b64}.{sig}"


def parse_key(key: str, _secret: Optional[bytes] = None) -> Optional[dict]:
    if not key or key.count(".") != 1:
        return None
    payload_b64, sig = key.rsplit(".", 1)
    s = _secret if _secret is not None else _get_secret()
    expected_sig = hmac.new(s, payload_b64.encode(), hashlib.sha256).hexdigest()[:16]
    if not hmac.compare_digest(sig, expected_sig):
        return None
    try:
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        data = json.loads(base64.urlsafe_b64decode(payload_b64).decode())
        if not all(k in data for k in ("u", "t", "p", "n")):
            return None
        if data["t"] not in ("dlc", "credits"):
            return None
        return data
    except Exception:
        return None
