import hmac
import hashlib
import sqlite3
from typing import Optional
from src.db import get_connection
from src.shares import SHARE_1, SHARE_2

_P = 2**127 - 1

AVAILABLE_DLCS: dict[str, str] = {
    "storm_pack": "Storm Pack",
    "inferno_pack": "Inferno Pack",
}


def _reconstruct(s1: tuple, s2: tuple) -> int:
    x1, y1 = s1
    x2, y2 = s2
    l1 = y1 * pow(x1 - x2, _P - 2, _P) % _P * (-x2 % _P) % _P
    l2 = y2 * pow(x2 - x1, _P - 2, _P) % _P * (-x1 % _P) % _P
    return (l1 + l2) % _P


_SECRET: Optional[bytes] = None


def _get_secret() -> bytes:
    global _SECRET
    if _SECRET is None:
        _SECRET = _reconstruct(SHARE_1, SHARE_2).to_bytes(16, 'big')
    return _SECRET


def generate_dlc_key(dlc_id: str, _secret: Optional[bytes] = None) -> str:
    if dlc_id not in AVAILABLE_DLCS:
        raise ValueError(f"Unsupported DLC id: {dlc_id!r}")
    s = _secret if _secret is not None else _get_secret()
    return hmac.new(s, dlc_id.encode(), hashlib.sha256).hexdigest()[:32]


def validate_key(dlc_id: str, key: str,
                 _secret: Optional[bytes] = None) -> bool:
    if dlc_id not in AVAILABLE_DLCS:
        return False
    expected = generate_dlc_key(dlc_id, _secret)
    return hmac.compare_digest(key, expected)


def activate_dlc(user_id: int, dlc_id: str, key: str,
                 _conn: Optional[sqlite3.Connection] = None,
                 _secret: Optional[bytes] = None) -> bool:
    if not validate_key(dlc_id, key, _secret):
        return False
    conn = _conn or get_connection()
    try:
        conn.execute(
            "INSERT OR IGNORE INTO licenses (user_id, dlc_id) VALUES (?, ?)",
            (user_id, dlc_id)
        )
        conn.commit()
        return True
    except sqlite3.Error:
        return False


def is_dlc_unlocked(user_id: int, dlc_id: str,
                    _conn: Optional[sqlite3.Connection] = None) -> bool:
    conn = _conn or get_connection()
    return conn.execute(
        "SELECT 1 FROM licenses WHERE user_id = ? AND dlc_id = ?",
        (user_id, dlc_id)
    ).fetchone() is not None


def get_user_dlcs(user_id: int,
                  _conn: Optional[sqlite3.Connection] = None) -> set[str]:
    conn = _conn or get_connection()
    return {r[0] for r in conn.execute(
        "SELECT dlc_id FROM licenses WHERE user_id = ?", (user_id,)
    ).fetchall()}


def set_dlc_state(user_id: int, dlc_id: str, unlocked: bool,
                  _conn: Optional[sqlite3.Connection] = None) -> bool:
    if dlc_id not in AVAILABLE_DLCS:
        return False
    conn = _conn or get_connection()
    try:
        if unlocked:
            conn.execute(
                "INSERT OR IGNORE INTO licenses (user_id, dlc_id) VALUES (?, ?)",
                (user_id, dlc_id)
            )
        else:
            conn.execute(
                "DELETE FROM licenses WHERE user_id = ? AND dlc_id = ?",
                (user_id, dlc_id)
            )
        conn.commit()
        return True
    except sqlite3.Error:
        return False
