"""src/renderer package — public API for all rendering."""
import sys as _sys
import types as _types

from src import theme
from src.renderer.map import draw_map, _draw_path_direction_arrows
from src.renderer.entities import (
    draw_towers,
    draw_enemies,
    draw_projectiles,
    draw_meteors,
    draw_enemy_projectiles,
    get_enemy_render_color,
    TOWER_COLORS,
    ENEMY_COLORS,
)
from src.renderer.hud import draw_hud, draw_pause_overlay, draw_floating_text
from src.renderer.menus import (
    _get_difficulty_title_font,
    draw_difficulty_screen,
    draw_perk_selection_screen,
    render_profile_identify,
    render_profile_select,
    render_profile_create,
    render_profile_login,
    render_dlc_menu,
    render_key_input,
    render_admin_panel,
    draw_game_over_leaderboards,
    draw_wave_report,
    draw_analytics_screen,
    draw_adaptive_rationale,
)
from src.renderer.effects import (
    compute_screen_shake_offset,
    draw_damage_floats,
    draw_placement_ghost,
    draw_terrain_tooltip,
    draw_powerup_tooltip,
    draw_range_preview,
    draw_terrain_preview,
)

COLORS = {
    "grass": theme.TERRAIN_GRASS,
    "path": theme.PATH_SANDY,
    "road": theme.ROAD,
    "mud": (107, 72, 37),
    "wind": theme.WIND,
    "high_wind": theme.HIGH_WIND,
    "fortified": theme.FORTIFIED,
    "path_tube_border": theme.PATH_TUBE_BORDER,
    "path_arrow": theme.PATH_ARROW,
    "blocked": theme.BLOCKED,
    "blocked_accent": theme.BLOCKED_ACCENT,
    "basic_tower": TOWER_COLORS["BasicTower"],
    "ice_tower": TOWER_COLORS["IceTower"],
    "bomb_tower": TOWER_COLORS["BombTower"],
    "sniper_tower": TOWER_COLORS["SniperTower"],
    "anti_air_tower": TOWER_COLORS["AntiAirTower"],
    "storm_tower": TOWER_COLORS["StormTower"],
    "inferno_tower": TOWER_COLORS["InfernoTower"],
    "basic_enemy": ENEMY_COLORS["BasicEnemy"],
    "fast_enemy": ENEMY_COLORS["FastEnemy"],
    "tank_enemy": ENEMY_COLORS["TankEnemy"],
    "swarm_enemy": ENEMY_COLORS["SwarmEnemy"],
    "projectile": theme.PROJECTILE,
    "hp_bg": theme.HP_BAR_BG,
    "hp_fg": (0, 220, 0),
    "ui_bg": theme.PANEL_BG,
    "gold": theme.GOLD_COLOR,
    "text": theme.TEXT_PRIMARY,
    "selected": theme.SELECTION_HIGHLIGHT,
}

__all__ = [
    "COLORS",
    "TOWER_COLORS",
    "ENEMY_COLORS",
    "_draw_path_direction_arrows",
    "_get_difficulty_title_font",
    "draw_map",
    "draw_towers", "draw_enemies", "draw_projectiles",
    "draw_meteors", "draw_enemy_projectiles", "get_enemy_render_color",
    "draw_hud", "draw_pause_overlay", "draw_floating_text",
    "compute_screen_shake_offset", "draw_damage_floats",
    "draw_placement_ghost", "draw_terrain_tooltip", "draw_powerup_tooltip",
    "draw_range_preview", "draw_terrain_preview",
    "draw_difficulty_screen", "draw_perk_selection_screen",
    "render_profile_identify", "render_profile_select",
    "render_profile_create", "render_profile_login",
    "render_dlc_menu", "render_key_input", "render_admin_panel",
    "draw_game_over_leaderboards", "draw_wave_report",
    "draw_analytics_screen", "draw_adaptive_rationale",
]


class _RendererModule(_types.ModuleType):
    """Proxy setattr so monkeypatch reaches function-defining submodules."""

    _SUBMODULE_MAP = {
        "_draw_path_direction_arrows": "src.renderer.map",
        "_get_difficulty_title_font": "src.renderer.menus",
        "draw_towers": "src.renderer.entities",
        "draw_enemies": "src.renderer.entities",
        "draw_projectiles": "src.renderer.entities",
        "draw_meteors": "src.renderer.entities",
        "draw_enemy_projectiles": "src.renderer.entities",
        "draw_hud": "src.renderer.hud",
        "draw_pause_overlay": "src.renderer.hud",
        "draw_floating_text": "src.renderer.hud",
        "draw_difficulty_screen": "src.renderer.menus",
        "draw_perk_selection_screen": "src.renderer.menus",
        "render_profile_identify": "src.renderer.menus",
        "render_profile_select": "src.renderer.menus",
        "render_profile_create": "src.renderer.menus",
        "render_profile_login": "src.renderer.menus",
        "render_dlc_menu": "src.renderer.menus",
        "render_key_input": "src.renderer.menus",
        "render_admin_panel": "src.renderer.menus",
        "draw_game_over_leaderboards": "src.renderer.menus",
        "draw_wave_report": "src.renderer.menus",
        "draw_analytics_screen": "src.renderer.menus",
        "draw_adaptive_rationale": "src.renderer.menus",
        "compute_screen_shake_offset": "src.renderer.effects",
        "draw_damage_floats": "src.renderer.effects",
        "draw_placement_ghost": "src.renderer.effects",
        "draw_terrain_tooltip": "src.renderer.effects",
        "draw_powerup_tooltip": "src.renderer.effects",
        "draw_range_preview": "src.renderer.effects",
        "draw_terrain_preview": "src.renderer.effects",
    }

    def __setattr__(self, name: str, value) -> None:
        submod_path = self._SUBMODULE_MAP.get(name)
        if submod_path:
            submod = _sys.modules.get(submod_path)
            if submod is not None:
                setattr(submod, name, value)
        super().__setattr__(name, value)


_current = _sys.modules[__name__]
_proxy = _RendererModule(__name__, __doc__)
_proxy.__dict__.update(_current.__dict__)
_sys.modules[__name__] = _proxy
