from __future__ import annotations
"""Renderer submodule: towers, enemies, projectiles."""
import math
import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass
from typing import Optional
from src import theme
from src.renderer._fonts import fonts

TOWER_COLORS = {
    "BasicTower":   (70, 130, 180),
    "IceTower":     (100, 200, 255),
    "BombTower":    (200, 80, 40),
    "SniperTower":  (180, 60, 180),
    "AntiAirTower": (110, 210, 255),
    "StormTower":   (80, 200, 220),
    "InfernoTower": (255, 110, 40),
    "MedicTower":   (90, 170, 100),
    "SentinelTower": (160, 140, 90),
}

ENEMY_COLORS = {
    "BasicEnemy":  (220, 50, 50),
    "FastEnemy":   (255, 165, 0),
    "TankEnemy":   (100, 100, 200),
    "SwarmEnemy":  theme.ENEMY_SWARM,
    "FlyingEnemy": theme.ENEMY_FLYING_RENDER,
    "HeavyEnemy":  theme.ENEMY_HEAVY_RENDER,
    "BossEnemy":   (200, 50, 200),
}

_ENEMY_ELEMENT_SHADE = {
    "BasicEnemy": 1.00,
    "FastEnemy": 1.15,
    "TankEnemy": 0.78,
    "SwarmEnemy": 0.92,
    "HeavyEnemy": 0.82,
    "FlyingEnemy": 1.10,
    "BossEnemy": 1.25,
}


def _scale_rgb(color: tuple[int, int, int], factor: float) -> tuple[int, int, int]:
    return tuple(max(0, min(255, int(c * factor))) for c in color)


def get_enemy_render_color(enemy) -> tuple[int, int, int]:
    ename = type(enemy).__name__
    elem = getattr(enemy, "element", "ARCANE")
    base = theme.ELEMENT_COLORS.get(elem, ENEMY_COLORS.get(ename, (200, 0, 0)))
    return _scale_rgb(base, _ENEMY_ELEMENT_SHADE.get(ename, 1.0))


def _get_projectile_visual_data(projectile) -> dict:
    visual = {}
    for attr in ("visual", "metadata", "render"):
        data = getattr(projectile, attr, None)
        if isinstance(data, dict):
            visual.update(data)
    return visual


def _projectile_visual_value(projectile, visual: dict, keys: tuple, default):
    for key in keys:
        if key in visual:
            return visual[key]
    for key in keys:
        if hasattr(projectile, key):
            value = getattr(projectile, key)
            if value is not None:
                return value
    return default


def draw_towers(surface: pygame.Surface, towers: list,
                selected: object, tile_size: int,
                entity_scale: Optional[int] = None) -> None:
    from src.tower import MedicTower as _MedicTower, SentinelTower as _SentinelTower
    # ------------------------------------------------------------------ helpers
    def _hex_points(cx, cy, r):
        return [(int(cx + r * math.cos(math.radians(60 * i - 30))),
                 int(cy + r * math.sin(math.radians(60 * i - 30)))) for i in range(6)]

    def _oct_points(cx, cy, r):
        return [(int(cx + r * math.cos(math.radians(45 * i))),
                 int(cy + r * math.sin(math.radians(45 * i)))) for i in range(8)]

    visual_tile = int(entity_scale) if entity_scale else int(tile_size)
    bar_w, bar_h = 30, 5

    for tower in towers:
        cx, cy = tower.center_px
        cx_i, cy_i = int(cx), int(cy)
        tname = type(tower).__name__
        color = TOWER_COLORS.get(tname, (128, 128, 128))
        dark = tuple(max(0, c - 40) for c in color)
        body_r = max(6, visual_tile // 2 - 4)
        aim_angle = float(getattr(tower, "aim_angle", -math.pi / 2))

        # -------------------------------------------------------- body silhouette
        if tname == "BasicTower":
            # Rounded rectangle body
            rect = pygame.Rect(cx_i - body_r, cy_i - body_r, body_r * 2, body_r * 2)
            pygame.draw.rect(surface, color, rect, border_radius=6)
            pygame.draw.rect(surface, (0, 0, 0), rect, theme.BORDER_MEDIUM, border_radius=6)

        elif tname == "IceTower":
            # Regular hexagon body
            pts = _hex_points(cx_i, cy_i, body_r)
            pygame.draw.polygon(surface, color, pts)
            pygame.draw.polygon(surface, (0, 0, 0), pts, theme.BORDER_MEDIUM)
            # 3 triangular crystals at alternating vertices (0, 2, 4)
            for vi in (0, 2, 4):
                vx, vy = pts[vi]
                dx, dy = vx - cx_i, vy - cy_i
                norm = math.hypot(dx, dy) or 1
                tip_x = int(vx + dx / norm * 8)
                tip_y = int(vy + dy / norm * 8)
                perp_x, perp_y = int(-dy / norm * 4), int(dx / norm * 4)
                crystal = [(tip_x, tip_y),
                           (vx + perp_x, vy + perp_y),
                           (vx - perp_x, vy - perp_y)]
                pygame.draw.polygon(surface, dark, crystal)
                pygame.draw.polygon(surface, (0, 0, 0), crystal, 1)

        elif tname == "BombTower":
            # Large circle body
            pygame.draw.circle(surface, color, (cx_i, cy_i), body_r)
            pygame.draw.circle(surface, (0, 0, 0), (cx_i, cy_i), body_r, theme.BORDER_MEDIUM)
            # Thin vertical slot (cylindrical fissure)
            slot_rect = pygame.Rect(cx_i - 3, cy_i - body_r + 4, 6, body_r * 2 - 8)
            pygame.draw.rect(surface, dark, slot_rect, border_radius=2)
            pygame.draw.rect(surface, (0, 0, 0), slot_rect, 1, border_radius=2)

        elif tname == "SniperTower":
            # Elongated diamond (rhombus) body
            diamond = [(cx_i, cy_i - body_r),
                       (cx_i + body_r // 2, cy_i),
                       (cx_i, cy_i + body_r),
                       (cx_i - body_r // 2, cy_i)]
            pygame.draw.polygon(surface, color, diamond)
            pygame.draw.polygon(surface, (0, 0, 0), diamond, theme.BORDER_MEDIUM)

        elif tname == "AntiAirTower":
            # Inverted triangle: base on top, point at bottom.
            # half = tile_size//2 + 2 so the fill interior covers cy-24 (test top_px)
            # even after the width-2 border outline; at y=cy width is half, so cx+24 stays black.
            half = visual_tile // 2 + 2
            body_pts = [(cx_i - half, cy_i - half),
                        (cx_i + half, cy_i - half),
                        (cx_i, cy_i + half)]
            pygame.draw.polygon(surface, color, body_pts)
            pygame.draw.polygon(surface, (0, 0, 0), body_pts, theme.BORDER_MEDIUM)

        elif tname == "StormTower":
            # Six-pointed star: two overlapping equilateral triangles.
            # tri1 starts at 0° so its rightmost tip is at (cx+r, cy).
            # Use r slightly larger than tile_size//2 so the polygon fill
            # covers the test pixel at storm_center[0]+tile_size//2.
            r = visual_tile // 2 + 4
            tri1 = [(int(cx_i + r * math.cos(math.radians(120 * i))),
                     int(cy_i + r * math.sin(math.radians(120 * i)))) for i in range(3)]
            tri2 = [(int(cx_i + r * math.cos(math.radians(60 + 120 * i))),
                     int(cy_i + r * math.sin(math.radians(60 + 120 * i)))) for i in range(3)]
            pygame.draw.polygon(surface, color, tri1)
            pygame.draw.polygon(surface, (0, 0, 0), tri1, theme.BORDER_MEDIUM)
            pygame.draw.polygon(surface, color, tri2)
            pygame.draw.polygon(surface, (0, 0, 0), tri2, theme.BORDER_MEDIUM)

        elif tname == "InfernoTower":
            # Octagon body
            pts = _oct_points(cx_i, cy_i, body_r)
            pygame.draw.polygon(surface, color, pts)
            pygame.draw.polygon(surface, (0, 0, 0), pts, theme.BORDER_MEDIUM)
            # Central flame triangle — tip extends to cy-tile_size//2 so
            # inferno_top_px (cy-tile_size//2) is non-black in tests.
            flame_h = visual_tile // 2
            flame = [(cx_i, cy_i - flame_h),
                     (cx_i - body_r // 2, cy_i + body_r // 2),
                     (cx_i + body_r // 2, cy_i + body_r // 2)]
            pygame.draw.polygon(surface, dark, flame)
            # No outline on flame — outline would overwrite the tip vertex pixel
            # Restore center pixel to body color (flame may overwrite it)
            pygame.draw.circle(surface, color, (cx_i, cy_i), 3)

        else:
            # Fallback: plain circle
            pygame.draw.circle(surface, color, (cx_i, cy_i), body_r)
            pygame.draw.circle(surface, (0, 0, 0), (cx_i, cy_i), body_r, theme.BORDER_MEDIUM)

        if isinstance(tower, _MedicTower):
            arm = max(4, visual_tile // 5)
            pygame.draw.rect(surface, (60, 200, 60), (cx_i - 2, cy_i - arm, 4, arm * 2))
            pygame.draw.rect(surface, (60, 200, 60), (cx_i - arm, cy_i - 2, arm * 2, 4))
        elif isinstance(tower, _SentinelTower):
            shield_r = max(8, visual_tile // 3)
            pygame.draw.circle(surface, (180, 180, 100), (cx_i, cy_i), shield_r, 4)

        # Barrel + muzzle oriented toward the current tower aim angle.
        barrel_specs = {
            "BasicTower": (body_r - 2, 6, 3),
            "IceTower": (body_r - 3, 5, 3),
            "BombTower": (body_r - 4, 6, 3),
            "SniperTower": (body_r + 8, 4, 2),
            "AntiAirTower": (body_r - 2, 6, 3),
            "StormTower": (body_r - 4, 5, 3),
            "InfernoTower": (body_r - 3, 5, 3),
        }
        barrel_len, barrel_w, muzzle_r = barrel_specs.get(tname, (body_r - 3, 5, 3))
        ux = math.cos(aim_angle)
        uy = math.sin(aim_angle)
        start_x = int(cx_i + ux * max(3, body_r // 3))
        start_y = int(cy_i + uy * max(3, body_r // 3))
        max_tip_reach = max(6, (visual_tile // 2) - 2)
        tip_x = int(cx_i + ux * max_tip_reach)
        tip_y = int(cy_i + uy * max_tip_reach)
        if tname != "StormTower":
            pygame.draw.line(surface, dark, (start_x, start_y), (tip_x, tip_y), max(2, barrel_w))
            muzzle_color = tuple(min(255, c + 25) for c in dark)
            pygame.draw.circle(surface, muzzle_color, (tip_x, tip_y), max(2, muzzle_r))

        # -------------------------------------------------------- selection ring
        if tower is selected:
            tick_phase = (pygame.time.get_ticks() // 500) % 2
            ring_w = 4 if tick_phase else 2
            pygame.draw.circle(surface, (255, 255, 100),
                               (cx_i, cy_i), int(tower.range_px), ring_w)

        # -------------------------------------------------------- upgrade badges
        # Positioned near top of body (inside body_r) to avoid clashing with
        # silhouette extensions above the body.
        level = tower.level
        badge_colors = {1: (180, 180, 180), 2: (220, 220, 220), 3: (255, 215, 0)}
        badge_col = badge_colors.get(level, (180, 180, 180))
        badge_offsets = {1: [0], 2: [-8, 8], 3: [-8, 0, 8]}
        badge_y = cy_i - body_r + 5
        for offset in badge_offsets.get(level, [0]):
            pygame.draw.circle(surface, badge_col, (cx_i + offset, badge_y), 3)
            pygame.draw.circle(surface, (0, 0, 0), (cx_i + offset, badge_y), 3, 1)

        # -------------------------------------------------------- HP bar — skip if full health
        if tower.hp < tower.max_hp:
            ratio = tower.hp / tower.max_hp
            bx = int(cx) - bar_w // 2
            by = int(cy) - visual_tile // 2 + 2
            pygame.draw.rect(surface, (120, 0, 0), (bx, by, bar_w, bar_h))  # dark red HP bar bg, no exact theme match
            if ratio > 0.6:
                fg_color = (0, 200, 0)   # HP high green, approx theme.HP_HIGH=(80,200,80)
            elif ratio >= 0.3:
                fg_color = (200, 200, 0)  # HP med yellow, approx theme.HP_MED=(220,180,50)
            else:
                fg_color = (200, 0, 0)   # HP low red, approx theme.HP_LOW=(220,80,50)
            pygame.draw.rect(surface, fg_color, (bx, by, int(bar_w * ratio), bar_h))

        # -------------------------------------------------------- element indicator dot
        elem = getattr(tower, "element", "ARCANE")
        dot_color = theme.ELEMENT_COLORS.get(elem, (200, 200, 200))
        dot_r = max(4, tile_size // 10)
        dot_x = int(tower.col * tile_size + tile_size - dot_r - 3)
        dot_y = int(tower.row * tile_size + tile_size - dot_r - 3)
        pygame.draw.circle(surface, dot_color, (dot_x, dot_y), dot_r)


def draw_enemies(surface: pygame.Surface, enemies: list) -> None:
    for e in enemies:
        if not e.alive:
            continue
        px, py = e.pos
        cx, cy = int(px), int(py)
        ename = type(e).__name__
        color = get_enemy_render_color(e)
        dark = tuple(max(0, c - 40) for c in color)
        light = tuple(min(255, c + 40) for c in color)

        # --- shape per type ---
        if ename == "BasicEnemy":
            radius = 10
            pygame.draw.circle(surface, color, (cx, cy), radius)
            pygame.draw.circle(surface, dark, (cx, cy), 3)

        elif ename == "FastEnemy":
            radius = 10
            raw_dir = getattr(e, "direction", (1, 0))
            if isinstance(raw_dir, (list, tuple)) and len(raw_dir) == 2:
                try:
                    dx, dy = float(raw_dir[0]), float(raw_dir[1])
                except (TypeError, ValueError):
                    dx, dy = 1.0, 0.0
            else:
                dx, dy = 1.0, 0.0
            length = math.hypot(dx, dy)
            if length == 0:
                dx, dy = 1.0, 0.0
            else:
                dx, dy = dx / length, dy / length
            # perpendicular
            px2, py2 = -dy, dx
            half_w, h = 8, 16
            tip = (cx + int(dx * h), cy + int(dy * h))
            base_l = (cx - int(dx * 0) + int(px2 * half_w), cy - int(dy * 0) + int(py2 * half_w))
            base_r = (cx - int(px2 * half_w), cy - int(py2 * half_w))
            pygame.draw.polygon(surface, color, [tip, base_l, base_r])

        elif ename == "TankEnemy":
            radius = 10
            w, h = 22, 16
            rect = pygame.Rect(cx - w // 2, cy - h // 2, w, h)
            pygame.draw.rect(surface, dark, rect)
            pygame.draw.rect(surface, color, rect, 3)

        elif ename == "BossEnemy":
            radius = 18
            # aura glow on SRCALPHA surface
            aura_surf = pygame.Surface((radius * 2 + 14, radius * 2 + 14), pygame.SRCALPHA)
            aura_color = (min(255, color[0] + 40), min(255, color[1] + 40), min(255, color[2] + 40), 80)
            aura_r = 24
            pygame.draw.circle(aura_surf, aura_color,
                                (aura_r - 1, aura_r - 1), aura_r)
            surface.blit(aura_surf, (cx - aura_r + 1, cy - aura_r + 1))
            pygame.draw.circle(surface, color, (cx, cy), radius)

        elif ename == "HeavyEnemy":
            radius = 10
            w, h = 18, 14
            rect = pygame.Rect(cx - w // 2, cy - h // 2, w, h)
            pygame.draw.rect(surface, color, rect)
            # cannon: right side, centered vertically
            cannon_w, cannon_h = 10, 5
            cannon_rect = pygame.Rect(cx + w // 2, cy - cannon_h // 2, cannon_w, cannon_h)
            pygame.draw.rect(surface, dark, cannon_rect)

        elif ename == "FlyingEnemy":
            radius = 9  # ry of ellipse
            wing_color = tuple(min(255, c + 55) for c in color)
            # oscillating wings — angle offsets outer tips
            osc = math.sin(pygame.time.get_ticks() / 300.0) * 15
            # left wing polygon
            pygame.draw.polygon(
                surface,
                wing_color,
                [
                    (cx - 4, cy - 3),
                    (cx - 16, cy - 10 + int(osc)),
                    (cx - 12, cy),
                    (cx - 16, cy + 10 - int(osc)),
                ],
            )
            # right wing polygon
            pygame.draw.polygon(
                surface,
                wing_color,
                [
                    (cx + 4, cy - 3),
                    (cx + 16, cy - 10 + int(osc)),
                    (cx + 12, cy),
                    (cx + 16, cy + 10 - int(osc)),
                ],
            )
            # ellipse body on top of wings
            ellipse_rect = pygame.Rect(cx - 14, cy - 9, 28, 18)
            pygame.draw.ellipse(surface, color, ellipse_rect)

        elif ename == "SwarmEnemy":
            radius = 7
            pygame.draw.circle(surface, color, (cx, cy), radius)
            # 4 rotating satellites
            orbit_angle = pygame.time.get_ticks() / 400.0
            for i in range(4):
                a = orbit_angle + i * (math.pi / 2)
                sx = cx + int(math.cos(a) * 12)
                sy = cy + int(math.sin(a) * 12)
                pygame.draw.circle(surface, light, (sx, sy), 3)

        else:
            # fallback
            radius = 10
            pygame.draw.circle(surface, color, (cx, cy), radius)

        # --- health bar (all types) ---
        if ename == "BossEnemy":
            bar_w = 36
        elif ename in ("TankEnemy", "HeavyEnemy"):
            bar_w = 28
        else:
            bar_w = 22
        ratio = e.hp / e.max_hp if e.max_hp > 0 else 0.0
        bar_x = cx - bar_w // 2
        bar_y = cy - radius - 8
        pygame.draw.rect(surface, (120, 0, 0), (bar_x, bar_y, bar_w, theme.HEALTH_BAR_H))
        if ratio > 0.6:
            hp_color = theme.HP_HIGH
        elif ratio >= 0.3:
            hp_color = theme.HP_MED
        else:
            hp_color = theme.HP_LOW
        pygame.draw.rect(surface, hp_color, (bar_x, bar_y, int(bar_w * ratio), theme.HEALTH_BAR_H))

        # --- boss powerup badge (unchanged) ---
        if ename == "BossEnemy" and hasattr(e, "active_powerups"):
            sf = fonts.panel()
            for j, pu in enumerate(e.active_powerups):
                pu_surf = sf.render(pu, True, (255, 255, 100))  # boss powerup label yellow, approx TOWER_STORM=(255,220,50)
                surface.blit(pu_surf, (cx - pu_surf.get_width() // 2,
                                       cy - radius - 18 - j * 12))

        # --- boss telegraph indicator ---
        if ename == "BossEnemy" and getattr(e, "telegraph_active", False):
            ability_id = getattr(e, "telegraph_ability_id", "")
            tele_timer = getattr(e, "telegraph_timer", 0.0)
            # pulsing ring: radius grows from 20 to 32 based on remaining timer
            pulse_frac = max(0.0, min(1.0, tele_timer / 1.2))
            pulse_r = int(20 + 12 * (1.0 - pulse_frac))
            tele_surf = pygame.Surface((pulse_r * 2 + 4, pulse_r * 2 + 4), pygame.SRCALPHA)
            ring_alpha = int(180 * pulse_frac + 60)
            pygame.draw.circle(tele_surf, (255, 160, 0, ring_alpha),
                                (pulse_r + 2, pulse_r + 2), pulse_r, 3)
            surface.blit(tele_surf, (cx - pulse_r - 2, cy - pulse_r - 2))
            # ability label
            sf = fonts.panel()
            _ABILITY_LABELS = {
                "summon_swarm": "SUMMON SWARM",
                "armor_pulse": "ARMOR PULSE",
            }
            label = _ABILITY_LABELS.get(ability_id, ability_id.upper())
            lbl_surf = sf.render(label, True, (255, 160, 0))
            badge_offset = len(getattr(e, "active_powerups", [])) * 12
            surface.blit(lbl_surf, (cx - lbl_surf.get_width() // 2,
                                    cy - radius - 30 - badge_offset))


def draw_projectiles(surface: pygame.Surface, projectiles: list) -> None:
    for p in projectiles:
        is_active = getattr(p, "active", getattr(p, "alive", True))
        if not is_active:
            continue

        visual_kind = getattr(p, "visual_kind", None)
        px, py = int(p.x), int(p.y)

        # Determine target position for directional visuals (e.g., sniper)
        target = getattr(p, "target", None)
        if target is not None and hasattr(target, "pos"):
            tx, ty = target.pos
            angle = math.atan2(ty - p.y, tx - p.x)
        else:
            angle = 0.0

        # Draw based on visual_kind
        if visual_kind == "ice":
            # IceTower: blue ellipse + trail fade
            pygame.draw.ellipse(surface, theme.TOWER_ICE, (px - 5, py - 3, 10, 6))
            # Trail: 3 circles decrescending alpha behind
            dx = math.cos(angle) * 5
            dy = math.sin(angle) * 5
            trail_surface = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            for i in range(1, 4):
                trail_x = int(p.x - i * dx)
                trail_y = int(p.y - i * dy)
                trail_r = 3 - (i - 1)  # radius: 3, 2, 1
                trail_alpha = int(100 * (1.0 - i / 4.0))  # decrescending alpha
                trail_color = (*theme.TOWER_ICE, trail_alpha)
                pygame.draw.circle(trail_surface, trail_color, (trail_x, trail_y), trail_r)
            surface.blit(trail_surface, (0, 0))

        elif visual_kind == "bomb":
            # BombTower: orange circle + smoke trail
            pygame.draw.circle(surface, theme.TOWER_BOMB, (px, py), 5)
            # Smoke trail: 2 circles offset behind
            smoke_surface = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            for offset_x in [-6, -12]:
                smoke_x = px + offset_x
                smoke_y = py
                smoke_color = (100, 100, 100, 60)  # grey with alpha
                pygame.draw.circle(smoke_surface, smoke_color, (smoke_x, smoke_y), 3)
            surface.blit(smoke_surface, (0, 0))

        elif visual_kind == "sniper":
            # SniperTower: thin rectangle along direction of movement
            w, h = 12, 2
            # Rotate rectangle around projectile center
            cos_a = math.cos(angle)
            sin_a = math.sin(angle)
            # Corners of unrotated rectangle
            corners = [
                (-w / 2, -h / 2),
                (w / 2, -h / 2),
                (w / 2, h / 2),
                (-w / 2, h / 2)
            ]
            # Rotate and translate
            rotated = [
                (px + cx * cos_a - cy * sin_a, py + cx * sin_a + cy * cos_a)
                for cx, cy in corners
            ]
            pygame.draw.polygon(surface, theme.TOWER_SNIPER, rotated)

        elif visual_kind == "storm":
            # StormTower: yellow ellipse + spark
            pygame.draw.ellipse(surface, theme.TOWER_STORM, (px - 4, py - 4, 8, 8))
            # Spark: cross pattern
            spark_len = 3
            pygame.draw.line(surface, theme.TOWER_STORM, (px - spark_len, py), (px + spark_len, py), 1)
            pygame.draw.line(surface, theme.TOWER_STORM, (px, py - spark_len), (px, py + spark_len), 1)

        elif visual_kind == "inferno":
            # InfernoTower: red circle + orange glow
            pygame.draw.circle(surface, theme.TOWER_INFERNO, (px, py), 5)
            # Glow
            glow_surface = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            glow_color = (255, 140, 0, 60)  # orange with alpha
            pygame.draw.circle(glow_surface, glow_color, (px, py), 8)
            surface.blit(glow_surface, (0, 0))

        else:
            # Fallback or "default": use metadata-driven rendering
            visual = _get_projectile_visual_data(p)
            color = _projectile_visual_value(
                p, visual, ("color", "projectile_color", "fill_color"), theme.PROJECTILE
            )
            radius = int(_projectile_visual_value(p, visual, ("radius", "size"), 4))

            trail = _projectile_visual_value(
                p, visual, ("trail", "trail_points", "path"), None
            )
            if trail and not isinstance(trail, bool):
                trail_points = [(int(x), int(y)) for x, y in trail]
                if len(trail_points) > 1:
                    trail_color = _projectile_visual_value(
                        p, visual, ("trail_color",), color
                    )
                    trail_alpha = int(_projectile_visual_value(
                        p, visual, ("trail_alpha",), theme.OVERLAY_ALPHA_LIGHT  # default trail alpha = 80
                    ))
                    trail_width = int(_projectile_visual_value(
                        p, visual, ("trail_width",), max(1, radius // 2)
                    ))
                    if len(trail_color) == 3:
                        trail_rgba = (*trail_color, trail_alpha)
                    else:
                        trail_rgba = trail_color
                    trail_surface = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
                    pygame.draw.lines(trail_surface, trail_rgba, False, trail_points, trail_width)
                    surface.blit(trail_surface, (0, 0))

            pygame.draw.circle(surface, color, (int(p.x), int(p.y)), radius)


def draw_meteors(surface: pygame.Surface, positions: list, tile_size: int) -> None:
    radius = tile_size // 2
    for col, row in positions:
        cx = col * tile_size + tile_size // 2
        cy = row * tile_size + tile_size // 2
        pygame.draw.circle(surface, (220, 80, 20), (cx, cy), radius)   # outer meteor: fiery orange-red, approx EVENT_NEGATIVE=(220,80,80)
        pygame.draw.circle(surface, (255, 160, 60), (cx, cy), radius // 2)  # inner meteor: bright orange, approx TOWER_BOMB=(220,120,50)


def draw_enemy_projectiles(surface: pygame.Surface, projectiles: list) -> None:
    for p in projectiles:
        if p.alive:
            pygame.draw.circle(surface, theme.EVENT_NEGATIVE, (int(p.x), int(p.y)), 5)  # (220,80,80) → was (220,50,50); closest: EVENT_NEGATIVE
