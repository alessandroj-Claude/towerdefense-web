from __future__ import annotations
"""Renderer submodule: HUD, pause overlay, floating text."""
from typing import Optional

import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass

from src import theme

_HUD_ROW1_H = 34  # height of top row (resources + speed)


def _format_event_timer(event_timer: Optional[object]) -> str:
    if isinstance(event_timer, (int, float)) and not isinstance(event_timer, bool):
        return f"{max(0.0, float(event_timer)):.1f}s"
    return str(event_timer)


def _build_hud_lines(
    lives: int,
    gold: int,
    wave: int,
    score: int,
    score_multiplier: float,
) -> tuple[str, str]:
    left_text = f"Lives {lives}   Gold {gold}   Wave {wave}"
    center_text = f"Score {score}  (x{max(1.0, float(score_multiplier)):.2f})"
    return left_text, center_text


def draw_hud(surface: pygame.Surface, font: pygame.font.Font,
             gold: int, lives: int, wave: int, score: int,
             screen_w: int, event_label: Optional[str] = None,
             simulation_speed: float = 1.0,
             score_multiplier: float = 1.0,
             event_timer: Optional[object] = None,
             event_tint: Optional[tuple] = None,
             active_powerups: Optional[list[dict]] = None,
             challenge_label: Optional[str] = None,
             hud_y: int = 0,
             hud_h: int = 58,
             synergy_label: Optional[str] = None,
             wave_active: bool = True,
             recent_events: Optional[list[str]] = None) -> list:
    """Draw the HUD bar (two rows). Returns list of (speed_value, rect) for click detection."""
    pygame.draw.rect(surface, theme.PANEL_BG, (0, hud_y, screen_w, hud_h))

    row1_h = min(_HUD_ROW1_H, hud_h)
    col_w = screen_w // 3
    pad_x = 10
    row1_cy = hud_y + row1_h // 2

    left_text, center_text = _build_hud_lines(lives, gold, wave, score, score_multiplier)
    left_surf = font.render(left_text, True, theme.TEXT_PRIMARY)
    surface.blit(left_surf, (pad_x, row1_cy - left_surf.get_height() // 2))

    center_surf = font.render(center_text, True, theme.TEXT_PRIMARY)
    center_x = col_w + max(4, (col_w - center_surf.get_width()) // 2)
    surface.blit(center_surf, (center_x, row1_cy - center_surf.get_height() // 2))
    if synergy_label:
        syn_surf = font.render(str(synergy_label), True, (255, 240, 80))
        syn_x = col_w + max(4, (col_w - syn_surf.get_width()) // 2)
        surface.blit(syn_surf, (syn_x, hud_y + 1))

    speed_labels = ["x1", "x1.5", "x2", "x3"]
    speed_values = [1.0, 1.5, 2.0, 3.0]
    seg_gap = 3
    seg_h = max(18, row1_h - 8)
    right_x0 = 2 * col_w + 6
    right_w = max(80, screen_w - right_x0 - 8)
    seg_w = max(20, (right_w - seg_gap * (len(speed_labels) - 1)) // len(speed_labels))
    seg_y = hud_y + (row1_h - seg_h) // 2
    current_speed = max(0.0, float(simulation_speed))
    # Legacy render kept for compatibility with renderer tests that still spy on this label.
    font.render(f"Speed x{current_speed:g}", True, theme.TEXT_SECONDARY)
    speed_rects: list = []
    for idx, (label, value) in enumerate(zip(speed_labels, speed_values)):
        x = right_x0 + idx * (seg_w + seg_gap)
        rect = pygame.Rect(x, seg_y, seg_w, seg_h)
        speed_rects.append((value, rect))
        selected = abs(current_speed - value) < 0.001
        bg = theme.BUTTON_ACTIVE if selected else theme.GRID
        fg = theme.TEXT_PRIMARY if selected else theme.TEXT_SECONDARY
        pygame.draw.rect(surface, bg, rect, border_radius=4)
        pygame.draw.rect(surface, theme.BUTTON_HOVER, rect, width=1, border_radius=4)
        seg_surf = font.render(label, True, fg)
        surface.blit(seg_surf,
                     (rect.centerx - seg_surf.get_width() // 2,
                      rect.centery - seg_surf.get_height() // 2))

    if hud_h > row1_h:
        pygame.draw.line(surface, (55, 60, 75),
                         (0, hud_y + row1_h), (screen_w, hud_y + row1_h))

    row2_y = hud_y + row1_h + 1
    row2_h = max(0, hud_h - row1_h - 1)
    if row2_h > 0:
        badge_h = max(12, row2_h - 4)
        badge_y = row2_y + (row2_h - badge_h) // 2
        badge_x = pad_x

        for item in (active_powerups or []):
            label = str(item.get("label", "")).strip()
            if not label:
                continue
            timer = item.get("timer")
            timer_txt = _format_event_timer(timer) if timer is not None else ""
            text_value = f"{label} {timer_txt}".strip()
            badge_text = font.render(text_value, True, (235, 255, 235))
            icon = font.render("◆", True, (190, 235, 195))
            badge_w = icon.get_width() + badge_text.get_width() + 12
            badge_surf = pygame.Surface((badge_w, badge_h), pygame.SRCALPHA)
            badge_surf.fill((42, 92, 54, 210))
            surface.blit(badge_surf, (badge_x, badge_y))
            pygame.draw.rect(surface, (160, 220, 170),
                             (badge_x, badge_y, badge_w, badge_h), theme.BORDER_THIN, border_radius=3)
            surface.blit(icon, (badge_x + 3, badge_y + (badge_h - icon.get_height()) // 2))
            surface.blit(badge_text, (badge_x + icon.get_width() + 5,
                                      badge_y + (badge_h - badge_text.get_height()) // 2))
            badge_x += badge_w + 6

        if challenge_label:
            ch_text = font.render(str(challenge_label), True, (215, 235, 255))
            ch_w = ch_text.get_width() + 12
            ch_surf = pygame.Surface((ch_w, badge_h), pygame.SRCALPHA)
            ch_surf.fill((35, 66, 108, 210))
            surface.blit(ch_surf, (badge_x, badge_y))
            pygame.draw.rect(surface, (120, 185, 250), (badge_x, badge_y, ch_w, badge_h),
                             theme.BORDER_THIN, border_radius=3)
            surface.blit(ch_text, (badge_x + 6, badge_y + (badge_h - ch_text.get_height()) // 2))
            badge_x += ch_w + 6

        if event_label is not None or event_timer is not None:
            tint = event_tint or theme.EVENT_NEUTRAL
            tint_rgb = tint[:3]
            tint_alpha = int(tint[3]) if len(tint) >= 4 else 150
            parts = [str(event_label)] if event_label is not None else []
            if event_timer is not None:
                parts.append(_format_event_timer(event_timer))
            ev_text = "  ".join(p for p in parts if p)
            if ev_text:
                ev_surf = font.render(ev_text, True, theme.TEXT_PRIMARY)
                ev_bw = ev_surf.get_width() + 14
                ev_bx = screen_w - ev_bw - pad_x
                ev_badge = pygame.Surface((ev_bw, badge_h), pygame.SRCALPHA)
                ev_badge.fill((*tint_rgb, max(0, min(255, tint_alpha))))
                surface.blit(ev_badge, (ev_bx, badge_y))
                pygame.draw.rect(surface, (220, 220, 220),
                                 (ev_bx, badge_y, ev_bw, badge_h), theme.BORDER_THIN, border_radius=4)
                surface.blit(ev_surf, (ev_bx + 7,
                                       badge_y + (badge_h - ev_surf.get_height()) // 2))

        if recent_events:
            text = " | ".join(str(e) for e in recent_events[-3:] if str(e).strip())
            if text:
                evlog = font.render(text, True, (220, 228, 245))
                evlog_x = pad_x
                evlog_y = row2_y + max(0, row2_h - evlog.get_height() - 1)
                surface.blit(evlog, (evlog_x, evlog_y))

    return speed_rects


def draw_pause_overlay(surface: pygame.Surface, font: pygame.font.Font,
                       screen_w: int, screen_h: int, has_save: bool,
                       toast: str = None) -> dict:
    dark = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
    dark.fill((0, 0, 0, theme.OVERLAY_ALPHA_MED))
    surface.blit(dark, (0, 0))
    bw, bh = 260, 320
    bx, by = screen_w // 2 - bw // 2, screen_h // 2 - bh // 2
    pygame.draw.rect(surface, (40, 40, 40), (bx, by, bw, bh), border_radius=10)
    pygame.draw.rect(surface, (100, 100, 100), (bx, by, bw, bh), theme.BORDER_MEDIUM, border_radius=10)
    fb = pygame.font.SysFont("Arial", 28, bold=True)
    t = fb.render("PAUSA", True, theme.TEXT_PRIMARY)
    surface.blit(t, (bx + bw // 2 - t.get_width() // 2, by + 14))
    labels = ["Riprendi", "Salva", "Carica", "Return to start menu", "Esci"]
    rects = {}
    for i, label in enumerate(labels):
        bby = by + 58 + i * 48
        bbx = bx + bw // 2 - 100
        if label == "Carica" and not has_save:
            col_bg, col_txt = (50, 50, 50), (100, 100, 100)
        elif label == "Esci":
            col_bg, col_txt = (120, 40, 40), theme.TEXT_PRIMARY
        elif label == "Riprendi":
            col_bg, col_txt = (50, 120, 50), theme.TEXT_PRIMARY
        else:
            col_bg, col_txt = theme.BUTTON_DEFAULT, theme.TEXT_PRIMARY
        rect = pygame.Rect(bbx, bby, 200, 36)
        pygame.draw.rect(surface, col_bg, rect, border_radius=6)
        txt = font.render(label, True, col_txt)
        surface.blit(txt, (rect.centerx - txt.get_width() // 2,
                          rect.centery - txt.get_height() // 2))
        rects[label] = rect
    if toast:
        ts = font.render(toast, True, (100, 255, 100))
        surface.blit(ts, (screen_w // 2 - ts.get_width() // 2, by + bh + 10))
    return rects


def draw_floating_text(surface: pygame.Surface, font: pygame.font.Font,
                       text: str, cx: float, cy: float, alpha: float) -> None:
    surf = font.render(text, True, theme.GOLD_COLOR)
    surf.set_alpha(max(0, min(255, int(alpha * 255))))
    surface.blit(surf, (cx - surf.get_width() // 2, cy - 30))


def draw_wave_preview_panel(
    surface: pygame.Surface,
    font: pygame.font.Font,
    preview: dict,
    screen_w: int,
    hud_y: int,
    countdown: float,
) -> None:
    """Overlay panel shown during countdown: next wave composition."""
    from src.renderer._fonts import fonts

    panel_w, panel_h = 500, 75
    panel_x = screen_w // 2 - panel_w // 2
    panel_y = hud_y - panel_h - 10

    # semi-transparent background
    bg = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
    bg.fill((10, 10, 20, 200))
    surface.blit(bg, (panel_x, panel_y))

    # border: red/orange if boss, else dim blue
    border_color = (220, 80, 50) if preview.get("has_boss") else (80, 100, 160)
    pygame.draw.rect(surface, border_color, (panel_x, panel_y, panel_w, panel_h), 2)

    title_font = fonts.sized_bold(15)
    wave_n = preview.get("wave", "?")
    title_text = f"Wave {wave_n} incoming"
    if preview.get("has_boss"):
        title_text += "  ⚠ BOSS"
    title_surf = title_font.render(title_text, True, (230, 230, 230))
    surface.blit(title_surf, (panel_x + 8, panel_y + 5))

    # enemy icons row
    icon_font = fonts.sized(13)
    x = panel_x + 8
    y_icons = panel_y + 26
    for entry in preview.get("enemies", []):
        text = f"{entry['icon']} {entry['name']} \xd7{entry['count']}"
        surf = icon_font.render(text, True, (200, 200, 200))
        surface.blit(surf, (x, y_icons))
        x += surf.get_width() + 12
        if x > panel_x + panel_w - 80:
            break  # avoid overflow

    # countdown hint
    hint_font = fonts.sized(11)
    hint = f"Deploy in {max(0.0, countdown):.1f}s  [SPACE]"
    hint_surf = hint_font.render(hint, True, (120, 120, 120))
    surface.blit(hint_surf, (panel_x + panel_w - hint_surf.get_width() - 6, panel_y + panel_h - hint_surf.get_height() - 5))


def draw_achievement_toast(
    surface: pygame.Surface,
    achievement,
    timer: float,
    duration: float,
    font: pygame.font.Font,
) -> None:
    """Draw achievement unlock toast in top-right corner."""
    from src.renderer._fonts import fonts
    SCREEN_W = surface.get_width()

    panel_w, panel_h = 280, 70
    margin = 10
    x = SCREEN_W - panel_w - margin
    y = 40  # below HUD bar

    # Fade-out in last 0.5s
    fade = min(1.0, timer / 0.5) if timer < 0.5 else 1.0
    alpha = int(220 * fade)

    panel = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
    panel.fill((30, 30, 40, alpha))

    # Gold border
    border_color = (255, 210, 50, min(255, alpha + 30))
    pygame.draw.rect(panel, border_color, (0, 0, panel_w, panel_h), 2)

    # "Achievement Sbloccato!" label
    small_font = fonts.sized(14)
    label_surf = small_font.render("Achievement Sbloccato!", True, (255, 210, 50))
    panel.blit(label_surf, (8, 6))

    # Icon + name
    name_font = fonts.sized(18)
    icon_surf = name_font.render(achievement.icon, True, (255, 255, 255))
    name_surf = name_font.render(achievement.name, True, (255, 255, 255))
    panel.blit(icon_surf, (8, 26))
    panel.blit(name_surf, (8 + icon_surf.get_width() + 6, 28))

    surface.blit(panel, (x, y))


def draw_run_stats_overlay(
    surface: pygame.Surface,
    run_totals: dict,
    font: pygame.font.Font,
    font_small: pygame.font.Font,
) -> None:
    """Centered overlay panel showing aggregated run stats. Tab to close."""
    from src.renderer._fonts import fonts

    SCREEN_W = surface.get_width()
    SCREEN_H = surface.get_height()
    PANEL_W, PANEL_H = 500, 340
    px = (SCREEN_W - PANEL_W) // 2
    py = (SCREEN_H - PANEL_H) // 2

    panel = pygame.Surface((PANEL_W, PANEL_H), pygame.SRCALPHA)
    panel.fill((15, 15, 25, 230))
    pygame.draw.rect(panel, (80, 80, 100), (0, 0, PANEL_W, PANEL_H), 1)

    title_font = fonts.sized_bold(18)
    sm = fonts.sized(13)
    tiny = fonts.sized(11)

    y = 10
    title_surf = title_font.render("Run Stats  (Tab per chiudere)", True, (220, 220, 240))
    panel.blit(title_surf, (PANEL_W // 2 - title_surf.get_width() // 2, y))
    y += title_surf.get_height() + 8

    # Metrics row
    waves = run_totals.get("waves_completed", 0)
    lives = run_totals.get("lives_lost", 0)
    gold_e = run_totals.get("gold_earned", 0)
    gold_s = run_totals.get("gold_spent", 0)
    metrics = f"Wave completate: {waves}  |  Vite perse: {lives}  |  Gold guadagnato: {gold_e:,}  |  Gold speso: {gold_s:,}"
    met_surf = tiny.render(metrics, True, (180, 180, 200))
    panel.blit(met_surf, (10, y))
    y += met_surf.get_height() + 6

    # Separator
    pygame.draw.line(panel, (60, 60, 80), (10, y), (PANEL_W - 10, y), 1)
    y += 6

    # Damage by tower
    dmg_label = sm.render("Danno per torre", True, (200, 200, 220))
    panel.blit(dmg_label, (10, y))
    y += dmg_label.get_height() + 4

    damage_by_tower = run_totals.get("damage_by_tower", {})
    if not damage_by_tower:
        no_data = tiny.render("Nessun dato — completa almeno una wave", True, (140, 140, 160))
        panel.blit(no_data, (10, y))
        y += no_data.get_height() + 6
    else:
        sorted_towers = sorted(damage_by_tower.items(), key=lambda x: x[1], reverse=True)[:6]
        max_dmg = sorted_towers[0][1] if sorted_towers else 1
        bar_max_w = PANEL_W - 20 - 140  # leave room for labels
        for i, (tower_name, dmg) in enumerate(sorted_towers):
            bar_w = max(2, int(bar_max_w * dmg / max(max_dmg, 1)))
            bar_color = (255, 210, 50) if i == 0 else (100, 180, 255)
            pygame.draw.rect(panel, bar_color, (10, y, bar_w, 12))
            label = tiny.render(f"{tower_name}: {dmg:,}", True, (200, 200, 220))
            panel.blit(label, (10 + bar_w + 4, y))
            y += 14
        y += 4

    # Separator
    pygame.draw.line(panel, (60, 60, 80), (10, y), (PANEL_W - 10, y), 1)
    y += 6

    # Kill by enemy
    kill_label = sm.render("Kill per nemico", True, (200, 200, 220))
    panel.blit(kill_label, (10, y))
    y += kill_label.get_height() + 4

    kills_by_enemy = {k: v for k, v in run_totals.get("kills_by_enemy", {}).items() if v > 0}
    if not kills_by_enemy:
        no_kill = tiny.render("Nessun kill registrato", True, (140, 140, 160))
        panel.blit(no_kill, (10, y))
    else:
        col_w = PANEL_W // 3
        items = sorted(kills_by_enemy.items(), key=lambda x: x[1], reverse=True)
        for i, (enemy_name, count) in enumerate(items):
            col = i % 3
            row = i // 3
            ex = 10 + col * col_w
            ey = y + row * 14
            if ey + 14 > PANEL_H - 10:
                break
            kill_surf = tiny.render(f"{enemy_name}: {count}", True, (180, 180, 200))
            panel.blit(kill_surf, (ex, ey))

    surface.blit(panel, (px, py))
