from __future__ import annotations
"""Renderer submodule: map, terrain, path tube, direction arrows."""
import math
import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass
import random
from src.map import GameMap
from src import theme


def _draw_path_tube(surface: pygame.Surface, path_set: set, tile_size: int) -> None:
    border_color = theme.PATH_TUBE_BORDER
    border_w = theme.BORDER_MEDIUM
    inset = max(2, tile_size // 8)
    for c, r in path_set:
        x0 = c * tile_size
        y0 = r * tile_size
        x1 = x0 + tile_size
        y1 = y0 + tile_size
        if (c - 1, r) not in path_set:
            pygame.draw.line(surface, border_color, (x0 + inset, y0 + inset), (x0 + inset, y1 - inset), border_w)
        if (c + 1, r) not in path_set:
            pygame.draw.line(surface, border_color, (x1 - inset, y0 + inset), (x1 - inset, y1 - inset), border_w)
        if (c, r - 1) not in path_set:
            pygame.draw.line(surface, border_color, (x0 + inset, y0 + inset), (x1 - inset, y0 + inset), border_w)
        if (c, r + 1) not in path_set:
            pygame.draw.line(surface, border_color, (x0 + inset, y1 - inset), (x1 - inset, y1 - inset), border_w)


def _draw_path_direction_arrows(surface: pygame.Surface, path: list, tile_size: int) -> None:
    if len(path) < 2:
        return

    points = [
        (c * tile_size + tile_size // 2, r * tile_size + tile_size // 2)
        for c, r in path
    ]
    segments = []
    total_len = 0.0
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        dx = x1 - x0
        dy = y1 - y0
        seg_len = float((dx * dx + dy * dy) ** 0.5)
        if seg_len <= 0.0:
            continue
        segments.append((x0, y0, x1, y1, dx / seg_len, dy / seg_len, seg_len))
        total_len += seg_len
    if total_len <= 1.0:
        return

    def sample_at(distance: float):
        d = max(0.0, min(total_len, distance))
        for x0, y0, x1, y1, ux, uy, seg_len in segments:
            if d <= seg_len:
                return x0 + ux * d, y0 + uy * d, ux, uy
            d -= seg_len
        x0, y0, x1, y1, ux, uy, _ = segments[-1]
        return x1, y1, ux, uy

    arrow_surface = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    ticks = pygame.time.get_ticks()
    speed_px_s = tile_size * 0.85
    spacing = tile_size * 0.95
    phase = (ticks / 1000.0 * speed_px_s) % spacing
    arrow_color = (*theme.PATH_ARROW, 120)  # arrow alpha: 120
    half = max(2, tile_size // 8)
    d = phase
    while d < total_len - (tile_size * 0.25):
        ax, ay, ux, uy = sample_at(d)
        tip_x = int(ax + ux * half)
        tip_y = int(ay + uy * half)
        left_x = int(ax - ux * half - uy * half)
        left_y = int(ay - uy * half + ux * half)
        right_x = int(ax - ux * half + uy * half)
        right_y = int(ay - uy * half - ux * half)
        pygame.draw.polygon(
            arrow_surface,
            arrow_color,
            [(tip_x, tip_y), (left_x, left_y), (right_x, right_y)],
        )
        d += spacing

    surface.blit(arrow_surface, (0, 0))


def draw_map(surface: pygame.Surface, game_map: GameMap) -> None:
    ts = game_map.tile_size
    path_set = game_map._path_set
    terrain_by_cell = getattr(game_map, "terrain_by_cell", {})
    blocked_cells = getattr(game_map, "blocked_cells", set())
    path = getattr(game_map, "path", [])

    # Base colors for terrain types
    terrain_colors = {
        "road": theme.ROAD,           # (#4A4A4A)
        "mud": theme.MUD,             # (#5C3D1E)
        "wind": theme.WIND,           # (#7EC8E3)
        "high_wind": theme.HIGH_WIND, # (#1E90FF)
        "fortified": theme.FORTIFIED, # (#2D5016)
    }

    # Grass color (non-path, non-blocked): dark green (30, 50, 20)
    grass_color = (30, 50, 20)

    # Draw base terrain
    for r in range(game_map.rows):
        for c in range(game_map.cols):
            cell = (c, r)
            x0 = c * ts
            y0 = r * ts

            if cell in path_set:
                terrain = terrain_by_cell.get(cell, "road")
                color = terrain_colors.get(terrain, theme.ROAD)
                pygame.draw.rect(surface, color, (x0, y0, ts, ts))

                # Draw terrain-specific patterns
                if terrain == "road":
                    # White dashed center lines (handled in _draw_path_tube)
                    pass
                elif terrain == "mud":
                    # 4 dark dots at fixed quarter-positions (deterministic, avoids center)
                    dot_color = (40, 30, 15)
                    q = ts // 4
                    for dx_dot, dy_dot in ((q, q), (3 * q, q), (q, 3 * q), (3 * q, 3 * q)):
                        pygame.draw.circle(surface, dot_color, (x0 + dx_dot, y0 + dy_dot), 2)
                elif terrain == "wind":
                    # 3 diagonal lines at 45 degrees
                    light_wind = (200, 235, 255)
                    line_width = 1
                    step = ts // 3
                    for i in range(0, ts, step):
                        pygame.draw.line(surface, light_wind, (x0 + i, y0), (x0 + i + ts // 2, y0 + ts // 2), line_width)
                        pygame.draw.line(surface, light_wind, (x0 + i - ts // 2, y0 + ts // 2), (x0 + i, y0 + ts), line_width)
                elif terrain == "high_wind":
                    # 4 horizontal lines offset by half-step to avoid center pixel
                    light_wind = (200, 235, 255)
                    line_width = 2
                    step = ts // 5
                    half_step = step // 2
                    for i in range(1, 5):
                        y_line = y0 + i * step - half_step
                        pygame.draw.line(surface, light_wind, (x0, y_line), (x0 + ts, y_line), line_width)
                    # Small arrow at center (simplified right-pointing)
                    cx, cy = x0 + ts // 2, y0 + ts // 2
                    arrow_size = 4
                    pygame.draw.polygon(surface, light_wind, [
                        (cx + arrow_size, cy),
                        (cx - arrow_size, cy - arrow_size),
                        (cx - arrow_size, cy + arrow_size),
                    ])
                elif terrain == "fortified":
                    # Grid pattern: 2 vertical + 2 horizontal lines
                    grid_color = (100, 150, 70)
                    line_width = 1
                    x_third = x0 + ts // 3
                    x_twothird = x0 + 2 * ts // 3
                    y_third = y0 + ts // 3
                    y_twothird = y0 + 2 * ts // 3
                    pygame.draw.line(surface, grid_color, (x_third, y0), (x_third, y0 + ts), line_width)
                    pygame.draw.line(surface, grid_color, (x_twothird, y0), (x_twothird, y0 + ts), line_width)
                    pygame.draw.line(surface, grid_color, (x0, y_third), (x0 + ts, y_third), line_width)
                    pygame.draw.line(surface, grid_color, (x0, y_twothird), (x0 + ts, y_twothird), line_width)

            elif cell in blocked_cells:
                pygame.draw.rect(surface, theme.BLOCKED, (x0, y0, ts, ts))
                # 2-3 small dark rock triangles
                seed = hash((c, r, "blocked")) % 1000
                rng = random.Random(seed)
                num_rocks = rng.randint(2, 3)
                for _ in range(num_rocks):
                    px = x0 + rng.randint(2, ts - 5)
                    py = y0 + rng.randint(2, ts - 5)
                    rock_size = rng.randint(2, 4)
                    pygame.draw.polygon(surface, (50, 50, 50), [
                        (px, py),
                        (px + rock_size, py + rock_size),
                        (px - rock_size, py + rock_size),
                    ])
                    pygame.draw.polygon(surface, (30, 30, 30), [
                        (px, py),
                        (px + rock_size, py + rock_size),
                        (px - rock_size, py + rock_size),
                    ], 1)
            else:
                # Grass cells (non-path, non-blocked)
                pygame.draw.rect(surface, grass_color, (x0, y0, ts, ts))

            # Grid outline
            pygame.draw.rect(surface, (0, 0, 0), (x0, y0, ts, ts), theme.BORDER_THIN)

    # Draw path tube dashed lines
    _draw_path_tube(surface, path_set, ts)

    # Draw animated direction arrows
    _draw_path_direction_arrows(surface, path, ts)

    # Draw spawn and goal markers at entry/exit edge (not center) to avoid
    # overlapping interior pixels used by terrain texture checks.
    if path:
        spawn_cell = path[0]
        sx0 = spawn_cell[0] * ts
        sy0 = spawn_cell[1] * ts
        scx = sx0 + ts // 2
        scy = sy0 + ts // 2
        half = max(3, ts // 6)

        if len(path) > 1:
            next_cell = path[1]
            dx = next_cell[0] - spawn_cell[0]
            dy = next_cell[1] - spawn_cell[1]
            length = (dx * dx + dy * dy) ** 0.5
            if length > 0:
                ux, uy = dx / length, dy / length
                # Anchor at entry edge (opposite of travel direction)
                ax = int(scx - ux * (ts // 2 - half))
                ay = int(scy - uy * (ts // 2 - half))
                tip_x = int(ax + ux * half * 2)
                tip_y = int(ay + uy * half * 2)
                lx = int(ax - uy * half)
                ly = int(ay + ux * half)
                rx = int(ax + uy * half)
                ry = int(ay - ux * half)
                pygame.draw.polygon(surface, theme.EVENT_POSITIVE,
                                    [(tip_x, tip_y), (lx, ly), (rx, ry)])

        goal_cell = path[-1]
        gx0 = goal_cell[0] * ts
        gy0 = goal_cell[1] * ts
        gcx = gx0 + ts // 2
        gcy = gy0 + ts // 2
        if len(path) > 1:
            prev_cell = path[-2]
            dx = goal_cell[0] - prev_cell[0]
            dy = goal_cell[1] - prev_cell[1]
            length = (dx * dx + dy * dy) ** 0.5
            if length > 0:
                ux, uy = dx / length, dy / length
                # Anchor at exit edge (travel direction side)
                ax = int(gcx + ux * (ts // 2 - half))
                ay = int(gcy + uy * (ts // 2 - half))
                tip_x = int(ax + ux * half * 2)
                tip_y = int(ay + uy * half * 2)
                lx = int(ax - uy * half)
                ly = int(ay + ux * half)
                rx = int(ax + uy * half)
                ry = int(ay - ux * half)
                pygame.draw.polygon(surface, theme.EVENT_NEGATIVE,
                                    [(tip_x, tip_y), (lx, ly), (rx, ry)])
