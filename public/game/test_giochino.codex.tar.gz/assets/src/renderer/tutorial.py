from __future__ import annotations

import textwrap

import pygame


def draw_tutorial_step(
    surface: pygame.Surface,
    step: dict,
    font: pygame.font.Font,
    font_small: pygame.font.Font,
) -> tuple[pygame.Rect, pygame.Rect]:
    screen_w = surface.get_width()
    screen_h = surface.get_height()

    overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 120))

    highlight = str(step.get("highlight", "") or "")
    highlight_map = {
        "shop": pygame.Rect(max(16, screen_w - 240), max(80, screen_h // 2 - 110), 190, 92),
        "map": pygame.Rect(20, max(80, screen_h // 2 - 110), 180, 92),
        "wave_btn": pygame.Rect(max(16, screen_w - 180), max(16, screen_h - 150), 150, 78),
    }
    hl_rect = highlight_map.get(highlight)
    if hl_rect is not None:
        pygame.draw.rect(overlay, (100, 150, 255, 70), hl_rect, border_radius=10)
        pygame.draw.rect(overlay, (100, 150, 255, 150), hl_rect, 2, border_radius=10)

    surface.blit(overlay, (0, 0))

    panel_w = 380
    panel_h = 130
    panel_x = screen_w // 2 - panel_w // 2
    panel_y = max(8, screen_h - panel_h - 16)
    panel = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
    panel.fill((20, 20, 30, 220))
    pygame.draw.rect(panel, (100, 150, 255), panel.get_rect(), 2, border_radius=10)

    icon_surf = font.render("TIP", True, (235, 245, 255))
    title = str(step.get("title", "") or "Tutorial")
    title_surf = font.render(title, True, (245, 250, 255))
    panel.blit(icon_surf, (14, 10))
    panel.blit(title_surf, (52, 10))

    index = step.get("index")
    total = step.get("total")
    try:
        index_num = int(index) if index is not None else 1
    except (TypeError, ValueError):
        index_num = 1
    try:
        total_num = int(total) if total is not None else 4
    except (TypeError, ValueError):
        total_num = 4
    indicator = font_small.render(f"step {index_num}/{total_num}", True, (160, 180, 210))
    panel.blit(indicator, (panel_w - indicator.get_width() - 14, 12))

    body_text = str(step.get("text", "") or "")
    wrapped = textwrap.wrap(body_text, width=45) if body_text else []
    body_y = 42
    body_line_h = max(14, font_small.get_linesize())
    for line in wrapped[:3]:
        line_surf = font_small.render(line, True, (220, 225, 235))
        panel.blit(line_surf, (14, body_y))
        body_y += body_line_h

    btn_y = panel_h - 34
    btn_skip_local = pygame.Rect(14, btn_y, 84, 24)
    pygame.draw.rect(panel, (70, 80, 105), btn_skip_local, border_radius=4)
    pygame.draw.rect(panel, (120, 140, 170), btn_skip_local, 1, border_radius=4)
    skip_lbl = font_small.render("Salta", True, (235, 240, 250))
    panel.blit(
        skip_lbl,
        (btn_skip_local.centerx - skip_lbl.get_width() // 2, btn_skip_local.centery - skip_lbl.get_height() // 2),
    )

    btn_next_local = pygame.Rect(panel_w - 98, btn_y, 84, 24)
    if str(step.get("advance", "")) == "button":
        pygame.draw.rect(panel, (50, 110, 175), btn_next_local, border_radius=4)
        pygame.draw.rect(panel, (120, 180, 255), btn_next_local, 1, border_radius=4)
        next_lbl = font_small.render("Avanti", True, (245, 250, 255))
        panel.blit(
            next_lbl,
            (btn_next_local.centerx - next_lbl.get_width() // 2, btn_next_local.centery - next_lbl.get_height() // 2),
        )
    else:
        btn_next_local = pygame.Rect(-1000, -1000, 0, 0)

    surface.blit(panel, (panel_x, panel_y))
    return btn_next_local.move(panel_x, panel_y), btn_skip_local.move(panel_x, panel_y)
