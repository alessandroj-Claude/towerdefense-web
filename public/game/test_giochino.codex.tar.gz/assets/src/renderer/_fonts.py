from __future__ import annotations
"""Centralized font manager — replaces 5 module-level globals in renderer."""
import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass
from typing import Optional
from src import theme

_FONT_FAMILIES = (
    "Helvetica Neue",
    "Avenir Next",
    "SF Pro Text",
    "Verdana",
    "DejaVu Sans",
    "Arial",
)


class FontManager:
    def __init__(self):
        self._cache: dict = {}
        self._font_name_cache: dict[bool, Optional[str]] = {}

    def clear(self) -> None:
        self._cache.clear()
        self._font_name_cache.clear()

    def _font_name(self, bold: bool) -> Optional[str]:
        if bold in self._font_name_cache:
            return self._font_name_cache[bold]
        for family in _FONT_FAMILIES:
            path = pygame.font.match_font(family, bold=bold)
            if path:
                self._font_name_cache[bold] = family
                return family
        self._font_name_cache[bold] = None
        return None

    def get(self, size: int, bold: bool = False) -> pygame.font.Font:
        key = (size, bold)
        if key not in self._cache:
            font_name = self._font_name(bold)
            self._cache[key] = pygame.font.SysFont(font_name, size, bold=bold)
        return self._cache[key]

    def hud(self) -> pygame.font.Font:
        return self.get(theme.FONT_HUD)

    def panel(self) -> pygame.font.Font:
        return self.get(theme.FONT_PANEL)

    def tooltip(self) -> pygame.font.Font:
        return self.get(theme.FONT_TOOLTIP)

    def menu(self) -> pygame.font.Font:
        return self.get(theme.FONT_MENU)

    def label(self) -> pygame.font.Font:
        return self.get(theme.FONT_LABEL)

    def sized(self, size: int) -> pygame.font.Font:
        return self.get(size)

    def sized_bold(self, size: int) -> pygame.font.Font:
        return self.get(size, bold=True)


fonts = FontManager()
