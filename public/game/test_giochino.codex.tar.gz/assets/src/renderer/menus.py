from __future__ import annotations
"""Menu/profile/analytics rendering functions extracted from legacy renderer."""

from typing import Optional

import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass

from src import theme
from src.renderer._fonts import fonts


def _get_difficulty_title_font():
    return pygame.font.SysFont("Arial", 36)


def _get_profile_title_font():
    return pygame.font.SysFont("Arial", 28, bold=True)


def _get_input_font():
    return pygame.font.SysFont("Arial", 18)


def _get_small_font():
    return fonts.sized(14)


def _wrap_text_to_width(text: str, font: pygame.font.Font, max_width: int) -> list[str]:
    words = text.split()
    if not words:
        return []
    lines: list[str] = []
    current = words[0]
    for word in words[1:]:
        candidate = f"{current} {word}"
        if font.size(candidate)[0] <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


def draw_adaptive_rationale(
    surface: pygame.Surface,
    font: pygame.font.Font,
    text: str,
    x: int,
    y: int,
) -> None:
    if not text:
        return
    color = theme.TEXT_PRIMARY
    surf = font.render(text, True, color)
    surface.blit(surf, (x, y))


def _leaderboard_rows_for_difficulty(rows_by_difficulty, difficulty: str) -> list[dict]:
    if isinstance(rows_by_difficulty, dict):
        rows = rows_by_difficulty.get(difficulty, [])
    else:
        rows = rows_by_difficulty or []
    return list(rows)


def _draw_split_leaderboard_panels(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    start_y: int,
    global_rows_by_difficulty,
    user_rows_by_difficulty,
    version_filter: str,
    runtime_version: str,
) -> dict:
    title = font.render(
        f"Leaderboard ({'current' if version_filter == 'current' else 'all'}) - v={runtime_version}",
        True,
        theme.ACCENT,
    )
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, start_y))

    panel_top = start_y + max(28, title.get_height() + 10)
    left_margin = 20
    gap_v = 8
    panel_w = screen_w - left_margin * 2
    panel_h = 146
    row_step = 16
    row_y_offset = 52

    section_rects = {}
    for idx, difficulty in enumerate(("easy", "normal", "hard")):
        panel_x = left_margin
        panel_rect = pygame.Rect(panel_x, panel_top + idx * (panel_h + gap_v), panel_w, panel_h)
        pygame.draw.rect(surface, (*theme.PANEL_BG, 216), panel_rect, border_radius=12)
        pygame.draw.rect(surface, (*theme.BUTTON_HOVER, 220), panel_rect, theme.BORDER_MEDIUM, border_radius=12)

        py = panel_rect.y
        diff_title = font.render(difficulty.title(), True, theme.ACCENT)
        surface.blit(diff_title, (panel_x + 12, py + 8))

        g_title = font.render("Global Top 5", True, (255, 240, 180))
        u_title = font.render("Your Top 5", True, (180, 255, 200))
        left_x = panel_x + 12
        right_x = panel_x + panel_w // 2 + 4
        header_y = py + 24
        surface.blit(g_title, (left_x, header_y))
        surface.blit(u_title, (right_x, header_y))

        global_rows = _leaderboard_rows_for_difficulty(global_rows_by_difficulty, difficulty)
        user_rows = _leaderboard_rows_for_difficulty(user_rows_by_difficulty, difficulty)

        for row_idx in range(5):
            if row_idx < len(global_rows):
                row = global_rows[row_idx]
                txt = (
                    f"{row_idx + 1}. {row.get('username', '?')} "
                    f"{row.get('score', 0)} (W{row.get('wave', 0)}) {row.get('version', '-')}"
                )
            else:
                txt = f"{row_idx + 1}. -"
            s = font.render(txt, True, (230, 230, 230))
            surface.blit(s, (left_x, py + row_y_offset + row_idx * row_step))

        for row_idx in range(5):
            if row_idx < len(user_rows):
                row = user_rows[row_idx]
                txt = f"{row_idx + 1}. {row.get('score', 0)} (W{row.get('wave', 0)}) {row.get('version', '-')}"
            else:
                txt = f"{row_idx + 1}. -"
            s = font.render(txt, True, (230, 230, 230))
            surface.blit(s, (right_x, py + row_y_offset + row_idx * row_step))

        section_rects[difficulty] = panel_rect

    return section_rects


def draw_game_over_leaderboards(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    start_y: int,
    global_rows_by_difficulty,
    user_rows_by_difficulty,
    version_filter: str,
    runtime_version: str,
) -> dict:
    return _draw_split_leaderboard_panels(
        surface,
        font,
        screen_w,
        start_y,
        global_rows_by_difficulty,
        user_rows_by_difficulty,
        version_filter,
        runtime_version,
    )


def draw_difficulty_screen(surface: pygame.Surface, font: pygame.font.Font,
                           screen_w: int, screen_h: int) -> dict:
    surface.fill((0, 0, 0))
    title_font = _get_difficulty_title_font()
    title = title_font.render("Seleziona Difficoltà", True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, screen_h // 2 - 120))

    buttons = [
        ("easy", "Facile", (50, 180, 50)),
        ("normal", "Normale", (180, 180, 50)),
        ("hard", "Difficile", (180, 50, 50)),
    ]
    rects = {}
    for i, (key, label, color) in enumerate(buttons):
        btn_w, btn_h = 200, 50
        btn_x = screen_w // 2 - btn_w // 2
        btn_y = screen_h // 2 - 50 + i * 70
        rect = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
        pygame.draw.rect(surface, color, rect, border_radius=8)
        txt = font.render(label, True, theme.TEXT_PRIMARY)
        surface.blit(txt, (rect.centerx - txt.get_width() // 2,
                            rect.centery - txt.get_height() // 2))
        rects[key] = rect
    return rects


def draw_perk_selection_screen(surface: pygame.Surface, font: pygame.font.Font,
                               screen_w: int, screen_h: int, perk_offers: list[dict],
                               selected_ids: set[str], required_choices: int,
                               feedback: str = "") -> dict:
    surface.fill((14, 18, 26))
    title_font = _get_difficulty_title_font()
    title = title_font.render("Select Perks", True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 56))

    subtitle = font.render(
        f"Select {required_choices} perk(s) to start the run",
        True,
        (180, 190, 210),
    )
    surface.blit(subtitle, (screen_w // 2 - subtitle.get_width() // 2, 98))

    card_rects = {}
    card_w, card_h = 320, 200
    gap = 24
    count = len(perk_offers)
    row_w = count * card_w + max(0, count - 1) * gap
    y = 168
    card_positions: list[tuple[int, int]] = []
    if row_w > screen_w - 48:
        cols = 2
        rows = (count + cols - 1) // cols
        grid_w = cols * card_w + (cols - 1) * gap
        grid_h = rows * card_h + max(0, rows - 1) * gap
        start_x = screen_w // 2 - grid_w // 2
        start_y = y
        for idx in range(count):
            col_idx = idx % cols
            row_idx = idx // cols
            card_x = start_x + col_idx * (card_w + gap)
            card_y = start_y + row_idx * (card_h + gap)
            card_positions.append((card_x, card_y))
        last_row_y = start_y + (rows - 1) * (card_h + gap)
        confirm_y = last_row_y + card_h + 34
    else:
        start_x = screen_w // 2 - row_w // 2
        for idx in range(count):
            card_positions.append((start_x + idx * (card_w + gap), y))
        confirm_y = y + card_h + 34

    for idx, perk in enumerate(perk_offers):
        perk_id = str(perk.get("id", f"perk_{idx}"))
        label = str(perk.get("label", perk_id))
        description = str(perk.get("description", ""))
        card_x, card_y = card_positions[idx]
        rect = pygame.Rect(card_x, card_y, card_w, card_h)
        selected = perk_id in selected_ids
        bg = (60, 92, 130) if selected else (36, 42, 56)
        border = (140, 210, 255) if selected else (90, 110, 130)
        pygame.draw.rect(surface, bg, rect, border_radius=10)
        pygame.draw.rect(surface, border, rect, theme.BORDER_MEDIUM, border_radius=10)

        label_surf = font.render(label, True, (245, 245, 245))
        surface.blit(label_surf, (rect.x + 12, rect.y + 14))
        desc_font = _get_small_font()
        desc_box = pygame.Rect(rect.x + 14, rect.y + 60, rect.width - 28, rect.height - 78)
        wrapped = _wrap_text_to_width(description, desc_font, desc_box.width)
        line_h = max(18, desc_font.get_linesize())
        max_lines = max(1, desc_box.height // max(1, line_h))
        for line_idx, line in enumerate(wrapped[:max_lines]):
            line_surf = desc_font.render(line, True, (230, 235, 240))
            line_y = desc_box.y + line_idx * line_h
            surface.blit(line_surf, (desc_box.x, line_y))
        card_rects[perk_id] = rect

    can_confirm = len(selected_ids) == required_choices
    confirm_rect = pygame.Rect(screen_w // 2 - 110, confirm_y, 220, 46)
    confirm_bg = (46, 128, 66) if can_confirm else (78, 78, 78)
    confirm_border = (120, 220, 145) if can_confirm else (130, 130, 130)
    pygame.draw.rect(surface, confirm_bg, confirm_rect, border_radius=8)
    pygame.draw.rect(surface, confirm_border, confirm_rect, theme.BORDER_MEDIUM, border_radius=8)
    confirm_txt = font.render("Confirm", True, (250, 250, 250))
    surface.blit(
        confirm_txt,
        (confirm_rect.centerx - confirm_txt.get_width() // 2,
         confirm_rect.centery - confirm_txt.get_height() // 2),
    )

    if feedback:
        fb = font.render(feedback, True, (255, 170, 120))
        surface.blit(fb, (screen_w // 2 - fb.get_width() // 2, confirm_rect.y + 60))

    return {"cards": card_rects, "confirm": confirm_rect}


def render_profile_identify(surface: pygame.Surface, username: str,
                            screen_w: int, screen_h: int,
                            error: str = "") -> None:
    surface.fill(theme.BACKGROUND)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render("BENVENUTO", True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 80))

    sub = font.render("Inserisci username", True, (180, 200, 230))
    surface.blit(sub, (screen_w // 2 - sub.get_width() // 2, 150))

    box_w = 360
    r = pygame.Rect(screen_w // 2 - box_w // 2, 200, box_w, 40)
    pygame.draw.rect(surface, theme.PANEL_BG, r, border_radius=4)
    pygame.draw.rect(surface, theme.ACCENT, r, theme.BORDER_MEDIUM, border_radius=4)
    txt = font.render(username, True, (230, 230, 230))
    surface.blit(txt, (r.x + 10, r.centery - txt.get_height() // 2))

    hint = font.render("ENTER: continua", True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 80))
    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, 280))


def render_profile_select(surface: pygame.Surface, usernames: list,
                          screen_w: int, screen_h: int) -> dict:
    surface.fill(theme.BACKGROUND)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render("SELEZIONA PROFILO", True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 60))

    rects = {}
    btn_w, btn_h = 300, 44
    start_y = 140
    for i, name in enumerate(usernames):
        r = pygame.Rect(screen_w // 2 - btn_w // 2, start_y + i * 56, btn_w, btn_h)
        pygame.draw.rect(surface, (50, 70, 100), r, border_radius=6)
        pygame.draw.rect(surface, (100, 140, 200), r, theme.BORDER_MEDIUM, border_radius=6)
        lbl = font.render(name, True, (230, 230, 230))
        surface.blit(lbl, (r.centerx - lbl.get_width() // 2,
                           r.centery - lbl.get_height() // 2))
        rects[name] = r

    new_r = pygame.Rect(screen_w // 2 - btn_w // 2,
                        start_y + len(usernames) * 56 + 20, btn_w, btn_h)
    pygame.draw.rect(surface, (40, 100, 60), new_r, border_radius=6)
    pygame.draw.rect(surface, (80, 180, 100), new_r, theme.BORDER_MEDIUM, border_radius=6)
    lbl = font.render("+ Nuovo Profilo", True, (200, 255, 200))
    surface.blit(lbl, (new_r.centerx - lbl.get_width() // 2,
                       new_r.centery - lbl.get_height() // 2))
    rects["__new__"] = new_r
    return rects


def render_profile_create(surface: pygame.Surface, username: str,
                          password_len: int, screen_w: int, screen_h: int,
                          active_field: str = "username",
                          error: str = "") -> None:
    surface.fill(theme.BACKGROUND)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render("NUOVO PROFILO", True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 80))

    box_w = 320
    fields = [("Username", username, "username"), ("Password", "*" * password_len, "password")]
    for i, (label, value, field) in enumerate(fields):
        by = 180 + i * 90
        lbl = font.render(label, True, (180, 180, 180))
        surface.blit(lbl, (screen_w // 2 - box_w // 2, by - 22))
        border = theme.ACCENT if active_field == field else (80, 80, 120)
        r = pygame.Rect(screen_w // 2 - box_w // 2, by, box_w, 36)
        pygame.draw.rect(surface, theme.PANEL_BG, r, border_radius=4)
        pygame.draw.rect(surface, border, r, theme.BORDER_MEDIUM, border_radius=4)
        txt = font.render(value, True, (230, 230, 230))
        surface.blit(txt, (r.x + 8, r.centery - txt.get_height() // 2))

    hint = font.render("ENTER: crea account   ESC: indietro",
                       True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 80))
    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, 380))


def render_profile_login(surface: pygame.Surface, username: str,
                         password_len: int, screen_w: int, screen_h: int,
                         error: str = "") -> None:
    surface.fill(theme.BACKGROUND)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render("LOGIN", True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 80))

    uname = font.render(f"Utente: {username}", True, (180, 200, 230))
    surface.blit(uname, (screen_w // 2 - uname.get_width() // 2, 160))

    box_w = 320
    by = 220
    lbl = font.render("Password", True, (180, 180, 180))
    surface.blit(lbl, (screen_w // 2 - box_w // 2, by - 22))
    r = pygame.Rect(screen_w // 2 - box_w // 2, by, box_w, 36)
    pygame.draw.rect(surface, theme.PANEL_BG, r, border_radius=4)
    pygame.draw.rect(surface, theme.ACCENT, r, theme.BORDER_MEDIUM, border_radius=4)
    txt = font.render("*" * password_len, True, (230, 230, 230))
    surface.blit(txt, (r.x + 8, r.centery - txt.get_height() // 2))

    hint = font.render("ENTER: accedi   ESC: indietro", True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 80))
    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, 300))


def render_dlc_menu(surface: pygame.Surface, dlcs: dict,
                    user_dlcs: set, screen_w: int, screen_h: int,
                    error: str = "") -> dict:
    surface.fill(theme.BACKGROUND)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render("DLC", True, theme.GOLD_COLOR)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 60))

    rects = {}
    btn_w, btn_h = 360, 52
    start_y = 140
    for i, (dlc_id, dlc_name) in enumerate(dlcs.items()):
        unlocked = dlc_id in user_dlcs
        r = pygame.Rect(screen_w // 2 - btn_w // 2, start_y + i * 70, btn_w, btn_h)
        pygame.draw.rect(surface, (40, 80, 40) if unlocked else (50, 40, 40), r,
                         border_radius=6)
        pygame.draw.rect(surface, (80, 180, 80) if unlocked else (120, 80, 80), r, theme.BORDER_MEDIUM,
                         border_radius=6)
        icon = "[OK]" if unlocked else "[  ]"
        lbl = font.render(f"{icon} {dlc_name}", True,
                          (200, 255, 200) if unlocked else (220, 180, 180))
        surface.blit(lbl, (r.x + 14, r.centery - lbl.get_height() // 2))
        rects[dlc_id] = r

    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2,
                           start_y + len(dlcs) * 70 + 10))
    hint = font.render("ESC: menu principale", True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 60))
    return rects


def render_key_input(surface: pygame.Surface, dlc_name: str, key_text: str,
                     screen_w: int, screen_h: int, error: str = "") -> pygame.Rect:
    overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    surface.blit(overlay, (0, 0))

    font_t = _get_profile_title_font()
    font = _get_input_font()
    box_w, box_h = 500, 250
    bx = screen_w // 2 - box_w // 2
    by = screen_h // 2 - box_h // 2
    pygame.draw.rect(surface, theme.PANEL_BG, (bx, by, box_w, box_h), border_radius=10)
    pygame.draw.rect(surface, (100, 100, 180), (bx, by, box_w, box_h), theme.BORDER_MEDIUM, border_radius=10)

    title = font_t.render(f"Attiva: {dlc_name}", True, theme.GOLD_COLOR)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, by + 20))

    lbl = font.render("Inserisci chiave:", True, (180, 180, 180))
    surface.blit(lbl, (bx + 20, by + 70))
    inp_r = pygame.Rect(bx + 20, by + 96, box_w - 40, 36)
    pygame.draw.rect(surface, (20, 20, 40), inp_r, border_radius=4)
    pygame.draw.rect(surface, theme.ACCENT, inp_r, theme.BORDER_MEDIUM, border_radius=4)
    key_surf = font.render(key_text, True, (230, 230, 230))
    surface.blit(key_surf, (inp_r.x + 8, inp_r.centery - key_surf.get_height() // 2))

    paste_r = pygame.Rect(inp_r.right - 90, inp_r.y + 3, 80, 30)
    pygame.draw.rect(surface, (50, 70, 110), paste_r, border_radius=6)
    pygame.draw.rect(surface, (120, 160, 220), paste_r, theme.BORDER_MEDIUM, border_radius=6)
    paste_lbl = font.render("PASTE", True, (230, 238, 255))
    surface.blit(
        paste_lbl,
        (paste_r.centerx - paste_lbl.get_width() // 2, paste_r.centery - paste_lbl.get_height() // 2),
    )

    hint = font.render("ENTER: attiva   PASTE: incolla   ESC: annulla", True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, by + 188))
    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, by + 214))
    return paste_r


def render_admin_panel(surface: pygame.Surface,
                       user_records: list[tuple[int, str]],
                       selected_user_id: Optional[int],
                       selected_user_dlcs: set[str],
                       dlcs: dict[str, str],
                       screen_w: int, screen_h: int,
                       message: str = "") -> tuple[dict[int, pygame.Rect], dict[str, pygame.Rect], pygame.Rect]:
    surface.fill((18, 18, 30))
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render("ADMIN PANEL", True, theme.GOLD_COLOR)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 24))

    left_x = 60
    top_y = 90
    col_w = 360
    row_h = 42
    user_rects: dict[int, pygame.Rect] = {}

    lbl_users = font.render("Utenti", True, (180, 180, 220))
    surface.blit(lbl_users, (left_x, top_y - 28))
    for i, (uid, username) in enumerate(user_records):
        r = pygame.Rect(left_x, top_y + i * (row_h + 8), col_w, row_h)
        selected = uid == selected_user_id
        pygame.draw.rect(surface, (60, 80, 130) if selected else (45, 55, 80),
                         r, border_radius=6)
        pygame.draw.rect(surface, (130, 170, 230) if selected else (80, 100, 140),
                         r, theme.BORDER_MEDIUM, border_radius=6)
        txt = font.render(f"{username} (id:{uid})", True, (230, 230, 240))
        surface.blit(txt, (r.x + 10, r.centery - txt.get_height() // 2))
        user_rects[uid] = r

    right_x = 500
    dlc_rects: dict[str, pygame.Rect] = {}
    lbl_dlc = font.render("DLC (click per ON/OFF)", True, (180, 180, 220))
    surface.blit(lbl_dlc, (right_x, top_y - 28))
    for i, (dlc_id, dlc_name) in enumerate(dlcs.items()):
        unlocked = dlc_id in selected_user_dlcs
        r = pygame.Rect(right_x, top_y + i * 64, 380, 50)
        bg = (35, 95, 55) if unlocked else (95, 45, 45)
        border = (90, 200, 130) if unlocked else (210, 100, 100)
        pygame.draw.rect(surface, bg, r, border_radius=6)
        pygame.draw.rect(surface, border, r, theme.BORDER_MEDIUM, border_radius=6)
        state = "ON" if unlocked else "OFF"
        txt = font.render(f"[{state}] {dlc_name}", True, (235, 235, 235))
        surface.blit(txt, (r.x + 12, r.centery - txt.get_height() // 2))
        dlc_rects[dlc_id] = r

    delete_rect = pygame.Rect(right_x, top_y + max(2, len(dlcs)) * 64 + 12, 380, 46)
    pygame.draw.rect(surface, (115, 40, 40), delete_rect, border_radius=6)
    pygame.draw.rect(surface, (220, 110, 110), delete_rect, theme.BORDER_MEDIUM, border_radius=6)
    del_txt = font.render("Disattiva utente selezionato", True, (245, 230, 230))
    surface.blit(del_txt, (delete_rect.centerx - del_txt.get_width() // 2,
                           delete_rect.centery - del_txt.get_height() // 2))

    hint = font.render("ESC: menu principale", True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 50))
    if message:
        msg = font.render(message, True, (255, 220, 130))
        surface.blit(msg, (screen_w // 2 - msg.get_width() // 2, screen_h - 90))
    return user_rects, dlc_rects, delete_rect


def draw_wave_report(
    surface: pygame.Surface,
    font: pygame.font.Font,
    report,
    x: int,
    y: int,
) -> None:
    if not report:
        return

    title_font = font
    body_font = _get_small_font()
    accent = theme.ACCENT
    panel_bg = theme.PANEL_BG
    panel_border = theme.BUTTON_HOVER
    text_primary = theme.TEXT_PRIMARY
    text_secondary = theme.TEXT_SECONDARY
    stat_fill = theme.GRID
    stat_border = theme.BUTTON_DEFAULT

    dmg = report.get("damage_by_type", {}) or {}
    rows = [
        ("Wave", str(report.get("wave", "?")), accent),
        ("Flying kills", str(report.get("flying_kills", 0)), theme.ENEMY_FLYING),
        ("Lives lost", str(report.get("lives_lost", 0)), theme.EVENT_NEGATIVE),
        ("Gold earned", str(report.get("gold_earned", 0)), theme.HP_MED),
    ]

    title_surf = title_font.render(f"Wave {report.get('wave', '?')} Report", True, accent)
    stat_surfaces = [(label, value, color, body_font.render(value, True, color)) for label, value, color in rows]
    damage_items = []
    for ttype, dmg_val in dmg.items():
        value = int(dmg_val) if isinstance(dmg_val, (int, float)) else dmg_val
        damage_items.append((str(ttype), value))

    inner_pad = 12
    row_h = 22
    dmg_row_h = 20
    width_candidates = [title_surf.get_width()]
    width_candidates.extend(
        body_font.render(f"{label}", True, text_secondary).get_width() + 100 for label, *_ in rows
    )
    if damage_items:
        width_candidates.extend(
            body_font.render(f"{ttype}", True, text_primary).get_width() + 72 for ttype, _ in damage_items
        )
    bg_w = max(240, min(surface.get_width() - x - 8, max(width_candidates) + inner_pad * 2 + 12))
    bg_h = inner_pad * 2 + 28 + len(rows) * (row_h + 4) + (len(damage_items) * (dmg_row_h + 3) + 6 if damage_items else 0)

    panel = pygame.Surface((bg_w, bg_h), pygame.SRCALPHA)
    panel.fill((*panel_bg, 214))
    pygame.draw.rect(panel, (*panel_border, 220), (0, 0, bg_w, bg_h), theme.BORDER_MEDIUM, border_radius=12)

    panel.blit(title_surf, (inner_pad, 10))
    subtitle = body_font.render("Post-wave summary", True, text_secondary)
    panel.blit(subtitle, (bg_w - inner_pad - subtitle.get_width(), 12))

    row_y = 36
    for label, value, color, value_surf in stat_surfaces:
        row_rect = pygame.Rect(inner_pad, row_y, bg_w - inner_pad * 2, row_h)
        pygame.draw.rect(panel, (*stat_fill, 220), row_rect, border_radius=8)
        pygame.draw.rect(panel, (*stat_border, 180), row_rect, theme.BORDER_THIN, border_radius=8)

        label_surf = body_font.render(label, True, text_secondary)
        panel.blit(label_surf, (row_rect.x + 8, row_rect.centery - label_surf.get_height() // 2))
        pill_w = value_surf.get_width() + 12
        pill = pygame.Surface((pill_w, row_h - 6), pygame.SRCALPHA)
        pill.fill((*color, 65))
        pygame.draw.rect(pill, (*color, 150), (0, 0, pill_w, row_h - 6), theme.BORDER_THIN, border_radius=8)
        pill.blit(value_surf, (6, pill.get_height() // 2 - value_surf.get_height() // 2))
        panel.blit(pill, (row_rect.right - pill_w - 8, row_rect.y + 3))
        row_y += row_h + 4

    if damage_items:
        section_y = row_y + 2
        section_label = body_font.render("Damage by type", True, accent)
        panel.blit(section_label, (inner_pad, section_y))
        section_y += 18
        damage_total = sum(value for _, value in damage_items) or 1
        enemy_colors = {
            "BasicEnemy": theme.ENEMY_BASIC,
            "FastEnemy": theme.ENEMY_FAST,
            "TankEnemy": theme.ENEMY_TANK,
            "SwarmEnemy": theme.HP_MED,
            "FlyingEnemy": theme.ENEMY_FLYING,
            "HeavyEnemy": theme.ENEMY_HEAVY,
            "BossEnemy": theme.ENEMY_BOSS,
        }
        for ttype, dmg_val in damage_items:
            color = enemy_colors.get(ttype, accent)
            row_rect = pygame.Rect(inner_pad, section_y, bg_w - inner_pad * 2, dmg_row_h)
            pygame.draw.rect(panel, (*theme.BACKGROUND, 90), row_rect, border_radius=8)
            bar_w = max(18, int((int(dmg_val) / damage_total) * (row_rect.width - 116)))
            pygame.draw.rect(panel, (*color, 220), (row_rect.x + 8, row_rect.y + 4, bar_w, dmg_row_h - 8), border_radius=6)
            pygame.draw.rect(panel, (*color, 180), row_rect, theme.BORDER_THIN, border_radius=8)
            name_surf = body_font.render(ttype, True, text_primary)
            value_surf = body_font.render(str(dmg_val), True, text_primary)
            panel.blit(name_surf, (row_rect.x + 12, row_rect.centery - name_surf.get_height() // 2))
            panel.blit(value_surf, (row_rect.right - value_surf.get_width() - 10, row_rect.centery - value_surf.get_height() // 2))
            section_y += dmg_row_h + 3

    surface.blit(panel, (x, y))


def draw_analytics_screen(
    surface: pygame.Surface,
    top_runs: list[dict],
    font: pygame.font.Font,
    screen_w: int,
    screen_h: int,
    leaderboard_global_by_difficulty=None,
    leaderboard_user_by_difficulty=None,
    leaderboard_filter: str = "all",
    runtime_version: str = "",
) -> dict:
    if top_runs is None:
        top_runs = []

    surface.fill(theme.BACKGROUND)

    title_font = _get_difficulty_title_font()
    small_font = fonts.sized(14)
    header_font = fonts.sized_bold(14)
    accent = theme.ACCENT
    panel_bg = theme.PANEL_BG
    panel_border = theme.BUTTON_HOVER
    text_primary = theme.TEXT_PRIMARY
    text_secondary = theme.TEXT_SECONDARY
    title = title_font.render("Analytics - Top Runs", True, accent)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 20))

    content_x = 32
    content_y = 76
    content_w = screen_w - 64
    content_h = screen_h - content_y - 92
    panel = pygame.Surface((content_w, content_h), pygame.SRCALPHA)
    panel.fill((*panel_bg, 214))
    pygame.draw.rect(panel, (*panel_border, 220), (0, 0, content_w, content_h), theme.BORDER_MEDIUM, border_radius=16)
    panel.blit(small_font.render("Top runs overview", True, text_secondary), (16, 12))

    table_y = 44
    headers = ["Wave", "Score", "Difficulty", "Date"]
    col_x_positions = [16, 116, 236, 356]

    for header, x in zip(headers, col_x_positions):
        h_surf = header_font.render(header, True, text_secondary)
        panel.blit(h_surf, (x, table_y))

    row_y = table_y + 24
    for run in top_runs[:5]:
        wave_max = run.get("wave_max", 0)
        score = run.get("final_score", 0)
        difficulty = run.get("difficulty", "N/A")
        timestamp = run.get("timestamp", "")
        date_str = timestamp.split("T")[0] if timestamp else "N/A"

        row_rect = pygame.Rect(12, row_y - 2, content_w - 24, 20)
        pygame.draw.rect(panel, (*theme.GRID, 180), row_rect, border_radius=8)
        pygame.draw.rect(panel, (*theme.BUTTON_DEFAULT, 180), row_rect, theme.BORDER_THIN, border_radius=8)

        wave_text = small_font.render(str(wave_max), True, text_primary)
        score_text = small_font.render(str(score), True, theme.HP_MED)
        diff_text = small_font.render(difficulty, True, text_secondary)
        date_text = small_font.render(date_str, True, text_secondary)

        panel.blit(wave_text, (col_x_positions[0], row_y))
        panel.blit(score_text, (col_x_positions[1], row_y))
        panel.blit(diff_text, (col_x_positions[2], row_y))
        panel.blit(date_text, (col_x_positions[3], row_y))

        row_y += 22

    leaderboard_top = row_y + 12
    if top_runs:
        first_run = top_runs[0]
        kills_by_type = first_run.get("kills_by_type", {})

        if kills_by_type:
            chart_y = row_y + 30
            chart_title = small_font.render("Kills by Type (Top Run)", True, accent)
            panel.blit(chart_title, (16, chart_y))

            chart_y += 20
            bar_h = 14
            bar_gap = 4
            max_kills = max(kills_by_type.values()) if kills_by_type else 1
            max_kills = max(1, max_kills)
            chart_x_start = 16
            bar_width_scale = max(180, content_w - 220)
            enemy_colors = {
                "BasicEnemy": theme.ENEMY_BASIC,
                "FastEnemy": theme.ENEMY_FAST,
                "TankEnemy": theme.ENEMY_TANK,
                "SwarmEnemy": theme.HP_MED,
                "FlyingEnemy": theme.ENEMY_FLYING,
                "HeavyEnemy": theme.ENEMY_HEAVY,
                "BossEnemy": theme.ENEMY_BOSS,
            }

            for enemy_type, kill_count in sorted(kills_by_type.items()):
                bar_color = enemy_colors.get(enemy_type, theme.ACCENT)
                label = small_font.render(f"{enemy_type}: {kill_count}", True, text_primary)
                panel.blit(label, (chart_x_start, chart_y))

                bar_w = int((kill_count / max_kills) * bar_width_scale) if max_kills > 0 else 10
                bar_x = chart_x_start + 154
                bar_rect = pygame.Rect(bar_x, chart_y, bar_w, bar_h)
                pygame.draw.rect(panel, (*bar_color, 220), bar_rect, border_radius=6)
                pygame.draw.rect(panel, (*bar_color, 180), bar_rect, theme.BORDER_THIN, border_radius=6)

                chart_y += bar_h + bar_gap

            leaderboard_top = chart_y + 30

    leaderboard_rects = _draw_split_leaderboard_panels(
        panel,
        small_font,
        content_w,
        leaderboard_top,
        leaderboard_global_by_difficulty or {},
        leaderboard_user_by_difficulty or {},
        leaderboard_filter,
        runtime_version,
    )

    surface.blit(panel, (content_x, content_y))

    back_btn_w, back_btn_h = 120, 36
    back_btn_x = screen_w // 2 - back_btn_w // 2
    back_btn_y = screen_h - 60
    back_rect = pygame.Rect(back_btn_x, back_btn_y, back_btn_w, back_btn_h)
    pygame.draw.rect(surface, theme.BUTTON_DEFAULT, back_rect, border_radius=6)
    pygame.draw.rect(surface, (120, 140, 160), back_rect, theme.BORDER_MEDIUM, border_radius=6)
    back_lbl = font.render("Back", True, (220, 230, 255))
    surface.blit(back_lbl, (back_rect.centerx - back_lbl.get_width() // 2,
                            back_rect.centery - back_lbl.get_height() // 2))

    result = {"back": back_rect}
    result.update({f"leaderboard_{difficulty}": rect for difficulty, rect in leaderboard_rects.items()})
    return result


def render_web_loading(surface: pygame.Surface, msg: str) -> None:
    w, h = surface.get_size()
    overlay = pygame.Surface((w, h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    surface.blit(overlay, (0, 0))
    font = pygame.font.SysFont(None, 36)
    text = font.render(msg, True, (220, 220, 220))
    rect = text.get_rect(center=(w // 2, h // 2))
    surface.blit(text, rect)
