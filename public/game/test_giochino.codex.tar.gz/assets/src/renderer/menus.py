from __future__ import annotations
"""Menu/profile/analytics rendering functions extracted from legacy renderer."""

from typing import Optional

import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass

from src import theme, i18n
from src.renderer._fonts import fonts
from src.renderer.tutorial import draw_tutorial_step


def draw_menu_background(surface: pygame.Surface, screen_w: int, screen_h: int) -> None:
    surface.fill(theme.BACKGROUND)
    pitch = 64
    for x in range(0, screen_w + 1, pitch):
        pygame.draw.line(surface, theme.GRID, (x, 0), (x, screen_h), 1)
    for y in range(0, screen_h + 1, pitch):
        pygame.draw.line(surface, theme.GRID, (0, y), (screen_w, y), 1)


def draw_main_menu(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    screen_h: int,
    current_username: str,
    has_save: bool,
    is_admin: bool,
    button_width: int = 360,
) -> dict[str, pygame.Rect]:
    draw_menu_background(surface, screen_w, screen_h)
    font_big = fonts.sized_bold(72)
    title = font_big.render("TOWER DEFENSE", True, (255, 255, 255))
    sub = font.render(i18n.t("loading.press_enter"), True, (180, 180, 180))
    back = fonts.sized(14).render(i18n.t("loading.press_esc_login"), True, (130, 130, 130))
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 150))
    surface.blit(sub, (screen_w // 2 - sub.get_width() // 2, 248))
    surface.blit(back, (screen_w // 2 - back.get_width() // 2, 272))

    btn_h = 54
    menu_btn_top = 380
    center_x = screen_w // 2 - button_width // 2
    draw_font = fonts.sized(20)
    rects: dict[str, pygame.Rect] = {}

    load_r = pygame.Rect(center_x, menu_btn_top, button_width, btn_h)
    if has_save:
        pygame.draw.rect(surface, (40, 100, 60), load_r, border_radius=6)
        pygame.draw.rect(surface, (80, 200, 120), load_r, 2, border_radius=6)
        load_lbl = draw_font.render(i18n.t("menu.load"), True, (220, 255, 220))
    else:
        pygame.draw.rect(surface, (55, 55, 55), load_r, border_radius=6)
        pygame.draw.rect(surface, (110, 110, 110), load_r, 2, border_radius=6)
        load_lbl = draw_font.render(i18n.t("menu.load"), True, (160, 160, 160))
    surface.blit(load_lbl, (load_r.centerx - load_lbl.get_width() // 2, load_r.centery - load_lbl.get_height() // 2))
    rects["load"] = load_r

    dlc_r = pygame.Rect(center_x, menu_btn_top + 80, button_width, btn_h)
    pygame.draw.rect(surface, (60, 50, 100), dlc_r, border_radius=6)
    pygame.draw.rect(surface, (140, 100, 200), dlc_r, 2, border_radius=6)
    dlc_lbl = draw_font.render(i18n.t("menu.dlc"), True, (220, 200, 255))
    surface.blit(dlc_lbl, (dlc_r.centerx - dlc_lbl.get_width() // 2, dlc_r.centery - dlc_lbl.get_height() // 2))
    rects["dlc"] = dlc_r

    analytics_r = pygame.Rect(center_x, menu_btn_top + 160, button_width, btn_h)
    pygame.draw.rect(surface, (80, 70, 40), analytics_r, border_radius=6)
    pygame.draw.rect(surface, (200, 160, 100), analytics_r, 2, border_radius=6)
    analytics_lbl = draw_font.render(i18n.t("menu.analytics"), True, (240, 220, 180))
    surface.blit(
        analytics_lbl,
        (analytics_r.centerx - analytics_lbl.get_width() // 2, analytics_r.centery - analytics_lbl.get_height() // 2),
    )
    rects["analytics"] = analytics_r

    codex_r = pygame.Rect(center_x, menu_btn_top + 240, button_width, btn_h)
    pygame.draw.rect(surface, (20, 80, 90), codex_r, border_radius=6)
    pygame.draw.rect(surface, (60, 200, 220), codex_r, 2, border_radius=6)
    codex_lbl = draw_font.render(i18n.t("menu.codex"), True, (180, 240, 255))
    surface.blit(codex_lbl, (codex_r.centerx - codex_lbl.get_width() // 2, codex_r.centery - codex_lbl.get_height() // 2))
    rects["codex"] = codex_r

    daily_r = pygame.Rect(center_x, menu_btn_top + 320, button_width // 2 - 6, btn_h)
    weekly_r = pygame.Rect(daily_r.right + 12, menu_btn_top + 320, button_width // 2 - 6, btn_h)
    pygame.draw.rect(surface, (36, 92, 130), daily_r, border_radius=6)
    pygame.draw.rect(surface, (110, 190, 240), daily_r, 2, border_radius=6)
    pygame.draw.rect(surface, (80, 50, 120), weekly_r, border_radius=6)
    pygame.draw.rect(surface, (170, 130, 230), weekly_r, 2, border_radius=6)
    daily_lbl = draw_font.render(i18n.t("menu.daily"), True, (220, 245, 255))
    weekly_lbl = draw_font.render(i18n.t("menu.weekly"), True, (235, 220, 255))
    surface.blit(daily_lbl, (daily_r.centerx - daily_lbl.get_width() // 2, daily_r.centery - daily_lbl.get_height() // 2))
    surface.blit(
        weekly_lbl, (weekly_r.centerx - weekly_lbl.get_width() // 2, weekly_r.centery - weekly_lbl.get_height() // 2)
    )
    rects["daily"] = daily_r
    rects["weekly"] = weekly_r

    user_lbl = font.render(i18n.t("menu.user_label").format(username=current_username), True, (180, 220, 255))
    surface.blit(user_lbl, (screen_w // 2 - user_lbl.get_width() // 2, menu_btn_top + 392))

    if is_admin:
        admin_r = pygame.Rect(center_x, menu_btn_top + 428, button_width, btn_h)
        pygame.draw.rect(surface, (80, 60, 30), admin_r, border_radius=6)
        pygame.draw.rect(surface, (200, 160, 80), admin_r, 2, border_radius=6)
        admin_lbl = draw_font.render(i18n.t("menu.admin"), True, (255, 240, 200))
        surface.blit(admin_lbl, (admin_r.centerx - admin_lbl.get_width() // 2, admin_r.centery - admin_lbl.get_height() // 2))
        rects["admin"] = admin_r

    # Language picker — top-right corner
    lang_font = fonts.sized(13)
    btn_w_lang = 34
    btn_h_lang = 26
    lang_gap = 4
    lang_right = screen_w - 14
    lang_top = 14
    active_lang = i18n.current_locale()
    for idx, code in enumerate(("en", "it")):
        lx = lang_right - (2 - idx) * (btn_w_lang + lang_gap)
        lang_r = pygame.Rect(lx, lang_top, btn_w_lang, btn_h_lang)
        is_active = code == active_lang
        bg = (20, 60, 70) if is_active else (12, 20, 28)
        border_col = (60, 200, 220) if is_active else (35, 50, 60)
        border_px = 2 if is_active else 1
        pygame.draw.rect(surface, bg, lang_r, border_radius=4)
        pygame.draw.rect(surface, border_col, lang_r, border_px, border_radius=4)
        txt_col = (220, 240, 255) if is_active else (90, 110, 120)
        lbl = lang_font.render(code.upper(), True, txt_col)
        surface.blit(lbl, (lang_r.centerx - lbl.get_width() // 2, lang_r.centery - lbl.get_height() // 2))
        rects[f"lang_{code}"] = lang_r

    return rects


def _get_difficulty_title_font():
    return pygame.font.SysFont("Arial", 36)


def _get_profile_title_font():
    return fonts.sized_bold(48)


def _get_input_font():
    return fonts.sized(20)


def _get_small_font():
    return fonts.sized(14)


def _wrap_text_to_width(text: str, font: pygame.font.Font, max_width: int) -> list[str]:
    words = text.split()
    if not words:
        return []
    lines: list[str] = []
    current = words[0]
    for word in words[1:]:
        candidate = f"{current} {word}"
        if font.size(candidate)[0] <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


def draw_adaptive_rationale(
    surface: pygame.Surface,
    font: pygame.font.Font,
    text: str,
    x: int,
    y: int,
) -> None:
    if not text:
        return
    color = theme.TEXT_PRIMARY
    surf = font.render(text, True, color)
    surface.blit(surf, (x, y))


def _leaderboard_rows_for_difficulty(rows_by_difficulty, difficulty: str) -> list[dict]:
    if isinstance(rows_by_difficulty, dict):
        rows = rows_by_difficulty.get(difficulty, [])
    else:
        rows = rows_by_difficulty or []
    return list(rows)


def _draw_split_leaderboard_panels(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    start_y: int,
    global_rows_by_difficulty,
    user_rows_by_difficulty,
    version_filter: str,
    runtime_version: str,
) -> dict:
    title = font.render(
        f"Leaderboard ({'current' if version_filter == 'current' else 'all'}) - v={runtime_version}",
        True,
        theme.ACCENT,
    )
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, start_y))

    panel_top = start_y + max(28, title.get_height() + 10)
    left_margin = 20
    gap_v = 8
    panel_w = screen_w - left_margin * 2
    panel_h = 146
    row_step = 16
    row_y_offset = 52

    section_rects = {}
    for idx, difficulty in enumerate(("easy", "normal", "hard")):
        panel_x = left_margin
        panel_rect = pygame.Rect(panel_x, panel_top + idx * (panel_h + gap_v), panel_w, panel_h)
        pygame.draw.rect(surface, (*theme.PANEL_BG, 216), panel_rect, border_radius=12)

        diff_badge_colors = {
            "easy": (100, 200, 100),
            "normal": (230, 200, 50),
            "hard": (220, 80, 80),
        }
        badge_color = diff_badge_colors.get(difficulty, theme.ACCENT)
        pygame.draw.rect(surface, badge_color, panel_rect, theme.BORDER_MEDIUM, border_radius=12)

        py = panel_rect.y
        diff_title = font.render(difficulty.title(), True, badge_color)
        surface.blit(diff_title, (panel_x + 12, py + 8))

        g_title = font.render(i18n.t("leaderboard.global_top5"), True, (255, 240, 180))
        u_title = font.render(i18n.t("leaderboard.your_top5"), True, (180, 255, 200))
        left_x = panel_x + 12
        right_x = panel_x + panel_w // 2 + 4
        header_y = py + 24
        surface.blit(g_title, (left_x, header_y))
        surface.blit(u_title, (right_x, header_y))

        global_rows = _leaderboard_rows_for_difficulty(global_rows_by_difficulty, difficulty)
        user_rows = _leaderboard_rows_for_difficulty(user_rows_by_difficulty, difficulty)

        rank_colors = {
            1: (255, 215, 0),
            2: (192, 192, 192),
            3: (205, 127, 50),
        }

        for row_idx in range(5):
            rank = row_idx + 1
            if row_idx < len(global_rows):
                row = global_rows[row_idx]
                txt = f"{rank}. {row.get('username', '?')} — {row.get('score', 0)}  W{row.get('wave', 0)}"
            else:
                txt = f"{rank}. —"
            color = rank_colors.get(rank, theme.TEXT_SECONDARY)
            s = font.render(txt, True, color)
            surface.blit(s, (left_x, py + row_y_offset + row_idx * row_step))

        for row_idx in range(5):
            rank = row_idx + 1
            if row_idx < len(user_rows):
                row = user_rows[row_idx]
                txt = f"{rank}. {row.get('username', '?')} — {row.get('score', 0)}  W{row.get('wave', 0)}"
            else:
                txt = f"{rank}. —"
            color = rank_colors.get(rank, theme.TEXT_SECONDARY)
            s = font.render(txt, True, color)
            surface.blit(s, (right_x, py + row_y_offset + row_idx * row_step))

        section_rects[difficulty] = panel_rect

    return section_rects


def draw_game_over_leaderboards(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    start_y: int,
    global_rows_by_difficulty,
    user_rows_by_difficulty,
    version_filter: str,
    runtime_version: str,
) -> dict:
    return _draw_split_leaderboard_panels(
        surface,
        font,
        screen_w,
        start_y,
        global_rows_by_difficulty,
        user_rows_by_difficulty,
        version_filter,
        runtime_version,
    )


def draw_difficulty_screen(surface: pygame.Surface, font: pygame.font.Font,
                           screen_w: int, screen_h: int) -> dict:
    draw_menu_background(surface, screen_w, screen_h)
    title_font = _get_difficulty_title_font()
    title = title_font.render(i18n.t("difficulty.title"), True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 150))

    buttons = [
        ("easy", i18n.t("difficulty.easy"), (50, 180, 50)),
        ("normal", i18n.t("difficulty.normal"), (180, 180, 50)),
        ("hard", i18n.t("difficulty.hard"), (180, 50, 50)),
        ("endless", i18n.t("difficulty.endless"), (180, 50, 180)),
    ]
    descriptions = [
        i18n.t("difficulty.easy_desc"),
        i18n.t("difficulty.normal_desc"),
        i18n.t("difficulty.hard_desc"),
        i18n.t("difficulty.endless_desc"),
    ]
    rects = {}
    for i, (key, label, color) in enumerate(buttons):
        btn_w, btn_h = 280, 60
        btn_x = screen_w // 2 - btn_w // 2
        btn_y = 290 + i * 100
        rect = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
        pygame.draw.rect(surface, color, rect, border_radius=8)
        txt = font.render(label, True, theme.TEXT_PRIMARY)
        surface.blit(txt, (rect.centerx - txt.get_width() // 2,
                            rect.centery - txt.get_height() // 2))
        desc_font = fonts.sized(14)
        desc = desc_font.render(descriptions[i], True, theme.TEXT_SECONDARY)
        surface.blit(desc, (screen_w // 2 - desc.get_width() // 2, btn_y + btn_h + 8))
        rects[key] = rect
    return rects


def draw_perk_selection_screen(surface: pygame.Surface, font: pygame.font.Font,
                               screen_w: int, screen_h: int, perk_offers: list[dict],
                               selected_ids: set[str], required_choices: int,
                               feedback: str = "") -> dict:
    draw_menu_background(surface, screen_w, screen_h)

    title_font = fonts.sized_bold(48)
    title = title_font.render(i18n.t("perk.title"), True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 100))

    sub_font = fonts.sized(16)
    sub = sub_font.render(i18n.t("perk.choose_up_to").format(n=required_choices), True, (160, 175, 200))
    surface.blit(sub, (screen_w // 2 - sub.get_width() // 2, 168))

    CATEGORY_COLORS = {
        "RANGE":   (50, 160, 175),
        "OFFENSE": (200, 120, 45),
        "DEFENSE": (55, 100, 200),
        "ECONOMY": (190, 160, 45),
        "UTILITY": (60, 160, 80),
    }

    card_w, card_h = 320, 220
    gap = 28
    count = len(perk_offers)
    row_w = count * card_w + max(0, count - 1) * gap
    card_y = 220
    if row_w > screen_w - 48:
        cols = 2
        rows = (count + cols - 1) // cols
        grid_w = cols * card_w + (cols - 1) * gap
        start_x = screen_w // 2 - grid_w // 2
        card_positions = []
        for idx in range(count):
            col_idx = idx % cols
            row_idx = idx // cols
            card_positions.append((start_x + col_idx * (card_w + gap), card_y + row_idx * (card_h + gap)))
        confirm_y = card_y + rows * (card_h + gap) + 10
    else:
        start_x = screen_w // 2 - row_w // 2
        card_positions = [(start_x + idx * (card_w + gap), card_y) for idx in range(count)]
        confirm_y = card_y + card_h + 28

    card_rects = {}
    header_h = 36
    name_font = fonts.sized_bold(16)
    desc_font = _get_small_font()
    badge_font = fonts.sized(12)

    for idx, perk in enumerate(perk_offers):
        perk_id = str(perk.get("id", f"perk_{idx}"))
        label = i18n.t(f"perk_data.{perk_id}.label", str(perk.get("label", perk_id)))
        description = i18n.t(f"perk_data.{perk_id}.description", str(perk.get("description", "")))
        category = str(perk.get("category", "UTILITY"))
        rarity = int(perk.get("rarity", 1))
        card_x, cy = card_positions[idx]
        rect = pygame.Rect(card_x, cy, card_w, card_h)
        selected = perk_id in selected_ids
        cat_color = CATEGORY_COLORS.get(category, (100, 100, 140))

        # glow outline if selected
        if selected:
            glow_rect = rect.inflate(8, 8)
            glow_surf = pygame.Surface((glow_rect.width, glow_rect.height), pygame.SRCALPHA)
            glow_surf.fill((*cat_color, 70))
            surface.blit(glow_surf, glow_rect.topleft)

        # card background
        bg = (40, 52, 72) if selected else (30, 36, 50)
        pygame.draw.rect(surface, bg, rect, border_radius=10)

        # header bar
        header_rect = pygame.Rect(card_x, cy, card_w, header_h)
        pygame.draw.rect(surface, cat_color, header_rect, border_radius=10)
        # fix bottom corners of header (draw a non-rounded rect over bottom half)
        pygame.draw.rect(surface, cat_color,
                         pygame.Rect(card_x, cy + header_h // 2, card_w, header_h // 2))

        # badge [CATEGORY]
        badge = badge_font.render(f"[{category}]", True, (255, 255, 255))
        surface.blit(badge, (card_x + 10, cy + (header_h - badge.get_height()) // 2))

        # rarity dots — drawn directly (unicode stars unreliable in pygbag)
        _RARITY_COLORS = {1: (192, 192, 192), 2: (220, 190, 60), 3: (180, 80, 220)}
        dot_color = _RARITY_COLORS.get(rarity, (192, 192, 192))
        dot_r = 5
        dot_spacing = 14
        dot_cy_pos = cy + header_h // 2
        for i in range(3):
            dot_cx = card_x + card_w - 10 - (2 - i) * dot_spacing
            if i < rarity:
                pygame.draw.circle(surface, dot_color, (dot_cx, dot_cy_pos), dot_r)
            else:
                pygame.draw.circle(surface, (50, 50, 70), (dot_cx, dot_cy_pos), dot_r)
                pygame.draw.circle(surface, dot_color, (dot_cx, dot_cy_pos), dot_r, 1)

        # border
        border_color = cat_color if selected else (70, 80, 100)
        border_w = 3 if selected else 1
        pygame.draw.rect(surface, border_color, rect, border_w, border_radius=10)

        # perk name
        name_surf = name_font.render(label, True, (245, 245, 245))
        surface.blit(name_surf, (card_x + 12, cy + header_h + 12))

        # description wrapped
        desc_box = pygame.Rect(card_x + 12, cy + header_h + 36, card_w - 24, card_h - header_h - 48)
        wrapped = _wrap_text_to_width(description, desc_font, desc_box.width)
        line_h = max(18, desc_font.get_linesize())
        max_lines = max(1, desc_box.height // max(1, line_h))
        for line_idx, line in enumerate(wrapped[:max_lines]):
            line_surf = desc_font.render(line, True, (200, 210, 225))
            surface.blit(line_surf, (desc_box.x, desc_box.y + line_idx * line_h))

        card_rects[perk_id] = rect

    # confirm button — always green
    confirm_rect = pygame.Rect(screen_w // 2 - 150, confirm_y, 300, 54)
    pygame.draw.rect(surface, (46, 128, 66), confirm_rect, border_radius=10)
    pygame.draw.rect(surface, (100, 210, 130), confirm_rect, 2, border_radius=10)
    confirm_txt = fonts.sized_bold(18).render(i18n.t("boss_reward.confirm"), True, (240, 255, 240))
    surface.blit(confirm_txt, (confirm_rect.centerx - confirm_txt.get_width() // 2,
                               confirm_rect.centery - confirm_txt.get_height() // 2))

    if feedback:
        fb = sub_font.render(feedback, True, (255, 170, 120))
        surface.blit(fb, (screen_w // 2 - fb.get_width() // 2, confirm_rect.bottom + 16))

    return {"cards": card_rects, "confirm": confirm_rect}


def render_profile_identify(surface: pygame.Surface, username: str,
                            screen_w: int, screen_h: int,
                            error: str = "") -> None:
    draw_menu_background(surface, screen_w, screen_h)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render(i18n.t("profile.welcome_title"), True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 200))

    sub = font.render(i18n.t("profile.insert_username"), True, (180, 200, 230))
    surface.blit(sub, (screen_w // 2 - sub.get_width() // 2, 290))

    box_w = 400
    r = pygame.Rect(screen_w // 2 - box_w // 2, 330, box_w, 52)
    pygame.draw.rect(surface, theme.PANEL_BG, r, border_radius=6)
    pygame.draw.rect(surface, theme.ACCENT, r, theme.BORDER_MEDIUM, border_radius=6)
    txt = font.render(username, True, (230, 230, 230))
    surface.blit(txt, (r.x + 12, r.centery - txt.get_height() // 2))

    cursor_visible = (pygame.time.get_ticks() // 500) % 2 == 0
    if cursor_visible:
        cx = r.x + 12 + txt.get_width() + 2
        cy1 = r.centery - txt.get_height() // 2 + 2
        cy2 = r.centery + txt.get_height() // 2 - 2
        pygame.draw.line(surface, (230, 230, 230), (cx, cy1), (cx, cy2), 2)

    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, 410))

    hint = font.render(i18n.t("profile.enter_continue"), True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 80))
    esc_hint = font.render(i18n.t("profile.esc_home"), True, (90, 90, 90))
    surface.blit(esc_hint, (screen_w // 2 - esc_hint.get_width() // 2, screen_h - 52))


def render_profile_select(surface: pygame.Surface, usernames: list,
                          screen_w: int, screen_h: int) -> dict:
    draw_menu_background(surface, screen_w, screen_h)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render(i18n.t("profile.select_title"), True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 180))

    rects = {}
    btn_w, btn_h = 360, 52
    start_y = 290
    for i, name in enumerate(usernames):
        r = pygame.Rect(screen_w // 2 - btn_w // 2, start_y + i * 72, btn_w, btn_h)
        pygame.draw.rect(surface, (50, 70, 100), r, border_radius=6)
        pygame.draw.rect(surface, (100, 140, 200), r, theme.BORDER_MEDIUM, border_radius=6)
        lbl = font.render(name, True, (230, 230, 230))
        surface.blit(lbl, (r.centerx - lbl.get_width() // 2,
                           r.centery - lbl.get_height() // 2))
        rects[name] = r

    new_r = pygame.Rect(screen_w // 2 - btn_w // 2,
                        start_y + len(usernames) * 72 + 24, btn_w, btn_h)
    pygame.draw.rect(surface, (40, 100, 60), new_r, border_radius=6)
    pygame.draw.rect(surface, (80, 180, 100), new_r, theme.BORDER_MEDIUM, border_radius=6)
    lbl = font.render(i18n.t("profile.new_profile"), True, (200, 255, 200))
    surface.blit(lbl, (new_r.centerx - lbl.get_width() // 2,
                       new_r.centery - lbl.get_height() // 2))
    rects["__new__"] = new_r
    return rects


def render_profile_create(surface: pygame.Surface, username: str,
                          password_len: int, screen_w: int, screen_h: int,
                          active_field: str = "username",
                          error: str = "") -> None:
    draw_menu_background(surface, screen_w, screen_h)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render(i18n.t("profile.create_title"), True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 180))

    box_w = 400
    fields = [("Username", username, "username"), ("Password", "*" * password_len, "password")]
    for i, (label, value, field) in enumerate(fields):
        by = 290 + i * 110
        lbl = font.render(label, True, (180, 180, 180))
        surface.blit(lbl, (screen_w // 2 - box_w // 2, by - 24))
        is_active = active_field == field
        border = theme.ACCENT if is_active else (80, 80, 120)
        r = pygame.Rect(screen_w // 2 - box_w // 2, by, box_w, 52)
        pygame.draw.rect(surface, theme.PANEL_BG, r, border_radius=6)
        pygame.draw.rect(surface, border, r, theme.BORDER_MEDIUM, border_radius=6)
        txt = font.render(value, True, (230, 230, 230))
        surface.blit(txt, (r.x + 12, r.centery - txt.get_height() // 2))
        if is_active:
            cursor_visible = (pygame.time.get_ticks() // 500) % 2 == 0
            if cursor_visible:
                cx = r.x + 12 + txt.get_width() + 2
                cy1 = r.centery - txt.get_height() // 2 + 2
                cy2 = r.centery + txt.get_height() // 2 - 2
                pygame.draw.line(surface, (230, 230, 230), (cx, cy1), (cx, cy2), 2)

    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, 530))

    hint = font.render(i18n.t("profile.create_hint"), True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 80))


def render_profile_login(surface: pygame.Surface, username: str,
                         password_len: int, screen_w: int, screen_h: int,
                         error: str = "") -> None:
    draw_menu_background(surface, screen_w, screen_h)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render(i18n.t("profile.login_title"), True, theme.TEXT_PRIMARY)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 200))

    uname = font.render(i18n.t("menu.user_label").format(username=username), True, (180, 200, 230))
    surface.blit(uname, (screen_w // 2 - uname.get_width() // 2, 290))

    box_w = 400
    by = 345
    lbl = font.render(i18n.t("profile.password_label"), True, (180, 180, 180))
    surface.blit(lbl, (screen_w // 2 - box_w // 2, by - 24))
    r = pygame.Rect(screen_w // 2 - box_w // 2, by, box_w, 52)
    pygame.draw.rect(surface, theme.PANEL_BG, r, border_radius=6)
    pygame.draw.rect(surface, theme.ACCENT, r, theme.BORDER_MEDIUM, border_radius=6)
    txt = font.render("*" * password_len, True, (230, 230, 230))
    surface.blit(txt, (r.x + 12, r.centery - txt.get_height() // 2))

    cursor_visible = (pygame.time.get_ticks() // 500) % 2 == 0
    if cursor_visible:
        cx = r.x + 12 + txt.get_width() + 2
        cy1 = r.centery - txt.get_height() // 2 + 2
        cy2 = r.centery + txt.get_height() // 2 - 2
        pygame.draw.line(surface, (230, 230, 230), (cx, cy1), (cx, cy2), 2)

    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, 430))

    hint = font.render(i18n.t("profile.login_hint"), True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 80))


def render_dlc_menu(surface: pygame.Surface, dlcs: dict,
                    user_dlcs: set, screen_w: int, screen_h: int,
                    error: str = "") -> dict:
    surface.fill(theme.BACKGROUND)
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render("DLC", True, theme.GOLD_COLOR)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 60))

    rects = {}
    btn_w, btn_h = 360, 52
    start_y = 140
    for i, (dlc_id, dlc_name) in enumerate(dlcs.items()):
        unlocked = dlc_id in user_dlcs
        r = pygame.Rect(screen_w // 2 - btn_w // 2, start_y + i * 70, btn_w, btn_h)
        pygame.draw.rect(surface, (40, 80, 40) if unlocked else (50, 40, 40), r,
                         border_radius=6)
        pygame.draw.rect(surface, (80, 180, 80) if unlocked else (120, 80, 80), r, theme.BORDER_MEDIUM,
                         border_radius=6)
        icon = "[OK]" if unlocked else "[  ]"
        lbl = font.render(f"{icon} {dlc_name}", True,
                          (200, 255, 200) if unlocked else (220, 180, 180))
        surface.blit(lbl, (r.x + 14, r.centery - lbl.get_height() // 2))
        rects[dlc_id] = r

    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2,
                           start_y + len(dlcs) * 70 + 10))
    hint = font.render(i18n.t("dlc_menu.esc_hint"), True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 60))
    return rects


def render_key_input(surface: pygame.Surface, dlc_name: str, key_text: str,
                     screen_w: int, screen_h: int, error: str = "") -> pygame.Rect:
    overlay = pygame.Surface((screen_w, screen_h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    surface.blit(overlay, (0, 0))

    font_t = _get_profile_title_font()
    font = _get_input_font()
    box_w, box_h = 500, 250
    bx = screen_w // 2 - box_w // 2
    by = screen_h // 2 - box_h // 2
    pygame.draw.rect(surface, theme.PANEL_BG, (bx, by, box_w, box_h), border_radius=10)
    pygame.draw.rect(surface, (100, 100, 180), (bx, by, box_w, box_h), theme.BORDER_MEDIUM, border_radius=10)

    title = font_t.render(f"{i18n.t('dlc_menu.active_prefix')}: {dlc_name}", True, theme.GOLD_COLOR)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, by + 20))

    lbl = font.render(i18n.t("dlc_menu.key_label"), True, (180, 180, 180))
    surface.blit(lbl, (bx + 20, by + 70))
    inp_r = pygame.Rect(bx + 20, by + 96, box_w - 40, 36)
    pygame.draw.rect(surface, (20, 20, 40), inp_r, border_radius=4)
    pygame.draw.rect(surface, theme.ACCENT, inp_r, theme.BORDER_MEDIUM, border_radius=4)
    key_surf = font.render(key_text, True, (230, 230, 230))
    surface.blit(key_surf, (inp_r.x + 8, inp_r.centery - key_surf.get_height() // 2))

    paste_r = pygame.Rect(inp_r.right - 90, inp_r.y + 3, 80, 30)
    pygame.draw.rect(surface, (50, 70, 110), paste_r, border_radius=6)
    pygame.draw.rect(surface, (120, 160, 220), paste_r, theme.BORDER_MEDIUM, border_radius=6)
    paste_lbl = font.render(i18n.t("dlc_menu.paste"), True, (230, 238, 255))
    surface.blit(
        paste_lbl,
        (paste_r.centerx - paste_lbl.get_width() // 2, paste_r.centery - paste_lbl.get_height() // 2),
    )

    hint = font.render(i18n.t("dlc_menu.hint"), True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, by + 188))
    if error:
        err = font.render(error, True, theme.EVENT_NEGATIVE)
        surface.blit(err, (screen_w // 2 - err.get_width() // 2, by + 214))
    return paste_r


def render_admin_panel(surface: pygame.Surface,
                       user_records: list[tuple[int, str]],
                       selected_user_id: Optional[int],
                       selected_user_dlcs: set[str],
                       dlcs: dict[str, str],
                       screen_w: int, screen_h: int,
                       message: str = "") -> tuple[dict[int, pygame.Rect], dict[str, pygame.Rect], pygame.Rect]:
    surface.fill((18, 18, 30))
    font_t = _get_profile_title_font()
    font = _get_input_font()
    title = font_t.render(i18n.t("admin.title"), True, theme.GOLD_COLOR)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 24))

    left_x = 60
    top_y = 90
    col_w = 360
    row_h = 42
    user_rects: dict[int, pygame.Rect] = {}

    lbl_users = font.render(i18n.t("admin.users"), True, (180, 180, 220))
    surface.blit(lbl_users, (left_x, top_y - 28))
    for i, (uid, username) in enumerate(user_records):
        r = pygame.Rect(left_x, top_y + i * (row_h + 8), col_w, row_h)
        selected = uid == selected_user_id
        pygame.draw.rect(surface, (60, 80, 130) if selected else (45, 55, 80),
                         r, border_radius=6)
        pygame.draw.rect(surface, (130, 170, 230) if selected else (80, 100, 140),
                         r, theme.BORDER_MEDIUM, border_radius=6)
        txt = font.render(f"{username} (id:{uid})", True, (230, 230, 240))
        surface.blit(txt, (r.x + 10, r.centery - txt.get_height() // 2))
        user_rects[uid] = r

    right_x = 500
    dlc_rects: dict[str, pygame.Rect] = {}
    lbl_dlc = font.render(i18n.t("admin.dlc_toggle"), True, (180, 180, 220))
    surface.blit(lbl_dlc, (right_x, top_y - 28))
    for i, (dlc_id, dlc_name) in enumerate(dlcs.items()):
        unlocked = dlc_id in selected_user_dlcs
        r = pygame.Rect(right_x, top_y + i * 64, 380, 50)
        bg = (35, 95, 55) if unlocked else (95, 45, 45)
        border = (90, 200, 130) if unlocked else (210, 100, 100)
        pygame.draw.rect(surface, bg, r, border_radius=6)
        pygame.draw.rect(surface, border, r, theme.BORDER_MEDIUM, border_radius=6)
        state = "ON" if unlocked else "OFF"
        txt = font.render(f"[{state}] {dlc_name}", True, (235, 235, 235))
        surface.blit(txt, (r.x + 12, r.centery - txt.get_height() // 2))
        dlc_rects[dlc_id] = r

    delete_rect = pygame.Rect(right_x, top_y + max(2, len(dlcs)) * 64 + 12, 380, 46)
    pygame.draw.rect(surface, (115, 40, 40), delete_rect, border_radius=6)
    pygame.draw.rect(surface, (220, 110, 110), delete_rect, theme.BORDER_MEDIUM, border_radius=6)
    del_txt = font.render(i18n.t("admin.deactivate"), True, (245, 230, 230))
    surface.blit(del_txt, (delete_rect.centerx - del_txt.get_width() // 2,
                           delete_rect.centery - del_txt.get_height() // 2))

    hint = font.render(i18n.t("admin.esc_hint"), True, (120, 120, 120))
    surface.blit(hint, (screen_w // 2 - hint.get_width() // 2, screen_h - 50))
    if message:
        msg = font.render(message, True, (255, 220, 130))
        surface.blit(msg, (screen_w // 2 - msg.get_width() // 2, screen_h - 90))
    return user_rects, dlc_rects, delete_rect


def draw_wave_report(
    surface: pygame.Surface,
    font: pygame.font.Font,
    report,
    x: int,
    y: int,
) -> None:
    if not report:
        return

    title_font = font
    body_font = _get_small_font()
    accent = theme.ACCENT
    panel_bg = theme.PANEL_BG
    panel_border = theme.BUTTON_HOVER
    text_primary = theme.TEXT_PRIMARY
    text_secondary = theme.TEXT_SECONDARY
    stat_fill = theme.GRID
    stat_border = theme.BUTTON_DEFAULT

    dmg = report.get("damage_by_type", {}) or {}
    recap = report.get("combat_recap") or {}
    rows = [
        ("Wave", str(report.get("wave", "?")), accent),
        ("Flying kills", str(report.get("flying_kills", 0)), theme.ENEMY_FLYING),
        ("Lives lost", str(report.get("lives_lost", 0)), theme.EVENT_NEGATIVE),
        ("Gold earned", str(report.get("gold_earned", 0)), theme.HP_MED),
    ]

    title_surf = title_font.render(f"Wave {report.get('wave', '?')} Report", True, accent)
    stat_surfaces = [(label, value, color, body_font.render(value, True, color)) for label, value, color in rows]
    damage_items = []
    for ttype, dmg_val in dmg.items():
        value = int(dmg_val) if isinstance(dmg_val, (int, float)) else dmg_val
        damage_items.append((str(ttype), value))

    inner_pad = 12
    row_h = 22
    dmg_row_h = 20
    width_candidates = [title_surf.get_width()]
    width_candidates.extend(
        body_font.render(f"{label}", True, text_secondary).get_width() + 100 for label, *_ in rows
    )
    if damage_items:
        width_candidates.extend(
            body_font.render(f"{ttype}", True, text_primary).get_width() + 72 for ttype, _ in damage_items
        )
    bg_w = max(240, min(surface.get_width() - x - 8, max(width_candidates) + inner_pad * 2 + 12))
    recap_lines = []
    if recap:
        recap_lines = [
            f"Kills: {sum((recap.get('kills_by_enemy_type', {}) or {}).values())}",
            f"Spent: {int(recap.get('gold_spent', 0))}g",
            f"Repair/Upgrade: {int(recap.get('repairs', 0))}/{int(recap.get('upgrades', 0))}",
        ]
        events = list(recap.get("events", []) or [])
        if events:
            recap_lines.append("Events: " + " | ".join(str(e) for e in events[-3:]))

    recap_h = (len(recap_lines) * 17 + 8) if recap_lines else 0
    bg_h = (
        inner_pad * 2
        + 28
        + len(rows) * (row_h + 4)
        + (len(damage_items) * (dmg_row_h + 3) + 6 if damage_items else 0)
        + recap_h
    )

    panel = pygame.Surface((bg_w, bg_h), pygame.SRCALPHA)
    panel.fill((*panel_bg, 214))
    pygame.draw.rect(panel, (*panel_border, 220), (0, 0, bg_w, bg_h), theme.BORDER_MEDIUM, border_radius=12)

    panel.blit(title_surf, (inner_pad, 10))
    subtitle = body_font.render(i18n.t("hud.post_wave"), True, text_secondary)
    panel.blit(subtitle, (bg_w - inner_pad - subtitle.get_width(), 12))

    row_y = 36
    for label, value, color, value_surf in stat_surfaces:
        row_rect = pygame.Rect(inner_pad, row_y, bg_w - inner_pad * 2, row_h)
        pygame.draw.rect(panel, (*stat_fill, 220), row_rect, border_radius=8)
        pygame.draw.rect(panel, (*stat_border, 180), row_rect, theme.BORDER_THIN, border_radius=8)

        label_surf = body_font.render(label, True, text_secondary)
        panel.blit(label_surf, (row_rect.x + 8, row_rect.centery - label_surf.get_height() // 2))
        pill_w = value_surf.get_width() + 12
        pill = pygame.Surface((pill_w, row_h - 6), pygame.SRCALPHA)
        pill.fill((*color, 65))
        pygame.draw.rect(pill, (*color, 150), (0, 0, pill_w, row_h - 6), theme.BORDER_THIN, border_radius=8)
        pill.blit(value_surf, (6, pill.get_height() // 2 - value_surf.get_height() // 2))
        panel.blit(pill, (row_rect.right - pill_w - 8, row_rect.y + 3))
        row_y += row_h + 4

    if damage_items:
        section_y = row_y + 2
        section_label = body_font.render(i18n.t("hud.damage_by_type"), True, accent)
        panel.blit(section_label, (inner_pad, section_y))
        section_y += 18
        damage_total = sum(value for _, value in damage_items) or 1
        enemy_colors = {
            "BasicEnemy": theme.ENEMY_BASIC,
            "FastEnemy": theme.ENEMY_FAST,
            "TankEnemy": theme.ENEMY_TANK,
            "SwarmEnemy": theme.HP_MED,
            "FlyingEnemy": theme.ENEMY_FLYING,
            "HeavyEnemy": theme.ENEMY_HEAVY,
            "BossEnemy": theme.ENEMY_BOSS,
        }
        for ttype, dmg_val in damage_items:
            color = enemy_colors.get(ttype, accent)
            row_rect = pygame.Rect(inner_pad, section_y, bg_w - inner_pad * 2, dmg_row_h)
            pygame.draw.rect(panel, (*theme.BACKGROUND, 90), row_rect, border_radius=8)
            bar_w = max(18, int((int(dmg_val) / damage_total) * (row_rect.width - 116)))
            pygame.draw.rect(panel, (*color, 220), (row_rect.x + 8, row_rect.y + 4, bar_w, dmg_row_h - 8), border_radius=6)
            pygame.draw.rect(panel, (*color, 180), row_rect, theme.BORDER_THIN, border_radius=8)
            name_surf = body_font.render(ttype, True, text_primary)
            value_surf = body_font.render(str(dmg_val), True, text_primary)
            panel.blit(name_surf, (row_rect.x + 12, row_rect.centery - name_surf.get_height() // 2))
            panel.blit(value_surf, (row_rect.right - value_surf.get_width() - 10, row_rect.centery - value_surf.get_height() // 2))
            section_y += dmg_row_h + 3
        row_y = section_y + 2

    if recap_lines:
        recap_title = body_font.render(i18n.t("hud.combat_recap"), True, accent)
        panel.blit(recap_title, (inner_pad, row_y + 4))
        line_y = row_y + 22
        for line in recap_lines:
            line_surf = body_font.render(line, True, text_secondary)
            panel.blit(line_surf, (inner_pad + 2, line_y))
            line_y += 17

    surface.blit(panel, (x, y))


def draw_mutator_selection_screen(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    screen_h: int,
    pending_mutators: list[str],
) -> dict:
    """Draw the mutator selection screen.

    Returns {"cards": {mut_id: pygame.Rect}, "confirm": pygame.Rect}.
    """
    from src.mutators import available_mutators

    draw_menu_background(surface, screen_w, screen_h)

    title_font = _get_difficulty_title_font()
    title_surf = title_font.render(i18n.t("mutator.title"), True, theme.TEXT_PRIMARY)
    surface.blit(title_surf, (screen_w // 2 - title_surf.get_width() // 2, 50))

    sub_font = _get_small_font()
    sub_surf = sub_font.render(
        i18n.t("mutator.subtitle"), True, (160, 175, 200)
    )
    surface.blit(sub_surf, (screen_w // 2 - sub_surf.get_width() // 2, 110))

    # ESC hint
    esc_surf = sub_font.render(i18n.t("mutator.esc"), True, (120, 130, 145))
    surface.blit(esc_surf, (screen_w - esc_surf.get_width() - 16, 16))

    bonuses = available_mutators(kind="bonus")
    maluses = available_mutators(kind="malus")

    card_w = screen_w // 2 - 48
    card_h = 90
    gap = 12
    col_left_x = 24
    col_right_x = screen_w // 2 + 24
    start_y = 150

    BONUS_COL_TITLE = (80, 200, 120)
    MALUS_COL_TITLE = (200, 90, 90)
    SELECTED_BORDER = (255, 215, 0)
    NORMAL_BORDER = (80, 90, 110)
    CARD_BG = (28, 32, 44)

    card_rects: dict[str, pygame.Rect] = {}
    body_font = fonts.sized(14)

    # Column headers
    bonus_hdr = sub_font.render(i18n.t("mutator.bonus"), True, BONUS_COL_TITLE)
    malus_hdr = sub_font.render(i18n.t("mutator.malus"), True, MALUS_COL_TITLE)
    surface.blit(bonus_hdr, (col_left_x, start_y - 24))
    surface.blit(malus_hdr, (col_right_x, start_y - 24))

    def _draw_card(mut, x, y, col_color):
        rect = pygame.Rect(x, y, card_w, card_h)
        selected = mut.id in pending_mutators
        border_color = SELECTED_BORDER if selected else NORMAL_BORDER
        border_w = 3 if selected else 1
        pygame.draw.rect(surface, CARD_BG, rect, border_radius=6)
        pygame.draw.rect(surface, border_color, rect, border_w, border_radius=6)
        label_surf = body_font.render(i18n.t(f"mutator_data.{mut.id}.label", mut.label), True, col_color)
        surface.blit(label_surf, (x + 10, y + 8))
        desc_surf = body_font.render(i18n.t(f"mutator_data.{mut.id}.description", mut.description), True, theme.TEXT_PRIMARY)
        surface.blit(desc_surf, (x + 10, y + 28))
        score_text = f"Score x{mut.score_mult:.2f}"
        score_surf = body_font.render(score_text, True, (160, 175, 200))
        surface.blit(score_surf, (x + 10, y + 48))
        if mut.xp_bonus > 0:
            xp_surf = body_font.render(f"+{mut.xp_bonus} XP bonus", True, (180, 220, 120))
            surface.blit(xp_surf, (x + 10, y + 64))
        return rect

    for i, mut in enumerate(bonuses):
        y = start_y + i * (card_h + gap)
        rect = _draw_card(mut, col_left_x, y, BONUS_COL_TITLE)
        card_rects[mut.id] = rect

    for i, mut in enumerate(maluses):
        y = start_y + i * (card_h + gap)
        rect = _draw_card(mut, col_right_x, y, MALUS_COL_TITLE)
        card_rects[mut.id] = rect

    # Confirm button
    btn_w, btn_h = 220, 48
    btn_x = screen_w // 2 - btn_w // 2
    btn_y = screen_h - 90
    confirm_rect = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
    pygame.draw.rect(surface, (50, 130, 80), confirm_rect, border_radius=8)
    pygame.draw.rect(surface, (100, 200, 140), confirm_rect, 2, border_radius=8)
    btn_label = sub_font.render(i18n.t("mutator.confirm"), True, (255, 255, 255))
    surface.blit(btn_label, (btn_x + btn_w // 2 - btn_label.get_width() // 2,
                              btn_y + btn_h // 2 - btn_label.get_height() // 2))

    return {"cards": card_rects, "confirm": confirm_rect}


def draw_analytics_screen(
    surface: pygame.Surface,
    top_runs: list[dict],
    font: pygame.font.Font,
    screen_w: int,
    screen_h: int,
    leaderboard_global_by_difficulty=None,
    leaderboard_user_by_difficulty=None,
    leaderboard_filter: str = "all",
    runtime_version: str = "",
) -> dict:
    if top_runs is None:
        top_runs = []

    surface.fill(theme.BACKGROUND)

    title_font = _get_difficulty_title_font()
    small_font = fonts.sized(14)
    header_font = fonts.sized_bold(14)
    accent = theme.ACCENT
    panel_bg = theme.PANEL_BG
    panel_border = theme.BUTTON_HOVER
    text_primary = theme.TEXT_PRIMARY
    text_secondary = theme.TEXT_SECONDARY
    title = title_font.render(i18n.t("analytics.title"), True, accent)
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 20))

    content_x = 32
    content_y = 76
    content_w = screen_w - 64
    content_h = screen_h - content_y - 92
    panel = pygame.Surface((content_w, content_h), pygame.SRCALPHA)
    panel.fill((*panel_bg, 214))
    pygame.draw.rect(panel, (*panel_border, 220), (0, 0, content_w, content_h), theme.BORDER_MEDIUM, border_radius=16)
    panel.blit(small_font.render(i18n.t("analytics.subtitle"), True, text_secondary), (16, 12))

    table_y = 44
    headers = ["Wave", "Score", "Difficulty", "Date"]
    col_x_positions = [16, 116, 236, 356]

    for header, x in zip(headers, col_x_positions):
        h_surf = header_font.render(header, True, text_secondary)
        panel.blit(h_surf, (x, table_y))

    row_y = table_y + 24
    for run in top_runs[:5]:
        wave_max = run.get("wave_max", 0)
        score = run.get("final_score", 0)
        difficulty = run.get("difficulty", "N/A")
        timestamp = run.get("timestamp", "")
        date_str = timestamp.split("T")[0] if timestamp else "N/A"

        row_rect = pygame.Rect(12, row_y - 2, content_w - 24, 20)
        pygame.draw.rect(panel, (*theme.GRID, 180), row_rect, border_radius=8)
        pygame.draw.rect(panel, (*theme.BUTTON_DEFAULT, 180), row_rect, theme.BORDER_THIN, border_radius=8)

        wave_text = small_font.render(str(wave_max), True, text_primary)
        score_text = small_font.render(str(score), True, theme.HP_MED)
        diff_text = small_font.render(difficulty, True, text_secondary)
        date_text = small_font.render(date_str, True, text_secondary)

        panel.blit(wave_text, (col_x_positions[0], row_y))
        panel.blit(score_text, (col_x_positions[1], row_y))
        panel.blit(diff_text, (col_x_positions[2], row_y))
        panel.blit(date_text, (col_x_positions[3], row_y))

        row_y += 22

    leaderboard_top = row_y + 12
    if top_runs:
        first_run = top_runs[0]
        kills_by_type = first_run.get("kills_by_type", {})

        if kills_by_type:
            chart_y = row_y + 30
            chart_title = small_font.render(i18n.t("analytics.kills_chart"), True, accent)
            panel.blit(chart_title, (16, chart_y))

            chart_y += 20
            bar_h = 14
            bar_gap = 4
            max_kills = max(kills_by_type.values()) if kills_by_type else 1
            max_kills = max(1, max_kills)
            chart_x_start = 16
            bar_width_scale = max(180, content_w - 220)
            enemy_colors = {
                "BasicEnemy": theme.ENEMY_BASIC,
                "FastEnemy": theme.ENEMY_FAST,
                "TankEnemy": theme.ENEMY_TANK,
                "SwarmEnemy": theme.HP_MED,
                "FlyingEnemy": theme.ENEMY_FLYING,
                "HeavyEnemy": theme.ENEMY_HEAVY,
                "BossEnemy": theme.ENEMY_BOSS,
            }

            for enemy_type, kill_count in sorted(kills_by_type.items()):
                bar_color = enemy_colors.get(enemy_type, theme.ACCENT)
                label = small_font.render(f"{enemy_type}: {kill_count}", True, text_primary)
                panel.blit(label, (chart_x_start, chart_y))

                bar_w = int((kill_count / max_kills) * bar_width_scale) if max_kills > 0 else 10
                bar_x = chart_x_start + 154
                bar_rect = pygame.Rect(bar_x, chart_y, bar_w, bar_h)
                pygame.draw.rect(panel, (*bar_color, 220), bar_rect, border_radius=6)
                pygame.draw.rect(panel, (*bar_color, 180), bar_rect, theme.BORDER_THIN, border_radius=6)

                chart_y += bar_h + bar_gap

            leaderboard_top = chart_y + 30

    leaderboard_rects = _draw_split_leaderboard_panels(
        panel,
        small_font,
        content_w,
        leaderboard_top,
        leaderboard_global_by_difficulty or {},
        leaderboard_user_by_difficulty or {},
        leaderboard_filter,
        runtime_version,
    )

    surface.blit(panel, (content_x, content_y))

    back_btn_w, back_btn_h = 120, 36
    back_btn_x = screen_w // 2 - back_btn_w // 2
    back_btn_y = screen_h - 60
    back_rect = pygame.Rect(back_btn_x, back_btn_y, back_btn_w, back_btn_h)
    pygame.draw.rect(surface, theme.BUTTON_DEFAULT, back_rect, border_radius=6)
    pygame.draw.rect(surface, (120, 140, 160), back_rect, theme.BORDER_MEDIUM, border_radius=6)
    back_lbl = font.render(i18n.t("analytics.back"), True, (220, 230, 255))
    surface.blit(back_lbl, (back_rect.centerx - back_lbl.get_width() // 2,
                            back_rect.centery - back_lbl.get_height() // 2))

    result = {"back": back_rect}
    result.update({f"leaderboard_{difficulty}": rect for difficulty, rect in leaderboard_rects.items()})
    return result


def codex_layout_rects(screen_w: int, screen_h: int, category: str) -> dict:
    """Return Codex category and visible entry hitboxes."""
    from src.game_codex import codex_categories, entries_for_category

    margin = 20
    top = 100
    left_w = int(screen_w * 0.30)
    tab_h = 36
    tab_y = top

    cats = codex_categories()
    if category not in cats:
        category = cats[0]

    categories = {}
    for cat in cats:
        categories[cat] = pygame.Rect(margin, tab_y, left_w - margin, tab_h)
        tab_y += tab_h + 4

    entries = {}
    entry_h = 30
    list_y = tab_y + 12
    for i, _entry in enumerate(entries_for_category(category)):
        entries[i] = pygame.Rect(margin, list_y, left_w - margin, entry_h)
        list_y += entry_h + 2
        if list_y > screen_h - 40:
            break

    return {"categories": categories, "entries": entries}


def draw_codex_screen(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    screen_h: int,
    category: str,
    entry_index: int,
) -> dict:
    """Render the Codex screen with category tabs, entry list, and detail panel."""
    from src.game_codex import codex_categories, entries_for_category

    draw_menu_background(surface, screen_w, screen_h)
    rects = codex_layout_rects(screen_w, screen_h, category)

    # --- Title bar ---
    title_font = fonts.sized_bold(40)
    title_surf = title_font.render(i18n.t("codex_ui.title"), True, (60, 220, 240))
    surface.blit(title_surf, (screen_w // 2 - title_surf.get_width() // 2, 20))

    hint_font = fonts.sized(14)
    hint_surf = hint_font.render(i18n.t("codex_ui.hint"), True, (140, 140, 140))
    surface.blit(hint_surf, (screen_w // 2 - hint_surf.get_width() // 2, 72))

    MARGIN = 20
    TOP = 100
    LEFT_W = int(screen_w * 0.30)
    RIGHT_X = LEFT_W + MARGIN * 2
    RIGHT_W = screen_w - RIGHT_X - MARGIN

    # --- Category tabs ---
    cats = codex_categories()
    if category not in cats:
        category = cats[0]
    tab_font = fonts.sized(16)
    tab_h = 36
    tab_y = TOP
    for cat in cats:
        active = cat == category
        tab_r = rects["categories"][cat]
        bg = (30, 90, 100) if active else (30, 40, 50)
        border = (60, 200, 220) if active else (60, 80, 90)
        pygame.draw.rect(surface, bg, tab_r, border_radius=4)
        pygame.draw.rect(surface, border, tab_r, 1, border_radius=4)
        label = tab_font.render(i18n.t(f"cat.{cat}", cat), True, (220, 255, 255) if active else (160, 190, 200))
        surface.blit(label, (tab_r.x + 8, tab_r.centery - label.get_height() // 2))
        tab_y += tab_h + 4

    # --- Entry list ---
    entries = entries_for_category(category)
    n = len(entries)
    safe_index = entry_index % max(n, 1)
    entry_font = fonts.sized(15)
    entry_h = 30
    list_y = tab_y + 12
    for i, entry in enumerate(entries):
        if i not in rects["entries"]:
            break
        active = i == safe_index
        entry_r = rects["entries"][i]
        bg = (40, 70, 80) if active else (20, 30, 40)
        border = (80, 180, 200) if active else (40, 55, 65)
        pygame.draw.rect(surface, bg, entry_r, border_radius=3)
        pygame.draw.rect(surface, border, entry_r, 1, border_radius=3)
        _entry_title = i18n.t(f"entry.{entry.id}.title", entry.title)
        title_text = _entry_title if len(_entry_title) <= 24 else _entry_title[:21] + "..."
        lbl = entry_font.render(title_text, True, (230, 250, 255) if active else (170, 200, 210))
        surface.blit(lbl, (entry_r.x + 6, entry_r.centery - lbl.get_height() // 2))
        list_y += entry_h + 2
        if list_y > screen_h - 40:
            break  # clamp list within screen

    # --- Entry detail panel ---
    if n == 0:
        empty_lbl = fonts.sized(18).render(i18n.t("codex_ui.no_entries"), True, (140, 140, 140))
        surface.blit(empty_lbl, (RIGHT_X, TOP + 20))
        return rects

    sel_entry = entries[safe_index]
    detail_font = fonts.sized(17)
    small_font = fonts.sized(14)
    detail_y = TOP

    # Title
    detail_title = fonts.sized_bold(24).render(i18n.t(f"entry.{sel_entry.id}.title", sel_entry.title), True, (60, 230, 250))
    surface.blit(detail_title, (RIGHT_X, detail_y))
    detail_y += detail_title.get_height() + 6

    # Category tag
    cat_tag = small_font.render(f"[{sel_entry.category}]", True, (100, 200, 180))
    surface.blit(cat_tag, (RIGHT_X, detail_y))
    detail_y += cat_tag.get_height() + 10

    # Divider
    pygame.draw.line(surface, (60, 80, 90), (RIGHT_X, detail_y), (RIGHT_X + RIGHT_W, detail_y), 1)
    detail_y += 8

    # Summary — wrap at RIGHT_W
    def _wrap_text(text: str, render_font: pygame.font.Font, max_width: int) -> list[str]:
        words = text.split()
        lines: list[str] = []
        current = ""
        for word in words:
            test = (current + " " + word).strip()
            if render_font.size(test)[0] <= max_width:
                current = test
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return lines or [""]

    for line in _wrap_text(i18n.t(f"entry.{sel_entry.id}.summary", sel_entry.summary), detail_font, RIGHT_W):
        if detail_y + detail_font.get_linesize() > screen_h - 10:
            break
        surf = detail_font.render(line, True, (210, 230, 240))
        surface.blit(surf, (RIGHT_X, detail_y))
        detail_y += detail_font.get_linesize()
    detail_y += 10

    # Stats
    if sel_entry.stats:
        stats_lbl = small_font.render(i18n.t("codex_ui.stats_label"), True, (160, 210, 160))
        surface.blit(stats_lbl, (RIGHT_X, detail_y))
        detail_y += stats_lbl.get_height() + 4
        for key, val in sel_entry.stats:
            if detail_y + small_font.get_linesize() > screen_h - 10:
                break
            stat_surf = small_font.render(f"  {i18n.t(f'stat.{key}', key)}: {val}", True, (180, 230, 180))
            surface.blit(stat_surf, (RIGHT_X, detail_y))
            detail_y += small_font.get_linesize()
        detail_y += 8

    # Notes
    if sel_entry.notes:
        notes_lbl = small_font.render(i18n.t("codex_ui.notes_label"), True, (210, 180, 120))
        surface.blit(notes_lbl, (RIGHT_X, detail_y))
        detail_y += notes_lbl.get_height() + 4
        _notes = tuple(
            i18n.t(f"entry.{sel_entry.id}.note_{ni}", n)
            for ni, n in enumerate(sel_entry.notes)
        )
        for note in _notes:
            for line in _wrap_text(note, small_font, RIGHT_W - 12):
                if detail_y + small_font.get_linesize() > screen_h - 10:
                    break
                note_surf = small_font.render("  " + line, True, (220, 200, 160))
                surface.blit(note_surf, (RIGHT_X, detail_y))
                detail_y += small_font.get_linesize()
            if detail_y >= screen_h - 10:
                break

    return rects


def render_web_loading(surface: pygame.Surface, msg: str) -> None:
    w, h = surface.get_size()
    overlay = pygame.Surface((w, h), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    surface.blit(overlay, (0, 0))
    font = pygame.font.SysFont(None, 36)
    text = font.render(msg, True, (220, 220, 220))
    rect = text.get_rect(center=(w // 2, h // 2))
    surface.blit(text, rect)


def draw_map_preview_screen(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    screen_h: int,
    map_seed_state,
    preview_map,
    tile_size: int = 64,
) -> dict:
    """Draw the MAP_PREVIEW screen.

    Args:
        surface: Target surface.
        font: Body font.
        screen_w, screen_h: Screen dimensions.
        map_seed_state: MapSeedState instance.
        preview_map: GameMap instance for mini-map preview.
        tile_size: Game tile size (unused directly — preview scales to fit box).

    Returns:
        Dict with keys "random", "reroll", "confirm", "back" → pygame.Rect.
    """
    draw_menu_background(surface, screen_w, screen_h)

    title_font = _get_difficulty_title_font()
    title_surf = title_font.render(i18n.t("map_preview.title"), True, (255, 255, 255))
    surface.blit(title_surf, (screen_w // 2 - title_surf.get_width() // 2, 30))

    # --- Mini-map preview ---
    PREVIEW_W, PREVIEW_H = 400, 260
    preview_x = screen_w // 2 - PREVIEW_W // 2
    preview_y = 90
    preview_rect = pygame.Rect(preview_x, preview_y, PREVIEW_W, PREVIEW_H)
    pygame.draw.rect(surface, (30, 30, 40), preview_rect, border_radius=4)
    pygame.draw.rect(surface, (80, 80, 100), preview_rect, 2, border_radius=4)

    try:
        cols = getattr(preview_map, "cols", 18)
        rows = getattr(preview_map, "rows", 10)
        path = getattr(preview_map, "path", [])
        blocked = getattr(preview_map, "blocked_cells", set())
        path_set = set(path)

        cell_w = PREVIEW_W // max(1, cols)
        cell_h = PREVIEW_H // max(1, rows)
        cell_sz = max(1, min(cell_w, cell_h))

        draw_w = cell_sz * cols
        draw_h = cell_sz * rows
        off_x = preview_x + (PREVIEW_W - draw_w) // 2
        off_y = preview_y + (PREVIEW_H - draw_h) // 2

        BG_COLOR = (40, 50, 35)
        PATH_COLOR = (180, 150, 80)
        BLOCKED_COLOR = (90, 60, 60)

        for c in range(cols):
            for r in range(rows):
                rx = off_x + c * cell_sz
                ry = off_y + r * cell_sz
                if (c, r) in path_set:
                    color = PATH_COLOR
                elif (c, r) in blocked:
                    color = BLOCKED_COLOR
                else:
                    color = BG_COLOR
                pygame.draw.rect(surface, color, (rx, ry, cell_sz - 1, cell_sz - 1))
    except Exception:
        pass  # never crash in preview rendering

    # --- Seed label ---
    seed_text = f"Seed: {map_seed_state.seed_text}"
    seed_surf = font.render(seed_text, True, (200, 200, 160))
    surface.blit(seed_surf, (screen_w // 2 - seed_surf.get_width() // 2, preview_y + PREVIEW_H + 14))

    # --- Locked badge ---
    if map_seed_state.locked:
        badge_font = fonts.sized(13)
        badge_surf = badge_font.render(i18n.t("map_preview.challenge_locked"), True, (255, 200, 80))
        bx = screen_w // 2 - badge_surf.get_width() // 2
        by = preview_y + PREVIEW_H + 36
        pygame.draw.rect(surface, (80, 60, 20), (bx - 8, by - 4, badge_surf.get_width() + 16, badge_surf.get_height() + 8), border_radius=4)
        surface.blit(badge_surf, (bx, by))

    # --- Buttons ---
    btn_w, btn_h = 160, 44
    btn_y = screen_h - 80
    locked = map_seed_state.locked
    rerolls_left = map_seed_state.rerolls_left

    def _draw_btn(label: str, bx: int, enabled: bool) -> pygame.Rect:
        r = pygame.Rect(bx, btn_y, btn_w, btn_h)
        if enabled:
            bg = (50, 80, 130)
            border = (100, 150, 220)
            txt_color = (220, 230, 255)
        else:
            bg = (50, 50, 55)
            border = (90, 90, 100)
            txt_color = (110, 110, 120)
        pygame.draw.rect(surface, bg, r, border_radius=6)
        pygame.draw.rect(surface, border, r, 2, border_radius=6)
        lbl_surf = font.render(label, True, txt_color)
        surface.blit(lbl_surf, (r.centerx - lbl_surf.get_width() // 2, r.centery - lbl_surf.get_height() // 2))
        return r

    total_w = 4 * btn_w + 3 * 20
    start_x = screen_w // 2 - total_w // 2
    gap = 20

    random_rect = _draw_btn(i18n.t("map_preview.random"), start_x, not locked)
    reroll_label = i18n.t("map_preview.reroll").format(n=rerolls_left)
    reroll_rect = _draw_btn(reroll_label, start_x + btn_w + gap, not locked and rerolls_left > 0)
    confirm_rect = _draw_btn(i18n.t("map_preview.confirm"), start_x + 2 * (btn_w + gap), True)
    back_rect = _draw_btn(i18n.t("map_preview.back"), start_x + 3 * (btn_w + gap), True)

    return {
        "random": random_rect,
        "reroll": reroll_rect,
        "confirm": confirm_rect,
        "back": back_rect,
    }


def draw_boss_reward_screen(
    surface: pygame.Surface,
    font: pygame.font.Font,
    screen_w: int,
    screen_h: int,
    reward_ids: list[str],
    selected_reward_id: Optional[str],
) -> dict:
    draw_menu_background(surface, screen_w, screen_h)
    title_font = _get_difficulty_title_font()
    title = title_font.render(i18n.t("boss_reward.title"), True, (255, 255, 255))
    surface.blit(title, (screen_w // 2 - title.get_width() // 2, 56))

    labels = {
        rid: (
            i18n.t(f"boss_reward_data.{rid}.label", rid.replace("_", " ").title()),
            i18n.t(f"boss_reward_data.{rid}.description", ""),
        )
        for rid in ("gold_cache", "field_repair", "overclock_token")
    }

    cards: dict[str, pygame.Rect] = {}
    card_w, card_h = 240, 140
    gap = 20
    total_w = max(1, len(reward_ids)) * card_w + max(0, len(reward_ids) - 1) * gap
    start_x = screen_w // 2 - total_w // 2
    y = 180
    for i, reward_id in enumerate(reward_ids):
        rect = pygame.Rect(start_x + i * (card_w + gap), y, card_w, card_h)
        selected = reward_id == selected_reward_id
        bg = (55, 80, 120) if selected else (45, 45, 55)
        border = (120, 185, 255) if selected else (100, 100, 120)
        pygame.draw.rect(surface, bg, rect, border_radius=6)
        pygame.draw.rect(surface, border, rect, 2, border_radius=6)
        lbl, desc = labels.get(reward_id, (reward_id.replace("_", " ").title(), ""))
        lbl_s = font.render(lbl, True, (235, 240, 255))
        desc_s = font.render(desc, True, (190, 200, 220))
        surface.blit(lbl_s, (rect.centerx - lbl_s.get_width() // 2, rect.y + 34))
        surface.blit(desc_s, (rect.centerx - desc_s.get_width() // 2, rect.y + 74))
        cards[reward_id] = rect

    confirm = pygame.Rect(screen_w // 2 - 100, screen_h - 120, 200, 50)
    enabled = bool(selected_reward_id)
    bg = (60, 110, 70) if enabled else (60, 60, 65)
    border = (120, 220, 140) if enabled else (100, 100, 110)
    txt = (220, 255, 220) if enabled else (150, 150, 160)
    pygame.draw.rect(surface, bg, confirm, border_radius=6)
    pygame.draw.rect(surface, border, confirm, 2, border_radius=6)
    c_lbl = font.render(i18n.t("boss_reward.confirm"), True, txt)
    surface.blit(c_lbl, (confirm.centerx - c_lbl.get_width() // 2, confirm.centery - c_lbl.get_height() // 2))

    return {"cards": cards, "confirm": confirm}


def draw_profile_stats_summary(
    surface: pygame.Surface,
    font: pygame.font.Font,
    stats: dict,
    x: int,
    y: int,
) -> None:
    """Draw a compact profile stats line: Level N | XP: X | Runs: N | Best: N"""
    level = stats.get("level", 1)
    total_xp = stats.get("total_xp", 0)
    runs = stats.get("runs_played", 0)
    best = stats.get("best_score", 0)
    line = f"Level {level}  |  XP: {total_xp}  |  Runs: {runs}  |  Best: {best}"
    text_surf = font.render(line, True, (180, 230, 150))
    surface.blit(text_surf, (x, y))
