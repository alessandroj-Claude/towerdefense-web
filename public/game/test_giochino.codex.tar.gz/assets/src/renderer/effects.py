from __future__ import annotations
"""Renderer submodule: visual effects, tooltips, and placement previews."""
import random
from typing import Optional

import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass

from src import theme

_SELECTED_COLOR = (255, 255, 100)
_TOWER_COLORS = {
    "BasicTower": (70, 130, 180),
    "IceTower": (100, 200, 255),
    "BombTower": (200, 80, 40),
    "SniperTower": (180, 60, 180),
    "AntiAirTower": (110, 210, 255),
    "StormTower": (80, 200, 220),
    "InfernoTower": (255, 110, 40),
}


def compute_screen_shake_offset(strength: float, rng=None) -> tuple[int, int]:
    amplitude = max(0, int(round(float(strength))))
    if amplitude <= 0:
        return (0, 0)

    rand = random.random
    if rng is not None and callable(getattr(rng, "random", None)):
        rand = rng.random

    ox = int(round((rand() - 0.5) * 2 * amplitude))
    oy = int(round((rand() - 0.5) * 2 * amplitude))
    ox = max(-amplitude, min(amplitude, ox))
    oy = max(-amplitude, min(amplitude, oy))
    return (ox, oy)


def draw_damage_floats(
    surface: pygame.Surface,
    damage_floats: list[tuple[float, float, int, float]],
    dt: float,
) -> None:
    if not damage_floats:
        return
    max_age = 0.6
    step = max(0.0, float(dt))
    font = pygame.font.SysFont("Arial", 11)
    updated = []
    for x, y, value, age in damage_floats:
        new_age = float(age) + step
        if new_age > max_age:
            continue
        updated.append((x, y, int(value), new_age))
        progress = new_age / max_age if max_age > 0 else 1.0
        alpha = max(0, min(255, int(255 * (1.0 - progress))))
        y_offset = int(progress * 18.0)
        text = font.render(f"+{int(value)}", True, (255, 225, 120))
        text.set_alpha(alpha)
        surface.blit(text, (int(x) - text.get_width() // 2, int(y) - 20 - y_offset))
    damage_floats[:] = updated


def draw_placement_ghost(
    surface: pygame.Surface,
    selected_cls,
    hover_cell: Optional[tuple[int, int]],
    map_obj,
) -> None:
    if selected_cls is None or hover_cell is None or map_obj is None:
        return
    col, row = hover_cell
    if not (0 <= col < map_obj.cols and 0 <= row < map_obj.rows):
        return
    ts = map_obj.tile_size
    x = col * ts
    y = row * ts
    buildable = bool(map_obj.is_buildable(col, row))
    fill_rgb = (90, 220, 120) if buildable else (220, 80, 80)
    border_rgb = (180, 250, 190) if buildable else (255, 170, 170)
    ghost = pygame.Surface((ts, ts), pygame.SRCALPHA)
    pygame.draw.rect(ghost, (*fill_rgb, 100), (0, 0, ts, ts), border_radius=6)
    pygame.draw.rect(ghost, (*border_rgb, 170), (0, 0, ts, ts), width=2, border_radius=6)
    base_color = _TOWER_COLORS.get(getattr(selected_cls, "__name__", ""), _SELECTED_COLOR)
    cx = ts // 2
    cy = ts // 2
    r = max(6, ts // 4)
    pygame.draw.circle(ghost, (*base_color, 120), (cx, cy), r)
    surface.blit(ghost, (x, y))


def draw_terrain_tooltip(surface: pygame.Surface, font: pygame.font.Font,
                         mouse_pos: tuple[int, int], title: str, effects: list[str],
                         screen_w: int, screen_h: int, panel_top: int) -> None:
    lines = [title] + list(effects)
    rendered = [font.render(line, True, theme.TEXT_PRIMARY) for line in lines if line]
    if not rendered:
        return

    pad_x = 8
    pad_y = 6
    gap_y = 3
    w = max(s.get_width() for s in rendered) + pad_x * 2
    h = sum(s.get_height() for s in rendered) + gap_y * (len(rendered) - 1) + pad_y * 2
    w = min(w, max(1, screen_w - 8))
    h = min(h, max(1, min(screen_h - 8, panel_top - 8)))

    x = mouse_pos[0] + 14
    y = mouse_pos[1] + 14
    x = min(max(4, x), max(4, screen_w - w - 4))
    max_y = max(4, min(panel_top - h - 4, screen_h - h - 4))
    y = min(max(4, y), max_y)

    box = pygame.Surface((w, h), pygame.SRCALPHA)
    box.fill((28, 32, 36, 220))
    surface.blit(box, (x, y))
    pygame.draw.rect(surface, (120, 130, 145), (x, y, w, h), theme.BORDER_THIN, border_radius=5)

    cy = y + pad_y
    for idx, s in enumerate(rendered):
        tint = (235, 225, 160) if idx == 0 else theme.TEXT_PRIMARY
        line = font.render(lines[idx], True, tint)
        surface.blit(line, (x + pad_x, cy))
        cy += s.get_height() + gap_y


def draw_powerup_tooltip(surface: pygame.Surface, font: pygame.font.Font,
                         mouse_pos: tuple[int, int], tooltip: dict,
                         screen_w: int, screen_h: int) -> Optional[pygame.Rect]:
    lines = [
        str(tooltip.get("name", "")).strip(),
        f"Cost: {tooltip.get('cost', 0)}g",
        str(tooltip.get("description", "")).strip(),
        f"Duration: {tooltip.get('duration', '')}  Cooldown: {tooltip.get('cooldown', '')}",
        f"Status: {tooltip.get('status', '')}",
    ]
    rendered = [font.render(line, True, theme.TEXT_PRIMARY) for line in lines if line]
    if not rendered:
        return None

    pad_x = 8
    pad_y = 6
    gap_y = 3
    w = max(s.get_width() for s in rendered) + pad_x * 2
    h = sum(s.get_height() for s in rendered) + gap_y * (len(rendered) - 1) + pad_y * 2
    w = min(w, max(1, screen_w - 8))
    h = min(h, max(1, screen_h - 8))

    x = mouse_pos[0] + 14
    y = mouse_pos[1] + 14
    x = min(max(4, x), max(4, screen_w - w - 4))
    y = min(max(4, y), max(4, screen_h - h - 4))

    box = pygame.Surface((w, h), pygame.SRCALPHA)
    box.fill((28, 32, 36, 220))
    surface.blit(box, (x, y))
    pygame.draw.rect(surface, (120, 130, 145), (x, y, w, h), theme.BORDER_THIN, border_radius=5)

    cy = y + pad_y
    for idx, s in enumerate(rendered):
        tint = (235, 225, 160) if idx == 0 else theme.TEXT_PRIMARY
        line = font.render(lines[idx], True, tint)
        surface.blit(line, (x + pad_x, cy))
        cy += s.get_height() + gap_y

    return pygame.Rect(x, y, w, h)


def draw_range_preview(surface: pygame.Surface, col: int, row: int,
                       range_px: float, tile_size: int, buildable: bool) -> None:
    cx = col * tile_size + tile_size // 2
    cy = row * tile_size + tile_size // 2
    overlay = pygame.Surface((tile_size, tile_size), pygame.SRCALPHA)
    overlay.fill((0, 255, 0, 60) if buildable else (255, 0, 0, 60))
    surface.blit(overlay, (col * tile_size, row * tile_size))
    if buildable:
        r = int(range_px)
        rs = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
        pygame.draw.circle(rs, (255, 255, 255, theme.OVERLAY_ALPHA_LIGHT), (r + 2, r + 2), r, theme.BORDER_MEDIUM)
        surface.blit(rs, (cx - r - 2, cy - r - 2))


def draw_terrain_preview(
    surface: pygame.Surface,
    pending_delta: list,
    game_map,
    cell_size: int,
) -> None:
    if not pending_delta:
        return

    label_font = pygame.font.SysFont("Arial", 11)
    terrain_colors = {
        "mud": (180, 140, 60),
        "wind": (150, 196, 210),
        "high_wind": (126, 174, 196),
        "fortified": (180, 180, 180),
        "road": (220, 180, 100),
    }

    for col, row, new_terrain in pending_delta:
        x = col * cell_size
        y = row * cell_size
        border_color = terrain_colors.get(new_terrain, (255, 200, 0))
        border_thickness = theme.BORDER_THICK
        pygame.draw.rect(surface, border_color, (x, y, cell_size, cell_size), border_thickness)
        label_text = f"→{new_terrain}"
        label_surf = label_font.render(label_text, True, border_color)
        label_x = x + 4
        label_y = y + 4
        surface.blit(label_surf, (label_x, label_y))
