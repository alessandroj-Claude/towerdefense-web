from __future__ import annotations
import pygame
if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass
from typing import Optional
from src.tower import (
    BasicTower, IceTower, BombTower, SniperTower, AntiAirTower, LightningTower, StormTower,
    InfernoTower, VenomTower, MedicTower, SentinelTower, Tower, placement_cost_for_level,
    XP_THRESHOLDS,
)
from src.elements import ELEMENTS, get_damage_mult
from src.economy import Economy
from src.powerups import POWERUP_BY_ID, POWERUP_POOL
from src.renderer import COLORS
from src.renderer._fonts import fonts
from src import theme
from src import i18n
from src.ui_commands import (
    UICommand, PowerupCommand, TowerSelectCommand, TowerLevelSelectCommand,
    LoadoutCommand, QueueAddCommand, QueueRemoveCommand, PolicyCommand,
    LockedCommand, SpeedCommand, StartWaveCommand, RepairToggleCommand,
    RepairAllCommand, UpgradeAllCommand, AutoRepairAllToggleCommand,
    SellTowerCommand,
)

TOWER_CLASSES = [
    BasicTower, IceTower, BombTower, SniperTower, AntiAirTower, LightningTower, StormTower,
    InfernoTower, VenomTower, MedicTower, SentinelTower,
]
SPEED_OPTIONS = [
    ("x1", 1.0),
    ("x1.5", 1.5),
    ("x2", 2.0),
    ("x3", 3.0),
]
TOWER_SHOP_INFO = {
    BasicTower: ("Basic", "50g"),
    IceTower: ("Ice", "80g"),
    BombTower: ("Bomb", "120g"),
    SniperTower: ("Sniper", "150g"),
    AntiAirTower: ("Anti-Air", "130g"),
    LightningTower: ("Lightning", "160g"),
    StormTower: ("Storm", "110g"),
    InfernoTower: ("Inferno", "180g"),
    VenomTower: ("Venom", "140g"),
    MedicTower: ("Medic", "110g"),
    SentinelTower: ("Sentinel", "200g"),
}
TOWER_DLC_REQUIREMENTS = {
    StormTower: "storm_pack",
}
TOWER_WAVE_REQUIREMENTS: dict[type, int] = {
    IceTower: 3,
    BombTower: 3,
    LightningTower: 5,
    StormTower: 5,
    InfernoTower: 5,
    VenomTower: 5,
    MedicTower: 5,
    SentinelTower: 5,
}
TOWER_SPECIALS = {
    BasicTower: "Balanced single-target DPS.",
    IceTower: "Slows enemies on hit.",
    BombTower: "Splash damage in small area.",
    SniperTower: "Long range, high burst shots.",
    AntiAirTower: "Prioritizes flying enemies with bonus anti-air damage.",
    LightningTower: "Chains to 2 nearby enemies for 50% damage.",
    StormTower: "Fast shots with chain-lightning focus.",
    InfernoTower: "Explosive burn burst with splash.",
    VenomTower: "Poisons enemies for 2% max HP/s for 3s.",
    MedicTower: "Heals adjacent towers +8 HP/s. Cannot attack.",
    SentinelTower: "High HP tank. Enemies preferentially target this tower.",
}
TOWER_LEVEL_OPTIONS = [
    (1, "*"),
    (2, "**"),
    (3, "***"),
]
POWERUP_LABELS = {
    "overcharge": "Overchg",
    "field_repairs": "Repairs",
    "radar_pulse": "Radar",
    "aa_salvo": "AA Salvo",
    "scramble": "Scramble",
}

POWERUP_TOOLTIP_META = {
    "overcharge": {
        "name": "Overcharge",
        "description": "Boost tower fire rate for a short burst.",
    },
    "field_repairs": {
        "name": "Field Repairs",
        "description": "Repair all towers once when activated.",
    },
    "radar_pulse": {
        "name": "Radar Pulse",
        "description": "Reveal all flying enemies on the map.",
    },
    "aa_salvo": {
        "name": "AA Salvo",
        "description": "Deal 50 damage to all flying enemies.",
    },
    "scramble": {
        "name": "Scramble",
        "description": "Slow flying enemies to 0.5x speed.",
    },
}

PANEL_HEIGHT = 328
HUD_BAR_HEIGHT = 58  # row1 (34px resources+speed) + row2 (24px timers)

REPAIR_FRACTION = {"easy": 1.0, "normal": 0.66, "hard": 0.33, "endless": 0.33}


def repair_cost(tower) -> int:
    return int(tower.base_cost * 0.3)


def repair_hp(tower, difficulty: str) -> int:
    chunk = int(tower.max_hp * REPAIR_FRACTION.get(difficulty, 0.33))
    return min(chunk, tower.max_hp - tower.hp)


def tower_requires_dlc(cls) -> Optional[str]:
    return TOWER_DLC_REQUIREMENTS.get(cls)


def tower_is_unlocked(cls, unlocked_dlcs: set, current_wave: int = 0) -> bool:
    dlc_id = tower_requires_dlc(cls)
    if dlc_id is not None:
        return dlc_id in unlocked_dlcs
    wave_req = TOWER_WAVE_REQUIREMENTS.get(cls, 0)
    return current_wave >= wave_req


def get_tower_card_info(cls) -> Optional[dict]:
    if cls not in TOWER_CLASSES:
        return None
    range_scale = float(getattr(cls, "RANGE_SCALE", 1.0))
    element = str(getattr(cls, "element", "ARCANE"))
    strong_vs = [e for e in ELEMENTS if get_damage_mult(element, e) > 1.0]
    neutral_vs = [e for e in ELEMENTS if get_damage_mult(element, e) == 1.0]
    weak_vs = [e for e in ELEMENTS if get_damage_mult(element, e) < 1.0]
    return {
        "name": TOWER_SHOP_INFO[cls][0],
        "cost": cls.base_cost,
        "damage": cls.base_damage,
        "range": cls.base_range * range_scale,
        "fire_rate": cls.base_fire_rate,
        "max_hp": cls.max_hp,
        "element": element,
        "strong_vs": strong_vs,
        "neutral_vs": neutral_vs,
        "weak_vs": weak_vs,
        "special": TOWER_SPECIALS.get(cls, ""),
    }


class UI:
    def __init__(self, screen_w: int, screen_h: int, font: pygame.font.Font, touch_mode: bool = False):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.touch_mode = touch_mode
        self.font = font
        self.shop_font = fonts.sized_bold(14)
        self.shop_badge_font = fonts.sized_bold(12)
        self.card_font = fonts.sized(13)
        self.card_title_font = fonts.sized_bold(15)
        self.policy_font = fonts.sized_bold(14)
        self.panel_rect = pygame.Rect(0, screen_h - PANEL_HEIGHT, screen_w, PANEL_HEIGHT)
        self._tower_card_rect: Optional[pygame.Rect] = None
        self._sell_btn_rect: Optional[pygame.Rect] = None
        self._btn_rects: list = []
        self._speed_btn_rects: list = []
        self._powerup_slot_defs = [{"id": p.id, "cost": p.cost} for p in POWERUP_POOL]
        self._powerup_btn_rects: list = []
        self._policy_btn_rects: list = []
        content_top = self.panel_rect.y + HUD_BAR_HEIGHT + 8
        top_row_y = content_top
        top_row_h = 36 if touch_mode else 24
        bottom_row_y = top_row_y + top_row_h + 10
        # Two-row tower shop layout to avoid overcrowded single row.
        tower_row_gap = 8
        tower_btn_h = 60
        tower_rows = 2
        towers_per_row = (len(TOWER_CLASSES) + tower_rows - 1) // tower_rows
        btn_gap = 6
        # Compute repair button position: tower buttons + gap + repair area + card
        card_w = 260  # right-side card panel width
        repair_area_w = 100  # repair button width
        left_margin = 10
        right_margin = 10
        gap_before_repair = 4
        available_for_buttons = screen_w - left_margin - gap_before_repair - repair_area_w - card_w - right_margin
        btn_w = (available_for_buttons - (towers_per_row - 1) * btn_gap) // towers_per_row
        btn_w = max(56, btn_w)
        # Tower button rects (row-major order preserving TOWER_CLASSES mapping)
        self._btn_rects = []
        for i, _cls in enumerate(TOWER_CLASSES):
            row_idx = i // towers_per_row
            col_idx = i % towers_per_row
            x = left_margin + col_idx * (btn_w + btn_gap)
            y = bottom_row_y + row_idx * (tower_btn_h + tower_row_gap)
            rect = pygame.Rect(x, y, btn_w, tower_btn_h)
            self._btn_rects.append(rect)
        # Tower level boxes
        box_w = 16
        box_h = 16
        box_gap = 2
        self._tower_level_box_rects = {}
        for cls, rect in zip(TOWER_CLASSES, self._btn_rects):
            level_rects = []
            for index, _ in enumerate(TOWER_LEVEL_OPTIONS):
                box_x = rect.right - box_w - 4
                box_y = rect.y + 4 + index * (box_h + box_gap)
                level_rects.append(pygame.Rect(box_x, box_y, box_w, box_h))
            self._tower_level_box_rects[cls] = level_rects
        # Repair buttons positioned immediately to the right of the tower grid
        rightmost_tower = max(r.right for r in self._btn_rects)
        repair_x = rightmost_tower + gap_before_repair
        repair_btn_w = 100
        repair_btn_h = 36 if touch_mode else 28
        repair_btn_gap = 6 if touch_mode else 2
        repair_top = bottom_row_y
        self.repair_btn = pygame.Rect(
            repair_x, repair_top, repair_btn_w, repair_btn_h
        )
        self.repair_all_btn = pygame.Rect(
            repair_x, repair_top + repair_btn_h + repair_btn_gap, repair_btn_w, repair_btn_h
        )
        self.auto_repair_all_btn = pygame.Rect(
            repair_x, repair_top + 2 * (repair_btn_h + repair_btn_gap), repair_btn_w, repair_btn_h
        )
        self.upgrade_all_btn = pygame.Rect(
            repair_x, repair_top + 3 * (repair_btn_h + repair_btn_gap), repair_btn_w, repair_btn_h
        )
        self.start_btn = pygame.Rect(
            screen_w - 130, top_row_y, 120, top_row_h
        )
        powerup_btn_w = 74
        powerup_btn_h = top_row_h
        powerup_btn_gap = 2
        powerup_group_w = len(self._powerup_slot_defs) * powerup_btn_w + max(0, len(self._powerup_slot_defs) - 1) * powerup_btn_gap
        powerup_x = self.start_btn.left - powerup_group_w - 8
        powerup_y = top_row_y
        for i in range(len(self._powerup_slot_defs)):
            x = powerup_x + i * (powerup_btn_w + powerup_btn_gap)
            self._powerup_btn_rects.append(pygame.Rect(x, powerup_y, powerup_btn_w, powerup_btn_h))
        # Loadout buttons (pre-wave): positioned in top row, left of powerup buttons
        self._loadout_btn_rects: dict[str, pygame.Rect] = {}
        loadout_btn_w = 72
        loadout_btn_h = top_row_h
        loadout_btn_gap = 4
        loadout_presets = ["anti-air", "economy", "repair"]
        loadout_group_w = len(loadout_presets) * loadout_btn_w + (len(loadout_presets) - 1) * loadout_btn_gap
        loadout_x = 10
        loadout_y = top_row_y
        for i, preset_name in enumerate(loadout_presets):
            x = loadout_x + i * (loadout_btn_w + loadout_btn_gap)
            rect = pygame.Rect(x, loadout_y, loadout_btn_w, loadout_btn_h)
            self._loadout_btn_rects[preset_name] = rect

        # Queue add buttons (pre-wave): bottom of panel
        self._queue_add_btn_rects: list[dict] = []
        self._queue_remove_btn_rects: list[dict] = []
        queue_btn_w = 90
        queue_btn_h = 36 if touch_mode else 28
        queue_btn_gap = 2
        queue_presets = [
            ("auto-repair-all", "Q:AutoRep"),
            ("upgrade-all:tower_cls=BasicTower", "Q:UpgBasic"),
            ("powerup:powerup_id=overcharge", "Q:Overchg"),
        ]
        queue_x = 10
        queue_y = self.panel_rect.bottom - queue_btn_h - 4
        for i, (action_key, label) in enumerate(queue_presets):
            x = queue_x + i * (queue_btn_w + queue_btn_gap)
            rect = pygame.Rect(x, queue_y, queue_btn_w, queue_btn_h)
            self._queue_add_btn_rects.append({"action": action_key, "label": label, "rect": rect})

    def _draw_cost_tooltip(self, surface: pygame.Surface, mouse_pos: tuple, label: str, cost: int) -> None:
        import src.theme as theme
        font = self.shop_font
        text = f"{label}: {cost}g"
        text_surf = font.render(text, True, theme.TEXT_PRIMARY)
        pad = 6
        w = text_surf.get_width() + pad * 2
        h = text_surf.get_height() + pad * 2
        mx, my = mouse_pos
        rx = mx + 12
        ry = my - h - 4
        if rx + w > surface.get_width():
            rx = mx - w - 4
        if ry < 0:
            ry = my + 12
        bg = pygame.Surface((w, h), pygame.SRCALPHA)
        bg.fill((20, 20, 20, 210))
        surface.blit(bg, (rx, ry))
        pygame.draw.rect(surface, theme.TEXT_SECONDARY, pygame.Rect(rx, ry, w, h), 1, border_radius=4)
        surface.blit(text_surf, (rx + pad, ry + pad))

    def _wrap_text(self, text: str, max_chars: int) -> list[str]:
        words = text.split()
        if not words:
            return []
        lines = [words[0]]
        for word in words[1:]:
            candidate = f"{lines[-1]} {word}"
            if len(candidate) <= max_chars:
                lines[-1] = candidate
            else:
                lines.append(word)
        return lines

    def _get_available_powerup_slots(self, current_wave: int) -> list[dict]:
        """Filter powerup slots by wave availability."""
        available = []
        for powerup in POWERUP_POOL:
            min_wave = getattr(powerup, "min_wave", 0)
            if current_wave >= min_wave:
                available.append({"id": powerup.id, "cost": powerup.cost})
        return available

    def get_hovered_powerup_slot(self, pos, current_wave: int = 1) -> Optional[dict]:
        available_slots = self._get_available_powerup_slots(current_wave)
        for slot, rect in zip(available_slots, self._powerup_btn_rects[:len(available_slots)]):
            if rect.collidepoint(pos):
                return {"id": slot["id"], "cost": slot["cost"], "rect": rect}
        return None

    def get_powerup_tooltip(self, powerup_id: str, economy: Economy, powerup_state: Optional[object] = None) -> dict:
        powerup = POWERUP_BY_ID[powerup_id]
        meta = POWERUP_TOOLTIP_META.get(powerup_id, {})
        active_timers = getattr(powerup_state, "active_timers", {}) if powerup_state else {}
        cooldown_timers = getattr(powerup_state, "cooldown_timers", {}) if powerup_state else {}
        active_left = float(active_timers.get(powerup_id, 0.0))
        cooldown_left = float(cooldown_timers.get(powerup_id, 0.0))
        if active_left > 0.0:
            status = "active"
        elif cooldown_left > 0.0:
            status = "cooldown"
        else:
            status = "ready"
        duration = "instant" if powerup.duration <= 0.0 else f"{powerup.duration:.1f}s"
        return {
            "id": powerup.id,
            "name": meta.get("name", powerup_id.replace("_", " ").title()),
            "cost": powerup.cost,
            "description": meta.get("description", ""),
            "duration": duration,
            "cooldown": f"{powerup.cooldown:.1f}s",
            "status": status,
            "affordable": economy.can_afford(powerup.cost),
        }

    def draw(self, surface: pygame.Surface, economy: Economy,
             selected_cls, selected_tower: object,
             wave_active: bool, countdown: float,
             towers=None, tile_size=None, unlocked_dlcs: Optional[set] = None,
             notice: str = "", show_tower_card: bool = True,
             repair_mode_active: bool = False,
             auto_repair_all_enabled: bool = False,
             placement_levels: dict = None,
             simulation_speed: float = 1.0,
             powerup_state: Optional[object] = None,
             adaptive_rationale: str = "",
             current_wave: int = 1,
             active_synergies: list = None) -> None:
        pygame.draw.rect(surface, COLORS["ui_bg"], self.panel_rect)
        mouse_pos = pygame.mouse.get_pos()
        unlocked_dlcs = unlocked_dlcs or set()
        self._tower_card_rect = None
        _lvls = placement_levels or {}

        for i, (cls, rect) in enumerate(zip(TOWER_CLASSES, self._btn_rects)):
            cls_level = max(1, min(3, _lvls.get(cls, 1)))
            unlocked = tower_is_unlocked(cls, unlocked_dlcs, current_wave=current_wave)
            cost_for_level = placement_cost_for_level(cls, cls_level)
            can = economy.can_afford(cost_for_level)
            if not unlocked:
                color = theme.PANEL_BG  # darker shade for locked tower buttons
            elif can:
                color = theme.BUTTON_DEFAULT
            else:
                color = (40, 40, 40)  # no theme constant — kept original (R,G,B) to avoid visual regression
            if rect.collidepoint(mouse_pos):
                color = theme.BUTTON_HOVER if unlocked else theme.GRID
            pygame.draw.rect(surface, color, rect, border_radius=6)
            if cls is selected_cls and unlocked:
                pygame.draw.rect(surface, COLORS["selected"], rect, width=2, border_radius=6)
            name = TOWER_SHOP_INFO[cls][0]
            wave_req = TOWER_WAVE_REQUIREMENTS.get(cls, 0)
            wave_locked = not unlocked and wave_req > 0 and tower_requires_dlc(cls) is None
            if wave_locked:
                price = i18n.t("tower.locked_wave").format(n=wave_req)
            else:
                price = f"{cost_for_level}g"
            label_color = COLORS["text"] if unlocked and can else theme.TEXT_SECONDARY
            top_surf = self.shop_font.render(name, True, label_color)
            bottom_surf = self.shop_font.render(price, True, label_color)
            surface.blit(top_surf, (rect.x + 5, rect.y + 6))
            surface.blit(bottom_surf, (rect.x + 5, rect.y + 30))
            if wave_locked:
                overlay = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 120))
                surface.blit(overlay, rect.topleft)
            for (level, stars), level_rect in zip(TOWER_LEVEL_OPTIONS, self._tower_level_box_rects.get(cls, [])):
                level_selected = cls is selected_cls and level == cls_level
                if not unlocked:
                    box_bg = theme.GRID  # dark gray for locked level boxes
                    text_color = (115, 115, 115)  # no theme constant — kept original (R,G,B) to avoid visual regression
                elif can:
                    box_bg = theme.BUTTON_HOVER  # lighter button for affordable level
                    text_color = theme.TEXT_PRIMARY
                else:
                    box_bg = theme.PANEL_BG  # dark for unaffordable level
                    text_color = theme.TEXT_SECONDARY
                border_color = theme.SELECTED_BORDER if level_selected else (95, 95, 95)  # no theme constant — kept original (R,G,B) to avoid visual regression
                pygame.draw.rect(surface, box_bg, level_rect, border_radius=3)
                pygame.draw.rect(surface, border_color, level_rect, width=1, border_radius=3)
                stars_surf = self.card_font.render(stars, True, text_color)
                surface.blit(
                    stars_surf,
                    (
                        level_rect.centerx - stars_surf.get_width() // 2,
                        level_rect.centery - stars_surf.get_height() // 2,
                    ),
                )
            if not unlocked:
                badge = self.shop_badge_font.render("LOCK", True, theme.HP_MED)  # golden text for lock badge
                badge_bg = pygame.Rect(rect.x + 4, rect.y + 4, badge.get_width() + 6, badge.get_height() + 2)
                pygame.draw.rect(surface, theme.EVENT_NEGATIVE, badge_bg, border_radius=3)  # dark red badge bg
                surface.blit(badge, (badge_bg.x + 3, badge_bg.y + 1))

        # Draw loadout preset buttons (visible only when wave is NOT active)
        if not wave_active:
            loadout_labels = {
                "anti-air": "AA",
                "economy": "Eco",
                "repair": "Rep",
            }
            loadout_border_colors = {
                "anti-air": (255, 240, 50),
                "economy": (230, 200, 50),
                "repair": theme.HP_HIGH,
            }
            for preset_name, rect in self._loadout_btn_rects.items():
                label = loadout_labels.get(preset_name, preset_name.title())
                hovered = rect.collidepoint(mouse_pos)
                bg_color = theme.HIGH_WIND if hovered else theme.WIND
                border_color = loadout_border_colors.get(preset_name, theme.HIGH_WIND)
                pygame.draw.rect(surface, bg_color, rect, border_radius=4)
                pygame.draw.rect(surface, border_color, rect, width=1, border_radius=4)
                label_surf = self.shop_font.render(label, True, theme.TEXT_PRIMARY)
                surface.blit(label_surf, (rect.centerx - label_surf.get_width() // 2, rect.centery - label_surf.get_height() // 2))

        if show_tower_card and selected_cls:
            info = get_tower_card_info(selected_cls)
            if info is not None:
                card_left = self.repair_btn.right + 8
                card_top = self._btn_rects[0].y
                card_right = self.screen_w - 8
                card_w = max(0, card_right - card_left)
                card_h = self.panel_rect.bottom - card_top - 6
                if card_w > 0 and card_h > 0:
                    self._tower_card_rect = pygame.Rect(card_left, card_top, card_w, card_h)
                    pygame.draw.rect(surface, theme.GRID, self._tower_card_rect, border_radius=6)  # dark card bg
                    pygame.draw.rect(surface, theme.BUTTON_HOVER, self._tower_card_rect, 1, border_radius=6)  # card border

                    x = self._tower_card_rect.x + 6
                    y = self._tower_card_rect.y + 4
                    title = self.card_title_font.render(f"{info['name']}  {info['cost']}g", True, COLORS["text"])
                    surface.blit(title, (x, y))

                    label_y = y + 15
                    mid_x = x + max(82, (card_w // 2) - 10)
                    left_lines = (
                        f"DMG: {info['damage']:.0f}",
                        f"RNG: {info['range']:.0f}",
                    )
                    right_lines = (
                        f"FR: {info['fire_rate']:.2f}/s",
                        f"HP: {info['max_hp']}",
                    )
                    for idx, line in enumerate(left_lines):
                        surf = self.card_font.render(line, True, COLORS["text"])
                        surface.blit(surf, (x, label_y + idx * 11))
                    for idx, line in enumerate(right_lines):
                        surf = self.card_font.render(line, True, COLORS["text"])
                        surface.blit(surf, (mid_x, label_y + idx * 11))

                    matchup_y = label_y + 24
                    elem_color = theme.ELEMENT_COLORS.get(info["element"], theme.TEXT_PRIMARY)
                    elem_line = self.card_font.render(f"ELEM: {info['element']}", True, elem_color)
                    surface.blit(elem_line, (x, matchup_y))
                    matchup_y += 10

                    strong_line = "STRONG: " + (", ".join(info["strong_vs"]) if info["strong_vs"] else "-")
                    neutral_line = "NEUTRAL: " + (", ".join(info["neutral_vs"]) if info["neutral_vs"] else "-")
                    weak_line = "WEAK: " + (", ".join(info["weak_vs"]) if info["weak_vs"] else "-")
                    for line, color in (
                        (strong_line, theme.EVENT_POSITIVE),
                        (neutral_line, theme.TEXT_SECONDARY),
                        (weak_line, theme.EVENT_NEGATIVE),
                    ):
                        for wrapped_line in self._wrap_text(line, max_chars=max(14, card_w // 9))[:2]:
                            surf = self.card_font.render(wrapped_line, True, color)
                            surface.blit(surf, (x, matchup_y))
                            matchup_y += 10

                    special_y = max(matchup_y + 2, label_y + 24)
                    max_chars = max(14, card_w // 8)
                    special_lines = self._wrap_text(f"PWR: {info['special']}", max_chars=max_chars)
                    for line in special_lines[:2]:
                        surf = self.card_font.render(line, True, theme.HP_MED)
                        surface.blit(surf, (x, special_y))
                        special_y += 10

        if not selected_tower:
            self._sell_btn_rect = None

        if selected_tower:
            t = selected_tower
            info = (f"{type(t).__name__} Lv{t.level}  "
                    f"DMG:{t.damage:.0f}  RNG:{t.range_px:.0f}")
            if t.level < 3:
                info += f"  [U] Upgrade {t.upgrade_cost}g"
            surf = self.font.render(info, True, COLORS["gold"])
            surface.blit(surf, (10, self.panel_rect.y - 24))

            # Draw XP progress bar
            _xp_tier = getattr(t, "xp_tier", 0)
            _xp_bar_w = 140
            _xp_bar_h = 8
            _xp_bar_x = 10
            _xp_bar_y = self.panel_rect.y - 24 - _xp_bar_h - 14 - 2  # above info line
            if _xp_tier < len(XP_THRESHOLDS):
                _xp_prev = XP_THRESHOLDS[_xp_tier - 1] if _xp_tier > 0 else 0
                _xp_next = XP_THRESHOLDS[_xp_tier]
                _xp_val = getattr(t, "xp", 0)
                _xp_progress = max(0.0, min(1.0, (_xp_val - _xp_prev) / (_xp_next - _xp_prev)))
                _xp_label = f"★{_xp_tier}  {_xp_val}/{_xp_next} XP → ★{_xp_tier + 1}"
            else:
                _xp_progress = 1.0
                _xp_label = f"★{_xp_tier}  MAX"
            pygame.draw.rect(surface, (50, 50, 60),
                             (_xp_bar_x, _xp_bar_y, _xp_bar_w, _xp_bar_h), border_radius=4)
            pygame.draw.rect(surface, (255, 215, 80),
                             (_xp_bar_x, _xp_bar_y, int(_xp_bar_w * _xp_progress), _xp_bar_h),
                             border_radius=4)
            _xp_label_surf = self.card_font.render(_xp_label, True, (220, 200, 100))
            surface.blit(_xp_label_surf, (_xp_bar_x, _xp_bar_y + _xp_bar_h + 2))

            # Draw policy buttons
            self._policy_btn_rects = []
            policies = [
                ("Far", "furthest"),
                ("Str", "strongest"),
                ("Low", "lowest-hp"),
                ("Fly", "flying-first"),
            ]
            btn_w, btn_h = 36, 24
            btn_gap = 4
            policy_y = self.panel_rect.y - 44 - 26  # shifted up to make room for XP bar
            current_policy = getattr(t, "targeting_policy", "furthest")

            for idx, (label, policy_name) in enumerate(policies):
                btn_x = 10 + idx * (btn_w + btn_gap)
                rect = pygame.Rect(btn_x, policy_y, btn_w, btn_h)
                is_active = current_policy == policy_name
                hovered = rect.collidepoint(mouse_pos)
                bg_color = theme.EVENT_POSITIVE if is_active else (theme.BUTTON_HOVER if hovered else theme.BUTTON_DEFAULT)
                pygame.draw.rect(surface, bg_color, rect, border_radius=3)
                border = theme.SELECTED_BORDER if (is_active or hovered) else theme.GRID
                pygame.draw.rect(surface, border, rect, width=1, border_radius=3)

                txt_color = theme.TEXT_PRIMARY if (is_active or hovered) else theme.TEXT_SECONDARY
                txt = self.policy_font.render(label, True, txt_color)
                surface.blit(txt, (rect.centerx - txt.get_width() // 2,
                                   rect.centery - txt.get_height() // 2))

                self._policy_btn_rects.append({
                    "policy": policy_name,
                    "rect": rect,
                    "bulk": False,
                })

            # Draw "All" bulk button
            if True:
                bulk_x = 10 + len(policies) * (btn_w + btn_gap) + 4
                bulk_rect = pygame.Rect(bulk_x, policy_y, 34, btn_h)
                bulk_hovered = bulk_rect.collidepoint(mouse_pos)
                bulk_bg = theme.EVENT_NEGATIVE if bulk_hovered else (100, 80, 80)
                pygame.draw.rect(surface, bulk_bg, bulk_rect, border_radius=3)
                pygame.draw.rect(surface, theme.SELECTED_BORDER if bulk_hovered else theme.GRID, bulk_rect, width=1, border_radius=3)
                bulk_txt = self.policy_font.render(i18n.t("ui.all"), True, theme.TEXT_PRIMARY)
                surface.blit(bulk_txt, (bulk_rect.centerx - bulk_txt.get_width() // 2,
                                       bulk_rect.centery - bulk_txt.get_height() // 2))
                self._policy_btn_rects.append({
                    "policy": current_policy,
                    "rect": bulk_rect,
                    "bulk": True,
                })

            # Draw Sell button (to the right of bulk button)
            sell_btn_w = 48
            sell_btn_h = 36 if self.touch_mode else 24
            sell_x = bulk_x + 34 + 8
            sell_rect = pygame.Rect(sell_x, policy_y, sell_btn_w, sell_btn_h)
            sell_hovered = sell_rect.collidepoint(mouse_pos)
            sell_bg = (200, 50, 50) if sell_hovered else (160, 40, 40)
            pygame.draw.rect(surface, sell_bg, sell_rect, border_radius=3)
            pygame.draw.rect(surface, theme.SELECTED_BORDER if sell_hovered else theme.GRID,
                             sell_rect, width=1, border_radius=3)
            sell_txt = self.policy_font.render(i18n.t("ui.sell"), True, theme.TEXT_PRIMARY)
            surface.blit(sell_txt, (sell_rect.centerx - sell_txt.get_width() // 2,
                                    sell_rect.centery - sell_txt.get_height() // 2))
            self._sell_btn_rect = sell_rect

            # Draw synergy badges (max 2) to the right of Sell button
            if active_synergies:
                tower_synergies = [
                    e for e in active_synergies
                    if e.tower_a is t or e.tower_b is t
                ][:2]
                badge_x = sell_rect.right + 10
                for effect in tower_synergies:
                    badge_surf = self.policy_font.render(
                        f"* {effect.label}", True, theme.HP_MED
                    )
                    surface.blit(badge_surf, (badge_x, sell_rect.centery - badge_surf.get_height() // 2))
                    badge_x += badge_surf.get_width() + 8

        # Upgrade hover preview when same-type tower is under cursor
        if selected_cls and towers is not None and tile_size is not None:
            mx, my = pygame.mouse.get_pos()
            if not self.is_in_panel((mx, my)) and my // tile_size < (self.screen_h - PANEL_HEIGHT) // tile_size:
                hov_col, hov_row = mx // tile_size, my // tile_size
                hov_tower = next(
                    (t for t in towers if t.col == hov_col and t.row == hov_row
                     and isinstance(t, selected_cls)), None
                )
                if hov_tower:
                    preview = hov_tower.upgrade_preview_stats
                    if preview["max_level"]:
                        info = f"[Shop-click] Max livello raggiunto"
                    else:
                        info = (f"[Shop-click] Upgrade → Lv{hov_tower.level + 1}  "
                                f"DMG:{preview['damage']:.0f}  RNG:{preview['range_px']:.0f}  "
                                f"Cost:{preview['cost']}g")
                    surf = self.font.render(info, True, theme.EVENT_POSITIVE)  # bright green for upgrade preview
                    surface.blit(surf, (10, self.panel_rect.y - 44))

        if notice:
            surf = self.font.render(notice, True, theme.HP_MED)  # golden/yellow for notice text
            surface.blit(
                surf,
                (
                    self.screen_w // 2 - surf.get_width() // 2,
                    self.panel_rect.y - surf.get_height() - 6,
                ),
            )

        available_slots = self._get_available_powerup_slots(current_wave)
        for slot, rect in zip(available_slots, self._powerup_btn_rects[:len(available_slots)]):
            powerup_id = slot["id"]
            active_timers = getattr(powerup_state, "active_timers", {}) if powerup_state else {}
            cooldown_timers = getattr(powerup_state, "cooldown_timers", {}) if powerup_state else {}
            active_left = float(active_timers.get(powerup_id, 0.0))
            cooldown_left = float(cooldown_timers.get(powerup_id, 0.0))
            if active_left > 0.0:
                bg = theme.EVENT_POSITIVE  # green when active
                state_txt = f"{active_left:.1f}s"
            elif cooldown_left > 0.0:
                bg = (85, 65, 65)  # no theme constant — dark muted danger fill, EVENT_NEGATIVE is too bright for large fills
                state_txt = f"CD {cooldown_left:.1f}s"
            elif economy.can_afford(slot["cost"]):
                bg = theme.BUTTON_DEFAULT  # neutral gray when affordable
                state_txt = f"{slot['cost']}g"
            else:
                bg = theme.PANEL_BG  # dark when unaffordable
                state_txt = f"{slot['cost']}g"
            pygame.draw.rect(surface, bg, rect, border_radius=4)
            label_txt = POWERUP_LABELS.get(powerup_id, powerup_id.replace("_", " ").title())
            title_surf = self.shop_badge_font.render(label_txt, True, theme.TEXT_PRIMARY)
            state_surf = self.shop_badge_font.render(state_txt, True, (220, 220, 220))  # no theme constant — subtle darkening for state text contrast
            surface.blit(title_surf, (rect.centerx - title_surf.get_width() // 2, rect.y + 1))
            surface.blit(state_surf, (rect.centerx - state_surf.get_width() // 2, rect.y + 10))

        # Repair button
        damaged_towers = [t for t in (towers or []) if t.hp < t.max_hp]
        min_repair_cost = min((repair_cost(t) for t in damaged_towers), default=0)
        has_repair_target = bool(damaged_towers) and economy.gold >= min_repair_cost

        repair_color = (40, 120, 60) if repair_mode_active else (50, 80, 50)  # no theme constant — active state green, FORTIFIED terrain color is too dark; EVENT_POSITIVE too bright for bg
        pygame.draw.rect(surface, repair_color, self.repair_btn, border_radius=6)
        repair_label = "Repair ON" if repair_mode_active else "Repair"
        repair_label_color = theme.EVENT_POSITIVE if has_repair_target or repair_mode_active else theme.TEXT_SECONDARY
        surf = self.font.render(repair_label, True, repair_label_color)
        surface.blit(surf, (self.repair_btn.centerx - surf.get_width() // 2,
                            self.repair_btn.centery - surf.get_height() // 2))

        repair_all_enabled = has_repair_target
        repair_all_color = (70, 110, 70) if repair_all_enabled else theme.PANEL_BG  # no theme constant — active state green, FORTIFIED terrain color is too dark
        pygame.draw.rect(surface, repair_all_color, self.repair_all_btn, border_radius=6)
        ra_color = theme.EVENT_POSITIVE if repair_all_enabled else theme.TEXT_SECONDARY  # bright green text when enabled
        ra_surf = self.font.render(i18n.t("ui.repair_all"), True, ra_color)
        surface.blit(ra_surf, (self.repair_all_btn.centerx - ra_surf.get_width() // 2,
                               self.repair_all_btn.centery - ra_surf.get_height() // 2))

        auto_repair_all_enabled = bool(auto_repair_all_enabled)
        auto_repair_all_color = (70, 110, 70) if auto_repair_all_enabled else theme.PANEL_BG  # no theme constant — active state green, FORTIFIED terrain color is too dark
        pygame.draw.rect(surface, auto_repair_all_color, self.auto_repair_all_btn, border_radius=6)
        checkbox_rect = pygame.Rect(self.auto_repair_all_btn.x + 8, self.auto_repair_all_btn.y + 7, 12, 12)
        pygame.draw.rect(surface, theme.TEXT_PRIMARY, checkbox_rect, width=1, border_radius=2)  # light gray checkbox
        if auto_repair_all_enabled:
            pygame.draw.line(surface, theme.EVENT_POSITIVE, checkbox_rect.topleft, checkbox_rect.bottomright, 2)  # green checkmark
            pygame.draw.line(surface, theme.EVENT_POSITIVE, checkbox_rect.topright, checkbox_rect.bottomleft, 2)
        auto_label = "Auto Repair All"
        auto_color = theme.EVENT_POSITIVE if auto_repair_all_enabled else theme.TEXT_SECONDARY  # bright green text when enabled
        auto_surf = self.shop_badge_font.render(auto_label, True, auto_color)
        surface.blit(
            auto_surf,
            (
                checkbox_rect.right + 6,
                self.auto_repair_all_btn.centery - auto_surf.get_height() // 2,
            ),
        )

        if selected_cls:
            pygame.draw.rect(surface, (70, 110, 70), self.upgrade_all_btn, border_radius=6)  # no theme constant — active state green, FORTIFIED terrain color is too dark
            up_surf = self.font.render("Upgrade All", True, theme.EVENT_POSITIVE)  # bright green text
            surface.blit(up_surf, (self.upgrade_all_btn.centerx - up_surf.get_width() // 2,
                                   self.upgrade_all_btn.centery - up_surf.get_height() // 2))

        btn_color = theme.GRID if wave_active else theme.EVENT_POSITIVE  # gray when wave active, green otherwise
        pygame.draw.rect(surface, btn_color, self.start_btn, border_radius=6)
        if wave_active:
            label = "Wave active"
        elif countdown > 0:
            label = f"Next: {countdown:.1f}s"
        else:
            label = "Start Wave"
        surf = self.font.render(label, True, COLORS["text"])
        surface.blit(surf, (self.start_btn.centerx - surf.get_width() // 2,
                            self.start_btn.centery - surf.get_height() // 2))

        if adaptive_rationale:
            rat_surf = self.card_font.render(adaptive_rationale, True, theme.TEXT_SECONDARY)  # gray text for rationale
            surface.blit(rat_surf, (10, self.panel_rect.bottom - 14))

        # hover tooltips per batch-action buttons
        towers_list = towers or []
        if self.repair_all_btn.collidepoint(mouse_pos):
            damaged = [t for t in towers_list if t.hp < t.max_hp]
            if damaged:
                total_cost = sum(repair_cost(t) for t in damaged)
                self._draw_cost_tooltip(surface, mouse_pos, i18n.t("ui.repair_all"), total_cost)
        if self.upgrade_all_btn.collidepoint(mouse_pos) and selected_cls is not None:
            upgradeable = [t for t in towers_list if isinstance(t, selected_cls) and t.level < 3]
            if upgradeable:
                total_cost = sum(t.upgrade_cost for t in upgradeable)
                self._draw_cost_tooltip(surface, mouse_pos, "Upgrade All", total_cost)

    def handle_click(self, pos, economy: Economy, selected_tower=None,
                     selected_cls=None,
                     towers=None,
                     unlocked_dlcs: Optional[set] = None,
                     placement_levels: dict = None,
                     current_wave: int = 0) -> Optional[UICommand]:
        """Returns UICommand subclass for clicked control, or None."""
        unlocked_dlcs = unlocked_dlcs or set()
        # Sell button — check before everything else
        if self._sell_btn_rect is not None and self._sell_btn_rect.collidepoint(pos):
            if selected_tower is not None:
                return SellTowerCommand()
        # Check repair-related buttons FIRST to prevent overlaps with tower buttons
        if self.repair_btn.collidepoint(pos):
            return RepairToggleCommand()
        if self.repair_all_btn.collidepoint(pos):
            damaged = [t for t in (towers or []) if t.hp < t.max_hp]
            if damaged:
                return RepairAllCommand()
        if self.auto_repair_all_btn.collidepoint(pos):
            return AutoRepairAllToggleCommand()
        if self.upgrade_all_btn.collidepoint(pos) and selected_cls is not None:
            return UpgradeAllCommand()
        # Check queue add buttons
        for btn_info in self._queue_add_btn_rects:
            if btn_info["rect"].collidepoint(pos):
                return QueueAddCommand(order_spec=btn_info["action"])
        # Check queue remove buttons
        for btn_info in self._queue_remove_btn_rects:
            if btn_info["rect"].collidepoint(pos):
                return QueueRemoveCommand(index=btn_info["index"])
        # Check loadout preset buttons
        for preset_name, rect in self._loadout_btn_rects.items():
            if rect.collidepoint(pos):
                return LoadoutCommand(preset_name=preset_name)
        for slot, rect in zip(self._powerup_slot_defs, self._powerup_btn_rects):
            if rect.collidepoint(pos):
                return PowerupCommand(powerup_id=slot["id"])
        for cls, level_rects in self._tower_level_box_rects.items():
            for level, level_rect in zip((1, 2, 3), level_rects):
                if level_rect.collidepoint(pos):
                    if not tower_is_unlocked(cls, unlocked_dlcs, current_wave=current_wave):
                        dlc_id = tower_requires_dlc(cls)
                        wave_req = TOWER_WAVE_REQUIREMENTS.get(cls, 0) if dlc_id is None else 0
                        return LockedCommand(dlc_id=dlc_id, wave_required=wave_req)
                    return TowerLevelSelectCommand(cls_name=cls.__name__, level=level)
        for i, rect in enumerate(self._btn_rects):
            if rect.collidepoint(pos):
                cls = TOWER_CLASSES[i]
                if not tower_is_unlocked(cls, unlocked_dlcs, current_wave=current_wave):
                    dlc_id = tower_requires_dlc(cls)
                    wave_req = TOWER_WAVE_REQUIREMENTS.get(cls, 0) if dlc_id is None else 0
                    return LockedCommand(dlc_id=dlc_id, wave_required=wave_req)
                cls_level = max(1, min(3, (placement_levels or {}).get(cls, 1)))
                placement_cost = placement_cost_for_level(cls, cls_level)
                if economy.can_afford(placement_cost):
                    return TowerSelectCommand(cls_name=cls.__name__)
        for btn_info in self._policy_btn_rects:
            if btn_info["rect"].collidepoint(pos):
                return PolicyCommand(policy=btn_info["policy"], bulk=btn_info["bulk"])
        if self.start_btn.collidepoint(pos):
            return StartWaveCommand()
        return None

    def is_in_panel(self, pos) -> bool:
        return self.panel_rect.collidepoint(pos)


def handle_profile_select_click(pos: tuple, rects: dict) -> tuple:
    for name, rect in rects.items():
        if rect.collidepoint(pos):
            if name == "__new__":
                return "new", None
            return "login", name
    return None, None


def handle_dlc_menu_click(pos: tuple, rects: dict) -> Optional[str]:
    for dlc_id, rect in rects.items():
        if rect.collidepoint(pos):
            return dlc_id
    return None


def draw_menu_buttons(surface: pygame.Surface, font: pygame.font.Font,
                      screen_w: int, screen_h: int) -> dict:
    """Draw menu buttons (Load, DLC, Analytics, Admin).

    Returns dict with button names as keys and pygame.Rect as values.
    """
    rects = {}
    btn_w, btn_h = 140, 36
    menu_btn_top = screen_h // 2 + 44

    # Load button
    load_r = pygame.Rect(screen_w // 2 - btn_w // 2, menu_btn_top, btn_w, btn_h)
    pygame.draw.rect(surface, (40, 100, 60), load_r, border_radius=6)  # no theme constant — active state green, FORTIFIED terrain color is too dark
    pygame.draw.rect(surface, theme.EVENT_POSITIVE, load_r, 2, border_radius=6)  # bright green border
    load_lbl = font.render("Load", True, theme.EVENT_POSITIVE)  # bright green text
    surface.blit(load_lbl, (load_r.centerx - load_lbl.get_width() // 2,
                            load_r.centery - load_lbl.get_height() // 2))
    rects["load"] = load_r

    # DLC button
    dlc_r = pygame.Rect(screen_w // 2 - btn_w // 2, menu_btn_top + 42, btn_w, btn_h)
    pygame.draw.rect(surface, (60, 50, 100), dlc_r, border_radius=6)  # no theme constant — dark purple DLC button bg, TOWER_SNIPER is too saturated
    pygame.draw.rect(surface, theme.ACCENT, dlc_r, 2, border_radius=6)  # light blue border for DLC highlight
    dlc_lbl = font.render("DLC", True, theme.TEXT_PRIMARY)  # light text
    surface.blit(dlc_lbl, (dlc_r.centerx - dlc_lbl.get_width() // 2,
                           dlc_r.centery - dlc_lbl.get_height() // 2))
    rects["dlc"] = dlc_r

    # Analytics button
    analytics_r = pygame.Rect(screen_w // 2 - btn_w // 2, menu_btn_top + 84, btn_w, btn_h)
    pygame.draw.rect(surface, theme.MUD, analytics_r, border_radius=6)  # brown/tan for analytics
    pygame.draw.rect(surface, theme.HP_MED, analytics_r, 2, border_radius=6)  # golden border
    analytics_lbl = font.render("Analytics", True, theme.HP_MED)  # golden text
    surface.blit(analytics_lbl, (analytics_r.centerx - analytics_lbl.get_width() // 2,
                                 analytics_r.centery - analytics_lbl.get_height() // 2))
    rects["analytics"] = analytics_r

    return rects
