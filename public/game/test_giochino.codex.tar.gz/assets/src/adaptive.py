from copy import deepcopy
import math
from typing import Dict

ADAPTIVE_CAPS: Dict[str, float] = {
    "hp_mult": 2.50,
    "speed_mult": 2.00,
    "damage_mult": 2.00,
}

ADAPTIVE_ENDLESS_CAPS: Dict[str, float] = {
    "hp_mult": 5.0,
    "speed_mult": 4.0,
    "damage_mult": 4.0,
}

ADAPTIVE_INCREMENTS: Dict[str, Dict[str, Dict[str, float]]] = {
    "easy": {
        "low": {"hp_mult": 0.0, "speed_mult": 0.0, "damage_mult": 0.0},
        "mid": {"hp_mult": 0.01, "speed_mult": 0.005, "damage_mult": 0.005},
        "high": {"hp_mult": 0.02, "speed_mult": 0.01, "damage_mult": 0.01},
    },
    "normal": {
        "low": {"hp_mult": 0.01, "speed_mult": 0.005, "damage_mult": 0.005},
        "mid": {"hp_mult": 0.025, "speed_mult": 0.0125, "damage_mult": 0.0125},
        "high": {"hp_mult": 0.04, "speed_mult": 0.02, "damage_mult": 0.02},
    },
    "hard": {
        "low": {"hp_mult": 0.02, "speed_mult": 0.01, "damage_mult": 0.01},
        "mid": {"hp_mult": 0.04, "speed_mult": 0.02, "damage_mult": 0.02},
        "high": {"hp_mult": 0.06, "speed_mult": 0.03, "damage_mult": 0.03},
    },
}

ADAPTIVE_EXP_BASE: Dict[str, Dict[str, float]] = {
    "easy": {"hp_mult": 0.04, "speed_mult": 0.02, "damage_mult": 0.02},
    "normal": {"hp_mult": 0.08, "speed_mult": 0.04, "damage_mult": 0.04},
    "hard": {"hp_mult": 0.12, "speed_mult": 0.06, "damage_mult": 0.06},
    "endless": {"hp_mult": 0.12, "speed_mult": 0.06, "damage_mult": 0.06},
}

ADAPTIVE_ENDLESS_EXP_BASE: Dict[str, Dict[str, float]] = {
    "endless": {"hp_mult": 0.18, "speed_mult": 0.12, "damage_mult": 0.10},
}

ADAPTIVE_EXPONENT = 2.2


def default_adaptive_state() -> Dict[str, float]:
    return {
        "hp_mult": 1.0,
        "speed_mult": 1.0,
        "damage_mult": 1.0,
        "last_wave_max_progress": 0.0,
    }


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def progress_band(progress_ratio: float) -> str:
    p = _clamp(float(progress_ratio), 0.0, 1.0)
    if p < 0.35:
        return "low"
    if p < 0.70:
        return "mid"
    return "high"


def is_endless(difficulty: str) -> bool:
    return difficulty == "endless"


def apply_adaptive_increment(
    state: Dict[str, float],
    difficulty: str,
    wave_max_progress: float,
    wave: int = 0,
) -> Dict[str, float]:
    next_state = deepcopy(state)
    p = _clamp(float(wave_max_progress), 0.0, 1.0)
    # Non-linear (exponential-like) pressure:
    # lower reached progress -> much stronger adaptive increment.
    pressure = math.pow(max(0.0, 1.0 - p), ADAPTIVE_EXPONENT)

    # Choose caps and exp base based on difficulty and wave
    use_endless_high = is_endless(difficulty) and wave > 30
    caps = ADAPTIVE_ENDLESS_CAPS if use_endless_high else ADAPTIVE_CAPS
    exp_base_dict = ADAPTIVE_ENDLESS_EXP_BASE if use_endless_high else ADAPTIVE_EXP_BASE
    diff_key = "endless" if (is_endless(difficulty) or use_endless_high) else difficulty

    for key in ("hp_mult", "speed_mult", "damage_mult"):
        base = float(next_state.get(key, 1.0))
        increment_pct = float(exp_base_dict[diff_key][key]) * pressure
        updated = base * (1.0 + increment_pct)
        next_state[key] = _clamp(updated, 1.0, caps[key])

    next_state["last_wave_max_progress"] = p
    return next_state
