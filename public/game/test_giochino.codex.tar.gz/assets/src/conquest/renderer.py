from __future__ import annotations
"""Conquest mode — world map rendering."""

import pygame

if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass

from src import theme, i18n
from src.renderer._fonts import fonts
from src.conquest.world import WorldGraph, TerrainType, Territory


def draw_world_map(
    screen: pygame.Surface, world: WorldGraph, selected_id: int | None = None
) -> dict:
    """
    Draw the conquest world map.

    Returns dict of clickable rects: {territory_id: pygame.Rect}.
    """
    screen_w, screen_h = screen.get_size()

    # Background
    screen.fill(theme.BACKGROUND)

    # Map area: 80% width, 85% height, with 10% margin
    margin_x = int(screen_w * 0.1)
    margin_y = int(screen_h * 0.1)
    map_w = int(screen_w * 0.8)
    map_h = int(screen_h * 0.85)

    # Terrain color map
    terrain_colors = {
        TerrainType.DESERT: (220, 180, 50),
        TerrainType.FOREST: (40, 120, 40),
        TerrainType.SWAMP: (80, 120, 80),
        TerrainType.MOUNTAIN: (140, 140, 160),
        TerrainType.TUNDRA: (160, 200, 220),
        TerrainType.PLAINS: (100, 180, 80),
    }

    # Owner fill colors
    owner_colors = {
        "player": (60, 100, 200),
        "cpu": (180, 50, 50),
        "neutral": (100, 100, 100),
    }

    gold_color = (255, 215, 0)
    white = (255, 255, 255)
    grey = (150, 150, 150)

    # Convert normalized positions to screen coordinates
    def norm_to_screen(pos: tuple) -> tuple:
        screen_x = int(margin_x + pos[0] * map_w)
        screen_y = int(margin_y + pos[1] * map_h)
        return (screen_x, screen_y)

    # Draw edges first (so they appear under nodes)
    drawn_edges = set()
    for territory in world.territories:
        for neighbor_id in territory.neighbors:
            edge = tuple(sorted([territory.id, neighbor_id]))
            if edge not in drawn_edges:
                drawn_edges.add(edge)
                pos1 = norm_to_screen(territory.pos)
                pos2 = norm_to_screen(world.get(neighbor_id).pos)
                pygame.draw.line(screen, grey, pos1, pos2, 1)

    # Build rect dict for click detection
    rects = {}

    # Draw nodes
    node_radius = 18
    for territory in world.territories:
        pos = norm_to_screen(territory.pos)
        x, y = pos

        # Determine if selected
        is_selected = selected_id == territory.id

        # Node radius and border width
        if is_selected:
            draw_radius = 22
            border_width = 5
            border_color = white
        else:
            draw_radius = node_radius
            border_width = 3
            border_color = terrain_colors.get(territory.terrain, grey)

        # Fill circle (owner color)
        fill_color = owner_colors.get(territory.owner, (100, 100, 100))
        pygame.draw.circle(screen, fill_color, pos, draw_radius)

        # Border circle (terrain color or white if selected)
        pygame.draw.circle(screen, border_color, pos, draw_radius, border_width)

        # Store rect for click detection (use standard node radius)
        rect = pygame.Rect(x - node_radius, y - node_radius, node_radius * 2, node_radius * 2)
        rects[territory.id] = rect

        # City marker (gold circle at center if is_city)
        if territory.is_city:
            pygame.draw.circle(screen, gold_color, pos, 5)
            pygame.draw.circle(screen, gold_color, pos, 5, 1)

        # Fortification: draw stars above node if fortification > 0
        if territory.fortification > 0:
            fort_text = "★" * territory.fortification
            font_small = fonts.sized(11)
            text_surf = font_small.render(fort_text, True, gold_color)
            text_rect = text_surf.get_rect(center=(x, y - 22))
            screen.blit(text_surf, text_rect)

        # Territory name: text below node
        name_font = fonts.sized(11)
        name_surf = name_font.render(territory.name, True, white)
        name_rect = name_surf.get_rect(center=(x, y + 22))
        screen.blit(name_surf, name_rect)

    return rects


def draw_territory_panel(
    screen: pygame.Surface,
    territory: Territory,
    font: pygame.font.Font,
    font_small: pygame.font.Font,
    player_gold: int,
    player_adjacent: bool,
    screen_w: int,
    screen_h: int,
) -> dict:
    """
    Draw the territory info panel on the right side of the screen.

    Returns dict with keys:
    - "attack" → pygame.Rect (only if player_adjacent and territory.owner == "cpu")
    - "fortify" → pygame.Rect (only if territory.owner == "player")
    - "end_turn" → pygame.Rect (always)
    """
    # Panel dimensions and position
    panel_left = screen_w - 220
    panel_top = 60
    panel_width = 210
    panel_height = 340

    # Colors
    panel_bg_color = (20, 20, 40)
    panel_bg_alpha = 200
    white = (255, 255, 255)
    blue_text = (100, 150, 255)
    red_text = (220, 100, 100)
    gold_color = (255, 215, 0)
    grey = (150, 150, 150)
    button_attack_color = (180, 50, 50)
    button_fortify_enabled = (50, 130, 80)
    button_fortify_disabled = (60, 60, 60)
    button_end_turn_color = (80, 80, 160)

    # Terrain colors (same as draw_world_map)
    terrain_colors = {
        TerrainType.DESERT: (220, 180, 50),
        TerrainType.FOREST: (40, 120, 40),
        TerrainType.SWAMP: (80, 120, 80),
        TerrainType.MOUNTAIN: (140, 140, 160),
        TerrainType.TUNDRA: (160, 200, 220),
        TerrainType.PLAINS: (100, 180, 80),
    }

    # Draw semi-transparent panel background
    panel_surface = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
    panel_surface.fill((*panel_bg_color, panel_bg_alpha))
    screen.blit(panel_surface, (panel_left, panel_top))

    # Border
    pygame.draw.rect(screen, white, (panel_left, panel_top, panel_width, panel_height), 2)

    # Current y position for drawing content
    y_pos = panel_top + 10

    # Territory name (large, bold)
    name_surf = font.render(territory.name, True, white)
    screen.blit(name_surf, (panel_left + 10, y_pos))
    y_pos += 40

    # Terrain type with colored dot
    terrain_color = terrain_colors.get(territory.terrain, grey)
    pygame.draw.circle(screen, terrain_color, (panel_left + 20, y_pos + 4), 4)
    terrain_text = font_small.render(territory.terrain.value, True, white)
    screen.blit(terrain_text, (panel_left + 35, y_pos))
    y_pos += 25

    # Owner label
    owner_label = i18n.t("conquest.territory") + ": "
    owner_text_color = blue_text if territory.owner == "player" else red_text
    owner_display = owner_label + territory.owner
    owner_surf = font_small.render(owner_display, True, owner_text_color)
    screen.blit(owner_surf, (panel_left + 10, y_pos))
    y_pos += 25

    # City marker
    if territory.is_city:
        city_text = "★ " + i18n.t("conquest.city")
        city_surf = font_small.render(city_text, True, gold_color)
        screen.blit(city_surf, (panel_left + 10, y_pos))
        y_pos += 25

    # Fortification display
    if territory.fortification > 0:
        fort_text = "★" * territory.fortification
        fort_surf = font_small.render(fort_text, True, gold_color)
        screen.blit(fort_surf, (panel_left + 10, y_pos))
    else:
        fort_label = i18n.t("conquest.fortification") + ": 0"
        fort_surf = font_small.render(fort_label, True, grey)
        screen.blit(fort_surf, (panel_left + 10, y_pos))
    y_pos += 25

    # Spacing before buttons
    y_pos += 10

    # Button rects dict
    result_rects: dict = {}

    # Button dimensions
    btn_width = 180
    btn_height = 44
    btn_center_x = panel_left + (panel_width // 2) - (btn_width // 2)

    # "Attacca" button (only if player_adjacent and territory.owner == "cpu")
    if player_adjacent and territory.owner == "cpu":
        attack_rect = pygame.Rect(btn_center_x, y_pos, btn_width, btn_height)
        pygame.draw.rect(screen, button_attack_color, attack_rect, border_radius=4)
        pygame.draw.rect(screen, (255, 150, 150), attack_rect, 2, border_radius=4)
        attack_label = i18n.t("conquest.attack")
        attack_text = font_small.render(attack_label, True, white)
        screen.blit(attack_text, attack_text.get_rect(center=attack_rect.center))
        result_rects["attack"] = attack_rect
        y_pos += 50

    # "Fortifica" button (only if territory.owner == "player")
    if territory.owner == "player":
        fortify_rect = pygame.Rect(btn_center_x, y_pos, btn_width, btn_height)
        is_affordable = player_gold >= 30
        fortify_color = button_fortify_enabled if is_affordable else button_fortify_disabled
        pygame.draw.rect(screen, fortify_color, fortify_rect, border_radius=4)
        pygame.draw.rect(screen, (100, 200, 120) if is_affordable else (100, 100, 100), fortify_rect, 2, border_radius=4)
        fortify_label = i18n.t("conquest.fortify") + " (30g)"
        fortify_text = font_small.render(fortify_label, True, white)
        screen.blit(fortify_text, fortify_text.get_rect(center=fortify_rect.center))
        result_rects["fortify"] = fortify_rect
        y_pos += 50

    # "Fine Turno" button (always present)
    end_turn_rect = pygame.Rect(btn_center_x, y_pos, btn_width, btn_height)
    pygame.draw.rect(screen, button_end_turn_color, end_turn_rect, border_radius=4)
    pygame.draw.rect(screen, (150, 150, 200), end_turn_rect, 2, border_radius=4)
    end_turn_label = i18n.t("conquest.end_turn")
    end_turn_text = font_small.render(end_turn_label, True, white)
    screen.blit(end_turn_text, end_turn_text.get_rect(center=end_turn_rect.center))
    result_rects["end_turn"] = end_turn_rect

    return result_rects
