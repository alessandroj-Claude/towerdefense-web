from __future__ import annotations
"""Conquest mode — world map rendering."""

import pygame

if not hasattr(pygame, "init"):
    import importlib

    for _mod in (
        "pygame.base",
        "pygame.display",
        "pygame.font",
        "pygame.time",
        "pygame.event",
        "pygame.draw",
        "pygame.transform",
        "pygame.mouse",
        "pygame.key",
        "pygame.scrap",
        "pygame.mixer",
    ):
        try:
            _m = importlib.import_module(_mod)
            setattr(pygame, _mod.rsplit(".", 1)[-1], _m)
            if _mod == "pygame.base" and hasattr(_m, "init"):
                pygame.init = _m.init
                if hasattr(_m, "quit"):
                    pygame.quit = _m.quit
        except Exception:
            pass

from src import theme, i18n
from src.renderer._fonts import fonts
from src.conquest.world import WorldGraph, TerrainType, Territory


def draw_world_map(
    screen: pygame.Surface, world: WorldGraph, selected_id: int | None = None
) -> dict:
    """
    Draw the conquest world map.

    Returns dict of clickable rects: {territory_id: pygame.Rect}.
    """
    screen_w, screen_h = screen.get_size()

    # Background
    screen.fill(theme.BACKGROUND)

    # Map area: 80% width, 85% height, with 10% margin
    margin_x = int(screen_w * 0.1)
    margin_y = int(screen_h * 0.1)
    map_w = int(screen_w * 0.8)
    map_h = int(screen_h * 0.85)

    # Terrain color map
    terrain_colors = {
        TerrainType.DESERT: (220, 180, 50),
        TerrainType.FOREST: (40, 120, 40),
        TerrainType.SWAMP: (80, 120, 80),
        TerrainType.MOUNTAIN: (140, 140, 160),
        TerrainType.TUNDRA: (160, 200, 220),
        TerrainType.PLAINS: (100, 180, 80),
    }

    # Owner fill colors
    owner_colors = {
        "player": (60, 100, 200),
        "cpu": (180, 50, 50),
        "neutral": (100, 100, 100),
    }

    gold_color = (255, 215, 0)
    white = (255, 255, 255)
    grey = (150, 150, 150)

    # Convert normalized positions to screen coordinates
    def norm_to_screen(pos: tuple) -> tuple:
        screen_x = int(margin_x + pos[0] * map_w)
        screen_y = int(margin_y + pos[1] * map_h)
        return (screen_x, screen_y)

    # Draw edges first (so they appear under nodes)
    drawn_edges = set()
    for territory in world.territories:
        for neighbor_id in territory.neighbors:
            edge = tuple(sorted([territory.id, neighbor_id]))
            if edge not in drawn_edges:
                drawn_edges.add(edge)
                pos1 = norm_to_screen(territory.pos)
                pos2 = norm_to_screen(world.get(neighbor_id).pos)
                pygame.draw.line(screen, grey, pos1, pos2, 1)

    # Build rect dict for click detection
    rects = {}

    # Draw nodes
    node_radius = 18
    for territory in world.territories:
        pos = norm_to_screen(territory.pos)
        x, y = pos

        # Determine if selected
        is_selected = selected_id == territory.id

        # Node radius and border width
        if is_selected:
            draw_radius = 22
            border_width = 5
            border_color = white
        else:
            draw_radius = node_radius
            border_width = 3
            border_color = terrain_colors.get(territory.terrain, grey)

        # Fill circle (owner color)
        fill_color = owner_colors.get(territory.owner, (100, 100, 100))
        pygame.draw.circle(screen, fill_color, pos, draw_radius)

        # Border circle (terrain color or white if selected)
        pygame.draw.circle(screen, border_color, pos, draw_radius, border_width)

        # Store rect for click detection (use standard node radius)
        rect = pygame.Rect(x - node_radius, y - node_radius, node_radius * 2, node_radius * 2)
        rects[territory.id] = rect

        # City marker (gold circle at center if is_city)
        if territory.is_city:
            pygame.draw.circle(screen, gold_color, pos, 5)
            pygame.draw.circle(screen, gold_color, pos, 5, 1)

        # Fortification: draw stars above node if fortification > 0
        if territory.fortification > 0:
            fort_text = "★" * territory.fortification
            font_small = fonts.sized(11)
            text_surf = font_small.render(fort_text, True, gold_color)
            text_rect = text_surf.get_rect(center=(x, y - 22))
            screen.blit(text_surf, text_rect)

        # Territory name: text below node
        name_font = fonts.sized(11)
        name_surf = name_font.render(territory.name, True, white)
        name_rect = name_surf.get_rect(center=(x, y + 22))
        screen.blit(name_surf, name_rect)

    return rects


def draw_territory_panel(
    screen: pygame.Surface,
    territory: Territory,
    font: pygame.font.Font,
    font_small: pygame.font.Font,
    player_gold: int,
    player_adjacent: bool,
    screen_w: int,
    screen_h: int,
) -> dict:
    """
    Draw the territory info panel on the right side of the screen.

    Returns dict with keys:
    - "attack" → pygame.Rect (only if player_adjacent and territory.owner == "cpu")
    - "fortify" → pygame.Rect (only if territory.owner == "player")
    - "end_turn" → pygame.Rect (always)
    """
    # Panel dimensions and position
    panel_left = screen_w - 220
    panel_top = 60
    panel_width = 210
    panel_height = 340

    # Colors
    panel_bg_color = (20, 20, 40)
    panel_bg_alpha = 200
    white = (255, 255, 255)
    blue_text = (100, 150, 255)
    red_text = (220, 100, 100)
    gold_color = (255, 215, 0)
    grey = (150, 150, 150)
    button_attack_color = (180, 50, 50)
    button_fortify_enabled = (50, 130, 80)
    button_fortify_disabled = (60, 60, 60)
    button_end_turn_color = (80, 80, 160)

    # Terrain colors (same as draw_world_map)
    terrain_colors = {
        TerrainType.DESERT: (220, 180, 50),
        TerrainType.FOREST: (40, 120, 40),
        TerrainType.SWAMP: (80, 120, 80),
        TerrainType.MOUNTAIN: (140, 140, 160),
        TerrainType.TUNDRA: (160, 200, 220),
        TerrainType.PLAINS: (100, 180, 80),
    }

    # Draw semi-transparent panel background
    panel_surface = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
    panel_surface.fill((*panel_bg_color, panel_bg_alpha))
    screen.blit(panel_surface, (panel_left, panel_top))

    # Border
    pygame.draw.rect(screen, white, (panel_left, panel_top, panel_width, panel_height), 2)

    # Current y position for drawing content
    y_pos = panel_top + 10

    # Territory name (large, bold)
    name_surf = font.render(territory.name, True, white)
    screen.blit(name_surf, (panel_left + 10, y_pos))
    y_pos += 40

    # Terrain type with colored dot
    terrain_color = terrain_colors.get(territory.terrain, grey)
    pygame.draw.circle(screen, terrain_color, (panel_left + 20, y_pos + 4), 4)
    terrain_text = font_small.render(territory.terrain.value, True, white)
    screen.blit(terrain_text, (panel_left + 35, y_pos))
    y_pos += 25

    # Owner label
    owner_label = i18n.t("conquest.territory") + ": "
    owner_text_color = blue_text if territory.owner == "player" else red_text
    owner_display = owner_label + territory.owner
    owner_surf = font_small.render(owner_display, True, owner_text_color)
    screen.blit(owner_surf, (panel_left + 10, y_pos))
    y_pos += 25

    # City marker
    if territory.is_city:
        city_text = "★ " + i18n.t("conquest.city")
        city_surf = font_small.render(city_text, True, gold_color)
        screen.blit(city_surf, (panel_left + 10, y_pos))
        y_pos += 25

    # Fortification display
    if territory.fortification > 0:
        fort_text = "★" * territory.fortification
        fort_surf = font_small.render(fort_text, True, gold_color)
        screen.blit(fort_surf, (panel_left + 10, y_pos))
    else:
        fort_label = i18n.t("conquest.fortification") + ": 0"
        fort_surf = font_small.render(fort_label, True, grey)
        screen.blit(fort_surf, (panel_left + 10, y_pos))
    y_pos += 25

    # Spacing before buttons
    y_pos += 10

    # Button rects dict
    result_rects: dict = {}

    # Button dimensions
    btn_width = 180
    btn_height = 44
    btn_center_x = panel_left + (panel_width // 2) - (btn_width // 2)

    # "Attacca" button (only if player_adjacent and territory.owner == "cpu")
    if player_adjacent and territory.owner == "cpu":
        attack_rect = pygame.Rect(btn_center_x, y_pos, btn_width, btn_height)
        pygame.draw.rect(screen, button_attack_color, attack_rect, border_radius=4)
        pygame.draw.rect(screen, (255, 150, 150), attack_rect, 2, border_radius=4)
        attack_label = i18n.t("conquest.attack")
        attack_text = font_small.render(attack_label, True, white)
        screen.blit(attack_text, attack_text.get_rect(center=attack_rect.center))
        result_rects["attack"] = attack_rect
        y_pos += 50

    # "Fortifica" button (only if territory.owner == "player")
    if territory.owner == "player":
        fortify_rect = pygame.Rect(btn_center_x, y_pos, btn_width, btn_height)
        is_affordable = player_gold >= 30
        fortify_color = button_fortify_enabled if is_affordable else button_fortify_disabled
        pygame.draw.rect(screen, fortify_color, fortify_rect, border_radius=4)
        pygame.draw.rect(screen, (100, 200, 120) if is_affordable else (100, 100, 100), fortify_rect, 2, border_radius=4)
        fortify_label = i18n.t("conquest.fortify") + " (30g)"
        fortify_text = font_small.render(fortify_label, True, white)
        screen.blit(fortify_text, fortify_text.get_rect(center=fortify_rect.center))
        result_rects["fortify"] = fortify_rect
        y_pos += 50

    # "Fine Turno" button (always present)
    end_turn_rect = pygame.Rect(btn_center_x, y_pos, btn_width, btn_height)
    pygame.draw.rect(screen, button_end_turn_color, end_turn_rect, border_radius=4)
    pygame.draw.rect(screen, (150, 150, 200), end_turn_rect, 2, border_radius=4)
    end_turn_label = i18n.t("conquest.end_turn")
    end_turn_text = font_small.render(end_turn_label, True, white)
    screen.blit(end_turn_text, end_turn_text.get_rect(center=end_turn_rect.center))
    result_rects["end_turn"] = end_turn_rect

    return result_rects


# Enemy type metadata for attack HUD hotbar
_ATTACK_HOTBAR_ENTRIES = None


def _get_hotbar_entries():
    global _ATTACK_HOTBAR_ENTRIES
    if _ATTACK_HOTBAR_ENTRIES is None:
        from src.enemy import (BasicEnemy, FastEnemy, SwarmEnemy, TankEnemy,
                               HeavyEnemy, PathFlyer, ScoutFlyer, BossEnemy)
        _ATTACK_HOTBAR_ENTRIES = [
            (BasicEnemy,  "Basic",  5,  (150,  80,  80)),
            (FastEnemy,   "Fast",   8,  (100, 200, 100)),
            (SwarmEnemy,  "Swarm",  4,  (200, 150,  50)),
            (TankEnemy,   "Tank",   25, ( 50,  80, 150)),
            (HeavyEnemy,  "Heavy",  30, (100,  50, 150)),
            (PathFlyer,   "Flyer",  15, (150, 200, 200)),
            (ScoutFlyer,  "Scout",  12, (200, 150, 200)),
            (BossEnemy,   "Boss",   80, (200,  50,  50)),
        ]
    return _ATTACK_HOTBAR_ENTRIES


def draw_attack_hud(
    screen: pygame.Surface,
    budget: int,
    castle_damage: int,
    castle_hp: int,
    pending_queue: list,
    font_small: pygame.font.Font,
) -> dict:
    """
    Draw the attack battle HUD.

    Returns dict of clickable rects:
    - "surrender" → pygame.Rect
    - enemy_cls   → pygame.Rect  (one per hotbar entry)
    """
    screen_w, screen_h = screen.get_size()
    white = (255, 255, 255)
    red   = (200,  50,  50)
    dark  = ( 20,  20,  40)
    gold  = (255, 215,   0)
    grey  = (120, 120, 120)

    rects: dict = {}

    # ── Budget counter (top-left) ─────────────────────────────────────────────
    budget_text = font_small.render(f"Budget: {budget}g", True, gold)
    screen.blit(budget_text, (12, 12))

    # ── Castle damage progress bar (top-center) ───────────────────────────────
    bar_w, bar_h = 280, 18
    bar_x = screen_w // 2 - bar_w // 2
    bar_y = 10
    fill_frac = min(1.0, castle_damage / max(1, castle_hp))
    pygame.draw.rect(screen, grey, (bar_x, bar_y, bar_w, bar_h), border_radius=4)
    if fill_frac > 0:
        pygame.draw.rect(screen, red,
                         (bar_x, bar_y, int(bar_w * fill_frac), bar_h), border_radius=4)
    pygame.draw.rect(screen, white, (bar_x, bar_y, bar_w, bar_h), 1, border_radius=4)
    bar_label = font_small.render(f"Castle: {castle_damage}/{castle_hp}", True, white)
    screen.blit(bar_label, bar_label.get_rect(center=(screen_w // 2, bar_y + bar_h // 2)))

    # ── Surrender button (top-right) ──────────────────────────────────────────
    surr_rect = pygame.Rect(screen_w - 120, 6, 110, 30)
    pygame.draw.rect(screen, (100, 30, 30), surr_rect, border_radius=4)
    pygame.draw.rect(screen, (200, 80, 80), surr_rect, 1, border_radius=4)
    surr_text = font_small.render("Surrender", True, white)
    screen.blit(surr_text, surr_text.get_rect(center=surr_rect.center))
    rects["surrender"] = surr_rect

    # ── Formation panel (center of panel area, y=648..768) ───────────────────
    MAP_H = 640
    panel_y = MAP_H + 8
    panel_h = 120
    panel_bg = pygame.Surface((screen_w - 20, panel_h), pygame.SRCALPHA)
    panel_bg.fill((15, 15, 30, 180))
    screen.blit(panel_bg, (10, panel_y))
    pygame.draw.rect(screen, (60, 60, 80), (10, panel_y, screen_w - 20, panel_h), 1)

    # Label
    queue_label = font_small.render("Formation:", True, (180, 180, 180))
    screen.blit(queue_label, (18, panel_y + 6))

    # Queue slots (max 12 visible)
    entries_meta = _get_hotbar_entries()
    color_by_cls = {cls: color for cls, _, _, color in entries_meta}
    label_by_cls = {cls: lbl for cls, lbl, _, _ in entries_meta}
    slot_w, slot_h = 56, 56
    slots_per_row = (screen_w - 20) // (slot_w + 4)
    for i, cls in enumerate(pending_queue[:12]):
        col_i = i % slots_per_row
        sx = 18 + col_i * (slot_w + 4)
        sy = panel_y + 24
        color = color_by_cls.get(cls, (120, 120, 120))
        pygame.draw.rect(screen, color, (sx, sy, slot_w, slot_h), border_radius=4)
        lbl_text = label_by_cls.get(cls, "?")
        lbl_surf = font_small.render(lbl_text, True, (255, 255, 255))
        screen.blit(lbl_surf, lbl_surf.get_rect(centerx=sx + slot_w // 2, top=sy + slot_h - 14))

    rects["formation_panel"] = pygame.Rect(10, panel_y, screen_w - 20, panel_h)

    # ── Enemy hotbar (bottom) ─────────────────────────────────────────────────
    entries = _get_hotbar_entries()
    btn_w, btn_h = 72, 72
    total_w = len(entries) * btn_w + (len(entries) - 1) * 8
    start_x = screen_w // 2 - total_w // 2
    btn_y = screen_h - btn_h - 8

    for i, (cls, label, cost, color) in enumerate(entries):
        bx = start_x + i * (btn_w + 8)
        btn_rect = pygame.Rect(bx, btn_y, btn_w, btn_h)

        # Background
        pygame.draw.rect(screen, dark, btn_rect, border_radius=6)
        pygame.draw.rect(screen, color, btn_rect, 2, border_radius=6)

        # Enemy color block (icon stand-in)
        icon_rect = pygame.Rect(bx + 4, btn_y + 4, btn_w - 8, btn_h - 32)
        pygame.draw.rect(screen, color, icon_rect, border_radius=4)

        # Label
        name_surf = font_small.render(label, True, white)
        screen.blit(name_surf, name_surf.get_rect(centerx=bx + btn_w // 2,
                                                   top=btn_y + btn_h - 28))

        # Cost
        cost_surf = font_small.render(f"{cost}g", True, gold)
        screen.blit(cost_surf, cost_surf.get_rect(centerx=bx + btn_w // 2,
                                                   top=btn_y + btn_h - 14))

        rects[cls] = btn_rect

    return rects


def draw_attack_enemy_queue(
    screen: pygame.Surface,
    enemies_spawned: list,
    font_small: pygame.font.Font,
) -> None:
    """Draw a small sidebar showing the last spawned enemy types."""
    if not enemies_spawned:
        return

    entries = _get_hotbar_entries()
    color_by_cls = {cls: color for cls, _, _, color in entries}
    label_by_cls = {cls: label for cls, label, _, _ in entries}

    x, y = 8, 50
    white = (255, 255, 255)
    dark  = (20,  20,  40, 180)

    panel_h = min(len(enemies_spawned), 6) * 22 + 8
    bg = pygame.Surface((88, panel_h), pygame.SRCALPHA)
    bg.fill(dark)
    screen.blit(bg, (x, y))

    for i, cls in enumerate(reversed(enemies_spawned[-6:])):
        color = color_by_cls.get(cls, (150, 150, 150))
        label = label_by_cls.get(cls, cls.__name__)
        pygame.draw.circle(screen, color, (x + 10, y + 8 + i * 22), 6)
        text = font_small.render(label, True, white)
        screen.blit(text, (x + 22, y + 2 + i * 22))
