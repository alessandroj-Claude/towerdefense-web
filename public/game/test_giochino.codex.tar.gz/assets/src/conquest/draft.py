"""Tower Draft Mode for Conquest battles.

No pygame import at module level.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from src.conquest.world import TerrainType
from src.tower import (
    BasicTower,
    IceTower,
    BombTower,
    SniperTower,
    AntiAirTower,
    LightningTower,
    StormTower,
    InfernoTower,
    VenomTower,
    MedicTower,
    SentinelTower,
)
from src.enemy import BasicEnemy, FastEnemy, SwarmEnemy, TankEnemy, HeavyEnemy, PathFlyer, ScoutFlyer


TOWER_POOL_BASE = [
    BasicTower,
    IceTower,
    BombTower,
    SniperTower,
    AntiAirTower,
    LightningTower,
    StormTower,
    InfernoTower,
    VenomTower,
    MedicTower,
    SentinelTower,
]

ENEMY_POOL_BASE = [BasicEnemy, FastEnemy, SwarmEnemy, TankEnemy, HeavyEnemy, PathFlyer, ScoutFlyer]

# Weights per terrain. 0 = excluded. Sum doesn't need to be 1.
TERRAIN_TOWER_WEIGHTS: dict[TerrainType, dict] = {
    TerrainType.DESERT: {
        BasicTower: 2,
        IceTower: 0,
        BombTower: 2,
        SniperTower: 2,
        AntiAirTower: 1,
        LightningTower: 1,
        StormTower: 1,
        InfernoTower: 3,
        VenomTower: 1,
        MedicTower: 1,
        SentinelTower: 1,
    },
    TerrainType.FOREST: {
        BasicTower: 2,
        IceTower: 1,
        BombTower: 2,
        SniperTower: 1,
        AntiAirTower: 1,
        LightningTower: 2,
        StormTower: 1,
        InfernoTower: 0,
        VenomTower: 3,
        MedicTower: 2,
        SentinelTower: 1,
    },
    TerrainType.SWAMP: {
        BasicTower: 2,
        IceTower: 2,
        BombTower: 2,
        SniperTower: 1,
        AntiAirTower: 1,
        LightningTower: 1,
        StormTower: 2,
        InfernoTower: 0,
        VenomTower: 3,
        MedicTower: 2,
        SentinelTower: 1,
    },
    TerrainType.MOUNTAIN: {
        BasicTower: 2,
        IceTower: 1,
        BombTower: 2,
        SniperTower: 3,
        AntiAirTower: 2,
        LightningTower: 2,
        StormTower: 1,
        InfernoTower: 1,
        VenomTower: 0,
        MedicTower: 1,
        SentinelTower: 2,
    },
    TerrainType.TUNDRA: {
        BasicTower: 2,
        IceTower: 3,
        BombTower: 1,
        SniperTower: 2,
        AntiAirTower: 1,
        LightningTower: 1,
        StormTower: 2,
        InfernoTower: 0,
        VenomTower: 1,
        MedicTower: 1,
        SentinelTower: 1,
    },
    TerrainType.PLAINS: {
        BasicTower: 2,
        IceTower: 1,
        BombTower: 2,
        SniperTower: 2,
        AntiAirTower: 1,
        LightningTower: 2,
        StormTower: 1,
        InfernoTower: 1,
        VenomTower: 1,
        MedicTower: 2,
        SentinelTower: 1,
    },
}


@dataclass
class TowerDraft:
    towers: list[type]  # tower classes, len = pool_size (default 6)
    enemies: list[type]  # enemy classes, len = pool_size (default 6)


def draw_unique_tower_draft(
    territory_seed: int, turn_number: int, terrain: TerrainType, pool_size: int = 6
) -> list[type]:
    """Draw pool_size unique tower types, weighted by terrain."""
    rng = random.Random(territory_seed ^ (turn_number * 1_000_003))
    weights_map = TERRAIN_TOWER_WEIGHTS.get(terrain, {t: 1 for t in TOWER_POOL_BASE})
    pool = [t for t in TOWER_POOL_BASE if weights_map.get(t, 1) > 0]
    weights = [weights_map.get(t, 1) for t in pool]
    selected: list[type] = []
    remaining_pool = list(pool)
    remaining_weights = list(weights)
    k = min(pool_size, len(pool))
    for _ in range(k):
        chosen = rng.choices(remaining_pool, weights=remaining_weights, k=1)[0]
        selected.append(chosen)
        idx = remaining_pool.index(chosen)
        remaining_pool.pop(idx)
        remaining_weights.pop(idx)
    return selected


def draw_enemy_draft(territory_seed: int, turn_number: int, pool_size: int = 6) -> list[type]:
    """Draw pool_size unique enemy types (uniform, not terrain-biased)."""
    rng = random.Random(territory_seed ^ (turn_number * 1_000_007))
    return rng.sample(ENEMY_POOL_BASE, min(pool_size, len(ENEMY_POOL_BASE)))


def get_draft(
    territory_seed: int, turn_number: int, terrain: TerrainType, pool_size: int = 6
) -> TowerDraft:
    """Get the full draft (towers + enemies) for a given territory/turn."""
    towers = draw_unique_tower_draft(territory_seed, turn_number, terrain, pool_size)
    enemies = draw_enemy_draft(territory_seed, turn_number, pool_size)
    return TowerDraft(towers=towers, enemies=enemies)
