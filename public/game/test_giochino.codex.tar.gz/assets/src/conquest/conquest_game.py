"""Conquest mode — ConquestGame state machine.

No pygame import at module level.
States: player_turn | cpu_turn | battle_pending | won | lost | stalemate
"""
from __future__ import annotations

from src.conquest.world import WorldGraph
from src.conquest.turn import TurnManager, BattleRequest
from src.conquest.cpu_ai import CpuAI


class ConquestGame:
    def __init__(self, world: WorldGraph, difficulty: str = "normal"):
        self.world = world
        self.difficulty = difficulty
        self.state: str = "player_turn"
        self.in_battle: bool = False
        self.turn_manager = TurnManager(world, difficulty)
        self.cpu_ai = CpuAI(world, difficulty)
        self._pending_battle: BattleRequest | None = None
        self._last_battle_result: dict | None = None  # for UI modal

    # --- Player actions ---

    def player_end_turn(self) -> None:
        """Player ends their turn → move to CPU phase."""
        self.turn_manager.end_player_turn()
        self.state = "cpu_turn"
        self._run_cpu_turn()

    def player_attack(self, territory_id: int, budget: int) -> BattleRequest:
        req = self.turn_manager.player_attack(territory_id, budget)
        self._pending_battle = req
        self.state = "battle_pending"
        self.in_battle = True
        return req

    def player_fortify(self, territory_id: int) -> bool:
        return self.turn_manager.player_fortify(territory_id)

    # --- Battle resolution ---

    def resolve_battle_stub(self, territory_id: int, player_wins: bool,
                            battle_type: str, refund: int = 0) -> None:
        """Resolve battle with stub result (random or forced). Updates world + gold."""
        self.turn_manager.apply_battle_result(territory_id, player_wins, battle_type, refund)
        self.in_battle = False
        self._last_battle_result = {
            "territory_id": territory_id,
            "player_wins": player_wins,
            "battle_type": battle_type,
        }
        self._pending_battle = None
        self.check_end_conditions()
        # If game not over, return to player turn
        if self.state == "battle_pending":
            self.state = "player_turn"

    # --- CPU turn ---

    def _run_cpu_turn(self) -> None:
        """Execute CPU turn (stub: auto-resolve battles)."""
        self.turn_manager.start_cpu_turn()
        action = self.cpu_ai.choose_action(self.turn_manager.cpu_gold)
        if action["type"] == "attack":
            tid = action["territory_id"]
            budget = action["budget"]
            self.turn_manager.cpu_gold -= budget
            # Stub: random battle result based on difficulty
            import random
            player_wins_defense = random.random() > 0.4  # 60% player survives defense
            self.turn_manager.apply_battle_result(tid, not player_wins_defense, "defense")
            self._last_battle_result = {
                "territory_id": tid,
                "player_wins": player_wins_defense,
                "battle_type": "defense",
                "is_cpu_attack": True,
            }
        self.state = "player_turn"
        self.turn_manager.start_player_turn()
        self.check_end_conditions()

    # --- Win/lose detection ---

    def check_end_conditions(self) -> None:
        if self.state in ("won", "lost", "stalemate"):
            return
        if self.world.player_wins():
            self.state = "won"
            return
        if self.world.player_loses():
            self.state = "lost"
            return
        # Stalemate: >50 turns, player wins if more or equal cities
        if self.turn_manager.turn_number > 50:
            player_cities = sum(1 for t in self.world.player_territories() if t.is_city)
            cpu_cities = sum(1 for t in self.world.cpu_territories() if t.is_city)
            if player_cities >= cpu_cities:
                self.state = "won"
            else:
                self.state = "lost"
