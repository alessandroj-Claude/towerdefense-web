"""Conquest mode — ConquestGame state machine.

No pygame import at module level.
States: player_turn | cpu_turn | battle_pending | won | lost | stalemate
"""
from __future__ import annotations

from src.conquest.world import WorldGraph
from src.conquest.turn import TurnManager, BattleRequest
from src.conquest.cpu_ai import CpuAI
from src.conquest.resources import ResourceInventory, generate_resources


class ConquestGame:
    def __init__(self, world: WorldGraph, difficulty: str = "normal"):
        self.world = world
        self.difficulty = difficulty
        self.state: str = "player_turn"
        self.in_battle: bool = False
        self.turn_manager = TurnManager(world, difficulty)
        self.cpu_ai = CpuAI(world, difficulty)
        self._pending_battle: BattleRequest | None = None
        self._pending_defense: dict | None = None
        self._last_battle_result: dict | None = None  # for UI modal
        self._draft_cache: dict = {}  # (territory_id, turn_number) -> TowerDraft
        self._turn_number: int = 0  # track turns for draft seeding
        self.resources = ResourceInventory()
        self._trades_this_turn: set[tuple] = set()

    # --- Player actions ---

    def accumulate_resources(self) -> None:
        """Add per-turn resource yield from all player-owned territories."""
        for t in self.world.territories:
            if t.owner == "player":
                yield_dict = generate_resources(t.terrain, t.fortification)
                self.resources.add(**yield_dict)

    def player_end_turn(self) -> None:
        """Player ends their turn → move to CPU phase."""
        self._trades_this_turn.clear()
        self.accumulate_resources()
        self._draft_cache.clear()
        self._turn_number += 1
        self.turn_manager.end_player_turn()
        self.state = "cpu_turn"
        self._run_cpu_turn()

    def player_attack(self, territory_id: int, budget: int) -> BattleRequest:
        req = self.turn_manager.player_attack(territory_id, budget)
        self._pending_battle = req
        self.state = "battle_pending"
        self.in_battle = True
        return req

    def player_fortify(self, territory_id: int) -> bool:
        return self.turn_manager.player_fortify(territory_id)

    def trade_resources(self, from_type: str, to_type: str, amount: int) -> bool:
        """Execute a market trade. Max 1 trade per (from_type, to_type) pair per turn.

        city_bonus: True if player owns at least one city territory.
        """
        from src.conquest.resources import trade_resources as _trade
        trade_key = (from_type, to_type)
        if trade_key in self._trades_this_turn:
            return False
        has_city = any(t.is_city and t.owner == "player" for t in self.world.territories)
        result = _trade(self.resources, from_type, to_type, amount, city_bonus=has_city)
        if result:
            self._trades_this_turn.add(trade_key)
        return result

    # --- Draft management ---

    def get_draft(self, territory_id: int):
        """Return cached draft for (territory_id, turn). Cache cleared each turn."""
        from src.conquest.draft import get_draft
        key = (territory_id, self._turn_number)
        if key not in self._draft_cache:
            territory = self.world.get(territory_id)
            self._draft_cache[key] = get_draft(
                territory.seed, self._turn_number, territory.terrain
            )
        return self._draft_cache[key]

    def defense_tower_whitelist(self, territory_id: int) -> list:
        """Return tower types available if defending this territory this turn."""
        return self.get_draft(territory_id).towers

    # --- Battle resolution ---

    def resolve_battle_stub(self, territory_id: int, player_wins: bool,
                            battle_type: str, refund: int = 0) -> None:
        """Resolve battle with stub result (random or forced). Updates world + gold."""
        self.turn_manager.apply_battle_result(territory_id, player_wins, battle_type, refund)
        self.in_battle = False
        self._last_battle_result = {
            "territory_id": territory_id,
            "player_wins": player_wins,
            "battle_type": battle_type,
        }
        self._pending_battle = None
        self.check_end_conditions()
        # If game not over, return to player turn
        if self.state == "battle_pending":
            self.state = "player_turn"

    def resolve_cpu_defense(self, territory_id: int, player_wins: bool, refund: int = 0) -> None:
        """Apply result of real defense battle (CPU attacked player)."""
        self._pending_defense = None
        self.turn_manager.apply_battle_result(territory_id, player_wins, "defense", refund)
        self._last_battle_result = {
            "territory_id": territory_id,
            "player_wins": player_wins,
            "battle_type": "defense",
            "is_cpu_attack": True,
        }
        self.turn_manager.start_player_turn()
        self.state = "player_turn"
        self.check_end_conditions()

    # --- CPU turn ---

    def _run_cpu_turn(self) -> None:
        """Execute CPU turn — signal defense_pending on attack, else return to player."""
        self.turn_manager.start_cpu_turn()
        action = self.cpu_ai.choose_action(self.turn_manager.cpu_gold)
        if action["type"] == "attack":
            tid = action["territory_id"]
            budget = action["budget"]
            self.turn_manager.cpu_gold -= budget
            self._pending_defense = {"territory_id": tid, "budget": budget}
            self.state = "defense_pending"
            return
        self.state = "player_turn"
        self.turn_manager.start_player_turn()

    # --- Resource checks ---

    def can_place_tower(self, tower_cls: type) -> bool:
        """Check if player has enough resources to place tower_cls.

        Returns True for towers with no resource cost (None resources = no check).
        """
        from src.conquest.resources import TOWER_RESOURCE_COST
        cost = TOWER_RESOURCE_COST.get(tower_cls, {})
        if not cost:
            return True
        return self.resources.can_afford(cost)

    def spend_tower_resources(self, tower_cls: type) -> None:
        """Deduct resource cost for placing tower_cls. No-op if no cost."""
        from src.conquest.resources import TOWER_RESOURCE_COST
        cost = TOWER_RESOURCE_COST.get(tower_cls, {})
        if cost:
            self.resources.spend(cost)

    # --- Win/lose detection ---

    def check_end_conditions(self) -> None:
        if self.state in ("won", "lost", "stalemate"):
            return
        if self.world.player_wins():
            self.state = "won"
            return
        if self.world.player_loses():
            self.state = "lost"
            return
        # Stalemate: >50 turns, player wins if more or equal cities
        if self.turn_manager.turn_number > 50:
            player_cities = sum(1 for t in self.world.player_territories() if t.is_city)
            cpu_cities = sum(1 for t in self.world.cpu_territories() if t.is_city)
            if player_cities >= cpu_cities:
                self.state = "won"
            else:
                self.state = "lost"
