"""CpuAI — conquest mode pseudo-random AI with city bias.

No pygame import.
"""
from __future__ import annotations

import random as _random
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from src.conquest.world import WorldGraph, Territory
    from src.conquest.turn import TurnManager


class CpuAI:
    """CPU AI for conquest mode.

    Chooses actions (attack/pass) based on adjacent player territories.
    Cities weighted 10x higher than normal territories.
    Spends max 40% of gold per attack.
    """

    def __init__(
        self,
        world: WorldGraph,
        difficulty: str = "normal",
        turn_manager: Optional[TurnManager] = None,
    ):
        self.world = world
        self.difficulty = difficulty
        self.turn_manager = turn_manager
        self._rng = _random.Random()
        self.cpu_gold: int = 50

    def _seed(self, n: int) -> None:
        """Seed RNG for deterministic tests."""
        self._rng.seed(n)

    def choose_action(self, cpu_gold: int) -> dict:
        """Choose attack or pass.

        Args:
            cpu_gold: Current CPU gold amount.

        Returns:
            {"type": "attack", "territory_id": int, "budget": int}
            or
            {"type": "pass"}
        """
        player_adjacents = self._adjacent_player_territories()
        if not player_adjacents:
            return {"type": "pass"}

        # Weight cities 10x higher
        weights = [10 if t.is_city else 1 for t in player_adjacents]
        chosen = self._rng.choices(player_adjacents, weights=weights, k=1)[0]

        # Budget: 40% of current gold
        budget = int(cpu_gold * 0.4)

        return {
            "type": "attack",
            "territory_id": chosen.id,
            "budget": budget,
        }

    def _adjacent_player_territories(self) -> list[Territory]:
        """Return list of unique player territories adjacent to any CPU territory."""
        result = []
        seen_ids = set()

        for t in self.world.cpu_territories():
            for nid in t.neighbors:
                neighbor = self.world.get(nid)
                if neighbor.owner == "player" and neighbor.id not in seen_ids:
                    result.append(neighbor)
                    seen_ids.add(neighbor.id)

        return result
