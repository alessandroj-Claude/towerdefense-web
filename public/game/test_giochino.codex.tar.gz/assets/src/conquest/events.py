"""Conquest neutral territory events — random rewards/penalties on conquest.

No pygame import at module level.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from src.conquest.world import TerrainType


class EventType(Enum):
    GOLD_CACHE         = "gold_cache"
    RESOURCE_DEPOSIT   = "resource_deposit"
    ABANDONED_FORTRESS = "abandoned_fortress"
    TRAP               = "trap"


@dataclass
class NeutralEvent:
    event_type: EventType
    value: int
    resource_type: str   # "oro"|"legno"|"pietra" (only for RESOURCE_DEPOSIT)
    description: str


# Weights per terrain: (gold_cache, resource_deposit, abandoned_fortress, trap)
TERRAIN_EVENT_WEIGHTS: dict[TerrainType, tuple[int, int, int, int]] = {
    TerrainType.DESERT:   (4, 3, 1, 2),
    TerrainType.FOREST:   (2, 4, 1, 3),
    TerrainType.MOUNTAIN: (2, 3, 3, 2),
    TerrainType.PLAINS:   (3, 2, 2, 3),
    TerrainType.SWAMP:    (1, 3, 1, 5),
    TerrainType.TUNDRA:   (2, 3, 2, 3),
}

TERRAIN_PRIMARY_RESOURCE: dict[TerrainType, str] = {
    TerrainType.DESERT:   "oro",
    TerrainType.FOREST:   "legno",
    TerrainType.MOUNTAIN: "pietra",
    TerrainType.PLAINS:   "oro",
    TerrainType.SWAMP:    "legno",
    TerrainType.TUNDRA:   "pietra",
}


def get_neutral_event(territory) -> NeutralEvent:
    """Return deterministic event for a neutral territory."""
    import random
    rng = random.Random(territory.seed ^ 0xDEAD_BEEF)
    weights = TERRAIN_EVENT_WEIGHTS.get(territory.terrain, (3, 2, 2, 3))
    event_types = [
        EventType.GOLD_CACHE,
        EventType.RESOURCE_DEPOSIT,
        EventType.ABANDONED_FORTRESS,
        EventType.TRAP,
    ]
    chosen = rng.choices(event_types, weights=list(weights), k=1)[0]
    primary = TERRAIN_PRIMARY_RESOURCE.get(territory.terrain, "oro")

    if chosen == EventType.GOLD_CACHE:
        value = rng.randint(20, 60)
        return NeutralEvent(EventType.GOLD_CACHE, value, "", f"Cache d'oro! +{value} gold")
    elif chosen == EventType.RESOURCE_DEPOSIT:
        value = rng.randint(2, 5)
        label = {"oro": "Oro", "legno": "Legno", "pietra": "Pietra"}[primary]
        return NeutralEvent(EventType.RESOURCE_DEPOSIT, value, primary,
                            f"Deposito di risorse! +{value} {label}")
    elif chosen == EventType.ABANDONED_FORTRESS:
        return NeutralEvent(EventType.ABANDONED_FORTRESS, 1, "",
                            "Fortezza abbandonata! +1 Fortification gratis")
    else:
        value = rng.randint(10, 30)
        return NeutralEvent(EventType.TRAP, value, "", f"Trappola! -{value} gold")


def apply_event(event: NeutralEvent, gold: int, resources, territory) -> int:
    """Apply event effects. Returns new gold value."""
    if event.event_type == EventType.GOLD_CACHE:
        gold += event.value
    elif event.event_type == EventType.RESOURCE_DEPOSIT:
        resources.add(**{event.resource_type: event.value})
    elif event.event_type == EventType.ABANDONED_FORTRESS:
        territory.fortification = min(3, territory.fortification + 1)
    elif event.event_type == EventType.TRAP:
        gold = max(0, gold - event.value)
    return gold
