from __future__ import annotations
import random
from dataclasses import dataclass
from src.conquest.world import TerrainType
from src.tower import (BasicTower, IceTower, BombTower, SniperTower,
                       LightningTower, InfernoTower, VenomTower)

TOWER_POOL_BY_TERRAIN: dict[TerrainType, list[type]] = {
    TerrainType.DESERT:   [BasicTower, BombTower, SniperTower, InfernoTower],
    TerrainType.FOREST:   [BasicTower, BombTower, VenomTower, LightningTower],
    TerrainType.SWAMP:    [BasicTower, IceTower, VenomTower, BombTower],
    TerrainType.MOUNTAIN: [BasicTower, SniperTower, BombTower, LightningTower],
    TerrainType.TUNDRA:   [BasicTower, IceTower, SniperTower, LightningTower],
    TerrainType.PLAINS:   [BasicTower, IceTower, BombTower, SniperTower, LightningTower],
}


@dataclass
class TowerPlacement:
    cls: type
    col: int
    row: int
    level: int = 1


def generate_cpu_towers(
    seed: int,
    terrain: TerrainType,
    fortification: int,
    buildable_cells: list[tuple[int, int]],
) -> list[TowerPlacement]:
    rng = random.Random(seed)
    count = 4 + fortification * 2
    pool = TOWER_POOL_BY_TERRAIN.get(terrain, [BasicTower])
    chosen_cells = rng.sample(buildable_cells, min(count, len(buildable_cells)))
    placements = []
    for col, row in chosen_cells:
        cls = rng.choice(pool)
        level = rng.choices([1, 2, 3], weights=[5, 3, 1 + fortification])[0]
        placements.append(TowerPlacement(cls=cls, col=col, row=row, level=level))
    return placements
