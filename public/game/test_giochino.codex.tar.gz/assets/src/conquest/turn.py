"""Conquest mode — TurnManager + BattleRequest.

Handles turn flow, income, fortification, battle setup.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.conquest.world import WorldGraph


TERRITORY_INCOME = 5
CITY_INCOME = 20
FORTIFY_COST = 30
BASE_WAVE_COUNT = 10
WAVE_PER_50_BUDGET = 1
MAX_WAVE_COUNT = 20


@dataclass
class BattleRequest:
    """Setup info for a battle."""

    battle_type: str        # "attack" | "defense"
    territory_id: int
    attacker_budget: int
    defender_budget: int

    @property
    def wave_count(self) -> int:
        """Attacker wave count: BASE + floor(budget/50), capped at MAX."""
        return min(MAX_WAVE_COUNT, BASE_WAVE_COUNT + self.attacker_budget // 50)


class TurnManager:
    """Manages conquest turn flow, income, fortification, phase transitions."""

    def __init__(self, world: WorldGraph, difficulty: str = "normal"):
        self.world = world
        self.difficulty = difficulty
        self.phase: str = "player"   # "player" | "cpu"
        self.player_gold: int = 50
        self.cpu_gold: int = 50
        self.turn_number: int = 1
        self._pending_battle: BattleRequest | None = None

    def collect_income(self, owner: str) -> int:
        """Sum income from all territories owned by owner."""
        territories = [t for t in self.world.territories if t.owner == owner]
        return sum(
            CITY_INCOME if t.is_city else TERRITORY_INCOME
            for t in territories
        )

    def start_player_turn(self) -> None:
        """Collect income at start of player turn."""
        self.player_gold += self.collect_income("player")

    def player_attack(self, territory_id: int, budget: int) -> BattleRequest:
        """Initiate attack on territory with given budget.

        Deduct budget from player gold, compute defender budget from fortification.
        """
        self.player_gold -= budget
        t = self.world.get(territory_id)
        cpu_budget = int(t.fortification * 20)
        return BattleRequest("attack", territory_id, budget, cpu_budget)

    def player_fortify(self, territory_id: int) -> bool:
        """Fortify owned territory: cost FORTIFY_COST, increase fortification by 1.

        Return False if: not owned, insufficient gold, max fortification reached.
        """
        t = self.world.get(territory_id)
        if t.owner != "player" or self.player_gold < FORTIFY_COST or t.fortification >= 3:
            return False
        self.player_gold -= FORTIFY_COST
        t.fortification += 1
        return True

    def end_player_turn(self) -> None:
        """End player turn, switch to CPU phase."""
        self.phase = "cpu"

    def start_cpu_turn(self) -> None:
        """Collect CPU income, switch back to player phase, increment turn counter."""
        self.cpu_gold += self.collect_income("cpu")
        self.phase = "player"
        self.turn_number += 1

    def apply_battle_result(
        self,
        territory_id: int,
        attacker_wins: bool,
        battle_type: str,
        refund: int = 0,
    ) -> None:
        """Apply battle result to territory and player state.

        If attack + attacker_wins: territory → player, fortification reset.
        If defense + attacker_wins: territory → cpu.
        Refund spent budget back to player.
        """
        t = self.world.get(territory_id)
        if battle_type == "attack" and attacker_wins:
            t.owner = "player"
            t.fortification = 0
        elif battle_type == "defense" and attacker_wins:
            t.owner = "cpu"
        self.player_gold += refund
