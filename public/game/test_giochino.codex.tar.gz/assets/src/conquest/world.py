"""Conquest mode — Territory, WorldGraph, generate_world.

No pygame import at module level.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import List


# ---------------------------------------------------------------------------
# Enums / data classes
# ---------------------------------------------------------------------------

class TerrainType(Enum):
    DESERT = "desert"
    FOREST = "forest"
    SWAMP = "swamp"
    MOUNTAIN = "mountain"
    TUNDRA = "tundra"
    PLAINS = "plains"


@dataclass
class Territory:
    id: int
    name: str
    terrain: TerrainType
    owner: str          # "player" | "cpu" | "neutral"
    is_city: bool
    neighbors: List[int]
    seed: int
    fortification: int = 0
    pos: tuple = (0.0, 0.0)


@dataclass
class WorldGraph:
    territories: List[Territory]
    seed: int

    def get(self, tid: int) -> Territory:
        return self.territories[tid]

    def player_territories(self) -> List[Territory]:
        return [t for t in self.territories if t.owner == "player"]

    def cpu_territories(self) -> List[Territory]:
        return [t for t in self.territories if t.owner == "cpu"]

    def player_wins(self) -> bool:
        return all(t.owner == "player" for t in self.territories)

    def player_loses(self) -> bool:
        return all(t.owner == "cpu" for t in self.territories)


# ---------------------------------------------------------------------------
# Name generation
# ---------------------------------------------------------------------------

_PREFIXES = [
    "Kal", "Mor", "Tel", "Ven", "Dar", "Sol", "Brak", "Fen",
    "Gor", "Has", "Ith", "Jar", "Kas", "Lir", "Nar", "Orm",
    "Pel", "Qir", "Reth", "Sal", "Tav", "Ural", "Vor", "Wys",
    "Xal", "Yar", "Zel", "Ald", "Bel", "Cor",
]
_SUFFIXES = [
    "ia", "on", "ar", "en", "um", "ath", "or", "ith",
    "eld", "est", "ora", "ura", "and", "eth", "ion",
    "ael", "ash", "ir", "ul", "orn",
]


def _make_names(n: int, rng: random.Random) -> List[str]:
    """Generate n unique territory names."""
    names: List[str] = []
    seen: set = set()
    attempts = 0
    while len(names) < n and attempts < n * 20:
        attempts += 1
        p = rng.choice(_PREFIXES)
        s = rng.choice(_SUFFIXES)
        name = p + s
        if name not in seen:
            seen.add(name)
            names.append(name)
    # fallback if not enough unique names
    idx = 0
    while len(names) < n:
        fallback = f"Territory {idx}"
        if fallback not in seen:
            seen.add(fallback)
            names.append(fallback)
        idx += 1
    return names


# ---------------------------------------------------------------------------
# Graph helpers
# ---------------------------------------------------------------------------

def _dist(a: tuple, b: tuple) -> float:
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)


def _build_graph(positions: List[tuple], rng: random.Random) -> List[List[int]]:
    """Build adjacency list ensuring:
    - Every node has 1–5 neighbors.
    - Graph is fully connected (spanning tree pass).
    """
    n = len(positions)
    adj: List[set] = [set() for _ in range(n)]

    # Step 1: connect each node to 2-3 nearest neighbors
    k_neighbors = 3
    for i in range(n):
        dists = sorted(range(n), key=lambda j, i=i: _dist(positions[i], positions[j]))
        # dists[0] == i itself, skip
        for j in dists[1: k_neighbors + 1]:
            if len(adj[i]) < 5 and len(adj[j]) < 5:
                adj[i].add(j)
                adj[j].add(i)

    # Step 2: spanning tree pass — BFS from 0, connect any disconnected component
    visited = set()
    queue = [0]
    visited.add(0)
    while queue:
        cur = queue.pop(0)
        for nb in adj[cur]:
            if nb not in visited:
                visited.add(nb)
                queue.append(nb)

    if len(visited) < n:
        # find unvisited nodes, connect to nearest visited
        unvisited = [i for i in range(n) if i not in visited]
        for u in unvisited:
            # find nearest already-visited node
            nearest = min(visited, key=lambda v: _dist(positions[u], positions[v]))
            adj[u].add(nearest)
            adj[nearest].add(u)
            visited.add(u)
            # propagate BFS from u
            q2 = [u]
            while q2:
                cur2 = q2.pop(0)
                for nb in adj[cur2]:
                    if nb not in visited:
                        visited.add(nb)
                        q2.append(nb)

    # Step 3: ensure every node has at least 1 neighbor
    for i in range(n):
        if len(adj[i]) == 0:
            # connect to nearest other node
            nearest = min(
                (j for j in range(n) if j != i),
                key=lambda j: _dist(positions[i], positions[j])
            )
            adj[i].add(nearest)
            adj[nearest].add(i)

    # Step 4: cap at 5 (remove excess edges, keeping smaller-id edges)
    for i in range(n):
        if len(adj[i]) > 5:
            sorted_nb = sorted(adj[i], key=lambda j: _dist(positions[i], positions[j]))
            adj[i] = set(sorted_nb[:5])

    return [sorted(adj[i]) for i in range(n)]


# ---------------------------------------------------------------------------
# Terrain assignment
# ---------------------------------------------------------------------------

_TERRAIN_LIST = list(TerrainType)


def _assign_terrain(positions: List[tuple], rng: random.Random) -> List[TerrainType]:
    """Divide 1x1 space into 6 zones (2x3 grid), assign random TerrainType per zone."""
    zone_terrain: dict = {}
    for zx in range(2):
        for zy in range(3):
            zone_terrain[(zx, zy)] = rng.choice(_TERRAIN_LIST)

    result = []
    for px, py in positions:
        zx = min(int(px * 2), 1)
        zy = min(int(py * 3), 2)
        result.append(zone_terrain[(zx, zy)])
    return result


# ---------------------------------------------------------------------------
# Main generator
# ---------------------------------------------------------------------------

_NODE_COUNTS = {"easy": 20, "normal": 28, "hard": 35}
_CITY_COUNTS = {"easy": 4, "normal": 5, "hard": 6}
_PLAYER_START = {"easy": 3, "normal": 2, "hard": 1}


def generate_world(seed: int, difficulty: str = "normal") -> WorldGraph:
    """Generate a deterministic WorldGraph for the given seed + difficulty."""
    rng = random.Random(seed)

    n = _NODE_COUNTS.get(difficulty, 28)
    n_cities = _CITY_COUNTS.get(difficulty, 5)
    n_player = _PLAYER_START.get(difficulty, 2)

    # 1. Scatter positions in [0.05, 0.95] to avoid edge clustering
    positions = [(rng.uniform(0.05, 0.95), rng.uniform(0.05, 0.95)) for _ in range(n)]

    # 2. Build graph
    adj = _build_graph(positions, rng)

    # 3. Terrain
    terrains = _assign_terrain(positions, rng)

    # 4. Names
    names = _make_names(n, rng)

    # 5. Unique seeds
    territory_seeds: List[int] = []
    seen_seeds: set = set()
    while len(territory_seeds) < n:
        s = rng.randint(1, 10 ** 9)
        if s not in seen_seeds:
            seen_seeds.add(s)
            territory_seeds.append(s)

    # 6. Assign cities — spread evenly by sorting by pos.x
    city_flags = [False] * n
    sorted_by_x = sorted(range(n), key=lambda i: positions[i][0])
    step = max(1, n // n_cities)
    city_indices = sorted_by_x[::step][:n_cities]
    for ci in city_indices:
        city_flags[ci] = True

    # 7. Player starting territories — choose from edge territories (border)
    edge_indices = [
        i for i in range(n)
        if positions[i][0] < 0.3 or positions[i][0] > 0.7
        or positions[i][1] < 0.3 or positions[i][1] > 0.7
    ]
    if not edge_indices:
        edge_indices = list(range(n))

    # Prefer edge city for player's first territory
    edge_cities = [i for i in edge_indices if city_flags[i]]
    if edge_cities:
        player_city_idx = rng.choice(edge_cities)
    else:
        player_city_idx = rng.choice(edge_indices)
        city_flags[player_city_idx] = True  # force city

    # Build player territory list: city first, then random neighbors
    player_indices = [player_city_idx]
    remaining_edge = [i for i in edge_indices if i != player_city_idx]
    rng.shuffle(remaining_edge)
    for idx in remaining_edge:
        if len(player_indices) >= n_player:
            break
        player_indices.append(idx)

    owner_list = ["cpu"] * n
    for pi in player_indices:
        owner_list[pi] = "player"

    # 8. Assemble territories
    territories = []
    for i in range(n):
        t = Territory(
            id=i,
            name=names[i],
            terrain=terrains[i],
            owner=owner_list[i],
            is_city=city_flags[i],
            neighbors=adj[i],
            seed=territory_seeds[i],
            pos=positions[i],
        )
        territories.append(t)

    return WorldGraph(territories=territories, seed=seed)
