"""Conquest save/load — JSON serialization of ConquestGame state.

No pygame import at module level.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.conquest.conquest_game import ConquestGame


def _default_path() -> Path:
    """Get default conquest save path."""
    from src.data_paths import data_path
    return data_path("conquest_save.json")


def save_conquest(cg: "ConquestGame", path: Path | None = None) -> None:
    """Serialize ConquestGame to JSON.

    Args:
        cg: ConquestGame instance to save.
        path: Optional custom save path. Defaults to data_path("conquest_save.json").
    """
    if path is None:
        path = _default_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    data = {
        "version": 1,
        "difficulty": cg.difficulty,
        "game_state": cg.state,
        "turn_manager": {
            "player_gold": cg.turn_manager.player_gold,
            "cpu_gold": cg.turn_manager.cpu_gold,
            "turn_number": cg.turn_manager.turn_number,
            "phase": cg.turn_manager.phase,
        },
        "territories": [
            {
                "id": t.id,
                "name": t.name,
                "terrain": t.terrain.value,
                "owner": t.owner,
                "is_city": t.is_city,
                "neighbors": t.neighbors,
                "seed": t.seed,
                "fortification": t.fortification,
                "pos": list(t.pos),
            }
            for t in cg.world.territories
        ],
        "world_seed": cg.world.seed,
    }
    path.write_text(json.dumps(data, indent=2))


def load_conquest(path: Path | None = None) -> "ConquestGame | None":
    """Deserialize ConquestGame from JSON.

    Args:
        path: Optional custom save path. Defaults to data_path("conquest_save.json").

    Returns:
        ConquestGame instance if save exists and is valid; None otherwise.
    """
    if path is None:
        path = _default_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        from src.conquest.world import Territory, WorldGraph, TerrainType
        from src.conquest.conquest_game import ConquestGame

        territories = []
        for td in data["territories"]:
            t = Territory(
                id=td["id"],
                name=td["name"],
                terrain=TerrainType(td["terrain"]),
                owner=td["owner"],
                is_city=td["is_city"],
                neighbors=td["neighbors"],
                seed=td["seed"],
                fortification=td.get("fortification", 0),
                pos=tuple(td["pos"]),
            )
            territories.append(t)

        world = WorldGraph(territories=territories, seed=data["world_seed"])
        cg = ConquestGame(world, difficulty=data["difficulty"])
        cg.state = data["game_state"]
        cg.turn_manager.player_gold = data["turn_manager"]["player_gold"]
        cg.turn_manager.cpu_gold = data["turn_manager"]["cpu_gold"]
        cg.turn_manager.turn_number = data["turn_manager"]["turn_number"]
        cg.turn_manager.phase = data["turn_manager"]["phase"]
        return cg
    except Exception:
        return None


def conquest_save_exists(path: Path | None = None) -> bool:
    """Check if conquest save file exists.

    Args:
        path: Optional custom save path. Defaults to data_path("conquest_save.json").

    Returns:
        True if save file exists; False otherwise.
    """
    if path is None:
        path = _default_path()
    return path.exists()
