"""Conquest victory conditions and campaign statistics.

No pygame import at module level.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum


class VictoryCondition(Enum):
    CONQUER_ALL    = "conquer_all"
    CONTROL_CITIES = "control_cities"
    SURVIVE_TURNS  = "survive_turns"


@dataclass
class CampaignStats:
    turns_played: int = 0
    battles_won: int = 0
    battles_lost: int = 0
    territories_conquered: int = 0
    territories_lost: int = 0
    resources_accumulated: dict = field(default_factory=lambda: {"oro": 0, "legno": 0, "pietra": 0})
    gold_earned_total: int = 0
    victory_condition: VictoryCondition = field(default_factory=lambda: VictoryCondition.CONQUER_ALL)
    survive_turns_target: int = 0

    @property
    def total_battles(self) -> int:
        return self.battles_won + self.battles_lost

    @property
    def win_rate(self) -> float:
        if self.total_battles == 0:
            return 0.0
        return self.battles_won / self.total_battles


def check_victory(world, stats: CampaignStats) -> str | None:
    """Return 'won' | 'lost' | None based on victory condition."""
    if stats.victory_condition == VictoryCondition.CONQUER_ALL:
        if world.player_wins():
            return "won"
        if world.player_loses():
            return "lost"

    elif stats.victory_condition == VictoryCondition.CONTROL_CITIES:
        cities = [t for t in world.territories if t.is_city]
        if cities and all(t.owner == "player" for t in cities):
            return "won"
        if world.player_loses():
            return "lost"

    elif stats.victory_condition == VictoryCondition.SURVIVE_TURNS:
        if stats.turns_played >= stats.survive_turns_target:
            return "won"
        if world.player_loses():
            return "lost"

    return None


def calculate_survive_target(world) -> int:
    """N turns to survive = total territories // 2 + 5."""
    return len(world.territories) // 2 + 5
