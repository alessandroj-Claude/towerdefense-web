"""ConquestContext — bridge between Conquest map and TD battle.

No pygame import. Safe to import in any context.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from src.conquest.world import TerrainType


SURVIVAL_REFUND_RATE = {"easy": 0.50, "normal": 0.30, "hard": 0.15, "endless": 0.0}


@dataclass
class BattleResult:
    survived: bool
    towers_alive: list  # list of Tower instances


@dataclass
class ConquestContext:
    battle_type: str            # "defense" | "attack"
    territory_id: int
    terrain: "TerrainType"
    map_seed: int
    battle_budget: int          # starting gold in battle
    wave_count: int             # 0 = use normal TD default
    difficulty: str
    on_battle_end: Callable[["BattleResult"], None]


def calculate_refund(towers_alive: list, difficulty: str) -> int:
    """Calculate gold refund from surviving towers.

    towers_alive: list of Tower objects with .base_cost and .hp attributes.
    Only towers with hp > 0 count as alive.

    Formula: sum(int(t.base_cost * 0.3) for t in towers_alive if t.hp > 0) * rate

    Args:
        towers_alive: List of Tower instances.
        difficulty: One of "easy", "normal", "hard", "endless".

    Returns:
        Gold refund amount as integer.
    """
    rate = SURVIVAL_REFUND_RATE.get(difficulty, 0.30)
    total = sum(int(t.base_cost * 0.3) for t in towers_alive if t.hp > 0)
    return int(total * rate)
