from __future__ import annotations
from dataclasses import dataclass, field
from src.conquest.world import Territory
from src.conquest.cpu_map import generate_cpu_towers
from src.enemy import (BasicEnemy, FastEnemy, SwarmEnemy, TankEnemy,
                       HeavyEnemy, PathFlyer, ScoutFlyer, BossEnemy)

ENEMY_SPAWN_COST: dict[type, int] = {
    BasicEnemy: 5, FastEnemy: 8, SwarmEnemy: 4,
    TankEnemy: 25, HeavyEnemy: 30,
    PathFlyer: 15, ScoutFlyer: 12,
    BossEnemy: 80,
}


@dataclass
class AttackBattleResult:
    attacker_wins: bool
    castle_damage: int
    castle_hp: int


class AttackBattle:
    def __init__(self, territory: Territory, attacker_budget: int,
                 difficulty: str, buildable_cells: list, tile_size: int):
        self.territory = territory
        self.budget = attacker_budget
        self.difficulty = difficulty
        self.tile_size = tile_size
        self.castle_hp = 100 + territory.fortification * 50
        self.castle_damage = 0
        self.cpu_repair_budget = territory.fortification * 20
        self._cpu_repair_timer = 0.0
        self.towers: list = []
        self.enemies: list = []
        self._projectiles: list = []
        self._setup_cpu_towers(buildable_cells, tile_size)

    def _setup_cpu_towers(self, buildable_cells: list, tile_size: int) -> None:
        placements = generate_cpu_towers(
            self.territory.seed, self.territory.terrain,
            self.territory.fortification, buildable_cells,
        )
        for p in placements:
            t = p.cls(col=p.col, row=p.row, tile_size=tile_size)
            for _ in range(p.level - 1):
                t.upgrade()
            self.towers.append(t)

    def spawn_enemy(self, enemy_cls: type, path: list) -> bool:
        cost = ENEMY_SPAWN_COST.get(enemy_cls, 5)
        if self.budget < cost:
            return False
        self.budget -= cost
        self.enemies.append(enemy_cls(path, self.tile_size))
        return True

    def update(self, dt: float) -> AttackBattleResult | None:
        for e in self.enemies:
            e.update(dt)

        reached = [e for e in self.enemies if e.reached_end]
        for e in reached:
            self.castle_damage += int(e.hp)
        self.enemies = [e for e in self.enemies if not e.reached_end and e.alive]

        for t in self.towers:
            t.update(dt, self.enemies, self._projectiles)

        surviving = []
        for p in self._projectiles:
            p.update(dt, self.enemies)
            if p.active:
                surviving.append(p)
        self._projectiles = surviving
        self.enemies = [e for e in self.enemies if e.alive]

        self._tick_cpu_repair(dt)
        return self.result

    def _tick_cpu_repair(self, dt: float) -> None:
        self._cpu_repair_timer -= dt
        if self._cpu_repair_timer > 0 or self.cpu_repair_budget <= 0:
            return
        self._cpu_repair_timer = 10.0
        damaged = [t for t in self.towers if t.hp < t.max_hp]
        if not damaged:
            return
        worst = min(damaged, key=lambda t: t.hp / t.max_hp)
        cost = min(self.cpu_repair_budget, int(worst.base_cost * 0.3))
        worst.heal(int(worst.max_hp * 0.33))
        self.cpu_repair_budget -= cost

    @property
    def result(self) -> AttackBattleResult | None:
        if self.castle_damage >= self.castle_hp:
            return AttackBattleResult(True, self.castle_damage, self.castle_hp)
        if self.budget <= 0 and not self.enemies:
            return AttackBattleResult(False, self.castle_damage, self.castle_hp)
        return None
