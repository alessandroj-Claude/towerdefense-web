import math
import random
from typing import List, Tuple
from src.enemy import FlyingEnemy
from src.elements import get_damage_mult

class Projectile:
    def __init__(self, x: float, y: float, target_enemy, damage: float,
                 speed: float, slow_factor: float, slow_duration: float,
                 splash_radius: float, visual_kind: str = "default",
                 color: Tuple[int, int, int] = (255, 255, 255),
                 trail: bool = False):
        self.x = x
        self.y = y
        self.target = target_enemy
        self.damage = damage
        self.speed = speed
        self.slow_factor = slow_factor
        self.slow_duration = slow_duration
        self.splash_radius = splash_radius
        self.visual_kind = visual_kind
        self.color = color
        self.trail = trail
        self.active = True

    def update(self, dt: float, enemies: list) -> list:
        if not self.active or not self.target.alive:
            self.active = False
            return []

        tx, ty = self.target.pos
        dx, dy = tx - self.x, ty - self.y
        dist = math.hypot(dx, dy)

        if dist < self.speed * dt:
            self.active = False
            return self._on_hit(enemies)

        self.x += (dx / dist) * self.speed * dt
        self.y += (dy / dist) * self.speed * dt
        return []

    def _on_hit(self, enemies: list) -> list:
        hit = []
        if self.splash_radius > 0:
            tx, ty = self.target.pos
            for e in enemies:
                if e.alive:
                    ex, ey = e.pos
                    if math.hypot(ex - tx, ey - ty) <= self.splash_radius:
                        e.take_damage(self.damage)
                        if self.slow_factor < 1.0:
                            e.apply_slow(self.slow_factor, self.slow_duration)
                        hit.append(e)
        else:
            self.target.take_damage(self.damage)
            if self.slow_factor < 1.0:
                self.target.apply_slow(self.slow_factor, self.slow_duration)
            hit.append(self.target)
        return hit


class Tower:
    RANGE_SCALE: float = 1.15
    element: str = "ARCANE"
    base_cost: int = 0
    base_damage: float = 0
    base_range: float = 0
    base_fire_rate: float = 1.0
    proj_speed: float = 300.0
    slow_factor: float = 1.0
    slow_duration: float = 0.0
    splash_radius: float = 0.0
    projectile_visual_kind: str = "default"
    projectile_color: Tuple[int, int, int] = (255, 255, 255)
    projectile_trail: bool = False
    max_hp: int = 0

    def __init__(self, col: int, row: int, tile_size: int):
        self.col = col
        self.row = row
        self.tile_size = tile_size
        self.level = 1
        self.cooldown = 0.0
        self.damage = float(self.base_damage)
        self.range_px = float(self.base_range) * self.RANGE_SCALE
        self.fire_rate = float(self.base_fire_rate)
        self.gold_invested: int = self.base_cost
        self.hp: int = self.max_hp
        self.targeting_policy: str = "furthest"
        self.aim_angle: float = -math.pi / 2

    @property
    def center_px(self) -> Tuple[float, float]:
        return (self.col * self.tile_size + self.tile_size / 2,
                self.row * self.tile_size + self.tile_size / 2)

    @property
    def upgrade_cost(self) -> int:
        return self.base_cost * self.level

    def in_range(self, enemy, range_modifier: float = 1.0) -> bool:
        cx, cy = self.center_px
        ex, ey = enemy.pos
        effective_range = self.range_px * max(0.0, range_modifier)
        return math.hypot(ex - cx, ey - cy) <= effective_range

    def get_target(self, enemies: list, range_modifier: float = 1.0):
        candidates = [e for e in enemies if e.alive and self.in_range(e, range_modifier=range_modifier)]
        if not candidates:
            return None
        policy = getattr(self, "targeting_policy", "furthest")
        if policy == "strongest":
            return max(candidates, key=lambda e: e.hp)
        elif policy == "lowest-hp":
            return min(candidates, key=lambda e: e.hp)
        elif policy == "flying-first":
            flying = [e for e in candidates if isinstance(e, FlyingEnemy)]
            pool = flying if flying else candidates
            return max(pool, key=lambda e: e.progress)
        else:  # "furthest" o default
            return max(candidates, key=lambda e: e.progress)

    def _shoot(self, target, projectiles: list) -> None:
        tx, ty = target.pos
        cx, cy = self.center_px
        self.aim_angle = math.atan2(ty - cy, tx - cx)
        mx, my = self.muzzle_px
        projectiles.append(Projectile(
            x=mx, y=my, target_enemy=target,
            damage=self.damage_for_target(target), speed=self.proj_speed,
            slow_factor=self.slow_factor, slow_duration=self.slow_duration,
            splash_radius=self.splash_radius,
            visual_kind=self.projectile_visual_kind,
            color=self.projectile_color,
            trail=self.projectile_trail,
        ))
        # Guard against division by zero for towers with base_fire_rate=0 (e.g., MedicTower)
        self.cooldown = (1.0 / self.fire_rate) if self.fire_rate > 0 else float('inf')

    def damage_for_target(self, target) -> float:
        mult = get_damage_mult(self.element, getattr(target, "element", "ARCANE"))
        return self.damage * mult

    @property
    def muzzle_px(self) -> Tuple[float, float]:
        cx, cy = self.center_px
        reach = max(10.0, self.tile_size * 0.4)
        return (
            cx + math.cos(self.aim_angle) * reach,
            cy + math.sin(self.aim_angle) * reach,
        )

    def update(self, dt: float, enemies: list, projectiles: list,
               accuracy_modifier: float = 1.0, range_modifier: float = 1.0,
               rng=None, accuracy_target_modifier=None, towers: list = None) -> None:
        self.cooldown = max(0.0, self.cooldown - dt)
        if self.cooldown == 0.0:
            target = self.get_target(enemies, range_modifier=range_modifier)
            if target:
                if rng is None:
                    rng = random.random
                accuracy = max(0.0, accuracy_modifier)
                if callable(accuracy_target_modifier):
                    accuracy *= max(0.0, float(accuracy_target_modifier(target)))
                if accuracy >= 1.0 or rng() <= accuracy:
                    self._shoot(target, projectiles)
                else:
                    self.cooldown = 1.0 / self.fire_rate

    def upgrade(self) -> None:
        if self.level >= 3:
            return
        self.gold_invested += self.upgrade_cost
        self.level += 1
        self.damage *= 1.25
        self.range_px *= 1.25

    def try_shop_upgrade(self, economy) -> str:
        """Returns 'ok', 'max_level', or 'insufficient_gold'."""
        if self.level >= 3:
            return "max_level"
        if not economy.can_afford(self.upgrade_cost):
            return "insufficient_gold"
        economy.spend(self.upgrade_cost)
        self.upgrade()
        return "ok"

    @property
    def upgrade_preview_stats(self) -> dict:
        if self.level >= 3:
            return {"damage": self.damage, "range_px": self.range_px, "cost": 0, "max_level": True}
        return {
            "damage": self.damage * 1.25,
            "range_px": self.range_px * 1.25,
            "cost": self.upgrade_cost,
            "max_level": False,
        }

    def take_damage(self, amount: int) -> None:
        self.hp = max(0, self.hp - amount)

    def heal(self, amount: int) -> None:
        self.hp = min(self.max_hp, self.hp + amount)


def towers_sorted_xy_for_type(towers: list, tower_cls: type) -> list:
    """Return towers filtered by class and sorted deterministically by x,y grid coords."""
    return sorted(
        (tower for tower in towers if isinstance(tower, tower_cls)),
        key=lambda tower: (tower.col, tower.row),
    )


def _sanitize_placement_level(level: int) -> int:
    value = int(level)
    if value < 1 or value > 3:
        raise ValueError("placement level must be between 1 and 3")
    return value


def build_tower_for_placement(tower_cls: type, col: int, row: int, tile_size: int, level: int = 1):
    """Create a tower already upgraded to the requested placement level."""
    target_level = _sanitize_placement_level(level)
    tower = tower_cls(col=col, row=row, tile_size=tile_size)
    while tower.level < target_level:
        tower.upgrade()
    return tower


def placement_cost_for_level(tower_cls: type, level: int) -> int:
    """Return total gold required to place a tower directly at the requested level."""
    preview_tower = build_tower_for_placement(tower_cls, col=0, row=0, tile_size=1, level=level)
    return int(preview_tower.gold_invested)


class BasicTower(Tower):
    base_cost = 50; base_damage = 25; base_range = 120; base_fire_rate = 1.0; max_hp = 150

class IceTower(Tower):
    element = "ICE"
    base_cost = 80; base_damage = 5; base_range = 100; base_fire_rate = 1.5
    slow_factor = 0.6; slow_duration = 2.0; max_hp = 100
    projectile_visual_kind = "ice"
    projectile_color = (160, 220, 255)

class BombTower(Tower):
    element = "EARTH"
    base_cost = 120; base_damage = 60; base_range = 90; base_fire_rate = 0.5
    splash_radius = 60.0; max_hp = 180
    projectile_visual_kind = "bomb"
    projectile_color = (255, 170, 60)
    projectile_trail = True

class SniperTower(Tower):
    base_cost = 150; base_damage = 120; base_range = 250; base_fire_rate = 0.3
    proj_speed = 600.0; max_hp = 80
    projectile_visual_kind = "sniper"
    projectile_color = (220, 220, 255)

class AntiAirTower(Tower):
    element = "LIGHTNING"
    base_cost = 130; base_damage = 40; base_range = 165; base_fire_rate = 1.8; max_hp = 120
    proj_speed = 420.0
    projectile_visual_kind = "storm"
    projectile_color = (170, 230, 255)

    def get_target(self, enemies: list, range_modifier: float = 1.0):
        candidates = [e for e in enemies if e.alive and self.in_range(e, range_modifier=range_modifier)]
        if not candidates:
            return None
        policy = getattr(self, "targeting_policy", "flying-first")
        if policy == "strongest":
            return max(candidates, key=lambda e: e.hp)
        elif policy == "lowest-hp":
            return min(candidates, key=lambda e: e.hp)
        else:  # "flying-first" o "furthest" o default
            flying = [e for e in candidates if isinstance(e, FlyingEnemy)]
            pool = flying if flying else candidates
            return max(pool, key=lambda e: e.progress)

    def damage_for_target(self, target) -> float:
        elem_mult = get_damage_mult(self.element, getattr(target, "element", "ARCANE"))
        class_bonus = 1.5 if isinstance(target, FlyingEnemy) else 0.5
        return self.damage * elem_mult * class_bonus

class StormTower(Tower):
    element = "LIGHTNING"
    base_cost = 110; base_damage = 35; base_range = 135; base_fire_rate = 1.4
    proj_speed = 340.0; max_hp = 130
    projectile_visual_kind = "storm"
    projectile_color = (120, 190, 255)
    projectile_trail = True

class InfernoTower(Tower):
    element = "FIRE"
    base_cost = 180; base_damage = 85; base_range = 110; base_fire_rate = 0.55
    splash_radius = 70.0; max_hp = 220
    projectile_visual_kind = "inferno"
    projectile_color = (255, 120, 40)
    projectile_trail = True

class VenomTower(Tower):
    base_cost = 140
    base_damage = 5
    base_range = 110
    base_fire_rate = 0.8
    proj_speed = 350.0
    max_hp = 100
    element = "ARCANE"
    projectile_visual_kind = "venom"
    projectile_color = (80, 200, 80)

    POISON_DPS_PCT = 0.02   # 2% of enemy max_hp per second
    POISON_DURATION = 3.0   # seconds

    def _apply_poison(self, target) -> None:
        poison_dps = target.max_hp * self.POISON_DPS_PCT
        target.poison_dps = max(getattr(target, "poison_dps", 0.0), poison_dps)
        target.poison_timer = max(target.poison_timer, self.POISON_DURATION)

    def _shoot(self, target, projectiles: list) -> None:
        super()._shoot(target, projectiles)
        self._apply_poison(target)


class MedicTower(Tower):
    base_cost = 110
    base_damage = 0
    base_range = 0
    base_fire_rate = 0
    max_hp = 180
    element = "ARCANE"
    projectile_visual_kind = "none"

    HEAL_RATE = 8       # HP healed per pulse
    HEAL_RADIUS_TILES = 1.5
    HEAL_INTERVAL = 1.0  # seconds between pulses

    def __init__(self, col: int, row: int, tile_size: int):
        super().__init__(col, row, tile_size)
        self._heal_pulse_timer: float = self.HEAL_INTERVAL

    def update(self, dt: float, enemies: list, projectiles: list,
               accuracy_modifier: float = 1.0, range_modifier: float = 1.0,
               rng=None, accuracy_target_modifier=None, towers: list = None) -> None:
        # MedicTower does not attack — skip parent weapon logic
        self._heal_pulse_timer -= dt
        if self._heal_pulse_timer <= 0:
            self._heal_pulse_timer = self.HEAL_INTERVAL
            if towers:
                radius_px = self.HEAL_RADIUS_TILES * self.tile_size
                cx, cy = self.center_px
                for t in towers:
                    if t is self:
                        continue
                    tx, ty = t.center_px
                    if math.hypot(tx - cx, ty - cy) <= radius_px:
                        t.heal(self.HEAL_RATE)


class SentinelTower(Tower):
    base_cost = 200
    base_damage = 15
    base_range = 100
    base_fire_rate = 0.6
    max_hp = 400
    element = "EARTH"
    is_sentinel = True
    projectile_visual_kind = "sentinel"
    projectile_color = (180, 180, 100)
