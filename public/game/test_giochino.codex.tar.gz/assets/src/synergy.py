from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


@dataclass(frozen=True)
class SynergyEffect:
    tower_a: object
    tower_b: object
    label: str
    description: str


_SYNERGY_RULES = [
    {
        "types": {"IceTower", "SniperTower"},
        "label": "Cryo-Snipe",
        "description": "Sniper +15% DMG",
        "bonuses": {"SniperTower": ("damage", "mult", 1.15)},
    },
    {
        "types": {"IceTower", "StormTower"},
        "label": "Arctic Storm",
        "description": "Storm +10% Fire Rate",
        "bonuses": {"StormTower": ("fire_rate", "mult", 1.10)},
    },
    {
        "types": {"BombTower", "InfernoTower"},
        "label": "Firestorm",
        "description": "Bomb+Inferno +10% DMG",
        "bonuses": {
            "BombTower": ("damage", "mult", 1.10),
            "InfernoTower": ("damage", "mult", 1.10),
        },
    },
    {
        "types": {"MedicTower", "SentinelTower"},
        "label": "Field Hospital",
        "description": "Sentinel +25% Max HP",
        "bonuses": {"SentinelTower": ("max_hp", "mult_hp", 1.25)},
    },
    {
        "types": {"VenomTower", "BasicTower"},
        "label": "Pestilence",
        "description": "Venom +0.5s Slow",
        "bonuses": {"VenomTower": ("slow_duration", "add", 0.5)},
    },
    {
        "types": {"AntiAirTower", "SniperTower"},
        "label": "Aerial Precision",
        "description": "AntiAir +20% DMG",
        "bonuses": {"AntiAirTower": ("damage", "mult", 1.20)},
    },
]


def _manhattan(a, b) -> int:
    return abs(a.col - b.col) + abs(a.row - b.row)


def get_adjacent_pairs(towers: list) -> list:
    pairs = []
    for i in range(len(towers)):
        for j in range(i + 1, len(towers)):
            if _manhattan(towers[i], towers[j]) == 1:
                pairs.append((towers[i], towers[j]))
    return pairs


def compute_synergies(towers: list) -> list:
    effects = []
    for t_a, t_b in get_adjacent_pairs(towers):
        name_a = type(t_a).__name__
        name_b = type(t_b).__name__
        pair_names = {name_a, name_b}
        for rule in _SYNERGY_RULES:
            if rule["types"] == pair_names:
                effects.append(SynergyEffect(
                    tower_a=t_a,
                    tower_b=t_b,
                    label=rule["label"],
                    description=rule["description"],
                ))
    return effects


def _level_multiplier(tower) -> float:
    return 1.25 ** (tower.level - 1)


def reset_synergy_bonuses(towers: list) -> None:
    for tower in towers:
        cls = type(tower)
        tower.damage = float(cls.base_damage) * _level_multiplier(tower)
        tower.fire_rate = float(cls.base_fire_rate)
        tower.slow_duration = cls.slow_duration
        base_max_hp = cls.max_hp
        tower.max_hp = base_max_hp
        if tower.hp > base_max_hp and base_max_hp > 0:
            tower.hp = base_max_hp


def apply_synergy_bonuses(towers: list, synergies: list) -> None:
    reset_synergy_bonuses(towers)
    tower_bonuses: dict = {}
    for effect in synergies:
        rule = next(r for r in _SYNERGY_RULES if r["label"] == effect.label)
        for tower in (effect.tower_a, effect.tower_b):
            name = type(tower).__name__
            if name in rule["bonuses"]:
                if id(tower) not in tower_bonuses:
                    tower_bonuses[id(tower)] = (tower, [])
                tower_bonuses[id(tower)][1].append(rule["bonuses"][name])
    for tower, bonus_list in tower_bonuses.values():
        cls = type(tower)
        for attr, mode, value in bonus_list:
            if mode == "mult":
                if attr == "damage":
                    base = float(cls.base_damage) * _level_multiplier(tower)
                    setattr(tower, attr, base * value)
                elif attr == "fire_rate":
                    setattr(tower, attr, float(cls.base_fire_rate) * value)
            elif mode == "add":
                base = cls.slow_duration
                setattr(tower, attr, base + value)
            elif mode == "mult_hp":
                base_max = cls.max_hp
                new_max = int(base_max * value)
                tower.max_hp = new_max
                if tower.hp < new_max:
                    tower.hp = new_max
