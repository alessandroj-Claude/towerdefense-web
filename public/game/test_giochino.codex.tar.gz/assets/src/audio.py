"""AudioManager: singleton, pygame.mixer, stdlib-synthesized sounds. IS_WEB → stub."""
from __future__ import annotations
import array
import math
from typing import Optional

from src.config import IS_WEB

_SAMPLE_RATE = 22050
_CHANNELS = 2


def _make_tone_buf(freq: float, duration_ms: int, volume: float = 0.5,
                   wave: str = "sine", fade_ms: int = 50) -> array.array:
    """Generate raw PCM samples (signed 16-bit stereo). No pygame dependency."""
    n_samples = int(_SAMPLE_RATE * duration_ms / 1000)
    fade_samples = int(_SAMPLE_RATE * fade_ms / 1000)
    buf = array.array("h", [0] * (n_samples * _CHANNELS))
    for i in range(n_samples):
        t = i / _SAMPLE_RATE
        if wave == "sine":
            v = math.sin(2 * math.pi * freq * t)
        elif wave == "square":
            v = 1.0 if math.sin(2 * math.pi * freq * t) >= 0 else -1.0
        elif wave == "sawtooth":
            v = 2 * (t * freq - math.floor(t * freq + 0.5))
        else:
            v = math.sin(2 * math.pi * freq * t)
        # fade in/out
        if i < fade_samples:
            v *= i / fade_samples
        elif i > n_samples - fade_samples:
            v *= (n_samples - i) / fade_samples
        sample = int(v * volume * 32767)
        sample = max(-32767, min(32767, sample))
        buf[i * _CHANNELS] = sample
        buf[i * _CHANNELS + 1] = sample
    return buf


class AudioManager:
    _instance: Optional[AudioManager] = None

    def __init__(self):
        self._ready = False
        self._muted = False
        self._volume = 0.7
        self._sounds: dict = {}

    @classmethod
    def get(cls) -> AudioManager:
        if cls._instance is None:
            cls._instance = cls()
            cls._instance._init()
        return cls._instance

    def _init(self) -> None:
        if IS_WEB:
            return
        try:
            import pygame.mixer
            pygame.mixer.init(_SAMPLE_RATE, -16, _CHANNELS, 512)
            self._generate_sounds()
            self._ready = True
        except Exception:
            pass

    def _make_tone(self, freq: float, duration_ms: int, volume: float = 0.5,
                   wave: str = "sine", fade_ms: int = 50):
        import pygame.mixer
        buf = _make_tone_buf(freq, duration_ms, volume, wave, fade_ms)
        return pygame.mixer.Sound(buffer=buf)

    def _generate_sounds(self) -> None:
        self._sounds = {
            "tower_fire":         self._make_tone(880, 60, 0.25, "square", 10),
            "enemy_death":        self._make_tone(220, 120, 0.3, "sawtooth", 20),
            "wave_start":         self._make_tone(440, 200, 0.4, "sine", 30),
            "wave_complete":      self._make_tone(523, 300, 0.45, "sine", 40),
            "boss_arrival":       self._make_tone(110, 400, 0.5, "sawtooth", 50),
            "achievement_unlock": self._make_tone(660, 250, 0.5, "sine", 30),
            "game_over":          self._make_tone(165, 500, 0.5, "sawtooth", 60),
            "level_up":           self._make_tone(587, 350, 0.5, "sine", 40),
        }

    def play(self, name: str) -> None:
        if not self._ready or self._muted:
            return
        sound = self._sounds.get(name)
        if sound is None:
            return
        sound.set_volume(self._volume)
        sound.play()

    def set_volume(self, v: float) -> None:
        self._volume = max(0.0, min(1.0, float(v)))

    def toggle_mute(self) -> bool:
        self._muted = not self._muted
        return self._muted

    @property
    def muted(self) -> bool:
        return self._muted
