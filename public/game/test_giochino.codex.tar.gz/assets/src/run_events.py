from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, TYPE_CHECKING
import random

if TYPE_CHECKING:
    from src.game import Game


@dataclass
class RunEvent:
    id: str
    category: str  # "positive" | "risky"
    label_key: str
    desc_key: str
    apply: Callable[["Game"], None]
    duration_waves: int = 1
    terrain_filter: list[str] | None = field(default=None)


def _apply_gold_bonus(game: "Game") -> None:
    game._event_modifiers["gold_mult"] = game._event_modifiers.get("gold_mult", 1.0) * 1.5
    game._event_modifiers["gold_mult_until_wave"] = game.wave_mgr.wave_number + 1

def _apply_repair_all(game: "Game") -> None:
    for tower in game.towers:
        tower.repair(tower.max_hp * 0.5)

def _apply_free_tower(game: "Game") -> None:
    import random as _rnd
    from src.tower import BasicTower
    empty = [(c, r) for c, r in game.game_map.get_buildable_cells()
             if not any(t.col == c and t.row == r for t in game.towers)]
    if empty:
        c, r = _rnd.choice(empty)
        tower = BasicTower(col=c, row=r, tile_size=game.tile_size)
        game.towers.append(tower)

def _apply_speed_boost(game: "Game") -> None:
    game._event_modifiers["fire_rate_mult"] = game._event_modifiers.get("fire_rate_mult", 1.0) * 1.2
    game._event_modifiers["fire_rate_mult_until_wave"] = game.wave_mgr.wave_number + 3

def _apply_shield_wave(game: "Game") -> None:
    game._event_modifiers["enemy_hp_mult"] = game._event_modifiers.get("enemy_hp_mult", 1.0) * 0.75
    game._event_modifiers["enemy_hp_mult_until_wave"] = game.wave_mgr.wave_number + 1

def _apply_life_gain(game: "Game") -> None:
    game.lives = min(game.lives + 1, game.MAX_LIVES)

def _apply_cost_discount(game: "Game") -> None:
    game._event_modifiers["tower_cost_mult"] = game._event_modifiers.get("tower_cost_mult", 1.0) * 0.7
    game._event_modifiers["tower_cost_mult_until_wave"] = game.wave_mgr.wave_number + 2

def _apply_xp_boost(game: "Game") -> None:
    for tower in game.towers:
        from src.tower import xp_tier_for
        tower.xp += 5
        tower.xp_tier = xp_tier_for(tower.xp)

def _apply_double_wave(game: "Game") -> None:
    game._event_modifiers["enemy_count_mult"] = game._event_modifiers.get("enemy_count_mult", 1.0) * 2.0
    game._event_modifiers["enemy_count_mult_until_wave"] = game.wave_mgr.wave_number + 1
    game._event_modifiers["gold_mult"] = game._event_modifiers.get("gold_mult", 1.0) * 3.0
    game._event_modifiers["gold_mult_until_wave"] = game.wave_mgr.wave_number + 1

def _apply_enemy_speed_up(game: "Game") -> None:
    game._event_modifiers["enemy_speed_mult"] = game._event_modifiers.get("enemy_speed_mult", 1.0) * 1.4
    game._event_modifiers["enemy_speed_mult_until_wave"] = game.wave_mgr.wave_number + 2
    game._event_modifiers["gold_mult"] = game._event_modifiers.get("gold_mult", 1.0) * 2.0
    game._event_modifiers["gold_mult_until_wave"] = game.wave_mgr.wave_number + 2

def _apply_inferno_trial(game: "Game") -> None:
    game._event_modifiers["damage_mult"] = game._event_modifiers.get("damage_mult", 1.0) * 2.0
    game._event_modifiers["damage_mult_until_wave"] = game.wave_mgr.wave_number + 1
    game._event_modifiers["tower_cost_mult"] = game._event_modifiers.get("tower_cost_mult", 1.0) * 2.0
    game._event_modifiers["tower_cost_mult_until_wave"] = game.wave_mgr.wave_number + 1

def _apply_boss_rush(game: "Game") -> None:
    game._event_modifiers["extra_boss_next_wave"] = True
    game._event_modifiers["extra_boss_next_wave_until_wave"] = game.wave_mgr.wave_number + 1
    game._event_modifiers["boss_rush_bonus_gold"] = 50
    game._event_modifiers["boss_rush_bonus_gold_until_wave"] = game.wave_mgr.wave_number + 1

def _apply_fragile_towers(game: "Game") -> None:
    for tower in game.towers:
        tower.hp = max(1, tower.hp // 2)
    game._event_modifiers["damage_mult"] = game._event_modifiers.get("damage_mult", 1.0) * 1.5
    game._event_modifiers["damage_mult_until_wave"] = game.wave_mgr.wave_number + 1

def _apply_golden_horde(game: "Game") -> None:
    game._event_modifiers["enemy_hp_mult"] = game._event_modifiers.get("enemy_hp_mult", 1.0) * 2.0
    game._event_modifiers["enemy_hp_mult_until_wave"] = game.wave_mgr.wave_number + 1
    game._event_modifiers["gold_per_kill_bonus"] = game._event_modifiers.get("gold_per_kill_bonus", 0) + 3
    game._event_modifiers["gold_per_kill_bonus_until_wave"] = game.wave_mgr.wave_number + 1

def _apply_no_sell(game: "Game") -> None:
    game._event_modifiers["no_sell"] = True
    game._event_modifiers["no_sell_until_wave"] = game.wave_mgr.wave_number + 2
    game._event_modifiers["gold_income_mult"] = game._event_modifiers.get("gold_income_mult", 1.0) * 1.4
    game._event_modifiers["gold_income_mult_until_wave"] = game.wave_mgr.wave_number + 2

def _apply_mud_flood(game: "Game") -> None:
    game._event_modifiers["enemy_speed_mult"] = game._event_modifiers.get("enemy_speed_mult", 1.0) * 0.85
    game._event_modifiers["enemy_speed_mult_until_wave"] = game.wave_mgr.wave_number + 2
    game._event_modifiers["enemy_hp_mult"] = game._event_modifiers.get("enemy_hp_mult", 1.0) * 1.3
    game._event_modifiers["enemy_hp_mult_until_wave"] = game.wave_mgr.wave_number + 2


EVENT_POOL: list[RunEvent] = [
    RunEvent("gold_bonus", "positive", "run_event.gold_bonus_label", "run_event.gold_bonus_desc", _apply_gold_bonus),
    RunEvent("repair_all", "positive", "run_event.repair_all_label", "run_event.repair_all_desc", _apply_repair_all),
    RunEvent("free_tower", "positive", "run_event.free_tower_label", "run_event.free_tower_desc", _apply_free_tower),
    RunEvent("speed_boost", "positive", "run_event.speed_boost_label", "run_event.speed_boost_desc", _apply_speed_boost, duration_waves=3),
    RunEvent("shield_wave", "positive", "run_event.shield_wave_label", "run_event.shield_wave_desc", _apply_shield_wave),
    RunEvent("life_gain", "positive", "run_event.life_gain_label", "run_event.life_gain_desc", _apply_life_gain, duration_waves=0),
    RunEvent("cost_discount", "positive", "run_event.cost_discount_label", "run_event.cost_discount_desc", _apply_cost_discount, duration_waves=2),
    RunEvent("xp_boost", "positive", "run_event.xp_boost_label", "run_event.xp_boost_desc", _apply_xp_boost, duration_waves=0),
    RunEvent("double_wave", "risky", "run_event.double_wave_label", "run_event.double_wave_desc", _apply_double_wave),
    RunEvent("enemy_speed_up", "risky", "run_event.enemy_speed_up_label", "run_event.enemy_speed_up_desc", _apply_enemy_speed_up, duration_waves=2),
    RunEvent("inferno_trial", "risky", "run_event.inferno_trial_label", "run_event.inferno_trial_desc", _apply_inferno_trial),
    RunEvent("boss_rush", "risky", "run_event.boss_rush_label", "run_event.boss_rush_desc", _apply_boss_rush),
    RunEvent("fragile_towers", "risky", "run_event.fragile_towers_label", "run_event.fragile_towers_desc", _apply_fragile_towers),
    RunEvent("golden_horde", "risky", "run_event.golden_horde_label", "run_event.golden_horde_desc", _apply_golden_horde),
    RunEvent("no_sell", "risky", "run_event.no_sell_label", "run_event.no_sell_desc", _apply_no_sell, duration_waves=2),
    RunEvent("mud_flood", "risky", "run_event.mud_flood_label", "run_event.mud_flood_desc", _apply_mud_flood, duration_waves=2, terrain_filter=["swamp", "forest", "plains"]),
]


def _terrain_ok(e: RunEvent, terrain: str | None) -> bool:
    if terrain is None or e.terrain_filter is None:
        return True
    return terrain in e.terrain_filter


def pick_events(difficulty: str, wave: int, rng: random.Random, terrain: str | None = None) -> list[RunEvent]:
    pool_positive = [e for e in EVENT_POOL if e.category == "positive" and _terrain_ok(e, terrain)]
    pool_risky = [e for e in EVENT_POOL if e.category == "risky" and _terrain_ok(e, terrain)]

    if difficulty == "easy":
        candidates = rng.sample(pool_positive, min(3, len(pool_positive)))
    elif difficulty == "normal":
        pos = rng.sample(pool_positive, 2)
        risk = rng.sample(pool_risky, 1)
        candidates = pos + risk
        rng.shuffle(candidates)
    else:
        candidates = rng.sample(pool_risky, min(3, len(pool_risky)))

    return candidates
