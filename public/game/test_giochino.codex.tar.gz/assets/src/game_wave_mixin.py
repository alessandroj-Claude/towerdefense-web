from typing import Optional

from src.enemy import FlyingEnemy


class WaveControllerMixin:
    """Wave lifecycle, enemy terrain modifiers, synergy, and event context."""

    def _event_context(self) -> dict:
        return {
            "modifiers": self._event_modifiers,
            "economy": self.economy,
            "grant_gold": self.economy.earn,
        }

    def _update_synergy(self) -> None:
        from src.game import TERRAIN_HIGH_WIND

        self._synergy_active = False
        self._synergy_label = ""
        if not self._event_label:
            return
        terrain_values = set(self.game_map.terrain_by_cell.values()) if hasattr(self, "game_map") else set()
        acc_mod = float(self._event_modifiers.get("accuracy_mult", 1.0))
        label = self._event_label.lower()
        if "earthquake" in label and "fortified" in terrain_values:
            self._synergy_active = True
            self._synergy_label = "⚡ EQ+Fort"
        elif "anti-air" in label and TERRAIN_HIGH_WIND in terrain_values:
            self._synergy_active = True
            self._synergy_label = "⚡ AA+Wind"
        elif acc_mod < 1.0 and ("wind" in terrain_values or TERRAIN_HIGH_WIND in terrain_values):
            self._synergy_active = True
            self._synergy_label = "⚡ Acc+Wind"

    def _update_adaptive_rationale(self) -> None:
        delta = self._adaptive_last_delta
        hp = float(delta.get("hp_mult", 0.0))
        sp = float(delta.get("speed_mult", 0.0))
        dm = float(delta.get("damage_mult", 0.0))
        if hp == 0.0 and sp == 0.0 and dm == 0.0:
            self._adaptive_rationale = "Adaptive: stabile"
            return
        parts = []
        if hp > 0:
            parts.append(f"HP+{hp:.0%}")
        elif hp < 0:
            parts.append(f"HP{hp:.0%}")
        if sp > 0:
            parts.append(f"Spd+{sp:.0%}")
        elif sp < 0:
            parts.append(f"Spd{sp:.0%}")
        if dm > 0:
            parts.append(f"Dmg+{dm:.0%}")
        elif dm < 0:
            parts.append(f"Dmg{dm:.0%}")
        arrow = "▲" if (hp + sp + dm) > 0 else "▼"
        self._adaptive_rationale = f"{arrow} {', '.join(parts)}"[:40]

    def _sync_event_display(self) -> None:
        active = self.event_director.active_event
        if active is None:
            self._event_label = None
            self._event_timer = 0.0
            self._event_tint = None
            self._update_synergy()
            return
        self._event_label = active.label
        self._event_timer = self.event_director.remaining_time
        self._event_tint = active.overlay_rgba
        self._update_synergy()

    def _on_wave_started(self) -> None:
        self.terrain_evolution.apply_delta(self.terrain_evolution.get_pending_delta())
        self.terrain_evolution.mark_wave_processed(self.wave_mgr.wave_number)
        self._execute_order_queue()
        self._event_modifiers.clear()
        self.event_director.on_wave_start(self.wave_mgr.wave_number)
        ctx = self._event_context()
        triggered = self.event_director.maybe_trigger(
            self.wave_mgr.total_to_spawn,
            self.wave_mgr.total_to_spawn,
            ctx,
        )
        if triggered is not None:
            self._sync_event_display()
        self._sync_event_display()
        self._meteor_triggered = False
        self._meteor_shower = None
        self._meteor_display_timer = 0.0
        self._current_wave_max_progress = 0.0
        self._wave_lives_lost = False

    def _start_wave(self) -> None:
        was_active = self.wave_mgr.active
        previous_wave = self.wave_mgr.wave_number
        self.wave_mgr.start_wave()
        if not was_active and self.wave_mgr.active and self.wave_mgr.wave_number != previous_wave:
            self._on_wave_started()

    def _clamp(self, value: float, low: float, high: float) -> float:
        return max(low, min(high, value))

    def _enemy_current_path_cell(self, enemy) -> Optional[tuple[int, int]]:
        path = getattr(enemy, "path", None)
        if not path:
            return None
        if len(path) == 1:
            return path[0]
        progress = float(getattr(enemy, "progress", 0.0))
        idx = int(max(0.0, min(progress, len(path) - 1)))
        return path[idx]

    def _enemy_terrain(self, enemy) -> str:
        cell = self._enemy_current_path_cell(enemy)
        if cell is None:
            return "road"
        return getattr(self.game_map, "terrain_by_cell", {}).get(cell, "road")

    def _enemy_speed_multiplier(self, enemy) -> float:
        from src.game import TERRAIN_FLYING_SPEED_MULT, TERRAIN_SPEED_MULT

        terrain = self._enemy_terrain(enemy)
        base = TERRAIN_SPEED_MULT.get(terrain, 1.0)
        if isinstance(enemy, FlyingEnemy):
            return base * TERRAIN_FLYING_SPEED_MULT.get(terrain, 1.0)
        return base

    def _enemy_damage_taken_multiplier(self, enemy) -> float:
        from src.game import TERRAIN_GROUND_DAMAGE_MULT

        terrain = self._enemy_terrain(enemy)
        if isinstance(enemy, FlyingEnemy):
            return 1.0
        return TERRAIN_GROUND_DAMAGE_MULT.get(terrain, 1.0)

    def _target_accuracy_multiplier(self, enemy, tower=None) -> float:
        from src.game import TERRAIN_ACCURACY_MULT, TERRAIN_HIGH_WIND

        terrain = self._enemy_terrain(enemy)
        if terrain == TERRAIN_HIGH_WIND and getattr(type(tower), "__name__", "") == "AntiAirTower":
            return 1.0
        return TERRAIN_ACCURACY_MULT.get(terrain, 1.0)

    def _finalize_wave_report(self) -> None:
        """Create final wave report with aggregated metrics and reset accumulators."""
        wave_num = self.wave_mgr.wave_number
        self._wave_report = {
            "wave": wave_num,
            "damage_by_type": dict(self._wave_report_dmg),
            "flying_kills": self._wave_report_flying_kills,
            "lives_lost": self._wave_report_lives_lost,
            "gold_earned": self._wave_report_gold_earned,
        }
        try:
            self.analytics_manager.track_event("wave_complete", {"wave_num": wave_num})
        except Exception:
            pass
        self._wave_report_dmg = {}
        self._wave_report_flying_kills = 0
        self._wave_report_lives_lost = 0
        self._wave_report_gold_earned = 0

    def _award_enemy_reward(self, reward: int) -> None:
        powerup_reward_pct = float(self._powerup_modifiers.get("reward_mult_pct", 0.0))
        perk_reward_pct = float(self._perk_modifiers.get("reward_mult_pct", 0.0))
        reward_mult = max(0.0, 1.0 + powerup_reward_pct + perk_reward_pct)
        adjusted_reward = int(round(float(reward) * reward_mult * self._score_multiplier()))
        self._wave_report_gold_earned += adjusted_reward
        self.economy.earn(adjusted_reward)
